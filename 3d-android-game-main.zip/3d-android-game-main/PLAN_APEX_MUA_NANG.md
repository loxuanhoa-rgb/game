# Plan v3 — APEX: Mùa Nắng, kịch bản chạy bằng Claude Code

File này là **kịch bản chạy đợt APEX bằng Claude Code** (phiên chính "Astra" + subagent). Nó không chứa quy tắc repo và không chứa hợp đồng kỹ thuật:

- Quy tắc chung cho mọi agent (git, `.meta`, bàn giao, không push/tag, trailer commit, lệnh Unity): [AGENTS.md](AGENTS.md) — Claude Code nạp qua `CLAUDE.md`.
- Hợp đồng kỹ thuật và **bảng sở hữu file**: [DECISIONS_APEX_MUA_NANG.md](DECISIONS_APEX_MUA_NANG.md).
- Hiện trạng và diff chưa commit: đầu [HANDOFF.md](HANDOFF.md).

Bản này thay Plan v2 (viết cho Codex). Mục tiêu, hành vi cần đạt và cổng nghiệm thu giữ nguyên; tổ chức nhóm và cơ chế phản biện viết lại theo cách Claude Code thực sự vận hành.

## 0. Khác gì so với v2

| v2 (Codex) | v3 (Claude Code) | Lý do |
|---|---|---|
| Subagent nhắn trực tiếp cho nhau | Mọi trao đổi đi qua Astra bằng `SendMessage`; đề xuất/phản biện viết ra file để chuyển tiếp nguyên văn | Subagent của Claude Code không có kênh nhắn cho nhau; tự nhiên giới hạn được số vòng tranh luận |
| Vai trò A/B/C cố định, "đổi vai" bằng lời | Mỗi đợt chọn **loại agent**: khảo sát/review dùng agent chỉ đọc, triển khai dùng agent được ghi | Agent chỉ đọc không thể vô tình sửa file ngoài phạm vi |
| Subagent giữ ngữ cảnh xuyên đợt | Mỗi lần gọi `Agent` là **khởi động lạnh**; nối tiếp bằng `SendMessage` cho agent cũ | Brief phải tự đủ; tránh tốn công đọc lại repo |
| Bắt đầu từ cây sạch | Bắt đầu từ diff Đợt 2 chưa commit, mô tả ở đầu `HANDOFF.md` | Không làm lại việc đã làm, cũng không mặc định nó đúng |
| Quy tắc repo nằm trong plan | Quy tắc ở `AGENTS.md` §0; plan chỉ ghi phần riêng của việc điều phối subagent | Sửa quy tắc ở một chỗ, không để lệch giữa hai file |

## 1. Mục tiêu sản phẩm

Hoàn thiện demo đua xe tại **Đồi Mây**, thị trấn cao nguyên Việt Nam hư cấu: nắng chiều, garage địa phương, lễ hội nhỏ và cảm giác chinh phục kỷ lục cá nhân.

Giữ các quyết định đã chốt:

- Một xe, một đường đua, hai vòng; offline.
- UI tiếng Việt có dấu, thương hiệu **APEX — Mùa Nắng**.
- Câu chuyện nhẹ qua lời nhắn của thợ máy **An** và cảnh vật.
- Luồng: **Thiệp lễ hội → Đua → Kết quả → Đua lại / Về lễ hội**.
- Bốn khu vực: **Sân hội, Garage Mây, Đồi Thông, Quán Dốc Nắng**.
- Giữ tuning xe, vùng chạm, collider đường, luật đua và dữ liệu kỷ lục hiện có.
- Nâng UI, cảnh, âm thanh; kiểm chức năng trên Pixel 9 và nghiệm thu cuối trên Xiaomi 14.

## 2. Tổ chức nhóm trên Claude Code

**Astra là phiên Claude Code chính (phiên này).** Astra chịu trách nhiệm kiến trúc, phân công, giải quyết bất đồng, tích hợp, chạy Unity/emulator/thiết bị và kết luận nghiệm thu. Chỉ Astra nói chuyện với người dùng.

Subagent được tạo bằng tool `Agent`, chạy nền, tối đa **ba subagent đồng thời** (Astra + 3). Cả nhóm là **một phiên** theo nghĩa của `AGENTS.md` §0 ("một agent một lúc"): chỉ Astra chạy Unity/adb/git, mỗi file một chủ, nên không vi phạm quy tắc đó. Không mở phiên Claude hay Codex thứ hai trên repo trong lúc nhóm chạy.

| Vai trò | Loại agent theo đợt | Được làm | Không được làm |
|---|---|---|---|
| **Astra — trưởng nhóm** | phiên chính | Đọc/sửa mọi file; Unity CLI, generator, build, adb, emulator; commit mốc (trailer Claude theo `AGENTS.md` §0); cập nhật tài liệu điều phối | Push, tag khi chưa được yêu cầu |
| **A — trải nghiệm và UI** | Đợt 0/3: `Explore` hoặc `feature-dev:code-reviewer` (chỉ đọc) · Đợt 1: `Plan` · Đợt 2: `general-purpose` | Luồng màn hình, phân cấp thông tin, typography, bố cục, phản hồi cảm ứng; sửa file trong phạm vi sở hữu | Chạy Unity/adb/emulator/build; git đổi trạng thái; viết `.meta` tay; sửa file ngoài phạm vi |
| **B — thế giới và hình ảnh** | như A | Lore, cảnh vật, nhận diện địa phương, màu, ánh sáng, ngân sách hình ảnh | như A |
| **C — hệ thống và kiểm chứng** | như A | Vòng đời, input, persistence, audio, rủi ro kỹ thuật; test cho phần được giao; phản biện độc lập | như A |

Ràng buộc của Claude Code mà mọi brief phải tính đến:

- **Khởi động lạnh:** subagent không thấy cuộc trò chuyện này. `AGENTS.md` được nạp tự động qua `CLAUDE.md`; mọi thứ khác (file được sửa, hợp đồng, tiêu chí, dạng báo cáo) phải nằm trong brief.
- **Nối tiếp bằng `SendMessage`:** phản biện vòng 2, sửa theo review, hỏi lại — gửi cho agent cũ để giữ ngữ cảnh; chỉ tạo agent mới khi đổi đợt hoặc đổi vai.
- **Báo cáo chỉ về Astra:** người dùng không thấy báo cáo subagent. Astra tóm tắt lại kèm đường dẫn bằng chứng.
- **Subagent có Bash:** lệnh cấm Unity/adb/git phải ghi rõ trong brief, không mặc định agent tự biết.
- **File mới không có `.meta`** cho đến khi Astra chạy Unity (`AGENTS.md` §0). Subagent tạo file mới thì ghi vào mục "Cần Astra" của báo cáo.
- **Test cần `Runtime`/`Editor` đặt ở `Tests.TrackEditMode`**, không phải `Tests.EditMode` (`AGENTS.md` §3).
- **`isolation: "worktree"`** chỉ dùng cho thử nghiệm phân biệt hai phương án (mục 3); không dùng cho triển khai chính vì worktree không có `Library` và Astra phải tự gộp diff về.

### Mẫu brief giao task (bắt buộc đủ 8 mục)

```
Vai trò: <A/B/C> — <tên đợt>
Mục tiêu: <một câu, đo được>
Đọc trước: đầu HANDOFF.md → PROGRESS.md (chỉ bảng tổng quan + mục cuối) → DECISIONS_APEX_MUA_NANG.md (mục ...) → <file liên quan>
File được sửa: <danh sách tuyệt đối; mọi file khác là chỉ đọc>
Hợp đồng phải giữ: <API, rect điều khiển, TrackId, records.json, tuning...>
Tiêu chí đạt: <liệt kê, kiểm được>
Cấm: chạy Unity.exe/adb/emulator/build; git commit/checkout/stash/reset; viết .meta hoặc YAML scene/prefab bằng tay; mở rộng phạm vi
Báo cáo về Astra theo mẫu:
  1. Đã sửa: file:dòng + tóm tắt
  2. Chưa làm / bỏ qua: lý do
  3. Giả định đã dùng
  4. Cần Astra: file mới cần .meta; lệnh cần chạy (generate/validate/EditMode/PlayMode/build); file ngoài phạm vi cần sửa
  5. Rủi ro và điểm cần phản biện
```

Người phản biện của mỗi task lấy theo bảng sở hữu trong `DECISIONS_APEX_MUA_NANG.md`.

## 3. Cơ chế thảo luận và phản biện

### Một task đi qua sáu bước

1. **Khảo sát:** đọc code, tài liệu và bằng chứng hiện tại; phân biệt rõ dữ kiện với giả định.
2. **Đề xuất:** người phụ trách viết phương án, lý do, chi phí, rủi ro vào `Artifacts/apex-mua-nang/de-xuat-<vai>-<chủ đề>.md`.
3. **Phản biện độc lập:** Astra `SendMessage` đường dẫn đề xuất cho agent phản biện; agent trả lời theo mẫu bên dưới vào `phan-bien-<vai>-<chủ đề>.md`.
4. **Đối chiếu:** dùng code, ảnh, test hoặc thử nghiệm nhỏ để giải quyết bất đồng. Chỉ Astra chạy được Unity nên bước đo do Astra làm; subagent phân tích log/XML/ảnh/`scene-stats.txt` do Astra đưa.
5. **Astra chốt:** ghi vào `DECISIONS_APEX_MUA_NANG.md` quyết định, lý do, phương án bị loại và điều kiện xem lại.
6. **Triển khai → review → kiểm chứng:** người phản biện kiểm lại kết quả thực tế (đọc diff, đọc XML) trước khi Astra đóng task.

### Tranh luận đi qua Astra

Subagent không nhắn được cho nhau, nên Astra là bộ định tuyến. Điều này không làm giảm tính độc lập: agent phản biện nhận nguyên văn đề xuất, không nhận ý kiến của Astra. Astra chuyển tiếp khi:

- Một agent chất vấn giả định hoặc phát hiện phụ thuộc bị bỏ sót.
- Cần so sánh hai cách triển khai bằng tiêu chí cụ thể.
- Có xung đột giữa thiết kế đẹp, dễ dùng và hiệu năng.
- Một kết luận chưa có bằng chứng.

Mẫu phản biện:

> **Điểm bất đồng → bằng chứng (file:dòng, ảnh, số đo) → tác động → phương án thay thế → cách kiểm tra.**

Không bắt buộc phản đối khi phương án đã tốt; trả lời "không có bất đồng, đã kiểm X/Y" cũng là kết quả hợp lệ. Không dùng đồng thuận số đông thay cho kết quả kiểm chứng.

### Giới hạn để tránh tranh luận kéo dài

- Tối đa **hai vòng** cho một quyết định (đề xuất → phản biện → phản hồi → phản biện lần cuối).
- Còn bất đồng thì Astra chọn một thử nghiệm phân biệt được hai phương án. Nếu thử nghiệm cần sửa code theo hai hướng, dùng `Agent` với `isolation: "worktree"` cho mỗi hướng, Astra đo trên cây chính từng bản.
- Chưa đo được thì chọn phương án ít rủi ro, dễ đảo ngược và ghi rõ giả định.
- Chỉ mở lại quyết định khi có bằng chứng mới hoặc thay đổi yêu cầu.
- Thẩm mỹ nhỏ do Astra quyết. Hỏi người dùng (qua `AskUserQuestion`) chỉ khi đổi hướng sáng tạo hoặc mở rộng phạm vi đáng kể.

**Thứ tự ưu tiên:** đúng chức năng → dễ điều khiển/đọc → bản sắc thống nhất → hiệu năng đạt yêu cầu → công sức bảo trì.

## 4. Các đợt công việc

Hiện trạng lúc chuyển sang Claude (17/09/2026) mô tả ở đầu `HANDOFF.md`: diff Đợt 2 chưa commit, **mới viết code, chưa có bằng chứng compile/test**, ba nhóm file chưa có `.meta`. Diff này là đầu vào cần kiểm, không phải baseline đã đạt.

### Đợt 0 — Đối chiếu hiện trạng (agent chỉ đọc, chạy song song)

- **Astra:** `git status/diff`; đọc đầu `HANDOFF.md`, `DECISIONS`, mục cuối `PROGRESS.md`. Chạy theo thứ tự `AGENTS.md` §6: **generate** (sinh `.meta`, `-nographics`) → **validate** → **SceneStats** → **EditMode** → **PlayMode**; XML và `scene-stats.txt` lưu vào `Artifacts/apex-mua-nang/`. Đây là bằng chứng đầu tiên của diff; chưa có nó thì chưa sửa tiếp.
- **A (`Explore`):** đối chiếu diff `UiBuilder`, presenter, `RaceHudFormatter`, `ApexFontAssets` với hợp đồng UI/font trong `DECISIONS`; liệt kê đã có / còn thiếu / sai hợp đồng.
- **B (`Explore`):** đối chiếu diff `FestivalVisuals`, `VenueDetails` với ngân sách cảnh trong `DECISIONS` (≤12 renderer mới, không collider/light mới) bằng `scene-stats.txt` Astra vừa sinh; kiểm kê asset tái dùng được cho bốn khu vực.
- **C (`Explore`):** đối chiếu diff `RaceDirector`, `FestivalPresenter`, `FestivalAudio`, `AudioPreferences`, `RaceLoopSceneTests`, `FestivalAudioTests`, `AudioPreferencesTests` với luồng trạng thái và API audio đã chốt; tìm listener/pause/focus chưa xử lý; kiểm test có nằm đúng asmdef.

**Đầu ra:** bảng ba cột *đã có trong diff / còn thiếu / sai hợp đồng* cho từng vai; kết quả test thật của diff; bảng sở hữu file cập nhật trong `DECISIONS`; Astra ghi tóm tắt vào `PROGRESS.md` và cập nhật đầu `HANDOFF.md` (cây vẫn bẩn, đã compile/test tới đâu).

### Đợt 1 — Chốt phần thiết kế còn hở (agent `Plan`, chỉ với khoảng trống Đợt 0 chỉ ra)

Phần lớn thiết kế đã nằm trong `DECISIONS` 17/09. Chỉ mở đề xuất mới cho mục còn thiếu hoặc bị Đợt 0 chứng minh sai:

- **A:** màn hình chưa có mockup/nội dung; giữ Be Vietnam Pro, xanh mực–kem–cam đất, hitbox điều khiển.
- **B:** khu vực chưa có mô tả, biểu tượng mặt trời sau đồi, lời nhắn của An chưa viết.
- **C:** chuyển trạng thái chưa có test, cách xử lý audio khi mất focus/pause chưa rõ.
- **Astra:** chốt API còn hở giữa director, presenter và audio; cập nhật tiêu chí nghiệm thu.

**Phản biện chéo** (qua Astra, tối đa hai vòng): A kiểm cảnh có che HUD/đường; B kiểm UI và lời nhắn có hợp thế giới; C kiểm khả thi, input, pause, chi phí render; Astra đối chiếu với gameplay hiện tại.

**Cổng hoàn tất:** `DECISIONS` không còn mục "chưa chốt" nào chặn triển khai. Nếu phạm vi đổi so với yêu cầu người dùng, Astra dùng `EnterPlanMode` trình bày trước khi làm.

### Đợt 2 — Hoàn tất triển khai (agent `general-purpose`, mỗi agent một tập file)

| Người phụ trách | Phần được triển khai |
|---|---|
| **A** | Presenter, font, cấu hình giao diện, `UiBuilder`, `RaceHudFormatterTests` |
| **B** | `FestivalVisuals`, `VenueDetails`, biển hiệu, màu sắc, trang trí bốn khu vực |
| **C** | `EngineAudio`, `FestivalAudio`, `AudioPreferences`, `FestivalAudioBuilder`, `FestivalAudioTests`, `AudioPreferencesTests` |
| **Astra** | `RaceDirector`, `DemoProjectGenerator`, `SceneValidator`, `RaceLoopSceneTests`, nối các thành phần, bảo toàn input và luật đua |

**Hành vi cần đạt**

- Màn lễ hội khóa xe, không tick lượt đua; bấm **Vào đua** mới bắt đầu countdown.
- **Đua lại** đi thẳng vào countdown; **Về lễ hội** kết thúc lượt đang dở, không Submit bản ghi dở.
- HUD gọn hơn, không có lời kể lúc lái; kết quả ưu tiên thời gian, huy chương, kỷ lục và lời nhắn.
- Trang trí qua Editor API, ngoài mặt đường, không collider; tận dụng asset hiện có.
- Nhạc và ambience không lấn động cơ; pause/mất focus xử lý âm thanh đúng.
- Không đổi schema `records.json`, track ID hoặc tuning.

**Nhịp làm việc:** subagent báo cáo → Astra đọc diff, đối chiếu hợp đồng, chạy generate (nếu có file mới) + EditMode/PlayMode (tuần tự, một tiến trình Unity) → gửi nhận xét hoặc lỗi compile/test ngược lại bằng `SendMessage` → lặp. Không chờ cả ba xong mới kiểm. Subagent cần sửa file ngoài phạm vi thì ghi vào mục "Cần Astra", không tự sửa. Cuối đợt: commit mốc nếu xanh, hoặc cập nhật đầu `HANDOFF.md` nếu còn bẩn.

### Đợt 3 — Review độc lập và tích hợp (agent `feature-dev:code-reviewer`, đổi vai)

Người viết không tự duyệt cuối. Reviewer nhận diff tích hợp và bằng chứng test do Astra đưa:

- **A** kiểm trải nghiệm toàn luồng và khả năng đọc cảnh (đọc `UiBuilder`, presenter, ảnh Astra chụp từ emulator).
- **B** kiểm bản sắc, nội dung, font và độ nhất quán hình ảnh; đối chiếu `scene-stats.txt` với ngân sách.
- **C** kiểm trạng thái, input, lưu dữ liệu, listener, tình huống lỗi trong `RaceDirector` và audio.
- **Astra** tích hợp, xử lý bất đồng, chạy trọn chuỗi `AGENTS.md` §6: generate → validate → SceneStats → rebuild ×2 (`Task3Verification`) → EditMode → PlayMode → build Development.

Mỗi phát hiện ghi: mức độ (chặn / nên sửa / thẩm mỹ), cách tái hiện, người sửa. Lỗi chặn phải sửa và kiểm lại; nhận xét thẩm mỹ không tự biến thành mở rộng phạm vi. Sửa theo review gửi về agent triển khai cũ bằng `SendMessage` nếu còn ngữ cảnh, tạo agent mới nếu không.

### Đợt 4 — Nghiệm thu và bàn giao (chỉ Astra thao tác; subagent phân tích bằng chứng)

- Unity tests và validator đạt; đọc XML, không chấp nhận lượt chạy 0 test.
- Rebuild hai lần giữ tuning và object ngoài vùng generator.
- Pixel 9 (`Pixel_9_root`, 6144 MB, hai ngón qua `Tools/mtinject/README.md`): toàn bộ luồng, hai ngón, mất focus, restart, về lễ hội, lưu lỗi.
- UI ở 16:9 và Pixel 9 có safe area; đủ dấu tiếng Việt, không tràn/chồng nút.
- Xiaomi 14: nghiệm thu cuối và đo 15 phút mỗi bản Development/Release bằng `Tools/perf/frametime-sample.ps1`; C phân tích `tiles.csv`/`summary.txt`.
- Mục tiêu 60 FPS; sàn P95 ≤ 33,33 ms và không có cửa sổ 5 giây dưới 30 FPS.
- Bàn giao: APK (byte + SHA256), ảnh trước/sau, nguồn asset, số test — tóm tắt vào `PROGRESS.md` vì `Artifacts/` bị gitignore; cập nhật `HANDOFF.md`, `README.md`, các giới hạn còn lại.

## 5. Điều phối subagent trong repo

Quy tắc chung (cây bẩn, `.meta`, bàn giao, push/tag, trailer, "không đánh dấu xong khi chưa chạy thật") ở `AGENTS.md` §0 — không lặp lại. Dưới đây chỉ là phần riêng của việc chạy nhóm subagent:

- **Sở hữu file** theo bảng trong `DECISIONS`; brief liệt kê file được sửa, mọi file khác là chỉ đọc. Cần sửa ngoài phạm vi → ghi vào báo cáo để Astra chuyển quyền hoặc tự sửa, không tự làm.
- **Chỉ Astra** chạy Unity CLI/generator/build/adb/emulator/`mtinject`/thiết bị và mọi lệnh git đổi trạng thái. Subagent đọc code, phân tích log/XML/ảnh trong `Artifacts/`, viết phần được giao, review song song; test Core nhanh bằng .NET SDK (`AGENTS.md` §8) được phép trong thư mục scratch.
- **Diff hiện có** trong working tree là của người dùng cho đến khi Astra kiểm xong; subagent không hoàn tác hay format lại phần không thuộc task.
- **Tài liệu Astra duy trì:** `PLAN` (file này — đợt, phụ thuộc, người phụ trách), `DECISIONS` (quyết định, phương án so sánh, bằng chứng, bảng sở hữu), `PROGRESS.md` (chỉ ghi khi đã kiểm chứng, phân biệt năm mức theo `AGENTS.md` §0), đầu `HANDOFF.md` (mỗi khi kết thúc đợt mà cây còn bẩn), `Artifacts/apex-mua-nang/` (đề xuất, phản biện, XML, log, ảnh — gitignored).

**Nguyên tắc kết thúc:** Astra chịu trách nhiệm về sản phẩm tích hợp và là người duy nhất báo cáo với người dùng. Báo cáo "xong" của subagent là đầu vào để kiểm tra, chưa phải bằng chứng toàn bộ game đã đạt.
