@AGENTS.md

<!-- Quy tắc dùng chung nằm ở AGENTS.md (Codex đọc trực tiếp, Claude Code đọc qua import trên).
     Chỉ thêm vào dưới đây những gì riêng cho Claude Code. -->

## Claude Code

- Kịch bản nhóm agent (phiên chính "Astra" + subagent, brief 8 mục, phản biện qua file) nằm ở PLAN_APEX_MUA_NANG.md mục 2–3 và 5. Subagent không chạy Unity/adb/emulator, không dùng git để đổi trạng thái.
- Không mở phiên Claude Code thứ hai trên repo này trong lúc một phiên (hoặc Codex) đang làm.
