# PROGRESS.md

Cập nhật: **18/09/2026** — ba việc kỹ thuật đã hoàn tất: Development, lỗi lưu emulator và checkout sạch. Chỉ đánh dấu ✅ khi đã chạy/kiểm chứng thật.

## Trạng thái tổng quan

| Task | Trạng thái |
|---|---|
| Task 1 — Thiết lập dự án và APK đầu tiên | ✅ đạt trên emulator **và đã chạy trên Xiaomi 14** (13/09) |
| Task 2 — Xe, camera, điều khiển | ✅ chạy đúng trên emulator và Xiaomi 14; đã tune theo người chơi thật: ma sát rào 0,2, FOV theo tốc độ, **thanh lái analog thay hai nút** — người chơi xác nhận độ nhạy ổn, bám tay, không kẹt lái |
| Task 3 — Đường đua + công cụ dựng | ✅ đạt chức năng trên Pixel 9: trọn vòng qua nút màn hình bằng **cả một điểm chạm lẫn hai ngón thật**; test/build/rebuild đạt. Phiên sau đã chạy lại độc lập toàn bộ chuỗi |
| Task 4 — Vòng chơi, pause, reset, kết quả | ✅ đạt chức năng trên Pixel 9: chạy trọn lượt 2 vòng bằng hai ngón, kết quả + huy chương + kỷ lục hiện đúng, pause/reset/restart khớp mục 4. 83/83 EditMode + 23/23 PlayMode |
| Task 5 — Kỷ lục | ✅ JSON đã lưu lần đầu/cập nhật trên IL2CPP Pixel 9, sống qua force-kill; 96 EditMode + 25 PlayMode đạt |
| Task 6 — Hình ảnh, âm thanh | ✅ APEX / Mùa Nắng, UI tiếng Việt, nhạc và tiếng động cơ; người chơi Xiaomi xác nhận hết rè, tiếng ga và cảm giác lái ổn. Giữ tuning đã chấp nhận; ngưỡng huy chương lấy từ 12 lượt lái tự động, chưa hiệu chỉnh bằng người chơi |
| Task 7 — Nghiệm thu, bàn giao | 🟡 Ba việc kỹ thuật đạt: Development chạy hai vòng/lưu/đọc lại, lỗi lưu và vòng đời trên Pixel 9; checkout sạch đạt rebuild 3/3, 151/151 EditMode + 36/36 PlayMode và Release riêng. Chất lượng âm nghe trực tiếp Development chưa đánh giá. Checklist máy thật chưa đủ; hiệu năng 15 phút ×2 và độ trễ chạm định lượng chưa kiểm chứng, không đo lại theo phạm vi hiện tại; tag/release chỉ khi được yêu cầu |

## Môi trường đã xác minh

| Thành phần | Giá trị |
|---|---|
| Unity | `6000.6.0f1` tại `D:\UnityHub\6000.6.0f1` (kế hoạch ghi 6000.3.11f1 — xem sai lệch #5) |
| Module | Android Build Support (+OpenJDK, SDK & NDK), Windows Build Support (Mono), WebGL |
| Package | Input System 1.20.0, uGUI 2.6.0 (kèm TMP), Test Framework 1.8.0, URP 17.6.0 |
| Git | 2.47.1 + LFS 3.6.0 |
| .NET SDK | 8.0.424 tại `C:\Users\VuIT\.dotnet` (chỉ để chạy nhanh test Core) |
| adb | `C:\Users\VuIT\AppData\Local\Android\Sdk\platform-tools\adb.exe` (Android Studio) |
| Emulator (môi trường chạy chính) | AVD `Pixel_9` (ảnh playstore) cho chạy thử thường; AVD `Pixel_9_root` (ảnh `google_apis`, userdebug) khi cần bơm hai ngón. Cả hai x86_64 API 37, chạy APK ARM64 qua dịch mã. **Phải chạy với `-memory 6144`** |
| NDK (chỉ để build công cụ test) | 27.2.12479018 kèm module Android của Unity. Binary cho ảnh `ps16k` phải link `-Wl,-z,max-page-size=16384` |

## Đã kiểm chứng ✅

### Bằng CLI — mốc Task 1/2 ngày 08/09 (Task 3 ở phần riêng bên dưới)
- `RacingDemo.Core` (C# thuần, `noEngineReferences: true`) — luật đua, huy chương, kỷ lục.
- **40/40 test EditMode pass trong Unity Test Runner** (`Artifacts/editmode-results.xml`, `total="40" passed="40" failed="0"`).
- `RebuildDemo` chạy 2 lần liên tiếp: vẫn đúng 1 Camera / 1 AudioListener / 1 Light; `CarConfig` đã tune không bị ghi đè.
- `SceneValidator` kiểm số lượng component **và** mọi reference bắt buộc — exit 0.
- Build APK Development: `Builds/Android/racing-demo-development.apk`, **60,2 MB**, 258 giây.

### Bằng chơi thử Task 1/2 trên emulator Pixel 9 ngày 08/09 (ảnh trong `Artifacts/`)
- App khởi động, **không exception nào** (chỉ còn `AssetPackManager` ClassNotFoundException — Unity dò Play Asset Delivery không dùng tới, vô hại).
- Xe đứng vững trên nền, không xuyên nền.
- Giữ **GA** → xe chạy tới. Bẻ **`>`** → xe rẽ (chạy đủ xa để văng khỏi nền 200×200 rồi rơi — đúng dự kiến vì chưa có rào Task 3 và chưa có luật tự reset Task 4).
- Bấm **RESET** khi xe đang rơi → xe về đúng điểm xuất phát, **camera snap đúng ngay**, không bị kéo lê từ vị trí cũ. Khung hình trùng khít trạng thái ban đầu.
- Bấm **Pause** → panel "TAM DUNG" mở ngay lần đầu, cảnh mờ đi. Bấm **CHOI TIEP** → chơi tiếp bình thường.
- **Ra Home rồi quay lại → game tự pause và KHÔNG tự resume** (đúng yêu cầu mục 4 của kế hoạch).
- Layout landscape: nhãn nằm trong nút, các nút không chồng lấn nhau.

## Chưa xong

- ✅ Task 3 đã nghiệm thu chức năng trên emulator. Cảm giác lái và hiệu năng phần cứng thật để cuối dự án.

- 🟡 **Xiaomi 14 đã chạy (13/09)** — app mở, chơi được, log sạch. Còn chưa làm: checklist 9 mục, đo 15 phút, độ trễ chạm. Xem mục "Lượt Xiaomi 14 — phiên 1".
- 🟡 **Tune theo người chơi thật đã làm một phần**: ga/lái/độ bám cua người chơi thấy ổn nên `CarConfig` **giữ nguyên**; sửa ở chỗ khác — ma sát rào, FOV, thanh lái analog (xem sai lệch #32–#35).
- ✅ **Kỷ lục đã lưu JSON xuống đĩa** từ Task 5; đã kiểm ghi lần đầu/cập nhật và mở lại sau force-kill trên Pixel 9.
- ✅ **Ngưỡng huy chương đã chốt** — tính ở Task 6 rồi tính lại ở Task 7 sau khi sửa bước vật lý: gold 115,618 s / silver 117,758 s / bronze 134,750 s. Số liệu là của **lái tự động**, chưa phải của người chơi.
- ⏳ Validator chưa kiểm tra rect các nút cảm ứng có chồng lấn không.
- ⏳ Chưa xoá project tạm `D:\Android\unity_temp\RacingDemo`, và `Artifacts/Task3Clean` (838 MB, có cả `Library`) vẫn nằm trong repo.
- ⏳ Trong ba điểm phát hiện khi kiểm chứng lại, **đã sửa hai**: tên mesh giờ luôn trùng tên file (hết cảnh báo `Main Object Name ... does not match filename`), và `SceneValidator.ValidateBuildScenes` in một dòng khi CLI chạy đạt. **Còn lại**: `Race.unity` vẫn đổi fileID sau mỗi lần rebuild vì `ResetGeneratedRoot` dựng lại cả cây — nội dung không đổi, chỉ số hiệu object đổi.
- ⏳ **Bằng chứng lái thử không nằm trong repo.** `.gitignore` bỏ qua `/Artifacts/`, nên mọi log, ảnh và file XML mà `PROGRESS.md` viện dẫn chỉ có trên máy này. Nếu cần nộp bài thì phải chép riêng.

## Sai lệch so với kế hoạch

1. Thêm `Core/Racing/RaceTimeFormatter.cs` — mục 3 không liệt kê nhưng mục 4 yêu cầu "format thời gian là hàm thuần" trong Core.
2. Thêm `Core/Guard.cs` (`internal`) để kiểm tra tham số dùng chung — Core không được dùng `Mathf`.
3. Thêm `Core/Racing/CheckpointPassResult.cs` để `CheckpointTracker` phân biệt Accepted / LapCompleted / RaceCompleted.
4. Viết Core (Task 4/5) **trước** Task 1 vì Core là C# thuần, không bị chặn bởi việc cài Editor.
5. **Unity `6000.6.0f1` thay cho `6000.3.11f1`** — Hub đã cài sẵn bản này; tải lại ~15 GB không đáng. Không đổi Editor nữa từ đây.
6. Thêm `Editor/FieldBinder.cs`, `Editor/CarBuilder.cs`, `Editor/UiBuilder.cs`, `Editor/DemoEditorPaths.cs`, `Editor/ProjectSetup.cs` — tách generator cho dễ đọc; kế hoạch chỉ liệt kê 3 file Editor.
7. Sửa `ApiCompatibilityLevel.NET_Standard_2_1` → `NET_Standard` (tên trong Unity 6).
8. **Không tự viết `SafeArea`** — Unity 6 (uGUI 2.6) đã có `UnityEngine.UI.SafeArea` tốt hơn. Dùng bản của Unity.
9. Project URP không có sẵn font TMP nên phải import TMP Essential Resources (`Assets/TextMesh Pro`, 3,9 MB).
10. **Gỡ 7 package template không dùng**: `ai.assistant`, `ai.inference`, `ai.navigation`, `collab-proxy`, `pipeline`, `timeline`, `visualscripting`. Lý do ở mục "Bài học" #4. APK giảm **86,3 → 60,2 MB**.
11. Chơi thử trên emulator Pixel 9 thay vì máy thật ở giai đoạn này (theo yêu cầu của người dùng). Kế hoạch chỉ nói tới Xiaomi 14.
12. Task 3 tách thêm `StadiumGeometry` (Runtime, không đưa kiểu Unity vào Core), `TrackBuilder`, `TrackSceneValidation` và `Task3Verification`; test hình học/Editor ở assembly riêng, giữ nguyên test Core thuần.
13. Nối Core vào `PrototypeDirector` sớm để kiểm checkpoint/reset trên đường thật: countdown, 2 vòng, reset 1,5 giây, pause và nút chơi lại; nhãn vòng/checkpoint/tốc độ tối thiểu. Task 4 vẫn phải thay bằng `RaceDirector`/presenter và kết quả đầy đủ. Log pose mỗi giây chỉ có trong Editor/Development để lưu bằng chứng lái thử.
14. Bỏ cách generator xóa root ngoài vùng quản lý theo tên mặc định; object người dùng được giữ lại, thành phần dư do validator báo. Không thay tuning `CarConfig`, phiên bản Unity hay package.
15. Bài lái Task 3 dùng API `sendTouch` chính thức của emulator qua localhost để bấm lần lượt GA/lái trái/phải, và adb tap cho pause/reset. Script chỉ đọc log pose để chọn nút, không sửa pose/vận tốc/input trong game. Thử đa điểm gRPC trên emulator 36.5.11/API 37 gây `Unhandled pen event action: 5/6` và trạng thái ga không đáng tin; lưu riêng `Artifacts/task3-multitouch-unsupported.log`, không dùng lượt đó nghiệm thu. Lượt một điểm chạy từ đầu không có lỗi này. Đây không phải kiểm hai ngón thật.
16. Script gRPC `Artifacts/task3-*-drive.ps1` **cần PowerShell 7**; trên Windows PowerShell 5.1 nó chết ngay ở `[System.Net.Http.HttpClient]` (5.1 không nạp sẵn assembly đó và cũng không nói HTTP/2). Phiên sau lái lại bằng `Artifacts/verify/drive-adb.ps1` — cùng thuật toán bám tim đường, nhưng bấm nút bằng `adb shell input swipe X Y X Y <ms>` đúng như AGENTS.md mục 7 mô tả, nên chạy được trên PowerShell 5.1 và không cần API điều khiển của emulator. Vẫn là một điểm chạm một lúc.
17. Thêm AVD **`Pixel_9_root`** dựng bằng tay từ ảnh `google_apis_ps16k` (userdebug) đã có sẵn trong SDK, để `adb root` được. `Pixel_8`/`Pixel_9` giữ nguyên không đụng tới.
18. **Đổi môi trường chạy chính sang emulator Pixel 9** (quyết định của người dùng ngày 09/09/2026). Kế hoạch gốc bắt điều kiện đạt của Task 1/2 — và mọi mốc chơi thử — phải lấy từ Xiaomi 14; từ đây **Xiaomi 14 chỉ dùng một lần ở cuối** để nghiệm thu thực tế khi dự án hoàn thành. Emulator gánh toàn bộ việc kiểm chức năng, kể cả **ga + lái hai ngón** (làm được nhờ sai lệch #19). Ba thứ emulator vẫn không thay thế được và vẫn chờ máy thật: độ trễ chạm, FPS/frame time, cảm giác lái.
19. Thêm `Tools/mtinject/mtinject.c` — một binary native nhỏ tạo màn hình cảm ứng ảo qua `/dev/uinput` để bơm multi-touch. Kế hoạch không nhắc tới; đây là công cụ kiểm thử, **không nằm trong sản phẩm** và không có gì trong `Assets/` phụ thuộc vào nó.
20. Task 4 tách presenter thành **ba lớp** (`HudPresenter`, `PausePresenter`, `ResultsPresenter`) cộng `RaceHudFormatter` thuần thay vì một lớp UI gộp; kế hoạch chỉ nói "presenter". Lý do: quy tắc "presenter trên object luôn active, panel là object con" cần mỗi panel một chủ, và tách hàm sinh chuỗi ra mới test được ở EditMode.
21. Task 4 thêm `Runtime/Persistence/SessionRecordRepository.cs` — kho kỷ lục **tạm trong bộ nhớ**, để màn kết quả có đủ dòng kỷ lục trước khi Task 5 làm JSON. Kế hoạch đặt toàn bộ phần kỷ lục ở Task 5; đây chỉ là chỗ cắm tạm, đổi một dòng ở `RaceDirector.CreateRecordRepository()` là sang JSON.
22. Giữ lại log `[TrackDrive] Pose` (một dòng mỗi giây) và thêm `[RaceLoop]` cho các mốc chuyển trạng thái, **chỉ có trong Editor/Development**; `[RaceLoop]` dùng `[Conditional]` nên bản Release không gọi tới. Kế hoạch không nhắc; đây là điều kiện để script lái tự động nghiệm thu được vòng chơi mà không cần người ngồi bấm.
23. Đã sửa hai trong ba điểm tồn của Task 3 khi làm Task 4: `EnsureMesh` đặt tên mesh trùng tên file, và `ValidateBuildScenes` in một dòng khi CLI đạt.
24. Task 5 thêm `IJsonFileStore` làm điểm thay thế IO trong test và log `[Records]` lúc startup chỉ trong Editor/Development để đối chiếu reload sau force-kill. Test scene gắn kho trong bộ nhớ qua `sceneLoaded` trước `Start`; không đọc/ghi dữ liệu kỷ lục thật của Editor.
25. **Task 6 chỉ chép 11 model Kenney thực dùng** vào `Assets/ThirdParty/KenneyRacingKit` thay vì cả gói 110 model (kèm bản DAE/GLTF/OBJ/STL). Giấy phép gốc, URL tải, SHA256 của zip và danh sách file ghi trong `README.md` cạnh asset.
26. **Tiếng động cơ do dự án tự sinh** (`EngineClipBuilder` → `Assets/Generated/Audio/EngineLoop.wav`) thay vì tải clip về. Kenney không có gói tiếng động cơ; tự sinh cho nguồn gốc và giấy phép rõ ràng tuyệt đối, và file chỉ 43 KB. Vòng lặp liền mạch nhờ tần số cơ bản 50 Hz khớp 22050 mẫu/giây; nhiễu dùng PRNG hạt giống cố định nên sinh lại ra đúng từng byte.
27. **Thêm hai thiết lập URP kế hoạch không nhắc tới**: `m_MainLightShadowmapResolution` 1024 → 2048 và `m_ShadowNormalBias` 1 → 2. Với một cascade phủ 40 m, shadow map 1024 cho texel ~8 cm và thân xe tự đổ bóng lên chính nó thành vệt răng cưa — thấy rõ trên ảnh chụp máy. Các giá trị kế hoạch chốt (HDR off, MSAA 2x, soft shadow off, 40 m, 1 cascade, additional light off, render scale 1.0) giữ nguyên.
28. **Ngưỡng huy chương lấy từ 12 lượt LÁI TỰ ĐỘNG trên emulator**, không phải từ người chơi. Kế hoạch chỉ nói "≥10 lượt hoàn chỉnh" mà không nói ai lái; người dùng chọn cách này để khỏi phải ngồi chơi 12 lượt. Hệ quả: ngưỡng phản ánh cách lái của script (giữ ga theo ngưỡng tốc độ, nhấp lái theo độ lệch), nên phải xem lại khi có số liệu người chơi thật.
29. Task 6 tách `MedalThresholdCalibrator` (Core, hàm thuần có test) khỏi `MedalCalibration` (Editor, đọc file + ghi asset), và thêm `Tools/mtinject/medal-calibration.ps1` gọi `race-autopilot.ps1` nhiều lượt. Kế hoạch không mô tả cách thu số liệu.
30. **Bước vật lý đã chạy sai suốt Task 1–6 và chỉ được sửa ở Task 7.** Kế hoạch mục 2 chốt 1/60 giây nhưng project vẫn để mặc định của Unity là 0,02 giây (50 Hz), trong khi `AppBootstrap` đặt `targetFrameRate = 60`. Thêm `FixedTimestepSetup` (đặt lại mỗi lần rebuild) + kiểm trong `SceneValidator` + 4 test. Hệ quả: **ngưỡng huy chương của Task 6 phải hiệu chỉnh lại** vì thời gian lượt đua thay đổi theo bước vật lý.
31. Task 7 thêm `README.md` ở gốc repo làm tài liệu bàn giao (cách cài, cách mở/build lại, giấy phép asset, giới hạn còn biết). Kế hoạch chỉ nói "bàn giao source Git, APK và hướng dẫn PowerShell" mà không nói để ở đâu.
32. **Rào và thân xe mang `PhysicsMaterial` ma sát 0,2 / `frictionCombine = Minimum`** (`Assets/Generated/Materials/DemoSlide.asset`, generator tạo và đặt lại mỗi lần rebuild, giữ GUID). Kế hoạch không nói gì về vật liệu vật lý; trên Xiaomi 14 với vật liệu mặc định (0,6) xe đâm rào góc ~15° bị khựng lại, phải lùi mới đi tiếp; thử 0 thì xe cọ rào không mất tốc nên dễ văng — người chơi chọn 0,2. `SceneValidator` từ chối scene nếu rào/thân xe không đúng giá trị này.
33. **Nhãn nút RESET đổi thành "UNSTUCK"** theo yêu cầu người chơi (không hiểu RESET làm gì). Chức năng không đổi: về checkpoint gần nhất đã qua theo mục 4 của kế hoạch. Tên object `ResetButton`, hàm `RequestReset`, log `[RaceLoop] Dat lai xe` giữ nguyên.
34. **Góc nhìn camera nới theo tốc độ** (`ChaseCamera`: 62° đứng yên → 72° ở `MaxSpeedKph`, bám 4/s, snap về đúng góc khi reset). Kế hoạch chốt camera bám cố định; người chơi yêu cầu để tăng cảm giác tốc độ. Hàm thuần `EvaluateFieldOfView` có 7 test.
35. **Lái bằng thanh analog (`SteerSlider`) thay cho hai nút `<` `>`**, theo yêu cầu người chơi muốn chỉnh được độ gắt khi rẽ. Thanh 430×200 tại (315; 190) bao trọn chỗ hai nút cũ; tâm = 0, vùng chết ±10, hết lái ở ±115 — **đúng tâm hai nút cũ**, nên script `race-autopilot.ps1` (bấm tâm nút cũ) vẫn cho steer ±1 mà không cần sửa. `TouchControlPad` chỉ còn `_steerSlider`/`_throttleButton`/`_brakeButton`. Ngưỡng huy chương (lấy bằng lái nút) **càng cần đo lại** với người chơi thật.
36. **Nhãn bake từ TMP trong `VenueDetails` phải tạo `MeshFilter` mới, và validator kiểm cả "renderer có mesh thật, không cờ DontSave"** (14/09, đợt VenueDetails). Kế hoạch chỉ yêu cầu trang trí không collider/không lấn đường; thực tế 15 nhãn bị mất im lặng khi lưu scene vì giữ lại `MeshFilter` `HideAndDontSave` của TMP — mọi bộ kiểm cũ đều xanh. Từ giờ `ValidateDecor` bắt hai điều kiện đó, có test cố tình làm hỏng, và `SceneStats` đếm "renderer không mesh". Chi tiết ở mục "Đợt VenueDetails".

## Task 3 — kết quả kiểm chứng ngày 09/09/2026

- Đã sinh sân vận động 80 m / R30 m / rộng 12 m, chu vi tim khoảng 348,496 m; 350 phân đoạn tối đa 1 m, mesh mặt đường 700 đỉnh, dùng chung đỉnh tại mối khép vòng. Hai rào kín rộng 0,4 m, cao 1,2 m; ba MeshCollider tĩnh liên tục.
- `TrackDefinition` tạo khi thiếu; 4 checkpoint cách nhau khoảng 87,124 m, index 3 là đích. Trigger 12 × 4 × 4 m. Start trước đích 8 m, respawn sau mỗi cổng 8 m, cao 0,64 m theo bán kính bánh và hành trình giảm xóc hiện tại.
- Unity EditMode **75/75 pass**: 40 Core, 14 hình học/dữ liệu/respawn, 21 validator. Đã đọc `Artifacts/task3-editmode-results.xml`.
- Unity PlayMode **10/10 pass**: xe nhiều collider, đúng/sai Rigidbody, đi tới/đi ngược/ngang, 120 km/h, spawn chồng trigger, teleport và khóa kinematic. Đã đọc `Artifacts/task3-playmode-results.xml`. Lượt đầu 4 ca đi tới thất bại; sửa việc mất trạng thái tiếp cận khi collider vừa chạm mép trước `OnTriggerEnter`, rồi chạy lại đạt.
- `Task3Verification.RunRebuildChecks` đạt: hai rebuild liên tiếp giữ nguyên JSON, byte file và GUID của hai config đã tune thử; root ngoài cây có tên `Main Camera`, child, pose và ID đã lưu đều giữ nguyên. Cấu hình thử đã được khôi phục. Kết quả: **1 Camera / 1 Light / 1 AudioListener / 1 EventSystem / 12 Collider / 4 CheckpointVolume**. Log/report: `Artifacts/task3-rebuild-checks.log`, `Artifacts/task3-rebuild-verification.txt`.
- Bản source/package độc lập ở `Artifacts/Task3Clean`, ban đầu không có `Assets/Generated`, `Race.unity` hoặc `Library`, dựng đủ demo bằng **một lệnh RebuildDemo**, exit 0; validator chạy trong generator đạt. Log: `Artifacts/task3-clean-generate.log`.
- Build Development ARM64 thành công và đã cài emulator: `Builds/Android/racing-demo-development.apk`, **63.104.448 byte**. Log: `Artifacts/task3-build-development.log`. SHA256: `4ED897B4EFA6919B523AEE6038F47F7A70B022F74B72F89B5E4270938658C0C0`.
- **Lái trọn một vòng trên Pixel 9, RAM 6144 MB:** bấm GA/lái qua UI, mong muốn qua đủ bốn cổng và mối nối → thực tế nhận **0 → 1 → 2 → 3**, chuyển **lap=2, next=0**, không reset trong vòng, không rơi/xuyên mặt đường. Log thiết bị ghi CP0 lúc 17:31:25, CP1 17:32:04, CP2 17:32:47, CP3 17:33:30 ngày 09/09. 170 mẫu pose ở độ cao 0,46–0,64 m; chỉ là bằng chứng bổ sung cho lượt chạy, không phải đo frame time. Ảnh: `Artifacts/task3-start.png`, `task3-corner.png`, `task3-lap.png`; trace thao tác: `task3-singlepoint-drive-actions.txt`; log: `task3-device.log`.
- Pause sau vòng đầu mở panel đúng; Resume rồi nhấn RESET hai lần liên tiếp → chỉ một respawn tại checkpoint 3: **(30; 0,64; 8)**, camera snap, HUD vẫn **VONG 2/2, CP 0**, có khóa reset rồi xe đứng lại trên đường. Ảnh `Artifacts/task3-lap-paused.png`, `task3-reset-lap2.png`; log `task3-device-final.log`. Không có exception gameplay mới trong lượt nghiệm thu; còn dòng dò `AssetPackManager` đã biết từ Task 2.
- Các lượt thử trước có đâm rào; rào chặn được xe. Chưa đánh giá lái nhanh, cảm giác ga/phanh hay tuning từ cách bấm ngắt quãng này.
- Validator cuối đã compile/chạy đạt sau khi siết đúng một Light (`Artifacts/task3-final-validate.log`, exit 0). Không đổi Runtime/APK sau lượt lái nghiệm thu.

## Task 3 — chạy kiểm chứng lại độc lập ngày 09/09/2026 (phiên sau)

Toàn bộ chuỗi dưới đây do phiên sau **tự chạy lại từ đầu**, không dùng lại kết quả phiên trước. Log/ảnh nằm trong `Artifacts/verify/`.

| Bước | Kết quả |
|---|---|
| `RebuildDemo` lần 1 | exit 0 — `verify/rebuild-1.log` |
| `RebuildDemo` lần 2 | exit 0 — `verify/rebuild-2.log` |
| `Task3Verification.RunRebuildChecks` | exit 0, ba dòng PASS, semantic SHA256 `5E6B2E92…` **trùng phiên trước** |
| `SceneValidator.ValidateBuildScenes` | exit 0, không exception |
| EditMode | **75/75 pass** (40 Core + 35 Track) — đã đọc `verify/editmode-results.xml` |
| PlayMode | **10/10 pass** — đã đọc `verify/playmode-results.xml` |
| Build APK Development | exit 0, 63.104.448 byte, 38 giây (incremental) |
| Lái trọn vòng trên Pixel 9 (`-memory 6144`) | **đạt** — chi tiết bên dưới |
| Một lệnh dựng từ checkout sạch | **đạt** — chi tiết bên dưới |

**Không ghi đè asset đã tune.** `CarConfig.asset`, `TrackDefinition.asset` và cả hai `.meta` **giống hệt từng byte** trước rebuild và sau cả hai lần rebuild (SHA256: `verify/before-rebuild-hashes.txt` vs `verify/after-rebuild2-hashes.txt`). Ba mesh `Road`/`InnerBarrier`/`OuterBarrier` cũng byte-identical giữa hai lần rebuild.

**Không nhân đôi gì.** Đếm trực tiếp trong `Race.unity` sau rebuild: 1 Camera, 1 Light, 1 AudioListener, 3 MeshCollider, 5 BoxCollider, 4 WheelCollider (tổng 12 collider), 4 CheckpointVolume, 115 GameObject — không đổi qua các lần chạy.

### Lượt lái trọn vòng của phiên này (17:57–17:59 ngày 09/09, APK vừa build lại và cài đè)

| Cổng | Thời điểm | Vị trí xe khi nhận | Độ dài dọc tim đường | Thiết kế | Lệch |
|---|---|---|---|---|---|
| CP0 | 17:58:00 | (−0,03; 0,46; 70,09) | 87,154 m | 87,124 m | 0,030 m |
| CP1 | 17:58:35 | (−30,11; 0,46; −0,01) | 174,258 m | 174,248 m | 0,010 m |
| CP2 | 17:59:10 | (0,02; 0,46; −70,16) | 261,392 m | 261,372 m | 0,020 m |
| CP3 | 17:59:45 | (29,99; 0,46; 0,02) | 0,020 m | 0,000 m | 0,020 m |

Bốn cổng cách nhau đúng một phần tư chiều dài, sai số ≤ 3 cm — **đo từ vị trí thật lúc chạy**, không đọc lại config. Sau CP3 chuyển **lap=2, next=0**. Trong cả vòng: **không có respawn nào** (dòng `Respawn` duy nhất là lần spawn lúc khởi động, `checkpoint=start`), không exception gameplay, độ cao xe giữ trong **0,46–0,64 m** suốt 241 mẫu pose — không lọt nền, không bị hất lên tại mối nối. Ảnh `verify/start.png` (`VONG 1/2 | CP 0`) và `verify/drive-lap.png` (`VONG 2/2 | CP 0`); trace `verify/drive-actions.txt`; log `verify/drive-device.log`.

**Vẫn là một điểm chạm một lúc, không phải hai ngón.** Script đọc log pose rồi bấm GA *hoặc* bấm lái, luân phiên — thấy rõ trong log: tốc độ nhảy 0 ↔ 18 km/h mỗi giây. Đây **chưa phải** bài kiểm ga + lái đồng thời.

### Dựng từ checkout sạch bằng một lệnh

Chép `Assets` (bỏ `Assets/Generated`), `Packages`, `ProjectSettings` sang thư mục scratch, **không có** `Library` và **không có** `Race.unity`. Một lệnh `RebuildDemo` → exit 0, sinh đủ `Generated/Config`, `Generated/Materials`, `Generated/Meshes` và `Race.unity`, với đúng cùng số lượng component (1 Camera / 1 Light / 1 AudioListener / 3 MeshCollider / 5 BoxCollider / 4 WheelCollider / 115 GameObject). Log: `verify/clean-generate.log`.

So sánh sản phẩm của checkout sạch với project chính:

- `CarConfig.asset`: **byte-identical** → xác nhận `CarConfig` trong repo **chưa hề được tune**, vẫn đúng giá trị generator sinh ra.
- `TrackDefinition.asset`: chỉ khác ở chỗ serialize `x: -0` so với `x: 0` trong ba `EulerAngles` — **giá trị số như nhau**.
- Ba mesh: dữ liệu đỉnh **byte-identical**, chỉ khác `m_Name`.

### Ba điểm phát hiện thêm khi kiểm chứng (chưa sửa)

1. **Mesh đổi tên tùy đường tạo.** Tạo mới thì asset mang tên theo file (`Road`), còn cập nhật asset đã có thì giữ tên cũ (`StadiumRoad`). Vì vậy mỗi lần rebuild trên project chính, Unity in cảnh báo `Main Object Name 'StadiumRoad' does not match filename 'Road'` (log clean **không** có dòng này). Vô hại về chức năng — reference đi theo GUID + fileID, validator kiểm hình học — nhưng làm sản phẩm của checkout sạch khác byte với project đã có. Sửa gọn: đặt `mesh.name` trùng tên file trong `TrackBuilder`.
2. **`Race.unity` đổi byte sau mỗi lần rebuild** dù nội dung không đổi: `ResetGeneratedRoot` xoá rồi dựng lại cả cây `__GeneratedScene`, nên Unity cấp fileID mới. Diff giữa hai lần rebuild **toàn bộ** là dòng `--- !u!N &N` / `fileID:` / `m_GameObject` / `m_Father` — không có object nào thêm hay mất. Hệ quả: `Race.unity` luôn hiện "modified" trong git sau mỗi rebuild.
3. **`SceneValidator.ValidateBuildScenes` không in gì khi đạt.** Dòng `Debug.Log("[RacingDemo] Scene build hop le.")` chỉ nằm trong bản menu `ValidateBuildScenesMenu`; chạy CLI thì bằng chứng "đã chạy" chỉ còn exit code và dòng `Loaded scene 'Assets/Scenes/Race.unity'` trong log. Đúng kiểu bẫy mà repo này vẫn cảnh báo ("exit 0 với 0 test là thất bại") — nên thêm một dòng log ở nhánh CLI.

## Thử hai ngón thật bằng `sendevent` — ngày 09/09/2026

> ⚠️ **Kết luận của mục này đã bị vượt qua.** Xem mục "Hai ngón qua thiết bị `uinput`" ngay bên dưới: dựng một màn hình cảm ứng ảo không có bit stylus thì hai ngón chạy đúng và **game xử lý tốt**. Giữ lại mục này vì phần chẩn đoán vẫn đúng và giải thích được lỗi `Unhandled pen event`.

**Kết luận ngắn:** bơm được hai ngón thật ở tầng kernel và **Android nhận đúng hai con trỏ**, nhưng **Unity từ chối con trỏ thứ hai** khi bơm qua thiết bị cảm ứng sẵn có của emulator. Nguyên nhân nằm ở thiết bị ảo đó, không phải ở code game.

### Đường đi để `sendevent` chạy được

- Trên `Pixel_9` (ảnh `google_apis_playstore`, `ro.build.type=user`): `adb root` bị từ chối, `/dev/input/event*` là `crw-rw---- root:input` — `shell` có group `1004(input)` nhưng **SELinux Enforcing chặn ghi**. Cờ `-selinux permissive` của emulator **bị bỏ qua lặng lẽ** (không có `androidboot.selinux` trong `/proc/cmdline`).
- Console emulator (`adb emu event send`) trả `OK` nhưng **không có sự kiện nào tới `/dev/input`** — đường này vô dụng cho cảm ứng.
- Cách đi được: SDK đã cài sẵn ảnh **`android-37.0/google_apis_ps16k`** (userdebug). Tạo AVD mới **`Pixel_9_root`** bằng tay (chỉ `.ini` + `config.ini`, cùng màn hình 1080×2424), không đụng `Pixel_8`/`Pixel_9`. Trên đó `adb root` + `setenforce 0` → `sendevent` ghi được.

### Thiết bị cảm ứng của emulator

`virtio_input_multi_touch_1` = `/dev/input/event2`, MT protocol B, toạ độ **chuẩn hoá 0–32767** (không phải pixel). Emulator tạo sẵn 11 thiết bị `virtio_input_multi_touch_1..11`.

Điểm quan trọng: thiết bị này **không khai báo `BTN_TOUCH`**. Phần `KEY` chỉ có `BTN_TOOL_RUBBER` và `BTN_STYLUS`. Tín hiệu chạm là `ABS_MT_TRACKING_ID` (≥0 xuống, −1 nhấc) kèm **`ABS_MT_PRESSURE`** — thiếu `ABS_MT_PRESSURE` thì tap không ăn. Ngoài ra input core **bỏ mọi giá trị ABS không đổi**, nên tap lặp lại đúng một toạ độ sẽ không sinh sự kiện X/Y (mất thời gian vì chỗ này).

### Kết quả

| Bài | Kết quả |
|---|---|
| Một ngón giữ GA (5–6 giây) | **Đạt.** Tốc độ lên đều 0 → 16,6 → 38,9 → 61,5 → 82,4 → 95 km/h. Giữ nút liên tục thật, hơn hẳn kiểu `adb input swipe` nhấp nhả |
| Hai ngón, **cùng** `event2`, hai slot | Ngón 2 vào → xe bẻ 54° nhưng tốc độ tụt 48,7 → −0,1 km/h và **không hồi lại** kể cả sau khi nhả ngón 2 |
| Hai ngón, **khác** thiết bị (`event2` + `event3`) | Ga chạy tiếp (50,6 → 70,8 → 91,5 km/h) nhưng **lái không có tác dụng gì**: yaw = 0, x = 30,00 suốt |
| Lớp phủ `pointer_location` của Android | **`P: 2 / 2`** — hệ thống thấy đúng hai con trỏ, hai dấu cộng nằm trên nút `<` và GA |
| Development Console của Unity | **`Unhandled pen event action: 5`** và **`: 6`** |

**Tương quan 1:1 đã đo:** giữ một ngón 3 giây → **0 lỗi**; thêm ngón thứ hai → đúng **2 lỗi**, một `action: 5` (`ACTION_POINTER_DOWN`) lúc ngón 2 chạm và một `action: 6` (`ACTION_POINTER_UP`) lúc nhấc.

### Nguyên nhân

Thiết bị cảm ứng ảo khai báo `BTN_STYLUS` + `BTN_TOOL_RUBBER` ở tầng kernel, nên `InputReader` gắn thêm nguồn `STYLUS`: `dumpsys input` ghi `Sources: KEYBOARD | TOUCHSCREEN | STYLUS`. Unity đẩy sự kiện có nguồn stylus vào nhánh bút cảm ứng, nhánh này **không xử lý `ACTION_POINTER_DOWN`/`UP`** nên bỏ luôn cả hai con trỏ. File IDC đã ghi đúng `touch.deviceType = touchScreen`; mấy bit stylus do kernel khai, không sửa được từ userspace.

Đây **đúng gốc rễ của lỗi phiên trước gặp qua API gRPC** (sai lệch #15: `Unhandled pen event action: 5/6`). Hai hướng khác nhau, cùng một nguyên nhân — không phải do cách gọi API sai.

Script: `Artifacts/verify/mt-sendevent.ps1` (helper), `mt-two-finger.ps1` (hai ngón cùng thiết bị), `mt-two-device.ps1` (hai thiết bị, có pha đối chứng). Ảnh: `pointer-2finger.png` (`P: 2/2` + lỗi pen), `mt-two-finger.png`. Log: `mt-two-finger.log`, `mt-two-device.log`.

## Hai ngón qua thiết bị `uinput` — ngày 09/09/2026

**Kết luận: game xử lý đúng hai ngón. Ga + lái đồng thời chạy tốt, và đã lái trọn một vòng bằng hai ngón.**

### Cách làm

`Tools/mtinject/mtinject.c` (189 dòng C) tạo một màn hình cảm ứng ảo qua `/dev/uinput`, khai **chỉ** `BTN_TOUCH` + `INPUT_PROP_DIRECT` + các trục MT protocol B, **không** `BTN_STYLUS`/`BTN_TOOL_RUBBER`. Android xếp nó là `Sources: TOUCHSCREEN` thuần (thiết bị cũ: `KEYBOARD | TOUCHSCREEN | STYLUS`). Nhận lệnh theo dòng qua FIFO `/data/local/tmp/mtpipe`, nên điều khiển được từ nhiều lệnh `adb` rời nhau. Cách build/chạy nằm ở `AGENTS.md` mục 7.

**Bẫy mất nhiều thời gian nhất:** ảnh `ps16k` dùng **trang 16 KB**. Binary NDK căn 4 KB (mặc định) **segfault ngay khi nạp, không in gì cả** — kể cả `hello world`. Phải link với `-Wl,-z,max-page-size=16384`.

### Ba phép đo

| Phép thử | Kết quả |
|---|---|
| Lỗi `Unhandled pen event` | **0** qua thiết bị uinput (thiết bị cũ: 2 lỗi cho mỗi lần thêm ngón) |
| Ngón 2 chạm **vùng trống** trong khi giữ GA | Tốc độ **vẫn lên đều** 22,8 → 45,3 → 67,0 → 87,7 km/h — ngón thứ hai không hề ngắt nút đang giữ |
| Giữ GA liên tục + **nhấp lái** trái/phải 6 nhịp bằng ngón 2 | Tốc độ **6,3 → 26,1 → 45,8 → 59,5 km/h** trong khi yaw dao động 341,7° ↔ 5,2° — hai đầu vào cùng tác dụng |

### Lái trọn vòng bằng hai ngón

Ngón 0 giữ GA liên tục (chỉ nhả khi vượt ngưỡng tốc độ), ngón 1 nhấp nút lái theo độ lệch — hai ngón cùng trên màn hình. Script: `Artifacts/verify/mt-lap.ps1`.

- Nhận đủ cổng **0 → 1 → 2 → 3**, chuyển `lap=2`, **không respawn nào** trong vòng (dòng `Respawn` duy nhất là lúc khởi động).
- **0 lỗi** `Unhandled pen event` trong cả lượt.
- **25/56 mẫu vừa giữ GA vừa đang bấm nút lái** — bằng chứng trực tiếp hai ngón cùng lúc trong lúc đua.
- Tốc độ đỉnh **49,6 km/h**, HUD lúc kết thúc `VONG 2/2 | CP 0 | 57 KM/H`.
- **Thời gian: CP0 19:07:24 → CP3 19:08:03 = 39 giây.** Lượt một điểm chạm sáng cùng ngày mất **105 giây** cho cùng quãng đó — nhanh hơn **2,7 lần**, vì không phải nhả ga mỗi lần bẻ lái.

Ảnh `verify/two-finger-lap.png`; trace `verify/lap-actions.txt`; log `verify/two-finger-lap.log`.

### Đính chính

Ở lần chạy `sendevent` trước tôi đọc dữ liệu là "ngón thứ hai ngắt ga". **Sai.** Mọi lượt thử đó đều giữ *hết* lái ở tốc độ cao; game chỉ có lái kiểu nút nên xe cắt ngang mặt đường và **ghim vào rào trong trong đúng một giây** (tính lại: xe ở x=26,11 với yaw −54° thì góc trước chạm x≈23,98, đúng vị trí rào ở x=24). Mất tốc là do va chạm, không phải do mất đầu vào. Muốn lái được thì phải **nhấp** lái như người thật.

### Còn lại gì

- Độ trễ chạm thật, FPS/frame time phần cứng thật và cảm giác lái — vẫn để dành cho lượt nghiệm thu Xiaomi 14 ở cuối dự án.
- AVD `Pixel_9_root` giữ lại để dùng tiếp; xoá được bằng cách bỏ `~/.android/avd/Pixel_9_root.ini` và thư mục `Pixel_9_root.avd`.

## Task 4 — vòng chơi, pause, reset và kết quả — ngày 09/09/2026

`PrototypeDirector` đã bị **xóa**. `RaceDirector` là nơi duy nhất nối Core với xe, camera, checkpoint, `timeScale`, respawn và UI.

### Đã thêm

| File | Vai trò |
|---|---|
| `Runtime/Race/RaceDirector.cs` | điều phối toàn bộ vòng chơi; sở hữu `timeScale` và việc khóa input |
| `Runtime/Race/HudPresenter.cs` | thời gian, vòng, checkpoint kế tiếp, tốc độ, dòng countdown/khóa reset |
| `Runtime/Race/PausePresenter.cs` | panel `TAM DUNG` |
| `Runtime/Race/ResultsPresenter.cs` | panel `KET QUA` + `RaceResultView` |
| `Runtime/Race/RaceHudFormatter.cs` | hàm thuần sinh chuỗi hiển thị |
| `Runtime/Persistence/SessionRecordRepository.cs` | kho kỷ lục **tạm trong bộ nhớ**, Task 5 thay bằng JSON |
| `Tools/mtinject/race-autopilot.ps1` | lái trọn lượt đua bằng hai ngón để nghiệm thu |

`UiBuilder` dựng thêm HUD, menu tạm dừng và màn kết quả; `DemoProjectGenerator` nối cả ba nút menu bằng `UnityEventTools`; `SceneValidator` kiểm phần vòng chơi.

### Bằng CLI

- **83/83 test EditMode pass** (`Artifacts/task4-editmode-results.xml`, `total="83" passed="83" failed="0"`) — 75 cũ + 8 test mới cho `RaceHudFormatter`.
- **19/19 test PlayMode pass** (`Artifacts/task4-playmode-results.xml`) — 10 test `CheckpointVolume` cũ + **9 test tích hợp mới `RaceLoopSceneTests` nạp thẳng `Race.unity`**: trạng thái đầu, countdown mở khóa xe, pause dừng đồng hồ/mở menu/khóa input, mất focus không tự resume, reset bị từ chối khi countdown và khóa 1,5 giây khi Running, restart từ pause, một lần bấm pause vẫn ra một lần pause sau nhiều lần restart, về đích mở màn kết quả ngoài bước vật lý, restart từ màn kết quả.
- `RebuildDemo` chạy 2 lần: **512 object cả hai lần**, đúng 1 Camera / 1 AudioListener / 1 Light / 1 RaceDirector / 1 mỗi presenter / 4 CheckpointVolume.
- `Task3Verification.RunRebuildChecks` vẫn PASS cả ba mục (rebuild giống nhau, tuning không bị ghi đè, object ngoài cây được giữ).
- `SceneValidator.ValidateBuildScenes` exit 0 **và in dòng xác nhận**.
- Build APK Development: 60,2 MB, 81 giây.

### Bằng chơi thử trên emulator Pixel 9 (ảnh trong `Artifacts/verify/task4-*.png`)

Chuỗi đã chạy liền một mạch trên APK vừa cài:

| Bước | Kết quả |
|---|---|
| Khởi động | `[RaceLoop] Bat dau luot moi \| phase=Countdown t=00:00.000`; HUD hiện `VONG 1/2`, `CP 1/4`, đồng hồ, `0 KM/H` |
| Bấm Pause | menu `TAM DUNG` mở **ngay lần đầu**, đồng hồ đứng tại 00:40.880 |
| Bấm `CHOI TIEP` | về Running, đúng mốc thời gian cũ 00:40.880 |
| Bấm `RESET` | banner `DAT LAI XE 0.9`, xe về vạch xuất phát, **đồng hồ vẫn chạy** (00:41.800 → 00:42.380) |
| Bấm `CHOI LAI` trong menu | đồng hồ về 00:00.000, countdown mới |
| Lái trọn **2 vòng bằng hai ngón** | 8 cổng đúng thứ tự: `1-0 1-1 1-2 1-3 2-0 2-1 2-2 2-3` |
| Về đích | `Ve dich: huy chuong=Bronze nhanh hon ky luc=True da luu=True`, màn `KET QUA` hiện `01:46.020` / `HUY CHUONG DONG` / `KY LUC: 01:46.020` / `KY LUC MOI DA LUU` |
| Bấm `CHOI LAI` trên màn kết quả | màn kết quả đóng, xe về vạch xuất phát, `VONG 1/2`, `CP 1/4`, countdown `3` |
| Bấm `RESET` **đầu vòng 2** (lượt riêng) | `Dat lai xe ve cong 3`; pose sau reset `x=30,00 z=+8,00` (điểm hồi của cổng 3), **không** phải start pose `z=−8,00`; giữ `lap=2 next=0` |

**Bỏ qua checkpoint thì không tính** — bằng chứng trực tiếp từ chính lượt này: start pose nằm 8 m **trước** vạch đích, nên xe cắt qua cổng 3 ngay giây đầu (mẫu `s=342,6` → `s=2,4` trong `Artifacts/verify/task4-race-actions.txt`), nhưng cổng đầu tiên được công nhận trong log là **cổng 0** ở giây 14,84, không phải cổng 3.

Không có exception nào trong `Artifacts/verify/task4-race.log` ngoài `AssetPackManager ClassNotFoundException` đã biết là vô hại.

### Chưa kiểm chứng ở mốc này

- Kỷ lục **không** sống qua lần mở app sau — đúng như thiết kế tạm của Task 4 (`SessionRecordRepository`), sẽ kiểm ở Task 5.
- Cảm giác lái, độ trễ chạm và FPS: vẫn để dành cho lượt nghiệm thu Xiaomi 14 cuối dự án.

## Bài học đã gặp (ghi lại để không lặp)

1. **Import package trong batch mode**: `AssetDatabase.ImportPackage` là bất đồng bộ và kéo theo domain reload. Không được chờ bằng `EditorApplication.update` — delegate bị huỷ đăng ký nên cả vòng chờ lẫn timeout đều chết, Unity batch treo vĩnh viễn (đã treo 13 phút). Cách đúng: import ở một phiên Unity, xác nhận ở phiên sau.
2. **`OpenScene`/`NewScene` gọi `Resources.UnloadUnusedAssets`**: asset vừa load mà chưa ai tham chiếu sẽ bị unload thành "fake null". Đọc field C# thuần vẫn ra giá trị (nên **không** có exception nào), nhưng gán vào `SerializedProperty` thì ghi `fileID: 0`. **Luôn load asset SAU khi mở scene.** Ba material thoát nạn chỉ vì `EditorUtility.SetDirty` giữ chúng lại.
3. `FieldBinder` giờ đọc lại mọi reference sau khi Apply và ném lỗi nếu lệch — lỗi #2 đã im lặng cho tới khi có bước kiểm chứng này.
4. **Package thừa của template có thể phá runtime**: `com.unity.dt.app-ui` (đi kèm `com.unity.ai.inference`) gọi `EnhancedTouchSupport.Enable()` trong bản build, làm `InputSystem.onDeviceChange` ném `ArgumentException: 'InputUpdateType.None' is not a valid update mask` **liên tục** ngay khi Android báo có touchscreen. Gỡ package là hết. Bài học: template tạo project không phải danh sách package tối thiểu.
5. **AVD mặc định 2 GB RAM là không đủ** cho game Unity — Android giết app giữa lúc load mà không để lại lỗi Unity nào (chỉ thấy `lowmemorykiller` trong logcat hệ thống). Chạy emulator với `-memory 6144`.

## Bàn giao

[HANDOFF.md](HANDOFF.md) — điểm bắt đầu cho agent tiếp theo: trạng thái sau Task 4, ràng buộc bắt buộc và bảy cái bẫy đã gặp.

## Việc tiếp theo

1. **Task 5 và Task 6 đã đạt.** Bằng chứng ở hai mục cuối tài liệu này. Giữ nguyên JSON/version của kỷ lục, ngưỡng huy chương đã chốt và tuning asset khi làm Task 7.
2. **Task 7 — nghiệm thu và bàn giao.** Chạy bộ kiểm tra mục 8 của kế hoạch, build Release APK, dựng lại từ checkout sạch, cập nhật tài liệu, tạo tag `demo-v1`. **Không tự push.**
3. **Lượt Xiaomi 14 (một lần, cuối dự án)**: đo FPS/frame time và độ trễ chạm, tune `CarConfig` theo cảm giác lái, và **đo lại thời gian của người chơi thật** để soát lại ngưỡng huy chương đang lấy từ lái tự động.
4. Dọn nhỏ, không chặn gì: xoá `Artifacts/Task3Clean` (838 MB) và project tạm `D:\Android\unity_temp\RacingDemo`; nếu muốn `Race.unity` hết "modified" sau mỗi rebuild thì phải giữ lại fileID của cây `__GeneratedScene` thay vì dựng lại.
5. Nút **CHOI LAI** trên màn kết quả không nhận cú chạm 130 ms do `mt-uinput.ps1` bơm, nên `medal-calibration.ps1` phải khởi động lại app giữa các lượt (chậm hơn ~10 giây/lượt, không ảnh hưởng số liệu). Bản thân nút vẫn đúng: validator kiểm nó nối tới `RaceDirector.Restart()`, test PlayMode gọi `Restart()` chạy đúng, và mốc Task 4 đã bấm được nút này bằng `adb shell input tap`. Chưa tìm ra vì sao riêng cú chạm qua uinput không ăn.

## Task 4 — Codex kiểm chứng khi tiếp quản ngày 09/09/2026

- Khi tiếp quản, code Task 4 và bằng chứng CLI/emulator đã có nhưng chưa commit; `HANDOFF.md` còn ghi Task 3. Đã đọc lại triển khai và đối chiếu mục 4/Task 4 của kế hoạch gốc, cập nhật bàn giao.
- Chạy lại Unity Test Runner: **83/83 EditMode**, **23/23 PlayMode**, không test thất bại; đã đọc XML `Artifacts/task4-review-editmode.xml` và `Artifacts/task4-review-playmode.xml`.
- Thêm 4 PlayMode test trên scene thật: pause trong countdown giữ thời gian/khóa pose; pause trong respawn và restart không bị bộ đếm cũ mở khóa; pause giữ vận tốc thẳng/góc; rơi dưới đường ở vòng hai tự reset về checkpoint 3 và giữ tiến trình vòng.
- Không đổi code Runtime, tuning, package hay YAML của scene. APK dùng kiểm chứng là bản Development đã build ở mốc Claude, SHA256 `3654A5B9CE2FF01CD943E9D2C332F9CE3A6F396C11BC16004705847605F71643`.
- Lượt lái kiểm chứng đầu ghim rào ở cua vòng một; adb bị restart trong lúc Unity chạy test. Giữ bằng chứng thất bại ở `Artifacts/task4-review/`; không dùng lượt này làm nghiệm thu. Lượt sau chạy khi Unity đã thoát.
- Lượt chạy lại **đạt**: qua `0 → 1 → 2 → 3` hai lần, không reset giữa lượt, về đích **01:42.840 / Bronze**, Results hiển thị đúng thời gian/kỷ lục và chơi lại được. Log và ảnh mới, tách riêng để tránh bị lượt khác ghi đè: `Artifacts/task4-review/retry/task4-race.log`, `task4-race-actions.txt`, `task4-results.png`.
- Bấm CHOI LAI trên Results → countdown 3, vòng 1/2, thời gian 0; Pause/Resume giữ đúng 00:01.859; Reset về start và đồng hồ vẫn tăng; Home rồi quay lại → vẫn TAM DUNG tại 00:02.819. Đã xem ảnh `restart.png`, `reset.png`, `background.png` và đối chiếu `menu.log` trong cùng thư mục.
- Log lượt đạt chỉ có cảnh báo dò `AssetPackManager` đã biết, không có exception gameplay mới. Kỷ lục vẫn chỉ ở bộ nhớ; Task 5 mới làm lưu đĩa. Xiaomi 14, cảm giác lái và hiệu năng chưa nghiệm thu ở phiên này.

## Task 5 — JSON kỷ lục — ngày 09/09/2026

- Đã thêm `JsonRecordRepository`, JSON DTO version 1 và `JsonFileStore` trong Runtime. Director dùng `persistentDataPath/records.json`; Core không đổi. Kho trong bộ nhớ chỉ còn dùng để cô lập test scene.
- File thiếu là kho rỗng; record sai bị bỏ, trùng trackId giữ thời gian nhỏ nhất. Version không hỗ trợ/lỗi đọc khóa ghi trong phiên. JSON không parse được phải backup thành công trước khi cho lưu mới; backup dùng tên GUID không ghi đè bản cũ.
- Ghi file tạm cùng thư mục, flush rồi `File.Move` (lần đầu) hoặc `File.Replace` (cập nhật). Không xóa file đích trước. Lỗi ghi giữ file/cache cũ; lượt nhanh hơn tiếp theo được thử lại.
- Unity EditMode **96/96 pass**, PlayMode **25/25 pass**, đã đọc `Artifacts/task5-editmode.xml` và `Artifacts/task5-playmode.xml`. Gồm 13 test JSON/IO mới và 2 test scene cho repository trả lỗi/ném exception: Results vẫn mở, hiện lỗi và Restart được.
- APK IL2CPP đã nghiệm thu lưu lần đầu/cập nhật/force-kill trên Pixel 9; bằng chứng chi tiết bên dưới.
- Build Development IL2CPP/ARM64 đạt, validator đạt, 60,2 MB / 150 giây (`Artifacts/task5-build-development.log`). SHA256 APK: `B01539162AFA79B505049B0F4ACE9BB01E5090EA7960CBC06192A847DE77BA0E`.
- Đã `pm clear com.vuit.racingdemo` trên Pixel 9 root trước lượt đầu. Startup báo `best=none writesDisabled=False`. Lái hai ngón đủ 2 vòng, Results báo lưu **02:03.320** (cố ý chờ ở start để lượt sau nhanh hơn); JSON version 1 chứa `timeSeconds=123.3199462890625`, `medal=0`.
- Force-stop sau khi Results báo lưu → mở lại bắt đầu countdown mới, log `[Records] Loaded ... best=02:03.320 writesDisabled=False`. Bằng chứng: `Artifacts/task5-device/clean-start.log`, `first/task4-results.png`, `first/task4-race.log`, `first-records.json`, `reopen-first.log`.
- Lượt sau phá kỷ lục **01:45.260 / Bronze**, Results báo `KY LUC MOI DA LUU`. JSON cập nhật còn đúng một record của track, `timeSeconds=105.25995635986328`, `medal=1`. Đã kiểm đường `File.Replace` trên Android IL2CPP, không chỉ đường tạo file lần đầu.
- Force-stop lần nữa → startup nạp `best=01:45.260 writesDisabled=False` và countdown mới. SHA256 file JSON trước/sau force-kill giống nhau. Bằng chứng trong `Artifacts/task5-device/`: `update/task4-results.png`, `update/task4-race.log`, `updated-records.json`, `after-forcekill.json`, `reopen-updated.log`.
- Hai lượt đều lái bằng nút cảm ứng hai ngón, qua đủ 8 cổng, không reset giữa lượt. Không sửa dữ liệu kỷ lục bằng adb; adb chỉ kéo JSON về để đối chiếu. Không có exception gameplay trong log lượt đua.
- Phạm vi còn chờ cuối dự án: Xiaomi 14, profiling thời gian IO/FPS và cảm giác lái. Không dùng hai lượt kiểm storage (có cố ý chờ) để tune huy chương Task 6.
## Task 6 — hình ảnh, âm thanh và ngưỡng huy chương — đêm 09→10/09/2026

> **Ngưỡng huy chương ghi trong mục này đã bị thay ở Task 7.** Sau khi sửa bước vật lý từ 0,02 s về 1/60 s, thời gian mỗi lượt chậm thêm 6–10 giây nên phải hiệu chỉnh lại. Số hiện hành nằm ở mục Task 7 và `GAME_DESIGN.md` mục 6.

### Đã thêm

- **Kenney Racing Kit 2.0 (CC0)** trong `Assets/ThirdParty/KenneyRacingKit`: 11 model FBX + 2 texture thực sự dùng, kèm `License.txt` gốc và `README.md` ghi URL tải, kích thước, SHA256 của zip (`8A71EA16…B853C6C0`) và ngày tải. Không chép cả gói 110 model.
- **Xe dùng model thật** (`raceCarRed.fbx`) thay khối hộp của Task 2. `CarBuilder` chuẩn hoá model theo **chiều dài cơ sở của WheelCollider** (không theo tỉ lệ riêng của Kenney), dời gốc về tâm bốn bánh, xoay 180° vì model quay đầu về −Z, rồi gắn bốn node bánh của model vào bốn pivot và thu về đúng `CarConfig.WheelRadius`. **Vật lý không đổi**: BoxCollider, WheelCollider và `CarConfig` giữ nguyên.
- **`DecorBuilder`**: 68 vật trang trí đặt theo hình học đường đua — cọc tiêu, khối chắn đỏ/trắng ở hai cua, ba khán đài, hai lều, 14 cây, tám cột đèn, ba biển quảng cáo, hai cờ ca-rô ở vạch đích. Không dùng số ngẫu nhiên nên rebuild hai lần ra y hệt; không vật nào có collider.
- **Thảm cỏ** 300 × 300 m ở `y = −0,02`, **không collider**, nên luật "rơi khỏi đường thì tự reset" của Task 4 không đổi.
- **Âm thanh**: `EngineAudio` + `EngineAudioCurve` (Runtime) và `EngineClipBuilder` (Editor) sinh `Assets/Generated/Audio/EngineLoop.wav` — PCM 16-bit mono 22050 Hz, 1,0 giây, 43 KB. Cao độ 0,65 → 2,1 và âm lượng 0,35 → 0,85 chạy theo `|SpeedKph| / MaxSpeedKph`.
- **`RenderQualitySetup`** áp cấu hình URP cho mức chất lượng Mobile qua `SerializedObject` mỗi lần rebuild; `SceneValidator` đọc lại để kiểm.
- **`MedalThresholdCalibrator`** (Core, hàm thuần) + **`MedalCalibration`** (Editor) + **`Tools/mtinject/medal-calibration.ps1`** để chốt ngưỡng huy chương từ thời gian thật.
- **Validator mở rộng**: đúng một `EngineAudio`/`AudioSource` có clip, loop bật, `playOnAwake` tắt; cây `Track/Decor` không có collider nào và **không vật nào lấn ra mặt đường** (đo bằng mesh + ma trận của chính object, tám đỉnh bao hình).

### Hai lỗi tự phát hiện khi xem ảnh chụp trên máy, đã sửa

1. **Bóng răng cưa trên thân xe.** Một cascade phủ 40 m với shadow map 1024 cho texel ~8 cm; thân xe tự đổ bóng lên chính nó thành vệt răng cưa. Nâng `m_MainLightShadowmapResolution` lên 2048 và `m_ShadowNormalBias` lên 2 (sai lệch #27). So sánh: `Artifacts/task6-device/car-zoom.png` (trước) và `car-zoom-after.png` (sau).
2. **Khán đài, cột đèn và biển quảng cáo quay lưng ra đường.** Ba model đó hướng mặt về −Z trong file gốc — xác định bằng phân bố chiều cao theo trục z và pháp tuyên của mặt mang material `tankco`. Thêm góc quay bù 180° cho đúng ba loại này.

### Bằng CLI (đọc XML, không tin exit code)

- **118/118 EditMode** (`Artifacts/task6-final-editmode.xml`) và **26/26 PlayMode** (`task6-final-playmode.xml`). So với mốc Task 5 (96 + 25): thêm 8 test hiệu chỉnh huy chương, 9 test đường cong âm thanh + file WAV, 5 test validator trang trí, 1 test scene cho pause/resume tiếng động cơ.
- `RebuildDemo` chạy **hai lần liên tiếp** sau khi chốt ngưỡng: SHA256 của `TrackDefinition.asset` **không đổi** (`3A069CEE…6A0956C7`) — ngưỡng vừa tune không bị generator ghi đè.
- `Task3Verification.RunRebuildChecks` đạt: hai lần rebuild ra cùng cây/hình học, tuning và object ngoài cây giữ nguyên, `Camera=1, Light=1, AudioListener=1, EventSystem=1, Collider=12, CheckpointVolume=4` — **trang trí không thêm collider nào**.
- `SceneValidator.ValidateBuildScenes` đạt, gồm cả phần kiểm cấu hình URP và trang trí.
- Build Development IL2CPP/ARM64 đạt: **60,18 MB**, SHA256 `695AD1E72B439224AB255E0B87E74DF382DD4DE11546438E1AD44EDA989901D2`.

### Bằng chơi thử trên emulator Pixel 9 (ảnh trong `Artifacts/task6-device/` và `task6-accept/`)

- Cảnh mới hiện đúng: thảm cỏ, khán đài quay mặt vào đường, cờ ca-rô hai bên vạch đích, biển quảng cáo đọc được chữ, cây và cột đèn — `01-countdown.png`, `02-driving.png`.
- **Âm thanh thật sự phát**: `dumpsys audio` cho thấy luồng AAudio `state:started` thuộc đúng pid của `com.vuit.racingdemo` trong lúc chơi (`task6-device/audio.txt`). Việc pause tắt tiếng và resume mở lại được kiểm bằng test PlayMode trên scene thật, vì `dumpsys` chỉ thấy luồng ra của Unity chứ không thấy trạng thái từng AudioSource.
- Pause/CHOI TIEP vẫn đúng sau khi thay hình và thêm âm thanh — `03-paused.png`, `04-resumed.png`.
- Bánh trước quay theo tay lái khi giữ **ga + lái trái bằng hai ngón thật** — `task6-accept/steering.png`.
- Một lượt đua trọn vẹn với ngưỡng huy chương mới: **01:42.420 → HUY CHUONG VANG**, `KY LUC MOI DA LUU` (dữ liệu app đã xoá trước lượt này). Nhanh hơn cả 12 lượt hiệu chỉnh, đúng như ngưỡng gold 105,657 s dự kiến. Ảnh `task6-accept/results.png`, log `task6-accept/session.log`, vệt lái `task6-accept/task4-race-actions.txt` (đủ 8 cặp vòng–cổng, không reset).

### Chưa làm / chưa kiểm chứng ở mốc này

- **`CarConfig` vẫn chưa tune.** Kế hoạch yêu cầu chỉnh theo phản hồi khi chơi; lái tự động không thay được cảm giác lái của người, nên để lại cho lượt nghiệm thu Xiaomi 14.
- **Ngưỡng huy chương là số của lái tự động**, không phải của người chơi (sai lệch #28). Cần xem lại khi có số liệu người thật.
- Mép bóng cứng vẫn răng cưa ở chỗ cánh gió đổ bóng lên thân xe — hệ quả của "soft shadows off" mà kế hoạch chốt, không phải lỗi.
- Hiệu năng (FPS, frame time) và độ trễ chạm chưa đo; emulator không dùng để đo hiệu năng.
- Chưa thêm trang trí dày hơn: kế hoạch yêu cầu chỉ thêm sau khi có số đo hiệu năng máy thật.
## Task 7 — nghiệm thu và bàn giao — ngày 10/09/2026

### Bộ kiểm tra mục 8

- **122/122 EditMode** (`Artifacts/task7-final-editmode.xml`) và **28/28 PlayMode** (`task7-final-playmode.xml`), chạy sau khi đã chốt ngưỡng huy chương mới.
- `RebuildDemo` hai lần liên tiếp, `SceneValidator.ValidateBuildScenes` và `Task3Verification.RunRebuildChecks` đều đạt; `TrackDefinition` giữ nguyên SHA256 qua hai lần rebuild.
- Hai APK cuối: `racing-demo-development.apk` 60,18 MB (SHA256 `F3E409EF…67053D0A`) và **`racing-demo.apk` 29,11 MB** (SHA256 `E59DEE23…ACFE0FA6`).
- Thêm 2 test PlayMode bịt đúng hai gạch đầu dòng của mục 8 mà trước đó chưa ai kiểm:
  - `TouchButtonsDoNotOverlapAndLabelsDoNotBlockInput` — đọc rect thật của canvas đang chạy: mọi nhãn `TextMeshProUGUI` phải tắt `raycastTarget`, và 6 nút luôn hiện trên màn hình không được chồng lên nhau. Việc này gỡ luôn mục "⏳ Validator chưa kiểm tra rect các nút cảm ứng có chồng lấn không" tồn từ Task 2.
  - `SeveralRestartsDoNotDuplicateSceneSingletons` — chơi lại 3 lần rồi đếm lại `CarController`/`Camera`/`AudioListener`/`AudioSource`/`EventSystem`/`RaceDirector`, mỗi thứ phải đúng 1.
- Thêm 4 test EditMode cho `FixedTimestepSetup` (xem phần dưới).

### Sai lệch phát hiện khi nghiệm thu: bước vật lý chạy 50 Hz thay vì 60 Hz

Kế hoạch mục 2 chốt "bước vật lý ban đầu 1/60 giây", nhưng `ProjectSettings/TimeManager.asset` vẫn
để mặc định của Unity là **0,02 giây (50 Hz)** trong khi `AppBootstrap` đặt `targetFrameRate = 60`.
Hai con số lệch nhau nghĩa là có khung hình không chạy bước vật lý nào, có khung chạy hai bước.
Tài liệu Task 3 còn tính độ dày cổng checkpoint dựa trên giả định 1/60 (`0,56 m ở 120 km/h`), tức là
giả định đó chưa bao giờ đúng — may là cổng dày 4 m nên vẫn an toàn ở cả hai mức.

Đã thêm `FixedTimestepSetup`: đặt lại giá trị mỗi lần `RebuildDemo`, `SceneValidator` kiểm lại, và
4 test EditMode chốt giá trị thật của project cộng chứng minh phép kiểm bắt được khi giá trị sai.

Hai điều phải biết nếu đụng lại chỗ này:

1. **`ProjectSettings` không nằm trong AssetDatabase** nên `AssetDatabase.SaveAssets()` một mình
   không ghi được; phải gọi `EditorApplication.ExecuteMenuItem("File/Save Project")`. Lần thử đầu
   giá trị chỉ đổi trong bộ nhớ rồi mất khi Unity thoát.
2. **Unity 6 lưu `Fixed Timestep` dạng phân số** (`m_Count: 2352000`, `m_Rate: 141120000/1` =
   đúng 1/60), không phải float. Đọc bằng `SerializedProperty.floatValue` ra 0 nên phép kiểm báo sai.
   Code cuối cùng đọc/ghi qua `Time.fixedDeltaTime` nên không phụ thuộc định dạng lưu.

Vì `SceneValidator` chạy ở **một phiên Unity khác** với lệnh sửa, việc validator đạt cũng chính là
bằng chứng giá trị đã ghi xuống đĩa thật chứ không chỉ nằm trong bộ nhớ.

### Ngưỡng huy chương hiệu chỉnh lại với vật lý 60 Hz

Chạy lại 12 lượt bằng `Tools/mtinject/medal-calibration.ps1` trên emulator Pixel 9 với APK vừa build (vật lý 1/60 s). **12/12 lượt về đích, không lượt nào phải reset.** Ngưỡng mới: **gold 115,618 s / silver 117,758 s / bronze 134,750 s** (nhanh nhất 112,250 × 1,03; trung vị 117,758; chậm nhất 122,500 × 1,10). Bộ số của Task 6 — gold 105,657 / silver 108,430 / bronze 122,826 — đo ở vật lý 50 Hz nên không còn dùng.

| Lượt | Thời gian (s) | | Lượt | Thời gian (s) |
|---|---|---|---|---|
| 1 | 116,766 | | 7 | 112,250 |
| 2 | 112,883 | | 8 | 116,066 |
| 3 | 116,083 | | 9 | 120,566 |
| 4 | 118,750 | | 10 | 112,283 |
| 5 | 122,133 | | 11 | 120,566 |
| 6 | 122,500 | | 12 | 119,700 |

Trung bình 117,546 s. Ở 60 Hz mỗi lượt chậm hơn khoảng 6–10 giây so với cùng script chạy ở 50 Hz — đây chính là lý do phải hiệu chỉnh lại. `TrackDefinition` mang ngưỡng mới vẫn giữ nguyên SHA256 sau hai lần rebuild (`8A65F642…EDFCA2C8`).

Lượt nghiệm thu sau khi chốt ngưỡng: **01:54.650 → HUY CHUONG VANG**, `KY LUC MOI DA LUU` (dữ liệu app đã xoá trước lượt này). Ảnh `Artifacts/task7-accept/results.png`, log `session.log`, vệt lái `task4-race-actions.txt` — đủ 8 cặp vòng–cổng, không reset.

### Dựng lại từ một checkout sạch

`git clone` sang `D:/Android/task7-clean`, `git lfs pull`, **không có `Library`** — nghĩa là không
dựa vào cache của máy cũ. Bằng chứng đầy đủ trong `Artifacts/task7-clean-checkout.txt`:

| Bước | Kết quả |
|---|---|
| LFS khôi phục file thật | `raceCarRed.fbx` 271.190 byte, `EngineLoop.wav` 44.144 byte (không phải file con trỏ ~130 byte) |
| `TrackDefinition` trong bản sao | SHA256 giống hệt bản gốc |
| `RebuildDemo` | đạt |
| `ValidateBuildScenes` | đạt |
| EditMode / PlayMode | 118/118 và 26/26 (số của commit `8868cce` mà bản sao đang đứng) |
| `TrackDefinition` sau khi rebuild | SHA256 không đổi — tuning không bị ghi đè |
| Build APK Development từ bản sao | đạt, cài lên emulator thành công |

### APK Release

- `Builds/Android/racing-demo.apk` — **29,11 MB**, IL2CPP/ARM64, `development`/`allowDebugging`/
  `connectProfiler`/`deep profiling` đều tắt (đặt tường minh trong `BuildCommand.Build`).
- Chạy thử trên emulator: khởi động, đếm ngược, giữ ga chạy được, Pause/CHOI TIEP đúng; log Unity
  **không có exception** nào ngoài cảnh báo `AssetPackManager` đã biết.
- **0 dòng log chẩn đoán** `[TrackDrive]`/`[RaceLoop]`/`[Records]` trong bản Release — đúng như
  thiết kế (chỉ biên dịch trong Editor/Development). Ảnh và log ở `Artifacts/task7-release/`.

### Máy và cấu hình của lượt kiểm chứng này

| Mục | Giá trị |
|---|---|
| Máy | Windows 11 Pro build 26200, Intel Core i5-12400 (6 nhân/12 luồng), 31,7 GB RAM, NVIDIA RTX 3070 Ti |
| Unity | 6000.6.0f1 |
| Git / LFS | 2.47.1 / 3.6.0 |
| Thiết bị chạy thử | Emulator AVD `Pixel_9_root`, Android API 37, x86_64 chạy APK ARM64 qua dịch mã, `-memory 6144` |
| Cấu hình build | IL2CPP, ARM64, OpenGLES3, Min API 26, Landscape Left, `targetFrameRate = 60`, `vSyncCount = 0`, bước vật lý 1/60 s, URP render scale 1.0 / MSAA 2x / shadow 40 m |

### Chưa làm được — cần máy thật

Toàn bộ mục **"Xiaomi 14 — vòng chơi và vòng đời ứng dụng"** và **"Hiệu năng và bằng chứng"** của
mục 8 vẫn chưa chạy, vì máy thật chưa được cắm vào. Cụ thể còn thiếu:

- 10 lượt liên tiếp không crash trên máy thật; khoá màn hình / chuyển app / quay lại; bấm đúng tâm nút;
  nhả và rê ngón ra ngoài nút.
- FPS trung bình + median/P95/P99 frame time theo kịch bản 15 phút của kế hoạch, đo cả bản
  Development (có Profiler) lẫn bản Release (không gắn Profiler).
- Độ trễ chạm.
- Tune `CarConfig` theo cảm giác lái, và đo lại thời gian của **người chơi thật** để soát ngưỡng huy chương.

Vì điều kiện đạt của Task 7 là "mọi tuyên bố hiệu năng có số đo và bản APK tương ứng", **Task 7 chưa
thể đánh dấu hoàn tất** và **chưa tạo tag `demo-v1`**.

## Lượt Xiaomi 14 — phiên 1 — ngày 13/09/2026

Máy thật đã cắm. Mọi bằng chứng nằm trong `Artifacts/xiaomi14/` (thư mục bị `.gitignore`, chỉ có trên máy này).

### Máy và cách kết nối

| Mục | Giá trị |
|---|---|
| Máy | **Xiaomi 14** (`23127PN0CC`, codename `houji`, bản Trung Quốc), serial USB `840c036a` |
| Hệ điều hành | Android **16** (API 36), HyperOS **3.0.305.0.WNCCNXM** |
| SoC / GPU | Snapdragon 8 Gen 3 (SM8650), Adreno 750, OpenGL ES 3.2 |
| Màn hình | 1200×2670, 480 dpi, tối đa **120 Hz** (`peak_refresh_rate = 120`, đang để mặc định) |
| Pin lúc bắt đầu | 75 %, 35,4 °C, **đang sạc qua USB** |
| APK đã chạy | Release `E59DEE23…` (commit 8e11c3d) → `94F90FB3…` (ma sát 0) → `1B323364…` (ma sát 0,2) → **`9183D3E6…` (thanh lái, bản hiện cài)** |

Ba cái bẫy khi cắm máy (đã ghi vào `HANDOFF.md`):

1. **`adb install` bị HyperOS chặn im lặng** (lỗi rỗng) khi chưa bật *Install via USB* (đòi tài khoản Mi). Bật rồi vẫn phải bấm đồng ý trên máy, không thì `INSTALL_FAILED_USER_RESTRICTED: Install canceled by user`.
2. **USB rớt mỗi khi truyền file lớn** (`failed to read copy response: EOF`, transport id đổi liên tục). Cách chạy được: `adb tcpip 5555` rồi `adb connect 192.168.1.4:5555` (Wi‑Fi cùng mạng), push APK vào `/data/local/tmp` rồi `pm install -r` ngay trên máy.
3. **Unity build Android khởi động lại adb server** → mất mọi kết nối; sau mỗi lần build phải `adb connect` lại.

### Đã kiểm chứng

- **App chạy trên máy thật**: mở, đếm ngược, đồng hồ chạy, HUD/nút đúng landscape, log chỉ có cảnh báo `AssetPackManager` đã biết, **không exception**. Ảnh `01-launch.png`, log `release-session.log`. → Điều kiện "chạy trên Xiaomi 14" của Task 1 đã có bằng chứng.
- **Frame time (thử nhanh 30 s, bản Release đầu, chưa phải kịch bản 15 phút)**: đo bằng `dumpsys SurfaceFlinger --timestats` trên layer `SurfaceView[com.vuit.racingdemo…](BLAST)`: ~60 FPS, 0 khung rơi, median 16 ms, **P95 24 ms**, P99 24 ms, không spike. Màn hình 120 Hz + game khóa 60 (vSync tắt) nên ~2 % khung trượt sang 24 ms rồi bù bằng khung 8 ms; SurfaceFlinger đếm các khung 16 ms là "janky" so với timeline 120 Hz — không phải lỗi. `Artifacts/xiaomi14/perf-smoke/`.
- Người chơi nhận xét lượt đầu: ga đủ mạnh, lái nhạy, **cua tốc độ cao không văng** → `CarConfig` giữ nguyên.

### Đã sửa theo phản hồi người chơi (sai lệch #32–#35)

| Phản hồi | Sửa | Kiểm |
|---|---|---|
| Đâm rào góc ~15° bị dính, phải lùi | `DemoSlide` PhysicsMaterial cho rào + thân xe; thử 0 → người chơi thấy văng dễ; **chốt 0,2** | validator + 6 test TrackEditMode; người chơi xác nhận 0,2 ổn |
| Không hiểu nút RESET | nhãn → **UNSTUCK** | ảnh `04-steer-slider.png`; người chơi OK |
| Muốn FOV theo tốc độ | `ChaseCamera` 62°→72°, `_car` bind qua generator | 7 test; người chơi OK |
| Muốn chỉnh độ gắt khi rẽ | `SteerSlider` thay hai nút | 8 test + PlayMode cập nhật; người chơi xác nhận: **độ nhạy ổn, bám tay, không kẹt lái** khi rê ra ngoài |

Sau tất cả: **143/143 EditMode, 28/28 PlayMode**, `ValidateBuildScenes` đạt, `Task3Verification` PASS ×3, `TrackDefinition`/`CarConfig` không đổi byte.

### Công cụ mới

`Tools/perf/frametime-sample.ps1 -Serial <adb serial> -DurationSeconds 900 -OutDir Artifacts/xiaomi14/perf-release`: lấy mẫu TimeStats mỗi 5 s, ghi `tiles.csv` (khung, khung rơi, FPS, pin, nhiệt độ, histogram) và `summary.txt` (cửa sổ 60 s quanh phút 1/5/15: FPS, median/P95/P99, spike ≥100 ms, ô 5 s nào FPS < 30). Không cần sửa code game, dùng được cho bản Release. Đã chạy thử 20 s đạt.

### Chưa làm — việc của phiên sau

1. ~~Phản hồi thanh lái~~ — đã có: ổn, không chỉnh. (Nếu sau này cần: `SteerFullDistance`/`SteerDeadZone` trong `UiBuilder`.)
2. **Build lại Development APK** — bản trong `Builds/` (SHA `F3E409EF…`, 10/09) **đã lỗi thời**, chưa có ma sát 0,2 / FOV / thanh lái.
3. Checklist 9 mục "Xiaomi 14 — vòng chơi và vòng đời ứng dụng" (mục 8 kế hoạch) trên APK cuối.
4. Đo 15 phút ×2 (Release và Development) bằng `frametime-sample.ps1`, ghi pin/sạc/refresh rate; điền bảng `GAME_DESIGN.md` mục 9.
5. Độ trễ chạm: chỉ đo được nếu có máy thứ hai quay slow‑motion; không thì ghi "chưa kiểm chứng".
6. Người chơi thật chạy ≥5 lượt → soát ngưỡng huy chương (đang là số của lái nút tự động).
7. Cập nhật `PROGRESS.md`/`GAME_DESIGN.md`, commit, rồi mới tag `demo-v1` (không tự push).

## Nâng cấp hình ảnh theo yêu cầu — 14/09/2026

Yêu cầu mới: cải thiện đồ hoạ, hình ảnh và vibe. Hướng đã triển khai: **APEX / Golden Hour**, lễ hội đua xe low-poly với nắng chiều ấm, xanh than/cam/kem.

- `FestivalVisuals`: skybox riêng, ambient ba màu, fog; 18 núi dùng chung mesh, hai dải viền đỏ–kem, vạch ca-rô, cổng có tên, ba biển sector, 10 biển cua trái. Hạt nhựa 128×128 tự sinh, mipmap/trilinear. Không cần package hay tài nguyên tải ngoài.
- `DecorBuilder`: thêm 24 cây thành tám cụm ở ngoài đường.
- Xe dùng material URP riêng trong Generated (đỏ, cao su, graphite, kính), giữ model Kenney gốc. HUD xanh đậm/cam/kem, các vùng chạm và độ nhạy lái giữ nguyên.
- Chỉ dùng Editor API để dựng scene/asset. Giữ một directional light và cấu hình URP Mobile. Collider, Core, CarConfig, TrackDefinition không đổi.
- Sai lệch chủ ý so với Task 6: tăng chi tiết hình ảnh theo yêu cầu mới của người dùng; đã có smoke performance máy thật ở phiên trước, nhưng bản mới phải đo lại trên Xiaomi 14.

Bằng chứng hiện tại ở `Artifacts/visual-upgrade/`: ảnh thử ban đầu `start.png`; sau khi hạ núi và sửa màu xe: `final-start.png`, `driving.png`. Generate/validator đạt, EditMode **143/143**, `Task3Verification` đạt cả ba điều kiện (hai rebuild giống nhau; tuning giữ JSON/byte/GUID; object ngoài cây giữ transform/ID).

SHA256 tuning sau rebuild: CarConfig `CC89720A65DEE06E09B249E560BCAB3280CD31C500A05DE3A6E0AF27E975B3DD`; TrackDefinition `8A65F64278622CAD3E39F8A9FEAF52B22A08796437175B7A29DEF098EDFCA2C8`, khớp trước thay đổi.

Lượt nghiệm thu Development trên Pixel_9_root (6144 MB): **02:00.766, Bronze**, đủ `1-0 1-1 1-2 1-3 2-0 2-1 2-2 2-3`, không reset. `race/task4-results.png`, `race/task4-race-actions.txt`, `final-session.log`. Không có exception gameplay mới; cảnh báo AssetPackManager có sẵn vẫn còn. Development có thông báo shader postprocess bị strip (DOF/Panini), các hiệu ứng đó không dùng trong thiết kế này.

PlayMode chính thức **28/28** (`playmode.xml`, đã đọc total/passed/failed); không có test bị bỏ qua do 0 test. Chưa đo FPS/frame time hay cảm giác lái trên Xiaomi 14 với bản đồ hoạ mới, không đánh dấu Task 7 hoàn tất và không tạo tag demo-v1.

APK cuối: cả Development và Release build đạt. Release `Builds/Android/racing-demo.apk` **30.649.692 byte (~29,23 MiB)**, SHA256 `0ECC3A8C001D63C1BA2FD0E80A1A6297B7EF950EE914496C540C3BEB989E8656`. Đã cài và mở trên emulator, đếm ngược/HUD/giữ ga/Pause hoạt động, không có exception mới ngoài AssetPackManager đã biết; không có log TrackDrive/RaceLoop trong Release. Ảnh `release.png`, `release-pause.png`; log `release-session.log`. Bản Release mới đang cài trên emulator; chưa cài sang Xiaomi 14.

## Đợt VenueDetails — kiểm chứng không cần máy thật — 14/09/2026 (tối)

Đợt hình ảnh thứ hai (`VenueDetails.cs`: 3 pit, tháp Race Control, podium, 45 khán giả, 24 cụm cây bụi, 10 cờ; `GAME_DESIGN.md` 9.4) được bàn giao trong working tree **chưa commit và chưa có bằng chứng**. Phiên này làm trọn mục "Việc tiếp theo KHÔNG cần máy thật" của `HANDOFF.md`. Bằng chứng trong `Artifacts/venue-verify/` (bị `.gitignore`, chỉ có trên máy này); thời gian từng bước ở `stages.txt`; log của lượt chạy đầu (trước khi sửa lỗi) giữ hậu tố `-r1`.

### Lỗi thật tìm được ở đợt bàn giao: 15 nhãn VenueDetails không hiện trong game (sai lệch #36)

Lượt chạy đầu: rebuild ×2, validator, `Task3Verification`, 143/143 EditMode, 28/28 PlayMode **đều xanh** — nhưng khi viết `SceneStats` thì thấy nhóm `VenueDetails` có 57 renderer mà chỉ 42 mesh, và **không mesh `VenueLabel*` nào được `Race.unity` tham chiếu**. Đọc scene đã lưu: 15 object `Label` ("PIT / 01", "RACE CONTROL", "APEX VICTORY CLUB", cờ "A P E X") chỉ có `RectTransform` + `MeshRenderer` (material font), **không có `MeshFilter`** → build chạy bình thường, không lỗi, nhưng chữ không bao giờ vẽ.

Nguyên nhân: `VenueDetails.Label` thêm `TextMeshPro` để bake glyph mesh rồi xoá component TMP và **dùng lại `MeshFilter` do TMP tạo**. TMP gắn `MeshFilter` đó cờ `HideInInspector | HideAndDontSave` (`TextMeshPro.cs:579` trong uGUI 2.6.0), nên nó tồn tại trong bộ nhớ lúc generator chạy (validator trong `RebuildDemo` thấy đủ mesh) rồi **bị bỏ khi lưu scene**. `ValidateBuildScenes` đọc scene đã lưu không bắt được vì `ValidateDecor` chỉ duyệt các `MeshFilter` còn tồn tại.

Sửa trong generator (không sửa YAML):

- `VenueDetails.Label`: bake trên object tạm `LabelScratch`, xoá cả object, rồi tạo `Label` sạch với `Transform + MeshFilter + MeshRenderer` thường; ném lỗi nếu TMP trả mesh rỗng.
- `SceneValidator.ValidateDecor`: thêm hai phép kiểm — mọi `MeshRenderer` trong `Track/Decor` phải có `MeshFilter` mang mesh (bỏ qua nhãn TMP sống vì mesh sinh lúc chạy), và `MeshFilter`/`MeshRenderer` không được mang cờ `DontSaveInEditor|DontSaveInBuild` (bắt được **ngay trong bộ nhớ**, trước khi lưu).
- Hai test EditMode mới trong `DecorValidationTests`: `RendererWithoutMeshFilterIsReported`, `DontSaveMeshFilterIsReported` (cố tình làm hỏng rồi xem validator có bắt không, theo đúng kiểu bộ test cũ).
- `SceneStats` thêm cột "Renderer khong mesh" để lớp lỗi này lộ ngay trong bảng.

Sau khi sửa, scene đã lưu tham chiếu đủ 15 mesh `VenueLabel*`, mỗi `Label` có `MeshFilter` với `m_Mesh` trỏ đúng asset; snapshot ngữ nghĩa của `Task3Verification` đổi từ `245DBB84…` sang `398356B4…` (đúng như mong đợi vì cây object đổi).

### Bước 1 — chuỗi kiểm chứng chuẩn, chạy lại sau khi sửa (Editor đã đóng, chạy CLI)

| Bước | Kết quả | Log |
|---|---|---|
| `RebuildDemo` lần 1 | exit 0, `RebuildDemo xong`, không cảnh báo mới | `generate-1.log` |
| `RebuildDemo` lần 2 | exit 0 | `generate-2.log` |
| `ValidateBuildScenes` | `Scene build hop le` — `ValidateDecor` kể cả hai phép kiểm mới: 0 collider trong `Track/Decor`, không vật nào lấn mặt đường, 0 renderer thiếu mesh, 0 cờ DontSave | `validate.log` |
| `Task3Verification.RunRebuildChecks` | **PASS cả ba**: hai rebuild cùng snapshot ngữ nghĩa `398356B49EE689CD…`; tuning giữ JSON/byte/GUID; object ngoài cây giữ transform/ID. `Camera=1, Light=1, AudioListener=1, EventSystem=1, Collider=12, CheckpointVolume=4` — đúng số của Task 7 | `rebuild-checks.log`, `task3-rebuild-verification.txt` |
| EditMode | **145/145** (`total=145 passed=145 failed=0 skipped=0`, đọc XML; 143 cũ + 2 mới) | `editmode.xml` |
| PlayMode | **28/28** (`total=28 passed=28 failed=0`, đọc XML) | `playmode.xml` |

SHA256 trước và sau toàn bộ chuỗi: `TrackDefinition` `8A65F64278622CAD3E39F8A9FEAF52B22A08796437175B7A29DEF098EDFCA2C8`, `CarConfig` `CC89720A65DEE06E09B249E560BCAB3280CD31C500A05DE3A6E0AF27E975B3DD` — không đổi. 45 khán giả và 24 cụm cây bụi đều qua kiểm tra bao hình của `ValidateDecor` mà không phải chỉnh vị trí.

### Bước 2 — ngân sách hình ảnh bằng `SceneStats` (lệnh Editor mới)

`RacingDemo.EditorTools.SceneStats.Report [-statsOut <file>]` (menu *RacingDemo/Scene Stats*) mở `Race.unity` **đã lưu** bằng preview scene và đếm từ `MeshFilter.sharedMesh` + `MeshRenderer` thật: renderer, tam giác, đỉnh, submesh (≈ draw call trước static batching), mesh/material riêng, renderer đổ bóng và tam giác đổ bóng, renderer không static, nhãn TMP sống (mesh sinh lúc chạy — chỉ đếm số lượng), renderer không mesh; kèm shader/texture riêng và cấu hình URP Mobile. Nhóm theo ba tầng đường dẫn, riêng `Track/Decor/VenueDetails` tách ra để đọc "trước/sau" trong một bảng.

Ba mốc đo trên cùng máy, cùng lệnh (`scene-stats-task7-bb5c7fb.txt`, `scene-stats-before.txt`, `scene-stats-after.txt`). Mốc "Task 6/7" là `bb5c7fb` — đúng bản đã đo 30 s trên Xiaomi 14; mốc "APEX" là `29c2f3c` (stash đợt VenueDetails theo pathspec rồi đo); mốc "VenueDetails" là scene sau khi sửa nhãn.

| Toàn scene | Task 6/7 (`bb5c7fb`) | APEX (`29c2f3c`) | + VenueDetails | VenueDetails so với Task 6/7 |
|---|---:|---:|---:|---:|
| MeshRenderer | 139 | 244 | **301** | ×2,17 |
| Tam giác | 15.160 | 18.278 | **27.236** | ×1,80 |
| Đỉnh | 18.725 | 24.799 | 40.555 | ×2,17 |
| Submesh (draw trước batching) | 194 | 311 | **464** | ×2,39 |
| Mesh riêng | 21 | 24 | 81 | — |
| Material riêng | 32 | 39 | 48 | ×1,5 |
| Renderer đổ bóng | 139 | 212 | 227 | ×1,63 |
| Tam giác đổ bóng | 15.160 | 18.152 | 23.948 | ×1,58 |
| Renderer không static | 5 | 19 | 19 | (14 là nhãn TMP sống của APEX) |
| Shader / texture riêng | 1 / 2 | 2 / 4 | 2 / 4 | — |
| Renderer không mesh | 0 | 0 | 0 (lượt đầu: **15**) | — |

Riêng cây `Track/Decor/VenueDetails`: 57 renderer, 8.958 tam giác, 153 submesh, 57 mesh, 10 material, chỉ **15 renderer đổ bóng** (pit, tháp, podium, cờ; khán giả và cây bụi tắt bóng), 5.796 tam giác đổ bóng. Mọi nhóm khác giữ nguyên số giữa "APEX" và "+ VenueDetails" — đợt này thuần bổ sung.

Đánh giá rủi ro (ghi theo yêu cầu, **không cắt cảnh** khi chưa có số đo máy thật): so với bản đã đo ~60 FPS / P95 24 ms trên Xiaomi 14, tam giác tăng 1,8×, submesh tăng 2,4×, tam giác đổ bóng tăng 1,6×. 27 nghìn tam giác và ~460 submesh (mọi cụm đều static nên static batching còn gộp bớt) là mức thấp với Adreno 750; điểm đáng theo dõi nhất khi đo lại là **số draw call** (submesh ×2,4, chủ yếu 24 cụm cây bụi ×3 material và 3 khán đài ×5 material) và **bóng đổ** (thêm 15 caster lớn: 3 pit, tháp 8 m, podium). URP vẫn giữ shadow distance 40 m, 1 cascade, shadowmap 2048, MSAA 2x, HDR off. Nếu Xiaomi 14 đo dưới 60 FPS thì thứ tự xử lý theo bằng chứng: gộp material cây bụi/khán giả (giảm submesh), rồi shadow distance — không đụng hình học collider hay tuning.

### Bước 3 — hai APK dựng từ source đã kiểm (sau khi sửa nhãn)

| APK | Byte | SHA256 | Log |
|---|---:|---|---|
| `Builds/Android/racing-demo-development.apk` | 63.104.614 (60,18 MiB) | `31FAA7338A5FB396ED4069F1CBDBF81BEF9D17E1A26CCB6BCDD5681B29AE177E` | `build-development.log` (16 s, build tăng dần) |
| `Builds/Android/racing-demo.apk` (Release) | 30.782.454 (29,36 MiB) | `9FC46FB1EF5EABCF50BB6DE231E016003504B1ED55F1702692D02768F5BA650F` | `build-release.log` (166 s) |

Cả hai đi qua `ValidateBuildScenes` trong `BuildCommand.Build`. Bản Development trùng đúng số byte với bản lỗi thời 19:38 — chỉ là trùng hợp sau nén deflate; nội dung khác (scene giờ mang 15 mesh nhãn). Kiểm bằng cách bung APK: static batching gộp mọi cụm `Venue*` (đều static) thành 11 `Combined Mesh (root: scene)` trong `level0`, `sharedassets0` còn tham chiếu `VenueLabelPit0`, `VenueGarden0` và 9 material `Venue*`. Release lớn hơn bản `0ECC3A8C…` của `29c2f3c` 132.762 byte — đúng phần VenueDetails.

### Bước 4 — trọn lượt trên emulator `Pixel_9_root` (6144 MB) với bản Development mới

- Emulator boot `userdebug`, `adb root` + `setenforce 0`, `mtinject` thường trú, Android nhận `racingdemo_virtual_touch` là `TOUCH | TOUCH_MT`.
- Cài đè APK Development `31FAA733…`, khởi động app. **Ảnh `01-launch.png`** lúc đếm ngược: nhãn dọc "A P E X" trên 10 cờ hiện đúng, 45 khán giả trên khán đài, tháp Race Control — bằng chứng lỗi nhãn đã sửa thật trên máy chứ không chỉ trong scene.
- `Tools/mtinject/race-autopilot.ps1` không sửa gì (thanh lái analog đặt hết lái đúng tâm nút cũ): **02:00.800 → Huy chương Đồng, "KY LUC MOI DA LUU"** (dữ liệu app đã xoá khi cài lại). Đủ `1-0 1-1 1-2 1-3 2-0 2-1 2-2 2-3` theo thứ tự, **0 lần `Dat lai xe`**, không exception trong cửa sổ log. Cổng theo thời gian: 23,2 / 38,8 / 52,5 / 64,3 / 79,9 / 92,9 / 107,0 / 120,8 s. Gần như trùng lượt APEX (02:00.766) → cảnh mới không lấn đường, không collider lạ, không hồi quy lái.
- Ảnh kết quả `race/task4-results.png`, vệt lái `race/task4-race-actions.txt` (112 mẫu), log `race/task4-race.log`.
- Ghi chú công cụ: gọi `race-autopilot.ps1` với `*>` redirect toàn lệnh trong PS 5.1 làm `adb logcat | Set-Content` ở khối `finally` ném NativeCommandError (ErrorActionPreference Stop) nên file `task4-race.log` phải kéo lại bằng tay ngay sau đó; lượt đua và ảnh không ảnh hưởng. Không sửa script (chạy trực tiếp không redirect thì không gặp).

## Kiểm tra Release và cập nhật bàn giao — 15/09/2026

Tiếp tục yêu cầu chi tiết cảnh vật trên source `d538e8e` (working tree sạch lúc bắt đầu). Đã đọc lại XML 145/145 EditMode + 28/28 PlayMode và đối chiếu SHA256 Release `9FC46FB1…5BA650F` đúng bảng trên; không build lại hay thay đổi code cảnh đã kiểm.

Cài Release lên `Pixel_9_root` (6144 MB), mở game, quan sát đủ nhãn cờ và khán giả, giữ ga lên 33 km/h, tạm dừng và Chơi tiếp thành công. Ảnh `Artifacts/venue-release/start.png`, `pause.png`, `resume.png`; log `session.log`: chỉ có cảnh báo AssetPackManager đã biết, không exception gameplay mới và không log chẩn đoán TrackDrive/RaceLoop. Game được để tạm dừng trên emulator.

Cập nhật README với cảnh mới, SHA APK và giới hạn hiệu năng; sửa HANDOFF còn ghi sai VenueDetails chưa commit. Chuỗi checkout sạch của phiên trước vẫn **chưa đủ bằng chứng**: generate exit 0 nhưng validate bị ngắt, không có test/build; không tuyên bố hoàn tất nghiệm thu toàn dự án. Hiệu năng Xiaomi 14 cho bản cảnh mới chưa đo.

## Cải thiện UI — 15/09/2026

Yêu cầu người dùng: cải thiện UI game. UiBuilder thêm phân cấp chữ HUD (đồng hồ/tốc độ đậm, checkpoint màu phụ, tên chế độ trong thẻ đồng hồ), đường ray/nhãn thanh lái, vân bàn đạp và hướng dẫn ngắn. Menu Pause và Results có thẻ nền đặc/viền cam riêng; CHOI TIEP và DUA LAI là hành động chính màu cam. Giữ nguyên vị trí/kích thước vùng chạm, tuning lái và luật đua. Mọi scene thay đổi qua Editor API. Sai lệch phạm vi chủ ý: bổ sung đợt UI theo yêu cầu mới sau phần đồ hoạ.

Bằng chứng `Artifacts/ui-upgrade/`:
- Rebuild/compile/validator đạt. `rebuild-checks.log`: PASS cả ba (hai rebuild cùng snapshot, giữ tuning JSON/byte/GUID, giữ object ngoài cây); semantic SHA256 `2D7B308D08EFB5D9B0C5AF759C593CB20EA8909ADD2ED1BB697BE78869832006`.
- XML chính thức: EditMode 145/145, PlayMode 28/28, failed=0, skipped=0.
- Development APK build thành công, SHA256 `447EC8D6F66155420AA0874430A98A962A00B33C02EF1B7A7AA57C405CE598F4`; đã cài trên Pixel_9_root.
- Đã xem `hud.png`, `pause.png`, `race/task4-results.png`, `restart.png`: chữ trong khung, không chồng nhau. Chơi tiếp, giữ ga, pause/restart và DUA LAI hoạt động; restart về countdown 2, vòng 1/2, thời gian 0.
- Lái hai ngón bằng script sẵn có: 02:03.400, Đồng, đủ 1-0 1-1 1-2 1-3 2-0 2-1 2-2 2-3; không reset, không Exception/FATAL trong race log. Kỷ lục cũ 02:00.800 vẫn hiển thị.
- Chưa build Release cho đợt UI này: `Builds/Android/racing-demo.apk` vẫn là bản cảnh vật trước đó. APK UI mới nằm ở `Builds/Android/racing-demo-development.apk`. Chưa kiểm tra UI trên Xiaomi 14; nghiệm thu máy thật Task 7 vẫn còn.

## Đợt APEX "Mùa Nắng" — Claude/Astra, sáng 17/09/2026 (bàn giao cho Codex lúc 10:15, chưa nghiệm thu)

Chạy theo `PLAN_APEX_MUA_NANG.md` (Astra + subagent chỉ đọc). Chỉ ghi những gì đã kiểm thật; phần còn lại là "đã viết code".

- **Đã kiểm (CLI):** diff Đợt 2 kế thừa từ phiên trước **không biên dịch** — `UiBuilder.cs:116/:202` gọi `BuildFestivalScreen`/`BuildAudioOptions` chưa viết (CS0103, `Artifacts/apex-mua-nang/dot0/generate.log`, 09:16). Runtime sạch, chỉ Editor + Tests.TrackEditMode hỏng. `.meta` cho 7 file mới và font BeVietnamPro đã được Unity sinh ở lần chạy này.
- **Đã kiểm (đọc code, ba agent chỉ đọc, báo cáo ở `Artifacts/apex-mua-nang/dot0/doi-chieu-*.md`):** cảnh đúng ngân sách (7 renderer mới ≤12, không collider/light, tắt bóng); luồng trạng thái/không Submit bản ghi dở/focus-pause/2 AudioSource đúng hợp đồng; UI thiếu thiệp lễ hội, widget âm thanh và "HUD gọn hơn".
- **Đã viết, CHƯA compile/test:** thiệp lễ hội 1320×800 + `BuildAudioOptions` + HUD bỏ Brand (agent A); lời An hai biến thể ở thiệp, ba nhánh ở Results; `FieldBinder.SetObjects`; validator kiểm mảng `_drivingGroups`/nhãn âm thanh; 3 test PlayMode focus/pause. Chi tiết và toạ độ ở `DECISIONS_APEX_MUA_NANG.md`.
- **Chưa kiểm chứng:** compile của code mới, validator, SceneStats, EditMode/PlayMode, ảnh Pixel 9, Xiaomi 14. Lần `generate` 10:11 thoát ngay vì project bị một tiến trình Unity khác (PID 27992, PlayMode) giữ khoá — không phải lỗi code.
- **Sai lệch có chủ ý:** #37 — Đợt 1 (agent `Plan` + phản biện chéo) gộp vào Đợt 2 vì ba agent bị ngắt bởi giới hạn usage; phản biện dồn vào Đợt 3. #38 — bẫy #11 (`Start-Process -Wait` treo vì VBCSCompiler mồ côi), đã sửa hàm mẫu ở AGENTS.md §6.
- **Việc tiếp theo:** xem khối đầu `HANDOFF.md`.

## APEX — Mùa Nắng: tiếp nhận Claude và kiểm chứng — 17/09/2026

Đã đối chiếu diff bàn giao: hai hàm UI thiếu trong log Đợt 0 đã được Claude bổ sung,
HUD rút gọn, lời An ở thiệp/kết quả, bind mảng đọc lại, test focus tích hợp.
Codex giữ các thay đổi và chạy lại chuỗi chính thức, không dùng kết quả mốc cũ thay thế.

- Compile + RebuildDemo: exit 0 (`generate-resume.log`).
- Validator exit 0; Task3Verification PASS 3/3: rebuild lặp, tuning byte/GUID và object ngoài cây.
  Semantic SHA256 `8A210C6959F2C96B66FDBD3A55082D0068F1DF3BB7E7B15051984E0F81724964`.
- XML: **150/150 EditMode, 35/35 PlayMode**, failed=0, skipped=0.
- CarConfig SHA256 `CC89720A65DEE06E09B249E560BCAB3280CD31C500A05DE3A6E0AF27E975B3DD`;
  TrackDefinition `8A65F64278622CAD3E39F8A9FEAF52B22A08796437175B7A29DEF098EDFCA2C8` — giữ nguyên.
- SceneStats: **308 renderer, 27.932 tam giác, 482 submesh, 48 material, 227 caster, 0 renderer thiếu mesh**.
  So baseline: +7 renderer, +696 tam giác, +18 submesh. Collider vẫn 12, checkpoint 4.
- Development APK build thành công: **63.105.163 byte**, SHA256
  `9200489FC44462039C4123C7D4B7C732BD784E738D449D46C4EE874BD1B39D89`.
- Đã cài đè Pixel_9_root: thiệp hiện kỷ lục cũ 02:00.800; UI đủ dấu,
  Pause/Về lễ hội hoạt động, giữ audio preference qua force-stop.
  Home/quay lại mở Pause, không tự resume. Lượt hai ngón đang kiểm tiếp.

Bằng chứng ở `Artifacts/apex-mua-nang/`, có ảnh trước từ mốc UI 15/09 và ảnh mới.
Chưa có số đo Xiaomi 14 cho bản này; không tuyên bố hoàn tất nghiệm thu máy thật.

### Chốt build sau review UI — Codex 17/09/2026

- Pixel_9_root đã chạy trọn hai vòng bằng mtinject: **01:54.116, Vàng**, đủ 8 cổng,
  không reset; `records-after-race.json` version 1, track ID giữ nguyên, thời gian 114.1166687.
- Ảnh bốn màn Pixel 9 và 16:9 đã xem; focus-return giữ Pause; audio settings sống qua force-stop.
- Sửa duy nhất sau lượt chạy: nới khoảng cách record/save/lời An ở Results, giữ rect nút.
  Thêm test lời lưu lỗi dài nhất không overflow/chồng nút và đủ glyph.
- Kiểm cuối: rebuild PASS 3/3, semantic SHA256
  `2EF618E6584F165207813E0747F8A7308955116AACD244EDC9C64E7B35AFE7FA`;
  **36/36 PlayMode**, failed=0/skipped=0 (`final-playmode.xml`). EditMode trước chỉnh layout 150/150.
- Development cuối: **63.105.163 byte**, SHA256
  `E7926C7923C8F169F5E473572E46F7A4461A9C99F8876CB1FB464DA8ADA6F8E3`.
- Release cuối: **31.265.279 byte**, SHA256
  `FE1F8FA53EF2B9340CAFB1AC207A341BBBE04F541346197871CF46695D0A660E`.
  Cả hai build exit 0; logs final-development/final-release.log.
- **Chưa kiểm thiết bị với APK cuối sau chỉnh spacing**; lượt hai ngón thuộc Development
  `9200489F…` ngay trước chỉnh spacing. Release cuối chưa cài/chạy.
- Phép thử records không ghi được trên emulator chưa chạy: auto-review từ chối toàn bộ
  lệnh vì usage limit (thông báo thử lại 15:08). Không có thao tác đổi/move records nào được thực thi.
  Lỗi lưu đã có Unity tests xanh; không gộp thành bằng chứng IL2CPP trên thiết bị.
- Còn: cài/kiểm APK cuối, lỗi lưu trên emulator (backup/restore), nghe audio thực tế,
  Xiaomi 14 15 phút ×2 và latency/cảm giác lái. Không tuyên bố hoàn tất toàn plan.

### Chuẩn bị cài Xiaomi 14 và commit theo yêu cầu người dùng

Đã đọc lại XML 150/150 EditMode và 36/36 PlayMode; Release SHA256 khớp
FE1F8FA53EF2B9340CAFB1AC207A341BBBE04F541346197871CF46695D0A660E.
Mọi asset mới có .meta. LiberationSans SDF được Unity nâng serialization khi import;
không sửa YAML bằng tay. Source diff check sạch. Chốt mốc APEX cùng generated scene/assets
và tài liệu phối hợp Claude/Codex. Chưa tính cài Xiaomi thành công: ADB chỉ thấy emulator,
mDNS chưa có dịch vụ; đang chờ IP:cổng Wireless debugging từ người dùng.

### Xiaomi 14 — đã cài Release cuối qua USB

Thiết bị xác nhận Xiaomi 14, serial 840c036a, Android 16. APK Release
31.265.279 byte, SHA256 FE1F8FA53EF2B9340CAFB1AC207A341BBBE04F541346197871CF46695D0A660E,
source commit c8fc81a. adb push + pm install -r trả Success; lastUpdateTime
2026-09-17 11:30:03. Đã mở app, PID 12466, màn lễ hội hiển thị tiếng Việt và
đọc được kỷ lục sẵn có trên máy 00:27.083 (không sửa/xóa dữ liệu).
Log khởi động không thấy FATAL/NullReference/InvalidOperation; có cảnh báo dò
AssetPackManager đã biết và NoSuchFieldException từ framework MIUI contentcatcher.
Ảnh/log ở Artifacts/apex-mua-nang/xiaomi14/release-launch.* (không commit ảnh có overlay app khác).
Đây là kiểm cài/khởi động, chưa phải nghiệm thu 15 phút hoặc cảm giác lái trên bản mới.

### 17/09/2026 tối — Xiaomi và sửa tiếng gió (Codex)

- Người chơi xác nhận hiệu năng ổn, tiếng ga ổn, nhạc nghe được ở lễ hội; yêu cầu chỉ xử lý tiếng gió rè khi tăng tốc. Không đổi tuning xe, nhạc hoặc ambience.
- Xác minh APK Xiaomi trước sửa bằng SHA256 trùng Release c8fc81a; thiếu nút nhạc là do đang ở Results (nút nằm ở lễ hội/Pause).
- Pixel_9_root chạy APK Development cuối trước sửa audio: 01:53.183/Vàng, đủ hai vòng và lưu record. Thử lỗi lưu chưa hoàn tất: autopilot dừng trên đường thẳng, ảnh có bảng volume Android phủ vùng ga. Đã khôi phục records byte-identical sau từng lượt; không ghi phép thử này đạt.
- Wireless Xiaomi đo Release cũ tới 670 giây thì Unity restart adb làm script dừng; console còn nhưng không có summary/CSV cuối. Có đoạn 0 frame, không coi đây là phép nghiệm thu 15 phút. Pin đầu 40%, 34,9°C, không sạc; cuối mẫu 37%, 33,8°C. Người chơi xác nhận cảm nhận hiệu năng ổn và chuyển ưu tiên sang audio; chưa có số đo 15 phút ×2 hợp lệ hoặc độ trễ chạm định lượng.
- Root-cause theo code: lớp nhiễu PRNG của EngineClipBuilder được trộn vào tiếng máy và cùng tăng pitch/volume theo tốc độ. Ambience FestivalAudio có âm lượng cố định theo màn. Bỏ riêng lớp PRNG, giữ hòa âm/nhịp nổ/peak 0,89 và EngineAudio.
- Regression test chu kỳ: bản cũ 4/5 pass, test mới fail đúng với sai khác 0,4658585 > 0,001. Bản sửa **151/151 EditMode**, failed=0, skipped=0. RebuildDemo và validator trong build đạt. Unity đã sinh WAV và scene; không sửa YAML tay.
- Release mới: `Builds/Android/racing-demo.apk`, **31.265.211 byte**, SHA256 `53B0FB6E8AE522D77AD8C9181519A594570E0F85C50051C4024AE5E00F6A6B2E`. Development chưa build lại, vẫn có nhiễu cũ.
- Bằng chứng: `Artifacts/audio-wind-fix/`; cần phân biệt test tín hiệu với xác nhận nghe thực tế trên Xiaomi. Không tuyên bố đã hết rè trước khi người chơi nghe bản mới.
- Sai lệch: tập trung bản sửa audio theo yêu cầu mới của người chơi, không tiếp tục ép đo hiệu năng. Bộ duyệt tự động chặn hoàn nguyên scene sau regenerate do rủi ro mất diff; giữ scene sinh bởi Unity và kiểm PlayMode thay vì vượt chặn.
- Kiểm cuối: **36/36 PlayMode**, failed=0, skipped=0. Cài và mở Release mới trên Pixel_9_root (ảnh lễ hội/kỷ lục 01:53.183) và Xiaomi 14 lúc **21:42:29**; hash base.apk Xiaomi trùng SHA APK ở trên. Records Xiaomi trước/sau có cùng SHA256 `5EB7A3F0A9768A4890AF4E693DD307250E54FB006BF462F2E096868F37FCBA27`, kỷ lục 00:27.083 giữ nguyên.
- **Người chơi xác nhận sau cài: “Đã hết rè, tiếng ga vẫn ổn”.** Vấn đề tiếng gió rè được chốt trên máy thật. CarConfig/TrackDefinition giữ hash `CC89720A…B3DD` / `8A65F642…CA2C8` như trước. Không mở rộng phạm vi điều chỉnh audio.

### 17/09/2026 — Chuẩn bị đẩy GitHub và rà soát việc tiếp theo

Người dùng đã cho phép commit và push lên GitHub. Commit code mới nhất `da766e5`; lúc bắt đầu cây sạch, chưa có remote. Kết nối GitHub nhận diện tài khoản WhiteY1n nhưng danh sách repo truy cập được rỗng; cần URL repo đích hoặc thông tin tạo repo từ người dùng, chưa push.
README được cập nhật đúng Release 31.265.211 byte/SHA 53B0FB6E…F6A6B2E, 151 EditMode +36 PlayMode, xác nhận âm thanh Xiaomi và giới hạn kiểm chứng. Việc tiếp theo: đồng bộ Development; hoàn tất phép thử lỗi ghi kỷ lục emulator; kiểm checkout sạch bản cuối; chốt phần checklist máy thật còn thiếu bằng chứng và bàn giao APK. Không mở lại tuning/âm thanh đã được chấp nhận; không tự tạo tag/release.
### 18/09/2026 — Đồng bộ Development và hoàn tất kiểm checkout sạch (Codex)

- Baseline `390e80e6f6ad673609c9b7170093184e067f8161`; chỉ cập nhật tài liệu bàn giao, không đổi gameplay, API/schema, tuning hoặc âm thanh. Theo yêu cầu người dùng, subagent thực hiện đọc bằng chứng/soạn công cụ/tài liệu, phiên chính điều phối và kiểm lại; không chạy hai Unity đồng thời.
- Development build 243 giây, **63.105.163 byte**, SHA256 `41FABBEF9E1AAAAEEA5456EF676C53D4412F4295A58611723715644E8A067D1E`; đã cài lên Pixel_9_root. Lượt ngày 18/09 chạy đủ 8 cổng/2 vòng **02:02.233, Đồng**, log `da luu=True`; records chứa 122.23333740234375 giây và đọc lại sau khởi động lại thành công (`writesDisabled=False`).
- Dữ liệu thử bình thường đã dọn và records gốc được khôi phục byte-identical: SHA256 trước/sau `780BF74CF410CF72D9FA8C5176A7869416B71969A0B9F18EED4662933C520665`. Bằng chứng `Artifacts/final-technical/device/normal-20260918-191551/`: log, records trước/sau, hashes và kết quả. Kết luận đọc lại dựa vào log khởi động.
- Checkout riêng `Artifacts/final-technical/clean-checkout`, source `390e80e`, không có Library ban đầu. Chuỗi generate → validator → rebuild → EditMode → PlayMode → Release đều exit 0; rebuild **PASS 3/3**, XML **151/151 + 36/36**, failed/skipped/inconclusive = 0. Semantic SHA256 `2EF618E6584F165207813E0747F8A7308955116AACD244EDC9C64E7B35AFE7FA`; giữ tuning và object ngoài cây generator.
- Hash CarConfig trước/sau `CC89720A65DEE06E09B249E560BCAB3280CD31C500A05DE3A6E0AF27E975B3DD`, TrackDefinition `8A65F64278622CAD3E39F8A9FEAF52B22A08796437175B7A29DEF098EDFCA2C8`; `.meta` cũng giữ nguyên. Clone còn diff scene do regenerate. Summary/log/XML ở `Artifacts/final-technical/clean-evidence/`.
- Release kiểm checkout riêng **31.265.311 byte**, SHA256 `D79318F161EB6A29D6DCB5B89AFF943E5FC814BD13753A4168CBB4EE7A009C15`; chưa cài/chạy APK này trên thiết bị. Release bàn giao không bị ghi đè: **31.265.211 byte**, SHA256 `53B0FB6E8AE522D77AD8C9181519A594570E0F85C50051C4024AE5E00F6A6B2E`.
- Thử lỗi ghi kỷ lục r2 **đạt** (`device/storage-20260918-191837/`): hai lượt **01:59.500 / 02:00.466, Đồng**, log đều `da luu=False`; phiên chính đã xem ảnh thông báo **“Không lưu được kỷ lục”**, kiểm Đua lại bắt đầu lượt mới và Về lễ hội hoạt động. Result `STORAGE_FAILURE_FLOW_PASSED`; records khôi phục byte-identical SHA256 `780BF74CF410CF72D9FA8C5176A7869416B71969A0B9F18EED4662933C520665`. Lượt trước bị Unity restart adb ngắt không tính đạt.
- Vòng đời Development **đạt** (`Artifacts/final-technical/lifecycle/`): pause thủ công/chơi tiếp, Home/quay lại vẫn Pause và không tự resume, trở lại lễ hội. Phiên chính đã xem ảnh; tùy chọn effects OFF ở audio-options/manual-pause và ON ở audio-persist-final sau force-stop, thay đổi/lưu tùy chọn đúng.
- **Ba việc kỹ thuật đã hoàn tất.** Chất lượng âm nghe trực tiếp Development chưa đánh giá; kiểm tùy chọn không thay thế nghe thực tế. Xác nhận hết rè/tiếng ga ổn trên Xiaomi là phản hồi bản Release phiên trước. APK checkout riêng chưa cài/chạy trên thiết bị.
- Không đo lại Xiaomi theo phạm vi đã chốt; hiệu năng 15 phút ×2, latency định lượng và phần checklist máy thật còn thiếu vẫn chưa kiểm chứng. Không tự push/tag.

### 18/09/2026 — Gói bàn giao cục bộ (Codex)

- Đã tạo `Artifacts/APEX-Mua-Nang-delivery-20260918.zip`: **74.641.199 byte**, SHA256 `B73F7FA9BB19095A917E992C2F44BE965E3E21662ECABB4F4E14BD01EFF62800`.
- Gồm Release đã xác nhận, Development đồng bộ, source snapshot `c68cf3c` (595 file tracked, asset LFS đầy đủ, không Library/.git), XML 151/36, báo cáo rebuild, ảnh kết quả/lỗi lưu/Home-return, START-HERE, ACCEPTANCE và SHA256SUMS. Kiểm từng file trong ZIP trùng hash bản gốc; không kèm file records riêng.
- APK Release kiểm checkout D79318F1… chỉ được nhận diện trong báo cáo, không kèm gói; Release bàn giao vẫn 53B0FB6E…F6A6B2E. Không build/test lại vì code không đổi.
- ADB chỉ thấy Pixel 9; checklist Xiaomi còn thiếu ghi trong ACCEPTANCE, không nhận đã nghiệm thu máy thật đầy đủ. Không push/tag hoặc phát hành trực tuyến.
