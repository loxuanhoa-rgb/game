# HANDOFF.md — Bàn giao cho agent tiếp theo
> **Bàn giao cục bộ 18/09:** gói `Artifacts/APEX-Mua-Nang-delivery-20260918.zip` đã kiểm hash, gồm APK/source c68cf3c/bằng chứng/checklist; SHA256 `B73F7FA9BB19095A917E992C2F44BE965E3E21662ECABB4F4E14BD01EFF62800`. Chưa phát hành trực tuyến. Việc còn lại là checklist máy thật nếu người dùng muốn nghiệm thu đầy đủ; không tự đo lại/push/tag.
> **Codex 18/09 — trạng thái hiện tại, ưu tiên hơn mọi khối lịch sử bên dưới.**
> Mốc này chỉ cập nhật tài liệu README/PROGRESS/HANDOFF; source build `390e80e`. Ba việc kỹ thuật đã hoàn tất.
> Development đồng bộ audio: 63.105.163 byte, SHA `41FABBEF…A067D1E`. Pixel 9 đã chạy đủ hai vòng **02:02.233 / Đồng**, lưu và đọc lại sau khởi động lại đạt.
> Records gốc được khôi phục byte-identical SHA `780BF74C…520665`; bằng chứng `Artifacts/final-technical/device/normal-20260918-191551/`.
> Checkout sạch không Library: generate/validator đạt, rebuild PASS 3/3, **151/151 EditMode + 36/36 PlayMode**, build Release đạt; tuning/meta trước-sau trùng hash.
> APK checkout riêng 31.265.311 byte, SHA `D79318F1…009C15`; chưa cài/chạy APK này. Release bàn giao SHA `53B0FB6E…F6A6B2E` giữ nguyên.
> Thử lỗi lưu r2 đạt: hai lượt Đồng 01:59.500 / 02:00.466 đều báo không lưu được, Đua lại/Về lễ hội hoạt động; records restore trùng SHA gốc.
> Pause/chơi tiếp, Home/return giữ Pause không tự resume, tùy chọn âm thanh OFF/ON lưu qua force-stop đạt. Chất lượng âm nghe trực tiếp Development chưa đánh giá; xác nhận nghe hết rè trên Xiaomi thuộc Release phiên trước.
> Không đổi gameplay/tuning/nhạc, không đo lại Xiaomi, không tự push/tag. Kết quả và SHA đầy đủ ở mục cuối PROGRESS.

> **Codex 17/09 tối — sửa tiếng gió theo phản hồi Xiaomi (ưu tiên khối này).**
> Người chơi xác nhận hiệu năng ổn và nhạc có nghe ở lễ hội; chỉ yêu cầu sửa tiếng gió rè khi nhanh.
> Diff phiên này: EngineClipBuilder bỏ nhiễu PRNG trong clip động cơ, test chu kỳ và WAV do Unity sinh;
> giữ hòa âm/đường cong âm lượng/cao độ và nhạc/ambience. Đã 151/151 EditMode, 36/36 PlayMode, generate/validator/build Release đạt.
> Release đã cài Pixel9 và Xiaomi (21:42:29); SHA 53B0FB6E…F6A6B2E, records Xiaomi byte-identical.
> **Người chơi xác nhận bản mới: “Đã hết rè, tiếng ga vẫn ổn”.** Development còn là bản cũ có nhiễu.
> Pixel9 bản trước sửa âm thanh đã chạy đủ hai vòng 01:53.183/Vàng và lưu record.
> Thử lỗi lưu chưa hoàn tất (autopilot bị ngắt; ảnh có bảng volume Android đè vùng ga), record đã restore byte-identical.
> Đo Wireless Release cũ bị ngắt ở 670 giây khi Unity khởi động lại adb; chỉ còn console.log, không có tổng kết 15 phút.
> Có đoạn 0 frame nên không dùng để tuyên bố nghiệm thu định lượng. Người chơi đã chốt không cần tiếp tục đo, ưu tiên âm thanh.

> **Codex cập nhật cuối 17/09 — ưu tiên khối này hơn ghi chú Claude bên dưới.**
> Đã review diff và kiểm 150 EditMode, 36 PlayMode, rebuild PASS 3/3; build cả hai APK cuối.
> Pixel 9 đã chạy hai ngón 01:54.116/Vàng, kỷ lục đã lưu; ảnh bốn màn ở Pixel9/16:9,
> focus/Pause/Return/settings đạt. Sau đó chỉnh spacing Results và thêm test, đã build lại.
> **Release cuối đã cài và mở trên Xiaomi 14 qua USB**, source c8fc81a; xem cuối PROGRESS. Trước đó auto-review chặn lệnh thử lỗi lưu
> nên phép thử lỗi lưu emulator chưa thực thi, records emulator còn nguyên. Chi tiết SHA/log ở cuối PROGRESS.
> Tiếp tục: kiểm APK cuối trên Pixel9, thử lỗi lưu với backup/restore, nghe audio, nghiệm thu Xiaomi14.
> Không chạy lại test xanh nếu source không đổi. Không tạo tag/push. Đợt APEX được chốt commit theo yêu cầu người dùng; ghi chú diff chưa commit bên dưới là lịch sử trước mốc này.


Cập nhật: **17/09/2026**. Quy tắc làm việc và phối hợp nhiều agent nằm ở [AGENTS.md](AGENTS.md) (Claude Code nạp qua `CLAUDE.md`); file này chỉ ghi hiện trạng và việc tiếp theo.

> **Diff chưa commit trong working tree — đợt APEX "Mùa Nắng", Đợt 2 (17/09/2026, Claude/Astra bàn giao cho Codex lúc 10:15).**
> Gồm 13 file `.cs` sửa + 7 file mới của đợt trước (nay đã có `.meta` do Unity sinh lúc import) và phần Claude làm sáng 17/09:
> `UiBuilder.cs` (hai hàm từng thiếu `BuildFestivalScreen`/`BuildAudioOptions`, HUD bỏ Brand, ClockCard 470×120, Pause Hint 600), `FestivalPresenter.cs` (`_messageLabel`, lời An hai biến thể, nhãn chữ hoa), `ResultsPresenter.cs` (lời An ba nhánh), `FieldBinder.cs` (`SetObjects` bind mảng có đọc lại), `DemoProjectGenerator.cs` (`_drivingGroups` qua `SetObjects`), `SceneValidator.cs` (`RequireReferenceArray` cho `_drivingGroups` ≥6, `FestivalPresenter._musicLabels/_effectsLabels` ≥1, `_recordLabel`), `RaceLoopSceneTests.cs` (+3 test focus/pause: `LosingFocusWhileRunningPausesRaceAndSuspendsSceneAudio`, `BackgroundingWhileRunningPausesAndReturningDoesNotResume`, `FocusLossAtFestivalAndResultsOnlySuspendsAudio`), `DECISIONS`/`PLAN`/`AGENTS.md` §6.
> **Trạng thái:** phiên Claude chỉ có bằng chứng `Artifacts/apex-mua-nang/dot0/generate.log` (09:16, bản trước khi sửa: 2 lỗi CS0103, Runtime sạch); lần `generate` của Claude lúc 10:11 (`dot2/generate-r1.log`) thoát ngay exit 1 vì project bị khoá. **Một chuỗi Unity khác — không do phiên Claude khởi động — đã chạy 10:09–10:13 trên đúng code này** và để kết quả ở `Artifacts/apex-mua-nang/` (thư mục gốc): `generate-resume.log` exit 0; `rebuild-verification.txt` PASS 3/3 (SHA `8A210C69…`); `scene-stats.txt` **308 renderer / 27.932 tam giác / 482 submesh** (= baseline 301 + 7 đúng như B đếm); `editmode.xml` **150/150**, `playmode.xml` **35/35** (28 cũ + 2 festival + 2 audio + 3 focus), failed=0; `build-development.log` đang chạy lúc bàn giao (Unity PID 26684). Claude chưa tự đọc lại `validate.log` từng dòng và chưa xem ảnh nào — coi số trên là **bằng chứng của lượt chạy ngoài phiên**, Codex đọc lại XML/log trước khi dựa vào.
> **Codex làm tiếp (theo thứ tự):** (1) `tasklist | findstr Unity` — chờ build 26684 xong, không mở Unity thứ hai; (2) đọc lại `Artifacts/apex-mua-nang/{validate.log,editmode.xml,playmode.xml,scene-stats.txt}`; nếu nghi ngờ thì chạy lại generate → validate → SceneStats → EditMode → PlayMode và **đọc XML**; (3) sửa lỗi compile/test nếu có — file nào của ai xem bảng sở hữu trong DECISIONS, Codex làm một mình thì tự sửa nhưng ghi rõ; (4) Đợt 3 review theo PLAN §4 (Codex tự review thay reviewer A/B/C: đọc diff tích hợp, kiểm hợp đồng DECISIONS); (5) Đợt 4 trên `Pixel_9_root` đang chạy sẵn (6 GB, app bản cũ đã cài): chụp thiệp lễ hội/HUD/Pause/Results, kiểm hai ngón, mất focus, Về lễ hội, nút nhạc/âm thanh đổi chữ; hai điểm B cần ảnh: cụm Đồi Thông mới có chồng cụm cây Kenney (DecorBuilder.cs:129-132) không, nhãn pit "HẸN VÒNG SAU" có lọt khung hình không; (6) chưa build Release; chưa commit — chỉ commit khi generate/validate/test xanh (trailer Codex).
> Không revert diff. Hàm `Invoke-DemoUnity` trong AGENTS.md §6 đã đổi sang `-PassThru` + `WaitForExit()` (bẫy #11).

Mốc đã commit gần nhất: `1a7797d` (UI, 15/09). VenueDetails tại `d538e8e`: 145/145 EditMode, 28/28 PlayMode, rebuild/validator đạt, chạy đủ hai vòng trên Pixel 9. Xem phần cuối `PROGRESS.md`.

**Môi trường chạy chính là emulator Pixel 9**; Xiaomi 14 chỉ dùng một lần ở cuối dự án (sai lệch #18 trong `PROGRESS.md`). Thứ tự đọc: AGENTS.md → file này → [PROGRESS.md](PROGRESS.md) (bảng tổng quan + mục cuối) → DECISIONS/PLAN đợt APEX → [GAME_DESIGN.md](GAME_DESIGN.md) khi đụng thông số. Yêu cầu gốc đầy đủ nằm ở [2026-09-06-android-racing-demo.md](2026-09-06-android-racing-demo.md) — **kế hoạch đó là nguồn sự thật, tài liệu này không thay thế nó**.

> **Cập nhật hình ảnh 14/09/2026:** đã triển khai APEX / Golden Hour theo yêu cầu mới. Xem mục cuối `PROGRESS.md` và `GAME_DESIGN.md` 9.3. Generator mới `FestivalVisuals` sở hữu skybox, material xe/nhựa, núi, viền đua và biển. Không thay tuning/luật đua. Số hiệu năng bản cũ không đại diện cho bản hình ảnh mới; vẫn cần nghiệm thu Xiaomi 14.
## 1. Dự án là gì

Demo game đua xe 3D Android cho môn học, làm bằng Unity + URP. Một xe, một đường đua khép kín, countdown 3 giây, chạy 2 vòng qua 4 checkpoint đúng thứ tự, xem thời gian + huy chương, lưu kỷ lục trên máy. Chơi offline, không quảng cáo, không tài khoản.

Thư mục làm việc: `D:\Android\3d-android-game`. Git đã init, branch `main`, **chưa có remote** — không tự push.

## 2. Trạng thái hiện tại

| Task | Trạng thái |
|---|---|
| 1 — Dự án + APK đầu tiên | ✅ đạt trên emulator và **đã chạy trên Xiaomi 14** |
| 2 — Xe, camera, điều khiển | ✅ đã tune theo người chơi thật (ma sát rào 0,2, FOV theo tốc độ, thanh lái analog — người chơi xác nhận ổn) |
| **3 — Đường đua + công cụ dựng** | ✅ đạt chức năng trên emulator: trọn vòng qua nút màn hình bằng cả một điểm chạm lẫn hai ngón, test/rebuild/APK đạt |
| 4 — Vòng chơi, pause, reset, kết quả | ✅ RaceDirector, HUD/pause/results đầy đủ; đã chạy trọn 2 vòng trên Pixel 9 |
| 5 — Kỷ lục | ✅ JSON lưu lần đầu/cập nhật và force-kill đạt trên IL2CPP Pixel 9 |
| **6 — Hình ảnh, âm thanh** | ✅ model Kenney, 68 vật trang trí, thảm cỏ, tiếng động cơ, cấu hình URP, ngưỡng huy chương chốt từ 12 lượt; 118 EditMode + 26 PlayMode |
| 7 — Nghiệm thu, bàn giao | 🟡 máy thật đã cắm, app chạy; **còn checklist 9 mục, đo 15 phút ×2 bản, độ trễ chạm, huy chương người thật, tag** |

### Đã có và đã chạy đúng

- `RacingDemo.Core` — toàn bộ luật đua, huy chương, kỷ lục, và `MedalThresholdCalibrator` (hàm thuần tính ngưỡng huy chương). C# thuần, `noEngineReferences: true`. **Tổng mới nhất: 118 EditMode và 26 PlayMode.**
- `RacingDemo.Runtime` — `AppBootstrap`, `CarConfig`, `CarController`, `ChaseCamera`, `HoldButton`, `TouchControlPad`, `CarInputRelay`, `RaceDirector`, `HudPresenter`, `PausePresenter`, `ResultsPresenter`, `EngineAudio` + `EngineAudioCurve`, `JsonRecordRepository` + `JsonFileStore`.
- `RacingDemo.Editor` — `DemoEditorPaths`, `FieldBinder`, `CarBuilder`, `UiBuilder`, `DemoProjectGenerator`, `SceneValidator`, `BuildCommand`, `ProjectSetup`, `TrackBuilder`, `DecorBuilder`, `KenneyKit`, `EngineClipBuilder`, `RenderQualitySetup`, `MedalCalibration`, `FixedTimestepSetup`.
- Đã chơi thử trên emulator Pixel 9: xe chạy/rẽ được, RESET đưa xe về đúng chỗ và camera snap đúng, Pause/Resume đúng, ra Home rồi quay lại thì tự pause và không tự resume.
- Task 3 đã có `TrackDefinition`, `StadiumGeometry`, `CheckpointVolume`, `RespawnService`, `TrackBuilder`, `TrackSceneValidation`, `Task3Verification`; đường/rào là ba mesh collider tĩnh liên tục. Core không đổi.
- Ở mốc Task 3, Unity **75/75 EditMode + 10/10 PlayMode** pass (đã đọc XML); số hiện tại là 118 + 26. Rebuild hai lần giữ JSON/byte/GUID tuning và object ngoài cây/ID đã lưu. Bản source không Generated/Race/Library dựng đủ bằng một lệnh. Xem các log `Artifacts/task3-*` và chi tiết trong `PROGRESS.md`.
- `PrototypeDirector` đã xóa. `RaceDirector` sở hữu vòng chơi/timeScale/input; kết quả được chốt trong bước vật lý và hiển thị ở Update. Kỷ lục dùng `JsonRecordRepository` + `JsonFileStore`, lưu `persistentDataPath/records.json`.

### Chưa có

- **Task 7**: chạy bộ kiểm tra mục 8 của kế hoạch, build Release APK, dựng lại từ checkout sạch, tag `demo-v1`.
- **`CarConfig` chưa tune.** Task 6 yêu cầu chỉnh theo phản hồi khi chơi; lái tự động không thay được cảm giác lái của người nên việc này để lại cho lượt Xiaomi 14.
- Cảm giác lái, FPS/frame time và độ trễ chạm. Xiaomi 14 chỉ dùng một lần ở cuối dự án (sai lệch #18); hai ngón thật đã kiểm trên emulator và đạt.
- **Ngưỡng huy chương đang lấy từ lái tự động**, không phải từ người chơi — cần đo lại ở lượt máy thật.

## Việc tiếp theo — phần còn lại của Task 7 (cần máy thật)

Task 6 đã xong: xe dùng model Kenney (CC0, nguồn/giấy phép trong `Assets/ThirdParty/KenneyRacingKit/README.md`), 68 vật trang trí không collider quanh đường, thảm cỏ không collider, tiếng động cơ tự sinh (`Assets/Generated/Audio/EngineLoop.wav`) và cấu hình URP theo kế hoạch. Lượt nghiệm thu mới nhất (sau khi sửa bước vật lý ở Task 7) đạt **01:54.650 → Huy chương Vàng**, kỷ lục mới đã lưu.

Ba điều cần nhớ khi làm tiếp:

1. **`TrackDefinition` giờ chứa ngưỡng đã tune.** Generator không ghi đè (đã kiểm bằng SHA256 sau hai lần rebuild), nhưng chỉ đổi ngưỡng qua `MedalCalibration`, đừng sửa YAML.
2. **Trang trí phải nằm ngoài mặt đường và không có collider** — `SceneValidator.ValidateDecor` kiểm bằng bao hình thật, và có bộ test riêng cố tình làm hỏng từng điều kiện.
3. **Ngưỡng huy chương là số của lái tự động.** Khi có người chơi thật trên Xiaomi 14 thì đo lại và cân nhắc chỉnh.

**Đã xong trên máy này** (xem mục Task 7 trong `PROGRESS.md`): bộ kiểm tra mục 8 (122 EditMode + 28 PlayMode), sửa sai lệch bước vật lý 50 Hz → 60 Hz, hiệu chỉnh lại ngưỡng huy chương theo vật lý mới, dựng lại toàn bộ từ một checkout sạch, build Release APK và chạy thử nó trên emulator, viết `README.md` bàn giao.

**Lượt Xiaomi 14 phiên 1 (13/09) đã làm:** cắm máy, cài và chạy Release APK, đo thử frame time 30 s (~60 FPS, P95 24 ms), thu phản hồi người chơi và sửa 4 thứ (ma sát rào 0,2, nhãn UNSTUCK, FOV theo tốc độ, thanh lái analog). Chi tiết + bẫy khi cắm máy ở mục cuối `PROGRESS.md`.

**Còn lại (làm trên Xiaomi 14, theo thứ tự):**

1. ~~Thanh lái~~ — người chơi đã xác nhận ổn (nhạy vừa, bám tay, không kẹt). Không chỉnh.
2. **Build lại Development APK** (bản trong `Builds/` đã lỗi thời so với source).
3. Checklist 9 mục "Xiaomi 14 — vòng chơi và vòng đời ứng dụng" (mục 8 kế hoạch) trên APK cuối: 10 lượt liên tiếp, khoá màn hình / chuyển app, bấm đúng tâm nút, nhả/rê ngón ra ngoài nút.
4. Đo 15 phút ×2 (Release và Development) bằng `Tools/perf/frametime-sample.ps1`; ghi pin, sạc, refresh rate; điền bảng `GAME_DESIGN.md` mục 9.
5. Độ trễ chạm — nếu chưa đo được thì ghi "chưa kiểm chứng", **không** ghi con số suy đoán.
6. `CarConfig` người chơi thấy ổn, **không** tune thêm nếu không có phản hồi mới.
7. Người chơi thật chạy ≥5 lượt → soát ngưỡng huy chương (đang là số của lái nút tự động; thanh lái analog có thể làm lượt nhanh hơn).
8. Sau khi tất cả đạt: tạo tag `demo-v1`. **Không tự push lên remote.**

Cách nối máy (đã chạy được): bật *USB debugging* + *Install via USB* (cần tài khoản Mi); USB hay rớt khi truyền file lớn nên dùng `adb tcpip 5555` + `adb connect <IP máy>:5555`; cài bằng `adb push … /data/local/tmp/` rồi `adb shell pm install -r`; **sau mỗi lần Unity build phải `adb connect` lại** vì Unity khởi động lại adb server.

Ngưỡng huy chương hiện tại (sau khi sửa bước vật lý): gold **115,618 s** / silver **117,758 s** / bronze **134,750 s**, đo từ 12 lượt lái tự động ở vật lý 60 Hz.

## Trạng thái VenueDetails và việc còn lại (15/09/2026)

Đã hoàn thành tại commit `d538e8e`: ba pit, tháp Race Control, podium, 45 khán giả, 24 cụm cây bụi và 10 cờ. Đã sửa lỗi 15 nhãn bake mất MeshFilter khi lưu scene, thêm hai test chống hồi quy và lệnh `SceneStats.Report`. Bằng chứng đầy đủ trong `Artifacts/venue-verify/` và phần cuối `PROGRESS.md`.

- Rebuild ×2, validator, Task3Verification đều đạt; tuning giữ nguyên byte/GUID và object ngoài cây được giữ.
- 145/145 EditMode, 28/28 PlayMode. Development chạy đủ hai vòng: 02:00.800, huy chương Đồng, không reset.
- Cả hai APK đã build. Release: 30.782.454 byte, SHA256 `9FC46FB1EF5EABCF50BB6DE231E016003504B1ED55F1702692D02768F5BA650F`.
- Cảnh hiện tại: 301 MeshRenderer, 27.236 tam giác, 464 submesh trước batching; cần đo lại FPS/frame time trên Xiaomi 14.

Còn lại cho nghiệm thu toàn dự án:

1. Hoàn tất chuỗi checkout sạch cho mốc mới. Lượt trong `Artifacts/venue-verify/clean/` chỉ có generate exit 0; log validate bị ngắt, chưa có bằng chứng validate/test/build đạt. Không coi chuỗi này đã xong.
2. Dọn các project tạm của phiên trước sau khi kiểm tra đúng đường dẫn và chắc chắn không còn cần dùng.
3. Thực hiện các mục Xiaomi 14 phía trên với APK mới nhất. Không tune xe/huy chương hoặc cắt cảnh nếu chưa có phản hồi/số đo mới.
## 3. Ràng buộc bắt buộc — vi phạm là phải sửa lại

Bản đầy đủ (kèm quy tắc phối hợp nhiều agent, `.meta`, trailer commit) ở `AGENTS.md` mục 0, 3, 4. Tóm tắt:

1. **Ranh giới assembly.** `RacingDemo.Core` **không được** dùng `UnityEngine`, `UnityEditor`, `System.IO`, `JsonUtility`, `ScriptableObject` hay đồng hồ hệ thống. Mọi cập nhật thời gian đi qua `Tick(float deltaSeconds)`. Runtime chuyển cấu hình Unity thành số thuần trước khi đưa vào Core. Core chỉ nhận **số lượng checkpoint** và cấu hình luật đua — không nhận `Transform` hay `Vector3`.
2. **Không sửa YAML của scene/prefab/ScriptableObject bằng tay.** Mọi thay đổi đi qua `DemoProjectGenerator` hoặc Inspector.
3. **Generator chỉ sở hữu** `Assets/Generated`, `Assets/Scenes/Race.unity` và cây `__GeneratedScene` trong scene. Đồ người dùng tự thêm phải nằm ngoài cây đó và không được đụng tới.
4. **Không ghi đè asset đã tune.** `CarConfig` và `TrackDefinition` chỉ được tạo khi chưa có. Rebuild hai lần phải ra kết quả giống hệt lần đầu — không nhân đôi camera, đèn, EventSystem, collider hay AudioListener.
5. **Không đánh dấu hoàn thành khi chưa chạy thật.** Số test xanh không thay cho chơi thử. Nếu chưa kiểm chứng được thì ghi vào `PROGRESS.md` là chưa kiểm chứng, đừng ghi là xong.
6. **Đóng Unity Editor trước khi chạy Unity CLI** trên cùng project. Không mở hai tiến trình Unity cùng một project.
7. **Không tự push lên remote**, không tự tạo tag.

## 4. Mười cái bẫy đã mất thời gian — đừng dẫm lại

1. **`OpenScene`/`NewScene` gọi `Resources.UnloadUnusedAssets`.** Asset vừa `LoadAssetAtPath` mà chưa ai tham chiếu sẽ bị unload thành "fake null". Đọc field C# thuần của nó **vẫn ra giá trị đúng** nên không có exception nào, nhưng gán vào `SerializedProperty` thì ghi ra `fileID: 0` → reference null im lặng trong scene. **Luôn load asset SAU khi mở scene.** (Material thoát nạn chỉ vì `EditorUtility.SetDirty` giữ chúng lại.)
2. **`FieldBinder` đọc lại mọi reference sau khi Apply và ném lỗi nếu lệch.** Giữ nguyên cơ chế này khi thêm component mới — chính nó phát hiện bẫy #1.
3. **Import package trong batch mode là bất đồng bộ và kéo theo domain reload.** Không được chờ bằng `EditorApplication.update`: delegate bị huỷ đăng ký nên cả vòng chờ lẫn timeout đều chết và Unity batch treo vĩnh viễn. Cách đúng: import ở một phiên Unity, xác nhận ở phiên sau (xem `ProjectSetup.cs`).
4. **Package thừa của template có thể phá runtime.** `com.unity.dt.app-ui` (đi kèm `com.unity.ai.inference`) gọi `EnhancedTouchSupport.Enable()` trong bản build, làm `InputSystem.onDeviceChange` ném `ArgumentException: 'InputUpdateType.None' is not a valid update mask` liên tục. Đã gỡ 7 package không dùng. **Đừng thêm package mới nếu không thực sự cần**, và nếu thêm thì phải chạy thử lại trên thiết bị.
5. **AVD mặc định 2 GB RAM không đủ** cho game Unity — Android giết app giữa lúc load mà không để lại lỗi Unity nào (chỉ thấy `lowmemorykiller` trong logcat hệ thống). Chạy emulator với `-memory 6144`.

6. **Muốn bơm hai ngón vào emulator thì phải tự dựng thiết bị cảm ứng — đừng dùng thiết bị sẵn có.** Thiết bị `virtio_input_multi_touch_N` của emulator khai `BTN_STYLUS`/`BTN_TOOL_RUBBER`, nên Android gắn thêm nguồn `STYLUS`, Unity đẩy vào nhánh bút và ném `Unhandled pen event action: 5/6` rồi bỏ **cả hai** con trỏ (đây cũng là gốc lỗi gRPC mà phiên trước gặp). Cách chạy được: `Tools/mtinject/mtinject.c` tạo thiết bị `/dev/uinput` chỉ khai `BTN_TOUCH`, cần AVD `Pixel_9_root` + `adb root` + `setenforce 0`. **Binary phải link `-Wl,-z,max-page-size=16384`** — ảnh `ps16k` dùng trang 16 KB, binary căn 4 KB segfault lúc nạp mà không in gì. Cách dùng đầy đủ ở `Tools/mtinject/README.md`.
7. **Giữ hết lái ở tốc độ cao thì xe ghim vào rào trong đúng một giây.** Game chỉ có lái kiểu nút; giữ nút lái liên tục ở 40 km/h làm xe cắt ngang mặt đường 12 m. Tôi đã đọc nhầm chuyện này thành "ngón thứ hai ngắt ga" một lần rồi. Muốn lái tự động thì phải **nhấp** lái theo độ lệch, ga giữ riêng bằng ngón kia — xem `Artifacts/verify/mt-lap.ps1`.

8. **Model Kenney không dùng thẳng được: sai hướng và sai tỉ lệ.** Xe `raceCarRed.fbx` quay đầu về **−Z** (kiểm bằng vị trí node bánh trước/sau), gốc toạ độ không nằm ở tâm trục bánh, và tỉ lệ của bộ Kenney không khớp mét thật (xe dài 13,46 đơn vị còn hàng rào dài 10 đơn vị = 5 m). `CarBuilder` vì vậy chuẩn hoá theo **hình học của mình** — tỉ lệ lấy từ chiều dài cơ sở của WheelCollider, gốc dời về tâm bốn bánh, xoay 180°, bánh thu riêng về `CarConfig.WheelRadius`. Khán đài, cột đèn và biển quảng cáo cũng hướng mặt về −Z nên cần góc quay bù 180°. **Đừng "sửa" bằng cách chỉnh file FBX** — sửa ở generator.

9. **Không đặt tên tham số PowerShell là `$args`.** `function Run($name, $args)` hay `param([string[]] $args)` bị biến tự động `$args` đè lên, splat `@args` ra rỗng → Unity được gọi **không có `-quit`** và treo mở project (đã mất một lần 10 phút và phải kill tiến trình). Dùng `$extra`, `$cmd`.
10. **HyperOS chặn `adb install` im lặng và USB rớt khi truyền file lớn** — xem mục Xiaomi 14 trong `PROGRESS.md`; đường chạy được là adb Wi‑Fi + `pm install` trên máy.
11. **`Start-Process -Wait` treo vô hạn khi Unity thoát vì lỗi compile.** `-Wait` chờ cả tiến trình con; Unity để lại `VBCSCompiler` (`dotnet.exe`) mồ côi nên script không bao giờ trả về dù Unity đã exit 1. Dùng `$p = Start-Process ... -PassThru` rồi `$p.WaitForExit()` (chỉ chờ đúng Unity). Gặp khi chạy chuỗi Đợt 0 APEX 17/09.

Ngoài ra: Unity 6000.6.0f1 dùng `ApiCompatibilityLevel.NET_Standard` (không còn `NET_Standard_2_1`), `Rigidbody.linearVelocity`/`linearDamping`/`angularDamping` (không còn `velocity`/`drag`/`angularDrag`), và uGUI 2.6 **đã có sẵn** `UnityEngine.UI.SafeArea` — đừng tự viết lại.

## 5. Đường đua (Task 3) — đã xong, chỉ tra cứu

Sân vận động: hai đoạn thẳng 80 m + hai nửa tròn bán kính tim 30 m, mặt đường 12 m, tim ≈ 348,5 m; bốn cổng cách nhau ≈ 87,1 m, **cổng index 3 là vạch kết thúc vòng**. Toàn bộ checklist Task 3 đã đạt và được chạy lại độc lập (rebuild ×2, `Task3Verification`, validator, test, APK, checkout sạch, lái trọn vòng); chi tiết ở `PROGRESS.md` mục "Task 3" và thông số ở `GAME_DESIGN.md`. Không viết lại `TrackDefinition`, `StadiumGeometry`, `CheckpointVolume`, `RespawnService`, `TrackBuilder`.

## 6. Lệnh hay dùng

Đường dẫn và toàn bộ lệnh nằm ở [AGENTS.md](AGENTS.md) mục 6 (Unity CLI) và mục 7 (emulator). Tóm tắt:

```powershell
$unityExe = 'D:/UnityHub/6000.6.0f1/Editor/Unity.exe'
$root = 'D:/Android/3d-android-game'
$adb = "$env:LOCALAPPDATA/Android/Sdk/platform-tools/adb.exe"
```

| Việc | Lệnh |
|---|---|
| Dựng demo | `-batchmode -quit -nographics -projectPath $root -executeMethod RacingDemo.EditorTools.DemoProjectGenerator.RebuildDemo -logFile Artifacts/generate.log` |
| Kiểm scene | `... -executeMethod RacingDemo.EditorTools.SceneValidator.ValidateBuildScenes -logFile Artifacts/validate.log` |
| Test EditMode | `-batchmode -buildTarget StandaloneWindows64 -nographics -runTests -testPlatform EditMode -testResults Artifacts/editmode-results.xml -logFile Artifacts/editmode.log` (**không** thêm `-quit`) |
| Build APK dev | `... -buildTarget Android -executeMethod RacingDemo.EditorTools.BuildCommand.BuildAndroidDevelopment -logFile Artifacts/build-development.log` |
| Emulator | `emulator -avd Pixel_9 -memory 6144 -no-snapshot-load -no-boot-anim` rồi `adb install -r ./Builds/Android/racing-demo-development.apk` |

Sau khi chạy test, **đọc file XML**: exit code 0 với 0 test là thất bại, không phải thành công.

Chơi thử bằng adb: `adb shell input tap X Y` (bấm), `adb shell input swipe X Y X Y 3000` (giữ 3 giây), `adb shell screencap -p /sdcard/s.png` + `adb pull` (chụp màn hình).

Muốn thử nhanh Core mà không cần Unity: `RacingDemo.Core` + test EditMode là C# thuần + NUnit, biên dịch được bằng .NET SDK 8 tại `C:\Users\VuIT\.dotnet` (đặt `LangVersion 9.0` cho khớp mức Unity 6 hỗ trợ). Project tạm để ngoài repo.

## 7. Kết thúc mỗi phiên

1. Cập nhật `PROGRESS.md`: đã xong gì, còn lỗi gì, việc tiếp theo. Ghi cả phần **chưa** kiểm chứng.
2. Ghi sai lệch so với kế hoạch gốc vào mục "Sai lệch" của `PROGRESS.md`.
3. Cập nhật `GAME_DESIGN.md` nếu thông số hoặc luật chơi đổi.
4. Commit mốc chạy được, trailer `Co-Authored-By` theo agent (`AGENTS.md` mục 0). Còn diff chưa commit thì ghi vào khối "Diff chưa commit" ở đầu file này: thuộc đợt nào, đã kiểm tới đâu.

## Bàn giao UI 15/09/2026

UI mới đã được kiểm trên Pixel_9_root: HUD/bàn đạp/thanh lái và thẻ Pause/Results; 145 EditMode + 28 PlayMode đạt; rebuild checks PASS 3/3; hai vòng cảm ứng 02:03.400, Đồng, restart đúng. Xem cuối PROGRESS.md và ảnh `Artifacts/ui-upgrade/`. APK mới hiện là Development; Release vẫn thuộc phiên VenueDetails trước. Không dùng SHA Release cũ để đại diện cho UI mới.



