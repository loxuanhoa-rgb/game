# AGENTS.md — Hướng dẫn làm việc trên repo này

Tài liệu dùng chung cho người và **mọi agent**: Codex đọc trực tiếp; Claude Code đọc qua [CLAUDE.md](CLAUDE.md) (chỉ chứa `@AGENTS.md`). Sửa quy tắc ở đây, không nhân bản sang file khác. File này chỉ ghi **quy tắc và lệnh**; trạng thái dự án nằm ở các tài liệu mục 0.

## 0. Thứ tự đọc và phối hợp nhiều agent

### Đọc gì, theo thứ tự nào

1. File này (tự nạp).
2. [HANDOFF.md](HANDOFF.md) — hiện trạng, diff chưa commit, việc tiếp theo và mục "bẫy đã mất thời gian" (đọc trước khi viết code Editor hoặc script PowerShell).
3. [PROGRESS.md](PROGRESS.md) — **chỉ** bảng "Trạng thái tổng quan" và mục cuối cùng. Phần còn lại là log ~80 KB, tra cứu khi cần.
4. [DECISIONS_APEX_MUA_NANG.md](DECISIONS_APEX_MUA_NANG.md) — hợp đồng kỹ thuật và **bảng sở hữu file** của đợt APEX; áp dụng cho mọi agent.
5. [PLAN_APEX_MUA_NANG.md](PLAN_APEX_MUA_NANG.md) — kịch bản chạy đợt APEX **bằng Claude Code** (phiên chính "Astra" + subagent). Codex đọc để nắm bối cảnh; phần tổ chức nhóm không áp dụng cho Codex.

Thông số game: [GAME_DESIGN.md](GAME_DESIGN.md). Yêu cầu gốc (nguồn sự thật): [2026-09-06-android-racing-demo.md](2026-09-06-android-racing-demo.md).

### Một cây làm việc, nhiều agent

- **Một agent một lúc.** Codex và Claude dùng chung checkout, `Library/` và Unity. Không chạy hai phiên song song trên repo này, kể cả hai phiên cùng một công cụ.
- **Bắt đầu phiên bằng `git status`.** Cây bẩn không phải của mình → không `checkout --`, `stash`, `reset`, không format lại. Đọc ghi chú ở đầu HANDOFF.md để biết diff thuộc đợt nào và đã kiểm tới đâu.
- **Bàn giao** = commit mốc chạy được, hoặc ghi vào đầu HANDOFF.md: diff thuộc đợt nào, đã compile/test chưa, còn gì. Không để cây bẩn mà không ghi chú.
- **Sở hữu file** theo bảng trong DECISIONS. Cần sửa ngoài phạm vi → ghi vào báo cáo/HANDOFF, không tự sửa.
- **Không tự push** (repo chưa có remote) và **không tự tạo tag**. Chỉ làm khi người dùng yêu cầu rõ.
- **Commit message** tiếng Việt, kết thúc bằng trailer của agent đang làm:
  - Claude: `Co-Authored-By: Claude Opus 5 <noreply@anthropic.com>`
  - Codex: `Co-Authored-By: Codex <noreply@openai.com>`
- **`.meta`:** file tạo ngoài Unity chỉ có `.meta` sau một lần Unity chạy (generate hoặc test). Chạy Unity trước khi commit; không viết `.meta` bằng tay. Commit mọi `.meta`.
- **`Artifacts/` bị gitignore.** Số test, SHA, kích thước APK, số đo phải được tóm tắt vào PROGRESS.md; đường dẫn log chỉ là phụ.
- **Không đánh dấu xong khi chưa chạy thật.** Phân biệt rõ: *đã viết code* / *đã compile + test* / *đã build APK* / *đã chạy emulator* / *đã đo máy thật*.

## 1. Phiên bản và công cụ

| Thành phần | Giá trị | Trạng thái |
|---|---|---|
| Unity Editor | `6000.6.0f1` (revision `f7f8ed4d1e24`) | ✅ đã cài |
| Đường dẫn Editor | `D:/UnityHub/6000.6.0f1/Editor/Unity.exe` | ✅ |
| Module đã cài | Android Build Support (+ OpenJDK, SDK & NDK), Windows Build Support (Mono), WebGL (thừa, không dùng) | ✅ |
| adb (module Unity) | `D:/UnityHub/6000.6.0f1/Editor/Data/PlaybackEngines/AndroidPlayer/SDK/platform-tools/adb.exe` | ✅ |
| adb (Android Studio) | `C:/Users/VuIT/AppData/Local/Android/Sdk/platform-tools/adb.exe` — adb 1.0.41 / 37.0.0 | ✅ dự phòng |
| Git / Git LFS | git 2.47.1, git-lfs 3.6.0 | ✅ |
| .NET SDK (chạy nhanh test Core, tùy chọn) | 8.0.424 tại `C:/Users/VuIT/.dotnet` | ✅ |

> **Sai lệch so với kế hoạch:** kế hoạch ghi `6000.3.11f1`, nhưng Hub đã cài `6000.6.0f1`. Giữ nguyên bản đã cài để khỏi tải lại ~15 GB; **không nâng/hạ Editor nữa trong suốt demo này**. Mọi tài liệu và lệnh dùng `6000.6.0f1`.

**Quy tắc:** dùng SDK/NDK/JDK do Unity Hub cài, không mặc định dùng SDK của Android Studio cho việc build (adb của Android Studio thì dùng được).

## 2. Cấu hình Player Android (chốt)

- Package ID `com.vuit.racingdemo`, Landscape Left, Minimum API 26.
- IL2CPP, ARM64 only, OpenGLES3, build APK cài trực tiếp.
- `targetFrameRate = 60`, `vSyncCount = 0` (đặt trong `AppBootstrap`).
- Asset Serialization = Force Text, Version Control = Visible Meta Files. Commit mọi `.meta`.

## 3. Ranh giới assembly

| Assembly | Được dùng | Cấm |
|---|---|---|
| `RacingDemo.Core` | C#/.NET thuần, `noEngineReferences: true` | `UnityEngine`, `UnityEditor`, `System.IO`, `JsonUtility`, `ScriptableObject`, đồng hồ hệ thống |
| `RacingDemo.Runtime` | MonoBehaviour, Input System, uGUI/TMP, JSON, filesystem | luật đua tự viết lại (phải gọi Core) |
| `RacingDemo.Editor` | Editor only: sinh scene/asset, validator, build, thống kê | code chạy lúc runtime |
| `RacingDemo.Tests.EditMode` | **chỉ** Core + Test Framework, Editor only — luật đua, hàm thuần | `Runtime`, `Editor`, scene |
| `RacingDemo.Tests.TrackEditMode` | Core + Runtime + Editor + Test Framework, Editor only — hình học đường, validator, generator, builder, audio preferences | Play mode |
| `RacingDemo.Tests.PlayMode` | Core, Runtime, Test Framework — scene thật, vòng đời, audio | — |

Test cần `Runtime` hay `Editor` **phải** đặt ở `Tests.TrackEditMode`, không phải `Tests.EditMode` (asmdef đó không thấy Runtime/Editor, compile sẽ lỗi).

Mọi cập nhật thời gian trong Core đi qua `Tick(float deltaSeconds)`. Runtime chuyển cấu hình Unity thành số thuần trước khi đưa vào Core; Core chỉ nhận số lượng checkpoint và cấu hình luật, không nhận `Transform`/`Vector3`.

Thêm reference **trực tiếp** ở từng assembly có dùng thư viện (không dựa vào truyền tiếp qua Runtime). Tên assembly thực xem mục 5.

## 4. Quy tắc asset và scene

- Không sửa YAML của scene/prefab/ScriptableObject bằng tay. Thay đổi qua Inspector hoặc API Editor (`DemoProjectGenerator`).
- Generator chỉ quản lý `Assets/Generated`, `Assets/Scenes/Race.unity` và cây `__GeneratedScene` trong scene. Đồ chỉnh tay phải nằm ngoài cây đó.
- Rebuild không được ghi đè `CarConfig`/`TrackDefinition` đã tune; rebuild hai lần phải ra kết quả giống lần đầu (không nhân đôi camera, đèn, EventSystem, collider, AudioListener).
- Đóng Unity Editor trước khi chạy Unity CLI trên cùng project. Không mở hai tiến trình Unity cùng một project — kiểm `tasklist | findstr Unity` trước; tiến trình khác đang giữ khoá làm lệnh mới thoát ngay với exit 1 mà log chỉ có phần licensing.
- Asset bên thứ ba đặt trong `Assets/ThirdParty/<tên>/` kèm `README.md` ghi nguồn, ngày tải, giấy phép (mẫu: `KenneyRacingKit`, `BeVietnamPro`).
- Trước khi viết code Editor (mở scene, load asset, import package) hoặc script PowerShell gọi Unity: đọc mục "bẫy đã mất thời gian" trong HANDOFF.md — `OpenScene` unload asset chưa tham chiếu, import package batch mode treo, tham số `$args` làm mất `-quit`.

## 5. Package đã khóa

Lấy từ `Packages/manifest.json` của template Universal 3D (Unity 6000.6.0f1). Tên assembly bên dưới là tên đang dùng trong các asmdef của repo.

| Package | Version | Assembly name |
|---|---|---|
| com.unity.inputsystem | 1.20.0 | `Unity.InputSystem` |
| com.unity.ugui (gồm cả TextMeshPro) | 2.6.0 | `UnityEngine.UI`, `Unity.TextMeshPro` |
| com.unity.test-framework | 1.8.0 | `UnityEngine.TestRunner`, `UnityEditor.TestRunner` |
| com.unity.render-pipelines.universal | 17.6.0 | `Unity.RenderPipelines.Universal.Runtime` (Editor asmdef đang dùng) |
| com.unity.modules.vehicles | 1.0.0 | (WheelCollider) |

Không ghi yêu cầu dạng "1.14+". Commit cả `Packages/manifest.json` và `Packages/packages-lock.json`. **Không thêm package mới nếu không thật cần**; thêm rồi phải chạy lại trên thiết bị (package thừa của template từng phá Input System — xem HANDOFF.md).

## 6. Lệnh PowerShell

Chạy tại thư mục gốc repo. Đóng Unity Editor trước.

```powershell
Set-Location -LiteralPath 'D:/Android/3d-android-game'
$unityExe = 'D:/UnityHub/6000.6.0f1/Editor/Unity.exe'
$unityEditorDir = Split-Path -Parent $unityExe
$adbExe = Join-Path $unityEditorDir 'Data/PlaybackEngines/AndroidPlayer/SDK/platform-tools/adb.exe'
$projectRoot = (Get-Location).Path

if (-not (Test-Path -LiteralPath $unityExe)) { throw 'Chưa tìm thấy Unity Editor đúng phiên bản.' }
if (-not (Test-Path -LiteralPath $adbExe)) { throw 'Chưa tìm thấy adb; kiểm tra module Android của Unity.' }
New-Item -ItemType Directory -Path './Artifacts' -Force | Out-Null
& $adbExe devices
```

```powershell
function Invoke-DemoUnity {
    param([Parameter(Mandatory = $true)][string[]] $ExtraArgs)   # không đặt tên $args

    $unityArgs = @('-batchmode', '-projectPath', ('"{0}"' -f $projectRoot)) + $ExtraArgs
    # Không dùng -Wait: nó chờ cả tiến trình con, mà Unity để lại VBCSCompiler (dotnet.exe) mồ côi khi
    # thoát vì lỗi compile → script treo vô hạn (HANDOFF bẫy #11). Chỉ chờ đúng tiến trình Unity.
    $unityProcess = Start-Process -FilePath $unityExe -ArgumentList $unityArgs -PassThru -WindowStyle Hidden
    $unityProcess.WaitForExit()
    if ($unityProcess.ExitCode -ne 0) {
        throw "Unity thất bại với exit code $($unityProcess.ExitCode). Đọc log tương ứng trong Artifacts."
    }
}
```

| Việc | ExtraArgs |
|---|---|
| Dựng demo | `-quit -nographics -executeMethod RacingDemo.EditorTools.DemoProjectGenerator.RebuildDemo -logFile Artifacts/generate.log` |
| Kiểm scene | `-quit -nographics -executeMethod RacingDemo.EditorTools.SceneValidator.ValidateBuildScenes -logFile Artifacts/validate.log` |
| Thống kê ngân sách hình ảnh | `-quit -nographics -executeMethod RacingDemo.EditorTools.SceneStats.Report -statsOut Artifacts/scene-stats.txt -logFile Artifacts/scene-stats.log` |
| Kiểm rebuild Task 3 | `-quit -executeMethod RacingDemo.EditorTools.Task3Verification.RunRebuildChecks -logFile Artifacts/task3-rebuild-checks.log` — tự thử tuning/object ngoài cây, rồi khôi phục |
| EditMode test | `-buildTarget StandaloneWindows64 -nographics -runTests -testPlatform EditMode -testResults Artifacts/editmode-results.xml -logFile Artifacts/editmode.log` |
| PlayMode test | `-buildTarget StandaloneWindows64 -runTests -testPlatform PlayMode -testResults Artifacts/playmode-results.xml -logFile Artifacts/playmode.log` (không `-nographics`) |
| Build dev APK | `-quit -buildTarget Android -executeMethod RacingDemo.EditorTools.BuildCommand.BuildAndroidDevelopment -logFile Artifacts/build-development.log` |
| Build release APK | `-quit -buildTarget Android -executeMethod RacingDemo.EditorTools.BuildCommand.BuildAndroidRelease -logFile Artifacts/build-release.log` |
| Chốt ngưỡng huy chương (Task 6) | `-quit -executeMethod RacingDemo.EditorTools.MedalCalibration.ApplyFromFile -lapTimes Artifacts/task6-calibration/lap-times.txt -logFile Artifacts/task6-medals.log` |
| Áp riêng cấu hình URP | `-quit -executeMethod RacingDemo.EditorTools.RenderQualitySetup.ApplyMobileSettings -logFile Artifacts/render-settings.log` — `RebuildDemo` đã tự làm việc này |

Không thêm `-quit` vào lệnh `-runTests`. Sau khi chạy test, **đọc file XML**: exit code 0 với 0 test là thất bại, không phải thành công. EditMode và TrackEditMode chạy chung trong `-testPlatform EditMode`.

Đo frame time trên máy thật (không cần Profiler, dùng được cho bản Release): `Tools/perf/frametime-sample.ps1 -Serial <serial> -DurationSeconds 900 -OutDir Artifacts/xiaomi14/perf-release` — đọc `dumpsys SurfaceFlinger --timestats` của layer game mỗi 5 s, ra `tiles.csv` + `summary.txt` (FPS, median/P95/P99, spike). Xiaomi 14: nối qua `adb tcpip 5555` + `adb connect <IP>:5555` vì USB rớt khi truyền file lớn; sau mỗi lần Unity build phải `adb connect` lại. Chi tiết ở `PROGRESS.md` mục "Lượt Xiaomi 14".

Số liệu cho ngưỡng huy chương lấy bằng `Tools/mtinject/medal-calibration.ps1` (lái tự động nhiều lượt trên emulator, xem mục 7 và `Tools/mtinject/README.md`).

Cài và xem log trên máy thật:

```powershell
& $adbExe install -r './Builds/Android/racing-demo-development.apk'
if ($LASTEXITCODE -ne 0) { throw 'Cài APK thất bại.' }
& $adbExe logcat -c
& $adbExe logcat -v time 'Unity:V' 'AndroidRuntime:E' '*:S' | Tee-Object -FilePath './Artifacts/device.log'
```

## 7. Chạy thử trên emulator Android — **môi trường chạy chính**

Từ 09/09/2026, **emulator Pixel 9 là môi trường chạy và nghiệm thu chính** trong suốt quá trình làm. **Xiaomi 14 chỉ dùng một lần ở cuối**, khi dự án đã hoàn thành, để nghiệm thu thực tế. Đây là thay đổi có chủ ý so với kế hoạch gốc — xem sai lệch #18 trong `PROGRESS.md`.

Hai AVD với vai trò khác nhau:

| AVD | Ảnh | Dùng khi nào |
|---|---|---|
| `Pixel_9` | `google_apis_playstore` (build `user`) | Chạy thử thông thường, gần máy người dùng thật nhất. Không root được |
| `Pixel_9_root` | `google_apis` (build `userdebug`) | Khi cần bơm cảm ứng hai ngón. Root được, cùng màn hình 1080×2424 |

AVD nào cũng mặc định chỉ 2 GB RAM — **không đủ**, Android sẽ giết app giữa lúc load. Phải ghi đè bằng cờ dòng lệnh (không sửa cấu hình AVD):

```powershell
$sdk = "$env:LOCALAPPDATA/Android/Sdk"
$adb = "$sdk/platform-tools/adb.exe"
Start-Process "$sdk/emulator/emulator.exe" -ArgumentList @('-avd','Pixel_9','-memory','6144','-no-snapshot-load','-no-boot-anim')

& $adb wait-for-device
& $adb shell 'while [ -z "$(getprop sys.boot_completed)" ]; do sleep 2; done; echo BOOT_COMPLETED'
& $adb install -r './Builds/Android/racing-demo-development.apk'
& $adb shell am start -n com.vuit.racingdemo/com.unity3d.player.UnityPlayerGameActivity
```

Ảnh x86_64 API 37 có **dịch mã ARM64**, nên APK ARM64 cài thẳng được, không cần build riêng x86_64 (`AndroidArchitecture.X86_64` trên 6000.6.0f1 build lỗi "Target architecture not specified").

### Một ngón: adb là đủ

```powershell
& $adb shell screencap -p /sdcard/s.png; & $adb pull /sdcard/s.png './Artifacts/shot.png'
& $adb shell input tap X Y                       # bấm một phát
& $adb shell input swipe X Y X Y 3000            # giữ nút 3 giây
```

Toạ độ của `input tap`/`swipe` là **toạ độ landscape 2424×1080**, đúng như nhìn trên màn hình game.

### Hai ngón: dùng `mtinject`

`adb shell input` chỉ có một con trỏ; thiết bị cảm ứng ảo sẵn có của emulator bị Unity nhận nhầm là bút và bỏ cả hai con trỏ. Cách dùng được là `Tools/mtinject` — thiết bị `/dev/uinput` tự dựng, cần AVD `Pixel_9_root` + `adb root` + `setenforce 0`, binary **phải** link `-Wl,-z,max-page-size=16384`. Cách build, chạy, giao thức FIFO và helper `Tools/mtinject/mt-uinput.ps1` (nhận toạ độ landscape) nằm đủ trong [Tools/mtinject/README.md](Tools/mtinject/README.md). Nếu một lượt chạy bị ngắt giữa chừng, ngón vẫn "đang chạm" — luôn mở đầu bằng `Send-Cmd @('U 0','U 1','U 2','S')`.

### Emulator vẫn KHÔNG kiểm được

Độ trễ chạm thật, FPS/frame time của phần cứng thật, và cảm giác lái. Ba thứ này để dành cho lượt nghiệm thu Xiaomi 14 ở cuối dự án; chưa đo thì ghi "chưa kiểm chứng", không ghi số suy đoán.

## 8. Kiểm tra nhanh Core không cần Unity (tùy chọn)

`RacingDemo.Core` và test `Tests.EditMode` là C# thuần + NUnit nên chạy được bằng .NET SDK để lấy phản hồi nhanh (vài giây thay vì chờ Unity domain reload; đặt `LangVersion 9.0` cho khớp Unity 6). Script và project tạm nằm ngoài repo, trong thư mục scratch của phiên làm việc; kết quả chính thức vẫn phải lấy từ Unity Test Runner.

## 9. Thói quen làm việc

1. Đọc theo thứ tự ở mục 0; `git status` trước khi sửa gì.
2. Viết chức năng kèm test; compile trước khi mở rộng.
3. Chơi thử trong Editor và trên **emulator Pixel 9** ở các mốc bắt buộc. Xiaomi 14 để dành cho lượt nghiệm thu cuối cùng khi dự án hoàn thành.
4. Ghi phản hồi theo "đang làm gì → mong muốn → thực tế" + log.
5. Kết thúc phiên: cập nhật PROGRESS.md (cả phần **chưa** kiểm chứng và sai lệch so với kế hoạch), GAME_DESIGN.md nếu thông số đổi, đầu HANDOFF.md nếu còn diff chưa commit; commit mốc chạy được với trailer đúng agent.
