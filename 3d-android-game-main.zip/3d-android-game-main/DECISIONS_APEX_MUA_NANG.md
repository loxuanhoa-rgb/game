# Quyết định APEX — Mùa Nắng

## 17/09/2026 — Sửa tiếng gió theo phản hồi Xiaomi (Codex)

Người chơi xác nhận hiệu năng ổn, tiếng ga ổn, nhạc có phát ở lễ hội; chỉ còn tiếng gió rè khi chạy nhanh.
Codex sửa EngineClipBuilder (mở rộng phần audio được bàn giao) và test audio: bỏ lớp nhiễu PRNG
trộn trong clip động cơ. Đây là lớp duy nhất cùng tăng pitch/volume theo tốc độ; ambience riêng
có âm lượng cố định theo màn. Giữ hòa âm, nhịp nổ, chuẩn hóa peak 0,89 và mọi tham số EngineAudio.
Không đổi nhạc/ambience hoặc tuning xe. Test so sánh chu kỳ 50 Hz bắt nhiễu ở bản cũ (max diff 0,4658585).
Không coi test tín hiệu thay cho nghe thử: cần người chơi xác nhận bản APK mới trên Xiaomi.
Phương án giảm toàn bộ âm lượng động cơ bị loại vì tiếng ga đã được người chơi chấp nhận.

## 17/09/2026 — Baseline và hợp đồng tích hợp

Working tree sạch trước triển khai. Baseline UI 15/09: 145 EditMode, 28 PlayMode;
chỉ APK Development mang UI mới. Đây là bằng chứng cũ, không thay cho kiểm bản mới.

| Chủ sở hữu | File/phạm vi | Người review |
|---|---|---|
| Astra | RaceDirector, DemoProjectGenerator, SceneValidator, RaceLoopSceneTests, tài liệu, generated assets | C (logic), A/B (trải nghiệm) |
| A / ui | UiBuilder, các presenter, RaceHudFormatter, ApexFontAssets, font nguồn, test formatter | B và Astra |
| B / world | FestivalVisuals, VenueDetails | A, C và Astra |
| C / systems | EngineAudio, FestivalAudio, AudioPreferences, FestivalAudioBuilder, test audio | A và Astra |

### Luồng trạng thái

Festival (Core Idle) → StartRace → Countdown → Running → Results.
Countdown/Running → Pause → Resume về trạng thái trước pause.
Pause/Results → Restart → Countdown; Pause/Results → ReturnToFestival → Idle.

Festival không tick Core, không nhận gate/reset/pause, khóa pose và xóa input.
ReturnToFestival bỏ RaceRules cũ và tạo lượt Idle mới, không Submit bản ghi dở.
Không thêm luật UI vào Core. Giữ nguyên TrackId, records.json và tuning.

### UI và font

Thiệp lễ hội ngang 1320×800, logo/lời An/kỷ lục/Vào đua/âm thanh.
HUD không kể chuyện khi lái. Bốn màn dùng xanh mực–kem–cam đất.
Giữ nguyên rect và độ nhạy mọi điều khiển lái; CanvasGroup ẩn/chặn raycast
HUD khi vào menu, presenter vẫn active. Be Vietnam Pro atlas dùng chung cho UI/biển.

Phản biện B/A: biển ngắn 1–2 dòng, không thêm slogan trước camera; giữ cao độ panel.
Phản biện Astra: card phải vừa 16:9, không đổi hierarchy làm hỏng validator.

### Cảnh

Tái sử dụng garage/podium/cây/núi hiện có thay vì tạo thêm bộ cảnh chồng lên.
Bổ sung quán và cụm thông ngoài mặt đường; ngân sách ≤12 renderer mới,
không collider/light mới, tắt bóng props mới, cluster nhỏ để culling có ích.
Giữ hình học collider và cấu hình URP hiện tại cho đến khi có số đo máy thật.

### Audio

FestivalAudio.SetContext(bool racing), SetPaused(bool), ToggleMusic/ToggleEffects;
preferences PlayerPrefs riêng, không sửa records. Music 0,09 ở menu / 0,035 lúc đua,
ambience 0,04 ở menu / 0,025 lúc đua; so với engine idle 0,35. Hai clip tự tổng hợp, không thêm package.
Focus/pause OS suspend audio cả Festival/Results; trở lại race đang pause không tự resume.
Phản biện Astra: EngineAudio.UnPause trước lần Play đầu có thể im sau lễ hội;
C sửa đường khởi phát để clip bắt đầu đúng khi vào đua.

## Cổng nghiệm thu

Đọc XML có test >0 và failed=0; validator, rebuild ×2 giữ tuning/object ngoài cây.
Pixel 9 kiểm toàn luồng, hai ngón, focus, restart, records và lỗi lưu;
ảnh UI 16:9/Pixel 9. Xiaomi 14 đo Development và Release mỗi bản 15 phút;
không tuyên bố đạt cảm giác lái/latency hoặc hiệu năng thiết bị khi chưa đo.

Thiết bị ở thời điểm khảo sát: adb không có máy kết nối. Sẽ khởi động Pixel_9_root;
nghiệm thu Xiaomi cần thiết bị hiện diện. Không tự tạo tag hay push.

## 17/09/2026 — Đợt 0: kết quả đối chiếu diff (Astra + A/B/C chỉ đọc)

Bằng chứng: `Artifacts/apex-mua-nang/dot0/` (generate.log, diff-*.patch, doi-chieu-{A,B,C}-*.md).

- **Generate thất bại ở bước biên dịch**: `UiBuilder.cs:116` gọi `BuildFestivalScreen`, `:202` gọi
  `BuildAudioOptions` — hai hàm chưa được viết (CS0103). Cả `RacingDemo.Editor` và
  `Tests.TrackEditMode` không build; Runtime không có lỗi. Chưa có test/validator/stats nào chạy được.
  `.meta` của file mới đã được Unity sinh lúc import (trước khi compile), nên có thể commit cùng đợt.
- **A (UI)**: chuỗi có dấu, nút Về lễ hội, lời An ở Results, `ApexFontAssets` (bộ ký tự bao đủ U+1EA0–1EF9,
  gọi sau OpenScene) đúng hợp đồng. Thiếu: toàn bộ thiệp lễ hội, widget âm thanh, bind
  `_recordLabel/_musicLabels/_effectsLabels` của `FestivalPresenter`; **"HUD gọn hơn" chưa làm** (chỉ đổi chuỗi).
- **B (cảnh)**: 7 renderer mới (≤12), không collider/light, tắt bóng, nằm đúng cây `VenueDetails`, deterministic.
  Chưa tái dùng cây Kenney/lều cho Đồi Thông/Quán. Cần ảnh thật để kiểm: cụm thông mới có chồng cụm cây
  Kenney cluster 1 (DecorBuilder.cs:129-132) không; nhãn "HẸN VÒNG SAU" có lọt khung hình chính không.
- **C (hệ thống)**: luồng trạng thái, không Submit bản ghi dở, guard `_atFestival`, focus/pause OS,
  EngineAudio khởi phát lại, 2 AudioSource, PlayerPrefs riêng — đúng hợp đồng. Lệch: ambience lúc đua 0,025
  (DECISIONS ghi 0,04). Thiếu test tích hợp: mất focus giữa Running suspend audio thật; lấy lại focus khi
  đang Paused vẫn Paused; `OnApplicationPause` trực tiếp trên director.
- **Astra**: verify `_drivingGroups` phải tạo `SerializedObject` mới như `FieldBinder` (bẫy #2).

**Quyết định Đợt 0:**
1. Ambience: giữ ducking 0,025 lúc đua (cùng logic với music 0,09→0,035; ambience không được lấn động cơ).
   Sửa văn bản mục Audio: "ambience 0,04 ở menu / 0,025 lúc đua". Lý do: code đã viết, nhất quán với music;
   phương án bị loại: một mức 0,04 (không có lợi ích rõ). Xem lại nếu nghe thử trên máy thấy ambience mất hẳn khi đua.
2. Bẫy mới ghi HANDOFF #11: `Start-Process -Wait` treo khi Unity thoát vì lỗi compile (chờ VBCSCompiler mồ côi);
   dùng `-PassThru` + `WaitForExit()`.
3. Bảng sở hữu file giữ nguyên; bổ sung: `FestivalPresenter` bind mọi field trừ `_audio` ngay trong `UiBuilder`
   (A); generator (Astra) chỉ gán `_audio` và listener. `MusicLabels/EffectsLabels` của cả Pause lẫn Festival
   đều vào `FestivalPresenter._musicLabels/_effectsLabels` để hai màn cùng đổi chữ.
4. Đợt 1 chỉ mở cho: (A) bố cục thiệp lễ hội + widget âm thanh + đề xuất rút gọn HUD; (B) lời An và nội dung
   chữ bốn khu vực; (C) ba test tích hợp còn thiếu. Không mở lại phần cảnh (B) — đã đúng hợp đồng, chờ ảnh.

## 17/09/2026 — Đợt 1 gộp vào Đợt 2 (sai lệch có chủ ý so với PLAN §4)

Ba agent `Plan` của Đợt 1 bị ngắt vì giới hạn usage của phiên trước khi kịp đề xuất. Để không tốn thêm ba
lần khởi động lạnh, Astra chốt trực tiếp phần còn hở (đều là khoảng trống đã được Đợt 0 mô tả rõ) và giao
thẳng cho agent triển khai; phản biện độc lập dồn vào Đợt 3 (reviewer A/B/C đọc diff tích hợp + ảnh).

- **Thiệp lễ hội (A):** card 1320×800, nền panel alpha 0,55 để thấy cảnh; eyebrow "ĐỒI MÂY / LỄ HỘI MÙA NẮNG",
  title "APEX — MÙA NẮNG" (72, cam), dòng bốn khu "SÂN HỘI · GARAGE MÂY · ĐỒI THÔNG · QUÁN DỐC NẮNG",
  lời An 2 dòng, kỷ lục, "VÀO ĐUA >" (440×140, ThrottleColor, tại 300,-140), widget âm thanh tại (-400,-140),
  eyebrow hướng dẫn lái ở đáy. `BuildAudioOptions(panel, result, x, y)`: hai nút 320×90 "NHẠC: BẬT"/"ÂM THANH: BẬT".
- **HUD gọn hơn (Astra quyết, thẩm mỹ nhỏ):** bỏ label Brand khỏi HUD (thương hiệu đã ở thiệp/Results),
  ClockCard 470×120; giữ 5 field HudPresenter và mọi rect điều khiển.
- **Lời An (Astra viết thay B; B kiểm ở Đợt 3):** thiệp — không kỷ lục: "An: Xe vừa bảo dưỡng xong. Chạy thử
  hai vòng quanh Đồi Mây nhé!"; có kỷ lục: "An: Kỷ lục cũ vẫn còn đó. Nắng chiều đẹp thế này, thử vượt nó xem!".
  Results — kỷ lục đã lưu: "An: Đẹp rồi! Đồi Mây vừa nhớ thêm một kỷ lục."; kỷ lục nhưng lưu lỗi: "An: Chạy hay
  lắm! Sổ ghi kỷ lục đang kẹt, nhưng tôi nhớ thời gian này."; còn lại: "An: Hai vòng trọn vẹn. Ghé garage nghỉ
  một chút nhé.". Nhãn âm thanh chữ hoa "NHẠC: BẬT/TẮT", "ÂM THANH: BẬT/TẮT". Nhãn pit "HẸN VÒNG SAU" giữ tới
  khi có ảnh chase camera (Đợt 4).
- **Test tích hợp (Astra viết trong RaceLoopSceneTests, C kiểm ở Đợt 3):** mất focus giữa Running → Paused +
  EngineAudio/FestivalAudio thật im, lấy lại focus không resume; OnApplicationPause trên director; mất focus ở
  Festival/Results chỉ suspend audio, không mở pause, focus lại nhạc chạy.
- **Hạ tầng (Astra):** `FieldBinder.SetObjects` bind mảng có đọc lại; validator `RequireReferenceArray` cho
  `_drivingGroups` (≥6) và `FestivalPresenter._musicLabels/_effectsLabels` (≥1), `_recordLabel` bắt buộc.

Điều kiện xem lại: reviewer Đợt 3 hoặc ảnh Pixel 9 cho thấy thiệp tràn/chồng, lời An lệch giọng, hoặc HUD thiếu thông tin.

## 17/09/2026 — Codex tiếp nhận sau phần Claude

Đọc lại toàn bộ diff hiện có thay vì dùng trạng thái trước lúc hết usage. Hai hàm
BuildFestivalScreen/BuildAudioOptions đã có trong source, cùng lời An, HUD rút gọn,
FieldBinder.SetObjects và ba test focus tích hợp. HANDOFF Đợt 0 chưa phản ánh các thay đổi này.
Codex tiếp nhận quyền tích hợp các file A/B/C đã bàn giao; không có agent khác chạy Unity.

Đã kiểm: RebuildDemo compile/generate exit 0; ValidateBuildScenes exit 0;
Task3Verification PASS 3/3 (tuning byte/GUID, scene lặp, object ngoài cây);
EditMode 150/150, failed=0, skipped=0. PlayMode/APK/emulator đang tiếp tục.
SceneStats: 308 renderer, 27.932 tam giác, 482 submesh, 48 material, 0 renderer thiếu mesh.
So với baseline: +7 renderer/+696 tam giác/+18 submesh, giữ 227 caster.
Bằng chứng mới: Artifacts/apex-mua-nang/ (khác dot0 của Claude).

## 17/09/2026 10:15 — Tạm dừng, bàn giao Đợt 2→3→4 cho Codex

Người dùng yêu cầu dừng phiên Claude. Code Đợt 2 đã viết xong nhưng chưa có bằng chứng compile (project đang bị
một tiến trình Unity khác giữ khoá lúc chạy generate). Codex làm tiếp theo khối đầu `HANDOFF.md`; phần tổ chức
nhóm subagent trong PLAN không áp dụng cho Codex — Codex tự review theo hợp đồng ở file này thay reviewer A/B/C.
