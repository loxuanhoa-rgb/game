using System;
using NUnit.Framework;
using RacingDemo.Core.Racing;
using RacingDemo.Core.Scoring;

namespace RacingDemo.Tests.EditMode
{
    public sealed class MedalEvaluatorTests
    {
        private static MedalThresholds Thresholds()
        {
            return new MedalThresholds(85f, 100f, 120f);
        }

        [Test]
        public void FasterThanGold_IsGold()
        {
            Assert.That(MedalEvaluator.Evaluate(70f, Thresholds()), Is.EqualTo(Medal.Gold));
        }

        [Test]
        public void TimeEqualToThreshold_KeepsThatMedal()
        {
            MedalThresholds thresholds = Thresholds();

            Assert.That(MedalEvaluator.Evaluate(85f, thresholds), Is.EqualTo(Medal.Gold));
            Assert.That(MedalEvaluator.Evaluate(100f, thresholds), Is.EqualTo(Medal.Silver));
            Assert.That(MedalEvaluator.Evaluate(120f, thresholds), Is.EqualTo(Medal.Bronze));
        }

        [Test]
        public void JustOverThreshold_DropsOneMedal()
        {
            MedalThresholds thresholds = Thresholds();

            Assert.That(MedalEvaluator.Evaluate(85.001f, thresholds), Is.EqualTo(Medal.Silver));
            Assert.That(MedalEvaluator.Evaluate(100.001f, thresholds), Is.EqualTo(Medal.Bronze));
            Assert.That(MedalEvaluator.Evaluate(120.001f, thresholds), Is.EqualTo(Medal.None));
        }

        [Test]
        public void InvalidTimeOrThresholds_AreRejected()
        {
            Assert.Throws<ArgumentNullException>(() => MedalEvaluator.Evaluate(90f, null));
            Assert.Throws<ArgumentOutOfRangeException>(() => MedalEvaluator.Evaluate(0f, Thresholds()));
            Assert.Throws<ArgumentException>(() => MedalEvaluator.Evaluate(float.NaN, Thresholds()));

            // Nguong phai tang dan: Gold < Silver < Bronze.
            Assert.Throws<ArgumentOutOfRangeException>(() => new MedalThresholds(100f, 100f, 120f));
            Assert.Throws<ArgumentOutOfRangeException>(() => new MedalThresholds(85f, 130f, 120f));
        }

        [Test]
        public void ProvisionalThresholds_MatchPlannedValues()
        {
            MedalThresholds thresholds = MedalThresholds.CreateProvisional();

            Assert.That(thresholds.GoldSeconds, Is.EqualTo(85f));
            Assert.That(thresholds.SilverSeconds, Is.EqualTo(100f));
            Assert.That(thresholds.BronzeSeconds, Is.EqualTo(120f));
        }
    }

    public sealed class RaceTimeFormatterTests
    {
        [Test]
        public void FormatsMinutesSecondsMilliseconds()
        {
            Assert.That(RaceTimeFormatter.Format(0.001f), Is.EqualTo("00:00.001"));
            Assert.That(RaceTimeFormatter.Format(1.234f), Is.EqualTo("00:01.234"));
            Assert.That(RaceTimeFormatter.Format(59.999f), Is.EqualTo("00:59.999"));
            Assert.That(RaceTimeFormatter.Format(60f), Is.EqualTo("01:00.000"));
            Assert.That(RaceTimeFormatter.Format(83.456f), Is.EqualTo("01:23.456"));
            Assert.That(RaceTimeFormatter.Format(3600f), Is.EqualTo("60:00.000"));
        }

        [Test]
        public void TruncatesInsteadOfRounding()
        {
            // 1.2999 giay hien thi la 1.299, khong lam tron len 1.300.
            Assert.That(RaceTimeFormatter.Format(1.2999f), Is.EqualTo("00:01.299"));
        }

        [Test]
        public void NonPositiveOrNonFinite_ShowsZero()
        {
            Assert.That(RaceTimeFormatter.Format(0f), Is.EqualTo(RaceTimeFormatter.ZeroText));
            Assert.That(RaceTimeFormatter.Format(-5f), Is.EqualTo(RaceTimeFormatter.ZeroText));
            Assert.That(RaceTimeFormatter.Format(float.NaN), Is.EqualTo(RaceTimeFormatter.ZeroText));
            Assert.That(RaceTimeFormatter.Format(float.PositiveInfinity), Is.EqualTo(RaceTimeFormatter.ZeroText));
        }
    }
}
