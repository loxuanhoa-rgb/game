using NUnit.Framework;
using RacingDemo.Core.Persistence;
using RacingDemo.Core.Scoring;

namespace RacingDemo.Tests.EditMode
{
    /// <summary>
    /// Kiem tra chinh sach luu ky luc o muc 4: chi luu khi nhanh hon, khong bao da luu
    /// khi ghi that bai, va khong ghi de khi doc khong an toan.
    /// </summary>
    public sealed class RecordStoreTests
    {
        private const string TrackId = "oval-v1";

        [Test]
        public void FirstRecord_IsSavedAndReportedAsImproved()
        {
            var repository = new FakeRecordRepository();
            var store = new RecordStore(repository);

            RecordSubmissionResult result = store.Submit(TrackId, 95f, Medal.Silver);

            Assert.That(result.Improved, Is.True);
            Assert.That(result.Saved, Is.True);
            Assert.That(result.BestPersisted, Is.EqualTo(95f));
            Assert.That(result.HasError, Is.False);
            Assert.That(repository.Stored.Count, Is.EqualTo(1));
            Assert.That(repository.Stored[0].TimeSeconds, Is.EqualTo(95f));
            Assert.That(repository.Stored[0].Medal, Is.EqualTo(Medal.Silver));
        }

        [Test]
        public void SlowerOrEqualTime_IsNotSaved()
        {
            var repository = new FakeRecordRepository();
            var store = new RecordStore(repository);
            store.Submit(TrackId, 95f, Medal.Silver);
            int savesAfterFirst = repository.SaveCallCount;

            RecordSubmissionResult equalTime = store.Submit(TrackId, 95f, Medal.Silver);
            RecordSubmissionResult slower = store.Submit(TrackId, 110f, Medal.Bronze);

            Assert.That(equalTime.Improved, Is.False);
            Assert.That(equalTime.Saved, Is.False);
            Assert.That(equalTime.BestPersisted, Is.EqualTo(95f));
            Assert.That(slower.Improved, Is.False);
            Assert.That(repository.SaveCallCount, Is.EqualTo(savesAfterFirst), "Khong duoc ghi lai khi khong nhanh hon.");
        }

        [Test]
        public void FasterTime_ReplacesStoredRecord()
        {
            var repository = new FakeRecordRepository();
            var store = new RecordStore(repository);
            store.Submit(TrackId, 95f, Medal.Silver);

            RecordSubmissionResult result = store.Submit(TrackId, 84f, Medal.Gold);

            Assert.That(result.Improved, Is.True);
            Assert.That(result.Saved, Is.True);
            Assert.That(result.BestPersisted, Is.EqualTo(84f));
            Assert.That(repository.Stored.Count, Is.EqualTo(1), "Mot track chi giu mot ban ghi.");
            Assert.That(repository.Stored[0].TimeSeconds, Is.EqualTo(84f));
            Assert.That(repository.Stored[0].Medal, Is.EqualTo(Medal.Gold));
        }

        [Test]
        public void MultipleTracks_AreKeptSideBySide()
        {
            var repository = new FakeRecordRepository();
            var store = new RecordStore(repository);

            store.Submit("oval-v1", 95f, Medal.Silver);
            store.Submit("oval-v2", 88f, Medal.Gold);

            Assert.That(repository.Stored.Count, Is.EqualTo(2));

            RecordData first;
            RecordData second;
            Assert.That(store.TryGetBest("oval-v1", out first), Is.True);
            Assert.That(store.TryGetBest("oval-v2", out second), Is.True);
            Assert.That(first.TimeSeconds, Is.EqualTo(95f));
            Assert.That(second.TimeSeconds, Is.EqualTo(88f));
        }

        [Test]
        public void LoadedRecords_AreFilteredAndDeduplicated()
        {
            var repository = new FakeRecordRepository();
            repository.SeedStored(
                new RecordData(TrackId, 120f, Medal.Bronze),
                new RecordData(TrackId, 92f, Medal.Silver),
                new RecordData(string.Empty, 50f, Medal.Gold),
                new RecordData("broken", float.NaN, Medal.Gold),
                new RecordData("negative", -3f, Medal.Gold),
                new RecordData("bad-medal", 70f, (Medal)99));

            var store = new RecordStore(repository);

            RecordData best;
            Assert.That(store.TryGetBest(TrackId, out best), Is.True);
            Assert.That(best.TimeSeconds, Is.EqualTo(92f), "Ban ghi trung trackId giu thoi gian nho nhat.");

            RecordData ignored;
            Assert.That(store.TryGetBest("broken", out ignored), Is.False);
            Assert.That(store.TryGetBest("negative", out ignored), Is.False);
            Assert.That(store.TryGetBest("bad-medal", out ignored), Is.False);
        }

        [Test]
        public void LoadFailure_DisablesWrites_ButKeepsPlaying()
        {
            var repository = new FakeRecordRepository { LoadShouldFail = true, FailureMessage = "JSON hong" };
            var store = new RecordStore(repository);

            RecordSubmissionResult result = store.Submit(TrackId, 90f, Medal.Silver);

            Assert.That(store.WritesDisabled, Is.True);
            Assert.That(result.Improved, Is.True, "Van tinh la nhanh hon vi chua biet ky luc nao.");
            Assert.That(result.Saved, Is.False);
            Assert.That(result.HasError, Is.True);
            Assert.That(repository.SaveCallCount, Is.EqualTo(0), "Khong duoc ghi de file khi doc that bai.");
        }

        [Test]
        public void LoadException_IsTreatedAsLoadFailure()
        {
            var repository = new FakeRecordRepository { LoadShouldThrow = true };
            var store = new RecordStore(repository);

            RecordSubmissionResult result = store.Submit(TrackId, 90f, Medal.Silver);

            Assert.That(store.WritesDisabled, Is.True);
            Assert.That(result.Saved, Is.False);
            Assert.That(result.HasError, Is.True);
        }

        [Test]
        public void SaveFailure_KeepsPreviousRecord_AndAllowsRetryLater()
        {
            var repository = new FakeRecordRepository();
            var store = new RecordStore(repository);
            store.Submit(TrackId, 95f, Medal.Silver);

            repository.SaveShouldFail = true;
            RecordSubmissionResult failed = store.Submit(TrackId, 90f, Medal.Silver);

            Assert.That(failed.Improved, Is.True);
            Assert.That(failed.Saved, Is.False);
            Assert.That(failed.BestPersisted, Is.EqualTo(95f), "Cache phai giu ky luc da luu truoc do.");
            Assert.That(repository.Stored[0].TimeSeconds, Is.EqualTo(95f));

            repository.SaveShouldFail = false;
            RecordSubmissionResult retried = store.Submit(TrackId, 89f, Medal.Gold);

            Assert.That(retried.Saved, Is.True, "Luot sau van duoc thu ghi lai.");
            Assert.That(retried.BestPersisted, Is.EqualTo(89f));
            Assert.That(repository.Stored[0].TimeSeconds, Is.EqualTo(89f));
        }

        [Test]
        public void SaveException_IsReportedWithoutCrashing()
        {
            var repository = new FakeRecordRepository { SaveShouldThrow = true };
            var store = new RecordStore(repository);

            RecordSubmissionResult result = store.Submit(TrackId, 90f, Medal.Silver);

            Assert.That(result.Improved, Is.True);
            Assert.That(result.Saved, Is.False);
            Assert.That(result.HasError, Is.True);
        }

        [Test]
        public void InvalidSubmissions_AreRejectedWithoutWriting()
        {
            var repository = new FakeRecordRepository();
            var store = new RecordStore(repository);

            Assert.That(store.Submit(string.Empty, 90f, Medal.Silver).HasError, Is.True);
            Assert.That(store.Submit(TrackId, 0f, Medal.Silver).HasError, Is.True);
            Assert.That(store.Submit(TrackId, float.NaN, Medal.Silver).HasError, Is.True);
            Assert.That(store.Submit(TrackId, 90f, (Medal)42).HasError, Is.True);
            Assert.That(repository.SaveCallCount, Is.EqualTo(0));
        }

        [Test]
        public void Repository_IsLoadedOnlyOnce()
        {
            var repository = new FakeRecordRepository();
            var store = new RecordStore(repository);

            store.EnsureLoaded();
            store.EnsureLoaded();
            RecordData best;
            store.TryGetBest(TrackId, out best);
            store.Submit(TrackId, 90f, Medal.Silver);

            Assert.That(repository.LoadCallCount, Is.EqualTo(1));
        }

        [Test]
        public void NewStore_ReadsRecordSavedByPreviousSession()
        {
            var repository = new FakeRecordRepository();
            new RecordStore(repository).Submit(TrackId, 91f, Medal.Silver);

            var reopened = new RecordStore(repository);

            RecordData best;
            Assert.That(reopened.TryGetBest(TrackId, out best), Is.True);
            Assert.That(best.TimeSeconds, Is.EqualTo(91f));
            Assert.That(reopened.Submit(TrackId, 95f, Medal.Silver).Improved, Is.False);
        }
    }
}
