using System;
using System.Collections.Generic;
using NUnit.Framework;
using RacingDemo.Core.Scoring;

namespace RacingDemo.Tests.EditMode
{
    public sealed class MedalThresholdCalibratorTests
    {
        /// <summary>Muoi luot tang dan deu: nhanh nhat 100 s, cham nhat 145 s, trung vi 122,5 s.</summary>
        private static List<float> TenRuns()
        {
            return new List<float> { 100f, 105f, 110f, 115f, 120f, 125f, 130f, 135f, 140f, 145f };
        }

        private static List<float> Repeat(float seconds, int count)
        {
            var runs = new List<float>(count);
            for (int i = 0; i < count; i++)
            {
                runs.Add(seconds);
            }

            return runs;
        }

        [Test]
        public void UsesPlanFormula()
        {
            MedalThresholds thresholds = MedalThresholdCalibrator.Calibrate(TenRuns());

            Assert.That(thresholds.GoldSeconds, Is.EqualTo(100f * 1.03f).Within(0.001f));
            Assert.That(thresholds.SilverSeconds, Is.EqualTo(122.5f).Within(0.001f));
            Assert.That(thresholds.BronzeSeconds, Is.EqualTo(145f * 1.10f).Within(0.001f));
        }

        [Test]
        public void OrderOfSamplesDoesNotMatter()
        {
            var shuffled = new List<float> { 130f, 100f, 145f, 115f, 125f, 105f, 140f, 110f, 135f, 120f };

            MedalThresholds fromShuffled = MedalThresholdCalibrator.Calibrate(shuffled);
            MedalThresholds fromSorted = MedalThresholdCalibrator.Calibrate(TenRuns());

            Assert.That(fromShuffled.GoldSeconds, Is.EqualTo(fromSorted.GoldSeconds));
            Assert.That(fromShuffled.SilverSeconds, Is.EqualTo(fromSorted.SilverSeconds));
            Assert.That(fromShuffled.BronzeSeconds, Is.EqualTo(fromSorted.BronzeSeconds));
        }

        [Test]
        public void EqualRuns_PushSilverUpByTheOneSecondRule()
        {
            // Muoi luot bang nhau: trung vi (100 s) khong con lon hon gold nua nen luat
            // "cach nhau it nhat 1 giay" quyet dinh silver. Bronze van do cham nhat x 1,10.
            MedalThresholds thresholds = MedalThresholdCalibrator.Calibrate(Repeat(100f, 10));

            Assert.That(thresholds.GoldSeconds, Is.EqualTo(103f).Within(0.001f));
            Assert.That(thresholds.SilverSeconds, Is.EqualTo(104f).Within(0.001f));
            Assert.That(thresholds.BronzeSeconds, Is.EqualTo(110f).Within(0.001f));
        }

        [Test]
        public void ShortRuns_PushBronzeUpByTheOneSecondRule()
        {
            // Luot rat ngan: cham nhat x 1,10 chi hon silver 0,7 s, nen bronze phai bi day len
            // de ba nguong khong dinh vao nhau.
            MedalThresholds thresholds = MedalThresholdCalibrator.Calibrate(Repeat(10f, 10));

            Assert.That(thresholds.GoldSeconds, Is.EqualTo(10.3f).Within(0.001f));
            Assert.That(thresholds.SilverSeconds, Is.EqualTo(11.3f).Within(0.001f));
            Assert.That(thresholds.BronzeSeconds, Is.EqualTo(12.3f).Within(0.001f));
        }

        [Test]
        public void MedianOfEvenCount_IsAverageOfTwoMiddleValues()
        {
            Assert.That(MedalThresholdCalibrator.Median(new[] { 10f, 20f, 30f, 40f }), Is.EqualTo(25f));
            Assert.That(MedalThresholdCalibrator.Median(new[] { 10f, 20f, 30f }), Is.EqualTo(20f));
        }

        [Test]
        public void InvalidTimesAreDropped_AndCountedAgainstTheMinimum()
        {
            List<float> runs = TenRuns();
            runs[3] = float.NaN;
            runs[7] = -5f;

            // Chi con 8 luot hop le nen khong du de chot nguong.
            Assert.Throws<ArgumentException>(() => MedalThresholdCalibrator.Calibrate(runs));

            // Ha nguong toi thieu thi tinh duoc, va hai gia tri hong khong lot vao ket qua.
            MedalThresholds thresholds = MedalThresholdCalibrator.Calibrate(runs, 8);
            Assert.That(thresholds.GoldSeconds, Is.EqualTo(100f * 1.03f).Within(0.001f));
            Assert.That(thresholds.BronzeSeconds, Is.EqualTo(145f * 1.10f).Within(0.001f));
        }

        [Test]
        public void FewerThanTenRuns_IsRejectedByDefault()
        {
            var nineRuns = new List<float> { 100f, 105f, 110f, 115f, 120f, 125f, 130f, 135f, 140f };

            Assert.Throws<ArgumentException>(() => MedalThresholdCalibrator.Calibrate(nineRuns));
            Assert.DoesNotThrow(() => MedalThresholdCalibrator.Calibrate(nineRuns, 9));
        }

        [Test]
        public void RejectsNullAndNonsenseArguments()
        {
            Assert.Throws<ArgumentNullException>(() => MedalThresholdCalibrator.Calibrate(null));
            Assert.Throws<ArgumentOutOfRangeException>(() => MedalThresholdCalibrator.Calibrate(TenRuns(), 0));
            Assert.Throws<ArgumentNullException>(() => MedalThresholdCalibrator.Median(null));
            Assert.Throws<ArgumentException>(() => MedalThresholdCalibrator.Median(Array.Empty<float>()));
        }

        [Test]
        public void ResultIsUsableByTheEvaluator()
        {
            MedalThresholds thresholds = MedalThresholdCalibrator.Calibrate(TenRuns());

            Assert.That(MedalEvaluator.Evaluate(100f, thresholds), Is.EqualTo(Medal.Gold));
            Assert.That(MedalEvaluator.Evaluate(122f, thresholds), Is.EqualTo(Medal.Silver));
            Assert.That(MedalEvaluator.Evaluate(150f, thresholds), Is.EqualTo(Medal.Bronze));
            Assert.That(MedalEvaluator.Evaluate(200f, thresholds), Is.EqualTo(Medal.None));
        }
    }
}
