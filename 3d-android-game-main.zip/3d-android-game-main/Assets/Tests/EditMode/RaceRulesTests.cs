using System;
using System.Collections.Generic;
using NUnit.Framework;
using RacingDemo.Core.Racing;

namespace RacingDemo.Tests.EditMode
{
    /// <summary>
    /// Kiem tra may trang thai luot dua theo muc 4 cua ke hoach.
    /// Cau hinh dung trong test: 4 checkpoint, 2 vong, countdown 3 s, khoa reset 1,5 s.
    /// </summary>
    public sealed class RaceRulesTests
    {
        private const float Countdown = 3f;
        private const float RespawnLock = 1.5f;
        private const float Tolerance = 1e-4f;

        private static RaceRules CreateRules()
        {
            return new RaceRules(new RaceConfig(4, 2, Countdown, RespawnLock));
        }

        /// <summary>Dua ve trang thai Running ngay sau khi countdown ket thuc (elapsed = 0).</summary>
        private static RaceRules CreateRunningRules()
        {
            RaceRules rules = CreateRules();
            rules.BeginCountdown();
            rules.Tick(Countdown);
            Assert.That(rules.Phase, Is.EqualTo(RacePhase.Running), "Chuan bi test that bai.");
            Assert.That(rules.ElapsedSeconds, Is.EqualTo(0f).Within(Tolerance));
            return rules;
        }

        private static void CompleteLap(RaceRules rules, float stepSeconds = 0.5f)
        {
            for (int index = 0; index < rules.Config.CheckpointCount; index++)
            {
                rules.Tick(stepSeconds);
                Assert.That(rules.TryPassCheckpoint(index), Is.True, "Checkpoint " + index + " bi tu choi.");
            }
        }

        [Test]
        public void NewRules_StartIdle_WithNoProgress()
        {
            RaceRules rules = CreateRules();

            Assert.That(rules.Phase, Is.EqualTo(RacePhase.Idle));
            Assert.That(rules.ElapsedSeconds, Is.EqualTo(0f));
            Assert.That(rules.CurrentLap, Is.EqualTo(1));
            Assert.That(rules.NextCheckpointIndex, Is.EqualTo(0));
            Assert.That(rules.LastAcceptedCheckpointIndex, Is.Null);
            Assert.That(rules.IsRespawning, Is.False);
        }

        [Test]
        public void Countdown_KeepsRaceTimeAtZero_UntilItEnds()
        {
            RaceRules rules = CreateRules();
            rules.BeginCountdown();

            rules.Tick(1f);
            rules.Tick(1.9f);

            Assert.That(rules.Phase, Is.EqualTo(RacePhase.Countdown));
            Assert.That(rules.CountdownRemaining, Is.EqualTo(0.1f).Within(Tolerance));
            Assert.That(rules.ElapsedSeconds, Is.EqualTo(0f).Within(Tolerance));
        }

        [Test]
        public void Countdown_OverflowDelta_CountsIntoRaceTimeOnly()
        {
            RaceRules rules = CreateRules();
            rules.BeginCountdown();

            rules.Tick(2.8f);
            rules.Tick(0.5f);

            Assert.That(rules.Phase, Is.EqualTo(RacePhase.Running));
            Assert.That(rules.CountdownRemaining, Is.EqualTo(0f).Within(Tolerance));
            Assert.That(rules.ElapsedSeconds, Is.EqualTo(0.3f).Within(Tolerance));
        }

        [Test]
        public void Tick_Zero_DoesNotChangeState()
        {
            RaceRules rules = CreateRules();
            rules.BeginCountdown();
            rules.Tick(1f);

            float remaining = rules.CountdownRemaining;
            rules.Tick(0f);

            Assert.That(rules.CountdownRemaining, Is.EqualTo(remaining));
            Assert.That(rules.Phase, Is.EqualTo(RacePhase.Countdown));
        }

        [Test]
        public void Tick_NegativeOrNonFinite_ThrowsArgumentException()
        {
            RaceRules rules = CreateRunningRules();

            Assert.Throws<ArgumentOutOfRangeException>(() => rules.Tick(-0.01f));
            Assert.Throws<ArgumentException>(() => rules.Tick(float.NaN));
            Assert.Throws<ArgumentException>(() => rules.Tick(float.PositiveInfinity));
            Assert.Throws<ArgumentException>(() => rules.Tick(float.NegativeInfinity));
        }

        [Test]
        public void Timer_AdvancesOnlyWhileRunning()
        {
            RaceRules rules = CreateRunningRules();
            rules.Tick(1f);

            rules.Pause();
            rules.Tick(5f);
            Assert.That(rules.ElapsedSeconds, Is.EqualTo(1f).Within(Tolerance), "Pause khong duoc cong thoi gian.");

            rules.Resume();
            rules.Tick(1f);
            Assert.That(rules.ElapsedSeconds, Is.EqualTo(2f).Within(Tolerance));
        }

        [Test]
        public void Timer_KeepsRunning_WhileRespawnLockIsActive()
        {
            RaceRules rules = CreateRunningRules();

            Assert.That(rules.TryRequestRespawn(), Is.True);
            rules.Tick(1f);

            Assert.That(rules.IsRespawning, Is.True);
            Assert.That(rules.RespawnRemaining, Is.EqualTo(0.5f).Within(Tolerance));
            Assert.That(rules.ElapsedSeconds, Is.EqualTo(1f).Within(Tolerance), "Dong ho dua van chay khi reset.");
        }

        [Test]
        public void Checkpoints_MustBePassedInOrder()
        {
            RaceRules rules = CreateRunningRules();

            Assert.That(rules.TryPassCheckpoint(1), Is.False, "Bo qua cong 0 khong duoc tinh.");
            Assert.That(rules.TryPassCheckpoint(3), Is.False, "Di thang toi vach dich khong duoc tinh.");
            Assert.That(rules.NextCheckpointIndex, Is.EqualTo(0));

            Assert.That(rules.TryPassCheckpoint(0), Is.True);
            Assert.That(rules.TryPassCheckpoint(0), Is.False, "Qua lai cung cong khong duoc tinh.");
            Assert.That(rules.NextCheckpointIndex, Is.EqualTo(1));
            Assert.That(rules.LastAcceptedCheckpointIndex, Is.EqualTo(0));
        }

        [Test]
        public void SecondLap_KeepsFinalGateAsLastAcceptedCheckpoint()
        {
            RaceRules rules = CreateRunningRules();

            CompleteLap(rules);

            Assert.That(rules.CurrentLap, Is.EqualTo(2));
            Assert.That(rules.NextCheckpointIndex, Is.EqualTo(0));
            Assert.That(rules.LastAcceptedCheckpointIndex, Is.EqualTo(3),
                "Dau vong 2 diem hoi xe van la cong cuoi vong 1.");
            Assert.That(rules.Phase, Is.EqualTo(RacePhase.Running));
        }

        [Test]
        public void Race_FinishesAfterTwoLaps_AndRaisesFinishedOnce()
        {
            RaceRules rules = CreateRunningRules();
            var finishedTimes = new List<float>();
            rules.RaceFinished += time => finishedTimes.Add(time);

            CompleteLap(rules);
            Assert.That(rules.Phase, Is.EqualTo(RacePhase.Running), "Mot vong chua ket thuc dua.");

            CompleteLap(rules);

            Assert.That(rules.Phase, Is.EqualTo(RacePhase.Finished));
            Assert.That(finishedTimes.Count, Is.EqualTo(1));
            Assert.That(finishedTimes[0], Is.EqualTo(4f).Within(Tolerance));

            // Sau khi ket thuc: khong nhan them checkpoint, dong ho dung.
            Assert.That(rules.TryPassCheckpoint(0), Is.False);
            rules.Tick(2f);
            Assert.That(rules.ElapsedSeconds, Is.EqualTo(4f).Within(Tolerance));
            Assert.That(finishedTimes.Count, Is.EqualTo(1));
        }

        [Test]
        public void Respawn_IsRejected_WhenAlreadyRespawningOrNotRunning()
        {
            RaceRules rules = CreateRules();
            rules.BeginCountdown();
            Assert.That(rules.TryRequestRespawn(), Is.False, "Countdown khong nhan reset.");

            rules.Tick(Countdown);
            Assert.That(rules.TryRequestRespawn(), Is.True);
            Assert.That(rules.TryRequestRespawn(), Is.False, "Nhan lan hai khong duoc chap nhan.");

            rules.Tick(0.5f);
            Assert.That(rules.RespawnRemaining, Is.EqualTo(1f).Within(Tolerance),
                "Nhan nhieu lan khong gia han khoa xe.");

            rules.Pause();
            Assert.That(rules.TryRequestRespawn(), Is.False, "Pause khong nhan reset.");
        }

        [Test]
        public void Respawn_IgnoresCheckpoints_UntilLockEnds()
        {
            RaceRules rules = CreateRunningRules();
            rules.TryRequestRespawn();

            Assert.That(rules.TryPassCheckpoint(0), Is.False, "Trigger khi dang khoa xe khong duoc tinh.");

            rules.Tick(RespawnLock);

            Assert.That(rules.IsRespawning, Is.False);
            Assert.That(rules.RespawnRemaining, Is.EqualTo(0f).Within(Tolerance));
            Assert.That(rules.TryPassCheckpoint(0), Is.True);
        }

        [Test]
        public void Pause_DuringRespawn_FreezesRemainingLock()
        {
            RaceRules rules = CreateRunningRules();
            rules.TryRequestRespawn();
            rules.Tick(1.1f);
            Assert.That(rules.RespawnRemaining, Is.EqualTo(0.4f).Within(Tolerance));

            rules.Pause();
            rules.Tick(3f);

            Assert.That(rules.Phase, Is.EqualTo(RacePhase.Paused));
            Assert.That(rules.RespawnRemaining, Is.EqualTo(0.4f).Within(Tolerance));
            Assert.That(rules.IsRespawning, Is.True);

            rules.Resume();
            Assert.That(rules.Phase, Is.EqualTo(RacePhase.Running));
            Assert.That(rules.RespawnRemaining, Is.EqualTo(0.4f).Within(Tolerance));
        }

        [Test]
        public void Pause_FromCountdown_ResumesBackToCountdown()
        {
            RaceRules rules = CreateRules();
            rules.BeginCountdown();
            rules.Tick(1f);

            rules.Pause();
            rules.Tick(5f);
            Assert.That(rules.Phase, Is.EqualTo(RacePhase.Paused));
            Assert.That(rules.CountdownRemaining, Is.EqualTo(2f).Within(Tolerance));

            rules.Resume();
            Assert.That(rules.Phase, Is.EqualTo(RacePhase.Countdown));
            Assert.That(rules.CountdownRemaining, Is.EqualTo(2f).Within(Tolerance));
        }

        [Test]
        public void Pause_IsIdempotent_AndIgnoredWhenFinished()
        {
            RaceRules rules = CreateRunningRules();

            rules.Pause();
            rules.Pause();
            Assert.That(rules.Phase, Is.EqualTo(RacePhase.Paused));

            rules.Resume();
            Assert.That(rules.Phase, Is.EqualTo(RacePhase.Running), "Pause hai lan khong duoc lam ket phase.");

            CompleteLap(rules);
            CompleteLap(rules);
            Assert.That(rules.Phase, Is.EqualTo(RacePhase.Finished));

            rules.Pause();
            Assert.That(rules.Phase, Is.EqualTo(RacePhase.Finished), "Results khong bi pause.");
        }

        [Test]
        public void Restart_DuringRespawn_ClearsPreviousRunState()
        {
            RaceRules rules = CreateRunningRules();
            CompleteLap(rules);
            rules.TryRequestRespawn();
            rules.Tick(0.5f);

            rules.Restart();

            Assert.That(rules.Phase, Is.EqualTo(RacePhase.Countdown));
            Assert.That(rules.CountdownRemaining, Is.EqualTo(Countdown).Within(Tolerance));
            Assert.That(rules.ElapsedSeconds, Is.EqualTo(0f).Within(Tolerance));
            Assert.That(rules.CurrentLap, Is.EqualTo(1));
            Assert.That(rules.NextCheckpointIndex, Is.EqualTo(0));
            Assert.That(rules.LastAcceptedCheckpointIndex, Is.Null);
            Assert.That(rules.IsRespawning, Is.False);
            Assert.That(rules.RespawnRemaining, Is.EqualTo(0f).Within(Tolerance));
        }

        [Test]
        public void Restart_FromPause_StartsNewCountdown()
        {
            RaceRules rules = CreateRunningRules();
            rules.Tick(10f);
            rules.Pause();

            rules.Restart();
            rules.Tick(Countdown);

            Assert.That(rules.Phase, Is.EqualTo(RacePhase.Running));
            Assert.That(rules.ElapsedSeconds, Is.EqualTo(0f).Within(Tolerance));
        }

        [Test]
        public void Restart_FromFinished_AllowsAnotherFullRace()
        {
            RaceRules rules = CreateRunningRules();
            int finishedCount = 0;
            rules.RaceFinished += _ => finishedCount++;

            CompleteLap(rules);
            CompleteLap(rules);
            Assert.That(finishedCount, Is.EqualTo(1));

            rules.Restart();
            rules.Tick(Countdown);
            CompleteLap(rules);
            CompleteLap(rules);

            Assert.That(finishedCount, Is.EqualTo(2));
            Assert.That(rules.Phase, Is.EqualTo(RacePhase.Finished));
        }

        [Test]
        public void PhaseChanged_ReportsEachTransitionOnce()
        {
            RaceRules rules = CreateRules();
            var phases = new List<RacePhase>();
            rules.PhaseChanged += phase => phases.Add(phase);

            rules.BeginCountdown();
            rules.Tick(Countdown);
            rules.Pause();
            rules.Resume();

            Assert.That(phases, Is.EqualTo(new[]
            {
                RacePhase.Countdown,
                RacePhase.Running,
                RacePhase.Paused,
                RacePhase.Running
            }));
        }

        [Test]
        public void Config_RejectsInvalidValues()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() => new RaceConfig(1, 2, 3f, 1.5f));
            Assert.Throws<ArgumentOutOfRangeException>(() => new RaceConfig(4, 0, 3f, 1.5f));
            Assert.Throws<ArgumentOutOfRangeException>(() => new RaceConfig(4, 2, -1f, 1.5f));
            Assert.Throws<ArgumentException>(() => new RaceConfig(4, 2, float.NaN, 1.5f));
        }
    }
}
