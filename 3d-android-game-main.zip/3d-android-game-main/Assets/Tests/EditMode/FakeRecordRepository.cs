using System;
using System.Collections.Generic;
using RacingDemo.Core.Persistence;

namespace RacingDemo.Tests.EditMode
{
    /// <summary>
    /// Repository gia de test RecordStore ma khong cham dia.
    /// Mo phong duoc ca hai kieu that bai: tra false + error, va nem exception.
    /// </summary>
    public sealed class FakeRecordRepository : IRecordRepository
    {
        private List<RecordData> _stored = new List<RecordData>();

        public bool LoadShouldFail { get; set; }

        public bool LoadShouldThrow { get; set; }

        public bool SaveShouldFail { get; set; }

        public bool SaveShouldThrow { get; set; }

        public string FailureMessage { get; set; } = "Loi gia lap.";

        public int LoadCallCount { get; private set; }

        public int SaveCallCount { get; private set; }

        public IReadOnlyList<RecordData> Stored
        {
            get { return _stored; }
        }

        public void SeedStored(params RecordData[] records)
        {
            _stored = new List<RecordData>(records);
        }

        public bool TryLoad(out IReadOnlyList<RecordData> records, out string error)
        {
            LoadCallCount++;

            if (LoadShouldThrow)
            {
                throw new InvalidOperationException(FailureMessage);
            }

            if (LoadShouldFail)
            {
                records = null;
                error = FailureMessage;
                return false;
            }

            records = new List<RecordData>(_stored);
            error = null;
            return true;
        }

        public bool TrySave(IReadOnlyList<RecordData> records, out string error)
        {
            SaveCallCount++;

            if (SaveShouldThrow)
            {
                throw new InvalidOperationException(FailureMessage);
            }

            if (SaveShouldFail)
            {
                error = FailureMessage;
                return false;
            }

            _stored = new List<RecordData>(records);
            error = null;
            return true;
        }
    }
}
