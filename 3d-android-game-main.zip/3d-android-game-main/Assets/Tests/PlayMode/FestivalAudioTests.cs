using System.Collections;
using System.Reflection;
using NUnit.Framework;
using RacingDemo.Runtime.Audio;
using UnityEngine;
using UnityEngine.TestTools;

namespace RacingDemo.Tests.PlayMode
{
    public sealed class FestivalAudioTests
    {
        [UnityTest]
        public IEnumerator FocusReturnCannotOverrideGamePauseAndMenusAlsoSuspend()
        {
            var go = new GameObject("audio-test");
            FestivalAudio audio = go.AddComponent<FestivalAudio>();
            try
            {
                yield return null;
                audio.SetContext(false);
                go.SendMessage("OnApplicationFocus", false);
                Assert.IsTrue(audio.IsSuspended, "Festival audio must also stop in background.");
                audio.SetPaused(true);
                go.SendMessage("OnApplicationFocus", true);
                Assert.IsTrue(audio.IsSuspended, "Regaining focus must not resume paused race audio.");
                audio.SetPaused(false);
                Assert.IsFalse(audio.IsSuspended);
                go.SendMessage("OnApplicationPause", true);
                go.SendMessage("OnApplicationFocus", true);
                Assert.IsTrue(audio.IsSuspended, "Focus callback must not override app pause callback.");
                go.SendMessage("OnApplicationPause", false);
                Assert.IsFalse(audio.IsSuspended);
            }
            finally { Object.Destroy(go); }
        }
        [UnityTest]
        public IEnumerator RaceContextDucksMusicAndRepeatedTransitionsKeepOnlyTwoSources()
        {
            var go = new GameObject("audio-test"); go.SetActive(false);
            AudioSource music = go.AddComponent<AudioSource>();
            AudioSource wind = go.AddComponent<AudioSource>();
            FestivalAudio audio = go.AddComponent<FestivalAudio>();
            typeof(FestivalAudio).GetField("_music", BindingFlags.NonPublic | BindingFlags.Instance).SetValue(audio, music);
            typeof(FestivalAudio).GetField("_ambience", BindingFlags.NonPublic | BindingFlags.Instance).SetValue(audio, wind);
            go.SetActive(true);
            try
            {
                yield return null;
                audio.SetContext(false); float festivalVolume = music.volume;
                audio.SetContext(true); Assert.Less(music.volume, festivalVolume);
                Assert.Less(wind.volume, 0.05f);
                for (int i = 0; i < 8; i++) { audio.SetPaused(true); audio.SetContext(false); audio.SetPaused(false); audio.SetContext(true); }
                Assert.AreEqual(2, go.GetComponents<AudioSource>().Length);
                Assert.IsFalse(audio.IsSuspended);
                Assert.IsFalse(music.playOnAwake);
            }
            finally { Object.Destroy(go); }
        }
    }
}
