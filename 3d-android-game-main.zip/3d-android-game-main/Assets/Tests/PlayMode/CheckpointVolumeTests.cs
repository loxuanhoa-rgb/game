using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using NUnit.Framework;
using RacingDemo.Runtime.Track;
using UnityEngine;
using UnityEngine.TestTools;

namespace RacingDemo.Tests.PlayMode
{
    public sealed class CheckpointVolumeTests
    {
        private static readonly Vector3 Origin = new Vector3(10000f, 1000f, 10000f);
        private readonly List<GameObject> _objects = new List<GameObject>();
        private readonly List<int> _passes = new List<int>();
        private Rigidbody _player;
        private CheckpointVolume _gate;
        private float _previousTimeScale;

        [SetUp]
        public void SetUp()
        {
            _previousTimeScale = Time.timeScale;
            Time.timeScale = 1f;
            _passes.Clear();
            _player = CreateBody("Player", new Vector3(0f, 1f, -7f));

            GameObject gateObject = NewObject("Gate");
            gateObject.SetActive(false);
            gateObject.transform.position = Origin;
            BoxCollider trigger = gateObject.AddComponent<BoxCollider>();
            trigger.isTrigger = true;
            trigger.size = new Vector3(12f, 4f, 4f);
            trigger.center = new Vector3(0f, 2f, 0f);
            _gate = gateObject.AddComponent<CheckpointVolume>();
            SetField(_gate, "_playerBody", _player);
            SetField(_gate, "_order", 3);
            _gate.Passed += _passes.Add;
            gateObject.SetActive(true);
            Physics.SyncTransforms();
        }

        [UnityTearDown]
        public IEnumerator TearDown()
        {
            if (_gate != null)
            {
                _gate.Passed -= _passes.Add;
            }

            foreach (GameObject gameObject in _objects)
            {
                Object.Destroy(gameObject);
            }

            _objects.Clear();
            Time.timeScale = _previousTimeScale;
            yield return null;
        }

        [UnityTest]
        public IEnumerator CompoundPlayerForwardCrossingReportsExactlyOnce()
        {
            yield return DriveToZ(_player, 7f, 12f);
            CollectionAssert.AreEqual(new[] { 3 }, _passes);
        }

        [UnityTest]
        public IEnumerator CrossingAt120KphIsDetectedByTheThickTrigger()
        {
            yield return DriveToZ(_player, 7f, 120f / 3.6f);
            CollectionAssert.AreEqual(new[] { 3 }, _passes);
        }

        [UnityTest]
        public IEnumerator SpawnWithOnlyTheFrontColliderInsideDoesNotArm()
        {
            Teleport(_player, new Vector3(0f, 1f, -3f));
            yield return DriveToZ(_player, 7f, 12f);
            Assert.That(_passes, Is.Empty);
        }

        [UnityTest]
        public IEnumerator ForeignRigidbodyIsIgnored()
        {
            Rigidbody foreignBody = CreateBody("Other car", new Vector3(3f, 1f, -7f));
            yield return DriveToZ(foreignBody, 7f, 12f);
            Assert.That(_passes, Is.Empty);
        }

        [UnityTest]
        public IEnumerator ReverseTraversalIsIgnored()
        {
            Teleport(_player, new Vector3(0f, 1f, 7f));
            yield return DriveToZ(_player, -7f, -12f);
            Assert.That(_passes, Is.Empty);
        }

        [UnityTest]
        public IEnumerator SideEntryDoesNotBecomeAForwardTraversalInsideGate()
        {
            Teleport(_player, new Vector3(-9f, 1f, -1f));
            _player.linearVelocity = Vector3.right * 12f;
            for (int step = 0; step < 180 && _player.position.x < Origin.x; step++)
            {
                yield return new WaitForFixedUpdate();
            }

            _player.linearVelocity = Vector3.zero;
            Assert.That(_player.position.x, Is.GreaterThanOrEqualTo(Origin.x));
            yield return DriveToZ(_player, 7f, 12f);
            Assert.That(_passes, Is.Empty);
        }

        [UnityTest]
        public IEnumerator SpawnInsideRequiresLeavingAndAFullNewApproach()
        {
            Teleport(_player, new Vector3(0f, 1f, -1f));
            yield return DriveToZ(_player, 7f, 12f);
            Assert.That(_passes, Is.Empty);

            yield return DriveToZ(_player, -7f, -12f);
            Assert.That(_passes, Is.Empty);
            yield return DriveToZ(_player, 7f, 12f);
            CollectionAssert.AreEqual(new[] { 3 }, _passes);
        }

        [UnityTest]
        public IEnumerator ClearTraversalDiscardsAnArmedPreTeleportApproach()
        {
            yield return DriveToZ(_player, -3f, 12f);
            Assert.That(_passes, Is.Empty);
            _gate.ClearTraversal();
            Teleport(_player, new Vector3(0f, 1f, -0.1f));
            yield return DriveToZ(_player, 7f, 12f);
            Assert.That(_passes, Is.Empty);
        }

        [UnityTest]
        public IEnumerator KinematicCrossingAndUnlockingInsideAreIgnored()
        {
            yield return new WaitForFixedUpdate();
            _player.isKinematic = true;
            for (int step = 0; step < 30; step++)
            {
                _player.MovePosition(_player.position + Vector3.forward * 0.3f);
                yield return new WaitForFixedUpdate();
            }

            Assert.That(_passes, Is.Empty);
            Teleport(_player, new Vector3(0f, 1f, -0.1f));
            yield return new WaitForFixedUpdate();
            _player.isKinematic = false;
            yield return DriveToZ(_player, 7f, 12f);
            Assert.That(_passes, Is.Empty);
        }

        [UnityTest]
        public IEnumerator ANewForwardTraversalCanReportAgainAfterFullExit()
        {
            yield return DriveToZ(_player, 7f, 12f);
            yield return DriveToZ(_player, -7f, -12f);
            CollectionAssert.AreEqual(new[] { 3 }, _passes);
            yield return DriveToZ(_player, 7f, 12f);
            CollectionAssert.AreEqual(new[] { 3, 3 }, _passes);
        }

        private IEnumerator DriveToZ(Rigidbody body, float localTarget, float speed)
        {
            float target = Origin.z + localTarget;
            body.linearVelocity = Vector3.forward * speed;
            for (int step = 0; step < 180; step++)
            {
                yield return new WaitForFixedUpdate();
                if ((speed > 0f && body.position.z >= target) ||
                    (speed < 0f && body.position.z <= target))
                {
                    body.linearVelocity = Vector3.zero;
                    yield break;
                }
            }

            body.linearVelocity = Vector3.zero;
            Assert.Fail("Physics traversal did not reach its bounded target.");
        }

        private Rigidbody CreateBody(string name, Vector3 localPosition)
        {
            GameObject car = NewObject(name);
            car.transform.position = Origin + localPosition;
            Rigidbody body = car.AddComponent<Rigidbody>();
            body.useGravity = false;
            body.constraints = RigidbodyConstraints.FreezeRotation;
            body.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
            // Both child colliders cross the trigger during one traversal. The
            // receiver must use attachedRigidbody, not collider.gameObject equality.
            AddBodyBox(car.transform, new Vector3(-0.4f, 0f, -0.4f));
            AddBodyBox(car.transform, new Vector3(0.4f, 0f, 0.4f));
            return body;
        }

        private void AddBodyBox(Transform parent, Vector3 localPosition)
        {
            GameObject child = new GameObject("Body collider");
            child.transform.SetParent(parent, false);
            child.transform.localPosition = localPosition;
            BoxCollider collider = child.AddComponent<BoxCollider>();
            collider.size = new Vector3(1f, 0.8f, 2f);
        }

        private GameObject NewObject(string name)
        {
            GameObject gameObject = new GameObject(name);
            _objects.Add(gameObject);
            return gameObject;
        }

        private static void Teleport(Rigidbody body, Vector3 localPosition)
        {
            body.position = Origin + localPosition;
            Physics.SyncTransforms();
        }

        private static void SetField(Object target, string name, object value)
        {
            FieldInfo field = target.GetType().GetField(name, BindingFlags.Instance | BindingFlags.NonPublic);
            Assert.That(field, Is.Not.Null);
            field.SetValue(target, value);
        }
    }
}
