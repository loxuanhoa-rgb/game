using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using NUnit.Framework;
using RacingDemo.Core.Racing;
using RacingDemo.Core.Persistence;
using RacingDemo.Runtime.Audio;
using RacingDemo.Runtime.Persistence;
using RacingDemo.Runtime.Input;
using RacingDemo.Runtime.Race;
using RacingDemo.Runtime.Vehicle;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.TestTools;
using UnityEngine.UI;

namespace RacingDemo.Tests.PlayMode
{
    /// <summary>
    /// Task 4: chay THAT scene Race.unity da build ra, khong dung scene gia.
    /// Kiem vong choi countdown -> chay -> pause/resume -> reset -> ket qua -> choi lai,
    /// tuc la phan ma test Core khong voi toi duoc: timeScale, khoa input va trang thai UI.
    ///
    /// Cong checkpoint vat ly da co bo test rieng (<see cref="CheckpointVolumeTests"/>);
    /// o day tien trinh vong duoc bao cho Core truc tiep de khong phai lai xe trong test.
    /// </summary>
    public sealed class RaceLoopSceneTests
    {
        private const string RaceSceneName = "Race";
        private const float PhaseTimeout = 12f;

        private RaceDirector _director;
        private CarController _car;
        private CarInputRelay _input;
        private float _previousTimeScale;

        [UnitySetUp]
        public IEnumerator SetUp()
        {
            _previousTimeScale = Time.timeScale;
            Time.timeScale = 1f;

            // sceneLoaded runs after Awake and before Start reads persistence.
            SceneManager.sceneLoaded += UseIsolatedRecords;
            try
            {
                yield return SceneManager.LoadSceneAsync(RaceSceneName, LoadSceneMode.Single);
            }
            finally { SceneManager.sceneLoaded -= UseIsolatedRecords; }
            yield return null;

            _director = Object.FindAnyObjectByType<RaceDirector>();
            _car = Object.FindAnyObjectByType<CarController>();
            _input = Object.FindAnyObjectByType<CarInputRelay>();

            Assert.IsNotNull(_director, "Scene Race.unity phai co RaceDirector. Chay RacingDemo/Rebuild Demo.");
            Assert.IsNotNull(_car);
            Assert.IsNotNull(_input);
            Assert.IsTrue(_director.IsFestivalVisible, "Cold launch must open the festival.");
            Assert.AreEqual(RacePhase.Idle, _director.Rules.Phase);
            _director.StartRace();
        }

        [TearDown]
        public void TearDown()
        {
            Time.timeScale = _previousTimeScale;
        }

        [UnityTest]
        public IEnumerator SceneStartsInCountdownWithCarLockedAndBothMenusHidden()
        {
            Assert.AreEqual(RacePhase.Countdown, _director.Rules.Phase);
            Assert.IsTrue(_car.IsPoseLocked, "Xe phai bi khoa tai cho trong luc dem nguoc.");
            Assert.IsFalse(_car.IsControlEnabled);
            Assert.IsFalse(_director.IsPauseMenuVisible);
            Assert.IsFalse(_director.IsResultsVisible, "Ket qua chi mo sau khi ve dich.");
            Assert.AreEqual(1f, Time.timeScale);
            yield break;
        }

        [UnityTest]
        public IEnumerator CountdownReleasesTheCarAndStartsTheClock()
        {
            yield return WaitForPhase(RacePhase.Running);

            Assert.IsFalse(_car.IsPoseLocked);
            Assert.IsTrue(_car.IsControlEnabled);
            Assert.IsTrue(_input.IsInputEnabled);
            Assert.Greater(_director.Rules.ElapsedSeconds, 0f, "Dong ho dua chi chay sau khi het dem nguoc.");
        }

        [UnityTest]
        public IEnumerator PauseStopsTimeAndOpensTheMenuThenResumeRestoresControl()
        {
            yield return WaitForPhase(RacePhase.Running);

            _director.RequestPause();
            Assert.AreEqual(RacePhase.Paused, _director.Rules.Phase);
            Assert.AreEqual(0f, Time.timeScale);
            Assert.IsTrue(_director.IsPauseMenuVisible, "Menu phai mo ngay lan dau bam.");
            Assert.IsFalse(_input.IsInputEnabled, "Pause phai xoa va khoa input.");

            float pausedTime = _director.Rules.ElapsedSeconds;
            yield return null;
            yield return null;
            Assert.AreEqual(pausedTime, _director.Rules.ElapsedSeconds, "Dong ho dua phai dung khi pause.");

            _director.Resume();
            Assert.AreEqual(RacePhase.Running, _director.Rules.Phase);
            Assert.AreEqual(1f, Time.timeScale);
            Assert.IsFalse(_director.IsPauseMenuVisible);
            Assert.IsTrue(_input.IsInputEnabled);
        }

        [UnityTest]
        public IEnumerator LosingFocusPausesAndComingBackDoesNotResume()
        {
            yield return WaitForPhase(RacePhase.Running);

            _director.gameObject.SendMessage("OnApplicationFocus", false);
            Assert.AreEqual(RacePhase.Paused, _director.Rules.Phase);
            Assert.IsTrue(_director.IsPauseMenuVisible);

            // Idempotent: mat focus lan hai khong duoc tao them trang thai nao.
            _director.gameObject.SendMessage("OnApplicationPause", true);
            Assert.AreEqual(RacePhase.Paused, _director.Rules.Phase);

            _director.gameObject.SendMessage("OnApplicationFocus", true);
            yield return null;
            Assert.AreEqual(RacePhase.Paused, _director.Rules.Phase, "Quay lai app khong duoc tu choi tiep.");
            Assert.AreEqual(0f, Time.timeScale);
        }

        [UnityTest]
        public IEnumerator ResetIsRejectedWhileCountingDownAndLocksTheCarWhileRunning()
        {
            _director.RequestReset();
            Assert.IsFalse(_director.Rules.IsRespawning, "Countdown khong nhan reset.");

            yield return WaitForPhase(RacePhase.Running);

            _director.RequestReset();
            Assert.IsTrue(_director.Rules.IsRespawning);
            Assert.IsTrue(_car.IsPoseLocked);
            Assert.IsFalse(_input.IsInputEnabled);

            float lockedAt = _director.Rules.RespawnRemaining;
            _director.RequestReset();
            Assert.AreEqual(lockedAt, _director.Rules.RespawnRemaining, "Bam reset lan hai khong duoc gia han khoa.");

            float beforeLock = _director.Rules.ElapsedSeconds;
            yield return WaitUntilTrue(() => !_director.Rules.IsRespawning);

            Assert.Greater(_director.Rules.ElapsedSeconds, beforeLock, "Dong ho dua van chay trong luc khoa reset.");
            Assert.IsFalse(_car.IsPoseLocked);
            Assert.IsTrue(_input.IsInputEnabled);
        }

        [UnityTest]
        public IEnumerator RestartFromPauseBeginsAFreshCountdown()
        {
            yield return WaitForPhase(RacePhase.Running);
            Assert.IsTrue(_director.Rules.TryPassCheckpoint(0));

            _director.RequestPause();
            _director.Restart();

            Assert.AreEqual(RacePhase.Countdown, _director.Rules.Phase);
            Assert.AreEqual(1f, Time.timeScale, "Restart phai tra timeScale ve 1.");
            Assert.AreEqual(1, _director.Rules.CurrentLap);
            Assert.AreEqual(0, _director.Rules.NextCheckpointIndex);
            Assert.IsNull(_director.Rules.LastAcceptedCheckpointIndex);
            Assert.IsFalse(_director.IsPauseMenuVisible);
            Assert.AreEqual(0f, _director.Rules.ElapsedSeconds);
        }

        /// <summary>
        /// Bam pause mot lan sau restart phai ra dung mot lan pause. Neu director dang ky
        /// listener lai o moi lan restart thi lan bam nay se pause roi resume ngay.
        /// </summary>
        [UnityTest]
        public IEnumerator PauseRequestStillTogglesOnceAfterSeveralRestarts()
        {
            yield return WaitForPhase(RacePhase.Running);
            _director.Restart();
            _director.Restart();
            yield return WaitForPhase(RacePhase.Running);

            _input.RequestPause();
            Assert.AreEqual(RacePhase.Paused, _director.Rules.Phase);

            _input.RequestPause();
            Assert.AreEqual(RacePhase.Running, _director.Rules.Phase);
        }

        [UnityTest]
        public IEnumerator FinishingEveryLapShowsResultsOutsideThePhysicsStep()
        {
            yield return WaitForPhase(RacePhase.Running);

            RaceRules rules = _director.Rules;
            for (int lap = 0; lap < rules.Config.LapCount; lap++)
            {
                for (int gate = 0; gate < rules.Config.CheckpointCount; gate++)
                {
                    Assert.IsTrue(rules.TryPassCheckpoint(gate), "Cong " + gate + " vong " + (lap + 1) + " bi tu choi.");
                }
            }

            Assert.AreEqual(RacePhase.Finished, rules.Phase);
            yield return null;

            Assert.IsTrue(_director.IsResultsVisible, "Ve dich phai mo man ket qua.");
            Assert.IsFalse(_director.IsPauseMenuVisible);
            Assert.IsFalse(_car.IsControlEnabled, "Ket thuc thi khoa dieu khien.");
            Assert.IsFalse(_input.IsInputEnabled);

            // Luot dau vua chot ky luc: dong ky luc phai la chinh thoi gian vua luu, khong phai 0.
            string finishTime = RaceTimeFormatter.Format(rules.ElapsedSeconds);
            ResultsPresenter results = Object.FindAnyObjectByType<ResultsPresenter>();
            Assert.AreEqual(finishTime, LabelText(results, "_timeLabel"));
            Assert.AreEqual("KỶ LỤC: " + finishTime, LabelText(results, "_recordLabel"));
            Assert.AreNotEqual(RaceTimeFormatter.ZeroText, finishTime, "Thoi gian ve dich khong duoc la 0.");
            Assert.AreEqual(RaceHudFormatter.NewRecordText, LabelText(results, "_saveStateLabel"));
        }

        [UnityTest]
        public IEnumerator RestartFromResultsClearsTheResultScreenAndProgress()
        {
            yield return WaitForPhase(RacePhase.Running);

            RaceRules rules = _director.Rules;
            for (int lap = 0; lap < rules.Config.LapCount; lap++)
            {
                for (int gate = 0; gate < rules.Config.CheckpointCount; gate++)
                {
                    rules.TryPassCheckpoint(gate);
                }
            }

            yield return null;
            Assert.IsTrue(_director.IsResultsVisible);

            _director.Restart();
            Assert.IsFalse(_director.IsResultsVisible);
            Assert.AreEqual(RacePhase.Countdown, rules.Phase);
            Assert.AreEqual(1, rules.CurrentLap);

            // Man ket qua chi duoc mo lai khi that su ve dich lan nua.
            yield return WaitForPhase(RacePhase.Running);
            Assert.IsFalse(_director.IsResultsVisible);
        }

        [UnityTest]
        public IEnumerator PauseDuringCountdownPreservesRemainingTimeAndPoseLock()
        {
            _director.RequestPause();
            float remaining = _director.Rules.CountdownRemaining;
            yield return new WaitForSecondsRealtime(0.2f);
            Assert.AreEqual(remaining, _director.Rules.CountdownRemaining);
            Assert.IsTrue(_car.IsPoseLocked);
            _director.Resume();
            Assert.AreEqual(RacePhase.Countdown, _director.Rules.Phase);
            Assert.IsFalse(_input.IsInputEnabled);
            Assert.IsTrue(_car.IsPoseLocked);
            yield return WaitForPhase(RacePhase.Running);
            Assert.IsTrue(_input.IsInputEnabled);
        }

        [UnityTest]
        public IEnumerator PauseDuringRespawnPreservesLockAndRestartCancelsOldRespawn()
        {
            yield return WaitForPhase(RacePhase.Running);
            _director.RequestReset();
            _director.RequestPause();
            float remaining = _director.Rules.RespawnRemaining;
            float elapsed = _director.Rules.ElapsedSeconds;
            yield return new WaitForSecondsRealtime(0.2f);
            Assert.AreEqual(remaining, _director.Rules.RespawnRemaining);
            Assert.AreEqual(elapsed, _director.Rules.ElapsedSeconds);
            _director.Resume();
            Assert.IsTrue(_car.IsPoseLocked);
            Assert.IsFalse(_input.IsInputEnabled);
            _director.RequestPause();
            _director.Restart();
            Assert.IsFalse(_director.Rules.IsRespawning);
            yield return new WaitForSeconds(remaining + 0.1f);
            Assert.AreEqual(RacePhase.Countdown, _director.Rules.Phase);
            Assert.IsTrue(_car.IsPoseLocked, "Old respawn must not unlock the new countdown.");
        }

        [UnityTest]
        public IEnumerator PausePreservesMovingCarVelocity()
        {
            yield return WaitForPhase(RacePhase.Running);
            Rigidbody body = _car.GetComponent<Rigidbody>();
            body.linearVelocity = new Vector3(0f, 0f, 8f);
            body.angularVelocity = new Vector3(0f, 0.5f, 0f);
            Vector3 velocity = body.linearVelocity;
            Vector3 angular = body.angularVelocity;
            _director.RequestPause();
            yield return new WaitForSecondsRealtime(0.2f);
            Assert.AreEqual(velocity, body.linearVelocity);
            Assert.AreEqual(angular, body.angularVelocity);
            Assert.IsFalse(body.isKinematic);
            _director.Resume();
            Assert.AreEqual(velocity, body.linearVelocity);
            Assert.AreEqual(angular, body.angularVelocity);
        }

        [UnityTest]
        public IEnumerator FallingAutomaticallyRespawnsAtLastGateOfPreviousLap()
        {
            yield return WaitForPhase(RacePhase.Running);
            for (int gate = 0; gate < 4; gate++)
                Assert.IsTrue(_director.Rules.TryPassCheckpoint(gate));
            Rigidbody body = _car.GetComponent<Rigidbody>();
            body.position = new Vector3(30f, -10f, 0f);
            yield return WaitUntilTrue(() => _director.Rules.IsRespawning);
            Assert.AreEqual(2, _director.Rules.CurrentLap);
            Assert.AreEqual(0, _director.Rules.NextCheckpointIndex);
            Assert.AreEqual(3, _director.Rules.LastAcceptedCheckpointIndex);
            Assert.That(body.position.x, Is.EqualTo(30f).Within(0.01f));
            Assert.That(body.position.z, Is.EqualTo(8f).Within(0.01f));
            Assert.IsTrue(_car.IsPoseLocked);
        }

        /// <summary>
        /// Task 6: timeScale = 0 khong dung am thanh, nen pause phai tat tieng dong co rieng.
        /// Choi lai cung phai mo tieng lai, neu khong luot sau se im.
        /// </summary>
        [UnityTest]
        public IEnumerator PauseStopsEngineSoundAndResumeBringsItBack()
        {
            EngineAudio engine = Object.FindAnyObjectByType<EngineAudio>();
            Assert.IsNotNull(engine, "Scene Race.unity phai co EngineAudio. Chay RacingDemo/Rebuild Demo.");
            Assert.IsTrue(engine.HasClip, "EngineAudio phai co clip that.");

            yield return WaitForPhase(RacePhase.Running);
            var source = engine.GetComponent<AudioSource>();
            bool wasPlaying = source.isPlaying;
            Assert.IsFalse(engine.IsPaused);

            _director.RequestPause();
            Assert.IsTrue(engine.IsPaused);
            if (wasPlaying)
            {
                Assert.IsFalse(source.isPlaying, "Pause phai dung tieng dong co lai.");
            }

            _director.Resume();
            Assert.IsFalse(engine.IsPaused);
            if (wasPlaying)
            {
                Assert.IsTrue(source.isPlaying, "Choi tiep phai mo lai tieng dong co.");
            }

            // Pause roi bam CHOI LAI (khong bam CHOI TIEP) van phai tra tieng ve binh thuong.
            _director.RequestPause();
            Assert.IsTrue(engine.IsPaused);
            _director.Restart();
            Assert.IsFalse(engine.IsPaused);
            if (wasPlaying)
            {
                Assert.IsTrue(source.isPlaying);
            }
        }

        /// <summary>
        /// Muc 8 cua ke hoach: nhan chu khong duoc chan input, va cac nut cam ung luon hien
        /// tren man hinh khong duoc chong len nhau. Do bang rect that cua canvas dang chay,
        /// khong tin vao so lieu dat trong generator.
        /// </summary>
        [UnityTest]
        public IEnumerator TouchButtonsDoNotOverlapAndLabelsDoNotBlockInput()
        {
            yield return null; // cho canvas dung xong layout

            Canvas canvas = Object.FindAnyObjectByType<Canvas>();
            Assert.IsNotNull(canvas, "Scene phai co HudCanvas.");

            foreach (TextMeshProUGUI label in canvas.GetComponentsInChildren<TextMeshProUGUI>(true))
            {
                Assert.IsFalse(label.raycastTarget,
                    "Nhan \"" + label.name + "\" dang nhan raycast nen se chan nut nam duoi.");
            }

            var buttons = new List<KeyValuePair<string, Rect>>();
            foreach (HoldButton hold in canvas.GetComponentsInChildren<HoldButton>(true))
            {
                buttons.Add(new KeyValuePair<string, Rect>(hold.name, ScreenRect((RectTransform)hold.transform)));
            }

            foreach (SteerSlider slider in canvas.GetComponentsInChildren<SteerSlider>(true))
            {
                buttons.Add(new KeyValuePair<string, Rect>(slider.name, ScreenRect((RectTransform)slider.transform)));
                // Num va hinh trang tri trong thanh khong duoc nhan raycast, neu khong se chan thanh.
                foreach (Image image in slider.GetComponentsInChildren<Image>(true))
                {
                    if (image.transform != slider.transform)
                        Assert.IsFalse(image.raycastTarget, "Hinh \"" + image.name + "\" trong thanh lai dang nhan raycast.");
                }
            }

            foreach (string name in new[] { "ResetButton", "PauseButton" })
            {
                Transform found = canvas.transform.Find("SafeArea/" + name);
                Assert.IsNotNull(found, "Thieu nut " + name + " tren HUD.");
                buttons.Add(new KeyValuePair<string, Rect>(name, ScreenRect((RectTransform)found)));
            }

            Assert.AreEqual(5, buttons.Count, "HUD phai co thanh lai, GA, PHANH cong UNSTUCK va Pause.");

            for (int i = 0; i < buttons.Count; i++)
            {
                Assert.Greater(buttons[i].Value.width * buttons[i].Value.height, 0f,
                    "Nut " + buttons[i].Key + " co dien tich bang 0.");
                for (int j = i + 1; j < buttons.Count; j++)
                {
                    Assert.IsFalse(buttons[i].Value.Overlaps(buttons[j].Value),
                        "Nut " + buttons[i].Key + " va " + buttons[j].Key + " chong len nhau: " +
                        buttons[i].Value + " vs " + buttons[j].Value);
                }
            }
        }

        /// <summary>
        /// Muc 8 cua ke hoach: choi lai nhieu lan khong duoc nhan doi xe, camera, EventSystem
        /// hay AudioListener. Restart di qua BeginRace chu khong nap lai scene, nen day la cach
        /// bat som neu co ai do them "tao moi" vao duong restart.
        /// </summary>
        [UnityTest]
        public IEnumerator SeveralRestartsDoNotDuplicateSceneSingletons()
        {
            yield return WaitForPhase(RacePhase.Running);

            for (int i = 0; i < 3; i++)
            {
                _director.Restart();
                yield return null;
            }

            Assert.AreEqual(1, Object.FindObjectsByType<CarController>(FindObjectsSortMode.None).Length);
            Assert.AreEqual(1, Object.FindObjectsByType<Camera>(FindObjectsSortMode.None).Length);
            Assert.AreEqual(1, Object.FindObjectsByType<AudioListener>(FindObjectsSortMode.None).Length);
            Assert.AreEqual(3, Object.FindObjectsByType<AudioSource>(FindObjectsSortMode.None).Length);
            Assert.AreEqual(1, Object.FindObjectsByType<EventSystem>(FindObjectsSortMode.None).Length);
            Assert.AreEqual(1, Object.FindObjectsByType<RaceDirector>(FindObjectsSortMode.None).Length);
            Assert.AreEqual(RacePhase.Countdown, _director.Rules.Phase);
        }

        /// <summary>Canvas o che do Screen Space - Overlay nen goc the gioi chinh la toa do man hinh.</summary>
        private static Rect ScreenRect(RectTransform rect)
        {
            var corners = new Vector3[4];
            rect.GetWorldCorners(corners);
            float minX = Mathf.Min(corners[0].x, corners[2].x);
            float maxX = Mathf.Max(corners[0].x, corners[2].x);
            float minY = Mathf.Min(corners[0].y, corners[2].y);
            float maxY = Mathf.Max(corners[0].y, corners[2].y);
            return new Rect(minX, minY, maxX - minX, maxY - minY);
        }

        [UnityTest]
        public IEnumerator StorageExceptionStillShowsResultsAndAllowsRestart()
        {
            yield return CheckFailedStorage(true);
        }

        [UnityTest]
        public IEnumerator StorageFailureStillShowsResultsAndAllowsRestart()
        {
            yield return CheckFailedStorage(false);
        }

        private IEnumerator CheckFailedStorage(bool throws)
        {
            SetRepository(new FailingRepository { Throws = throws });
            yield return WaitForPhase(RacePhase.Running);
            for (int lap = 0; lap < 2; lap++)
                for (int gate = 0; gate < 4; gate++) _director.Rules.TryPassCheckpoint(gate);
            yield return null;
            Assert.IsTrue(_director.IsResultsVisible);
            ResultsPresenter results = Object.FindAnyObjectByType<ResultsPresenter>();
            Assert.AreEqual(RaceHudFormatter.SaveFailedText, LabelText(results, "_saveStateLabel"));
            Assert.AreEqual(RaceHudFormatter.NoRecordText, LabelText(results, "_recordLabel"));
            _director.Restart();
            Assert.AreEqual(RacePhase.Countdown, _director.Rules.Phase);
            Assert.IsFalse(_director.IsResultsVisible);
        }

        private void SetRepository(IRecordRepository repository)
        {
            typeof(RaceDirector).GetField("_records", BindingFlags.Instance | BindingFlags.NonPublic)
                .SetValue(_director, new RecordStore(repository));
        }

        private void UseIsolatedRecords(Scene scene, LoadSceneMode mode)
        {
            _director = Object.FindAnyObjectByType<RaceDirector>();
            if (_director != null) SetRepository(new SessionRecordRepository());
        }

        private sealed class FailingRepository : IRecordRepository
        {
            public bool Throws;
            public bool TryLoad(out System.Collections.Generic.IReadOnlyList<RecordData> records, out string error)
            { records = System.Array.Empty<RecordData>(); error = null; return true; }
            public bool TrySave(System.Collections.Generic.IReadOnlyList<RecordData> records, out string error)
            {
                if (Throws) throw new System.IO.IOException("Simulated disk failure");
                error = "Simulated disk failure";
                return false;
            }
        }

        [UnityTest]
        public IEnumerator FestivalDiscardsPausedRunAndRejectsDrivingActions()
        {
            yield return WaitForPhase(RacePhase.Running);
            _director.Rules.TryPassCheckpoint(0);
            _director.RequestPause();
            _director.ReturnToFestival();
            Assert.IsTrue(_director.IsFestivalVisible);
            Assert.AreEqual(RacePhase.Idle, _director.Rules.Phase);
            Assert.AreEqual(0f, _director.Rules.ElapsedSeconds);
            Assert.IsNull(_director.Rules.LastAcceptedCheckpointIndex);
            Assert.IsTrue(_car.IsPoseLocked);
            Assert.IsFalse(_input.IsInputEnabled);
            Assert.IsFalse(_director.IsPauseMenuVisible);
            Assert.AreEqual(1f, Time.timeScale);
            var pose = _car.transform.position;
            _director.RequestPause();
            _director.RequestReset();
            _director.Resume();
            _director.gameObject.SendMessage("OnApplicationFocus", false);
            _director.gameObject.SendMessage("OnApplicationFocus", true);
            yield return new WaitForSeconds(0.2f);
            Assert.AreEqual(RacePhase.Idle, _director.Rules.Phase);
            Assert.AreEqual(0f, _director.Rules.ElapsedSeconds);
            Assert.Less(Vector3.Distance(pose, _car.transform.position), 0.001f);
            Assert.IsFalse(_director.Rules.TryPassCheckpoint(0));
            _director.StartRace();
            Assert.AreEqual(RacePhase.Countdown, _director.Rules.Phase);
            Assert.IsFalse(_director.IsFestivalVisible);
        }

        [UnityTest]
        public IEnumerator ReturnToFestivalCancelsPendingResultWithoutSaving()
        {
            var repository = new CountingRepository();
            SetRepository(repository);
            yield return WaitForPhase(RacePhase.Running);
            yield return WaitUntilTrue(() => _director.Rules.ElapsedSeconds > 0f);
            for (int lap = 0; lap < 2; lap++)
                for (int gate = 0; gate < 4; gate++) _director.Rules.TryPassCheckpoint(gate);
            _director.ReturnToFestival();
            yield return null;
            Assert.IsFalse(_director.IsResultsVisible);
            Assert.AreEqual(0, repository.Saves);
            _director.StartRace();
            yield return WaitForPhase(RacePhase.Running);
            yield return WaitUntilTrue(() => _director.Rules.ElapsedSeconds > 0f);
            for (int lap = 0; lap < 2; lap++)
                for (int gate = 0; gate < 4; gate++) _director.Rules.TryPassCheckpoint(gate);
            yield return null;
            Assert.IsTrue(_director.IsResultsVisible);
            Assert.AreEqual(1, repository.Saves, "Returning must not duplicate the finish listener.");
            _director.ReturnToFestival();
            Assert.IsTrue(_director.IsFestivalVisible);
            Assert.IsFalse(_director.IsResultsVisible);
        }

        /// <summary>
        /// Mat focus giua luc dang chay: director pause, va CA HAI nguon am thanh that trong scene
        /// (EngineAudio, FestivalAudio) phai dung. Unity goi OnApplicationFocus/Pause toi moi MonoBehaviour
        /// nen test gui toi tung object; lay lai focus KHONG duoc tu resume.
        /// </summary>
        [UnityTest]
        public IEnumerator LosingFocusWhileRunningPausesRaceAndSuspendsSceneAudio()
        {
            FestivalAudio festivalAudio = Object.FindAnyObjectByType<FestivalAudio>();
            EngineAudio engineAudio = Object.FindAnyObjectByType<EngineAudio>();
            Assert.IsNotNull(festivalAudio);
            Assert.IsNotNull(engineAudio);

            yield return WaitForPhase(RacePhase.Running);
            Assert.IsFalse(engineAudio.IsPaused);
            Assert.IsFalse(festivalAudio.IsSuspended);

            SendFocus(festivalAudio, false);
            Assert.AreEqual(RacePhase.Paused, _director.Rules.Phase);
            Assert.IsTrue(_director.IsPauseMenuVisible);
            Assert.IsTrue(engineAudio.IsPaused, "Dong co phai dung khi mat focus.");
            Assert.IsTrue(festivalAudio.IsSuspended, "Nhac/ambience phai dung khi mat focus.");

            SendFocus(festivalAudio, true);
            yield return null;
            Assert.AreEqual(RacePhase.Paused, _director.Rules.Phase, "Lay lai focus khong duoc tu resume.");
            Assert.IsTrue(_director.IsPauseMenuVisible);
            Assert.IsTrue(engineAudio.IsPaused, "Van pause vong choi nen dong co van im.");
            Assert.IsTrue(festivalAudio.IsSuspended, "Van pause vong choi nen nhac van im.");

            _director.Resume();
            Assert.AreEqual(RacePhase.Running, _director.Rules.Phase);
            Assert.IsFalse(engineAudio.IsPaused);
            Assert.IsFalse(festivalAudio.IsSuspended);
        }

        /// <summary>OnApplicationPause (vao nen) tren director cung pause va khong tu resume khi tro lai.</summary>
        [UnityTest]
        public IEnumerator BackgroundingWhileRunningPausesAndReturningDoesNotResume()
        {
            FestivalAudio festivalAudio = Object.FindAnyObjectByType<FestivalAudio>();
            yield return WaitForPhase(RacePhase.Running);

            _director.gameObject.SendMessage("OnApplicationPause", true);
            festivalAudio.gameObject.SendMessage("OnApplicationPause", true);
            Assert.AreEqual(RacePhase.Paused, _director.Rules.Phase);
            Assert.IsTrue(festivalAudio.IsSuspended);

            _director.gameObject.SendMessage("OnApplicationPause", false);
            festivalAudio.gameObject.SendMessage("OnApplicationPause", false);
            yield return null;
            Assert.AreEqual(RacePhase.Paused, _director.Rules.Phase, "Tro lai tu nen khong duoc tu resume.");
            Assert.IsTrue(festivalAudio.IsSuspended, "Vong choi con pause thi nhac con im.");
            Assert.IsFalse(_input.IsInputEnabled);
        }

        /// <summary>
        /// O le hoi va o man ket qua khong co pause vong choi: mat focus thi im, lay lai focus thi
        /// nhac choi lai; trang thai Core khong doi va menu tam dung khong mo.
        /// </summary>
        [UnityTest]
        public IEnumerator FocusLossAtFestivalAndResultsOnlySuspendsAudio()
        {
            FestivalAudio festivalAudio = Object.FindAnyObjectByType<FestivalAudio>();
            EngineAudio engineAudio = Object.FindAnyObjectByType<EngineAudio>();

            _director.ReturnToFestival();
            Assert.AreEqual(RacePhase.Idle, _director.Rules.Phase);
            Assert.IsFalse(festivalAudio.IsSuspended, "Nhac le hoi phai chay khi vao le hoi.");
            Assert.IsTrue(engineAudio.IsPaused, "Dong co im o le hoi.");

            SendFocus(festivalAudio, false);
            Assert.IsTrue(festivalAudio.IsSuspended);
            Assert.AreEqual(RacePhase.Idle, _director.Rules.Phase);
            Assert.IsFalse(_director.IsPauseMenuVisible, "Le hoi khong nhan pause.");
            Assert.IsTrue(_director.IsFestivalVisible);

            SendFocus(festivalAudio, true);
            Assert.IsFalse(festivalAudio.IsSuspended, "Khong co pause vong choi nen nhac le hoi chay lai.");
            Assert.AreEqual(RacePhase.Idle, _director.Rules.Phase);

            _director.StartRace();
            yield return WaitForPhase(RacePhase.Running);
            yield return WaitUntilTrue(() => _director.Rules.ElapsedSeconds > 0f);
            for (int lap = 0; lap < 2; lap++)
                for (int gate = 0; gate < 4; gate++) _director.Rules.TryPassCheckpoint(gate);
            yield return null;
            Assert.IsTrue(_director.IsResultsVisible);
            Assert.IsTrue(engineAudio.IsPaused, "Dong co im o man ket qua.");
            Assert.IsFalse(festivalAudio.IsSuspended);

            SendFocus(festivalAudio, false);
            Assert.IsTrue(festivalAudio.IsSuspended);
            Assert.IsTrue(_director.IsResultsVisible);
            Assert.IsFalse(_director.IsPauseMenuVisible, "Man ket qua khong nhan pause.");
            Assert.AreEqual(RacePhase.Finished, _director.Rules.Phase);

            SendFocus(festivalAudio, true);
            Assert.IsFalse(festivalAudio.IsSuspended);
            Assert.IsTrue(_director.IsResultsVisible);
        }

        private void SendFocus(FestivalAudio festivalAudio, bool hasFocus)
        {
            _director.gameObject.SendMessage("OnApplicationFocus", hasFocus);
            festivalAudio.gameObject.SendMessage("OnApplicationFocus", hasFocus);
        }

        [UnityTest]
        public IEnumerator ResultsSaveFailureTextFitsAndDoesNotOverlapRestart()
        {
            var results = Object.FindAnyObjectByType<ResultsPresenter>();
            results.Show(new RaceResultView(123.456f, RacingDemo.Core.Scoring.Medal.Bronze,
                null, true, false, "Simulated disk failure"));
            yield return null;
            Canvas.ForceUpdateCanvases();
            Transform panel = results.transform.Find("Panel");
            var message = panel.Find("AnMessage").GetComponent<TextMeshProUGUI>();
            var save = panel.Find("SaveStateLabel").GetComponent<TextMeshProUGUI>();
            message.ForceMeshUpdate(); save.ForceMeshUpdate();
            Assert.IsFalse(message.isTextOverflowing, "The longest An message must fit.");
            Assert.IsFalse(save.isTextOverflowing);
            Assert.IsFalse(ScreenRect(message.rectTransform).Overlaps(
                ScreenRect((RectTransform)panel.Find("RestartButton"))));
            Assert.IsFalse(ScreenRect(message.rectTransform).Overlaps(ScreenRect(save.rectTransform)));
            foreach (char character in message.text + save.text)
                if (!char.IsWhiteSpace(character))
                    Assert.IsTrue(message.font.HasCharacter(character), "Missing Vietnamese glyph: " + character);
        }

        private sealed class CountingRepository : IRecordRepository
        {
            public int Saves;
            public bool TryLoad(out IReadOnlyList<RecordData> records, out string error)
            { records = System.Array.Empty<RecordData>(); error = null; return true; }
            public bool TrySave(IReadOnlyList<RecordData> records, out string error)
            { Saves++; error = null; return true; }
        }

        private IEnumerator WaitForPhase(RacePhase phase)
        {
            yield return WaitUntilTrue(() => _director.Rules.Phase == phase);
        }

        private static IEnumerator WaitUntilTrue(System.Func<bool> condition)
        {
            float deadline = Time.realtimeSinceStartup + PhaseTimeout;
            while (!condition())
            {
                if (Time.realtimeSinceStartup > deadline)
                {
                    Assert.Fail("Qua " + PhaseTimeout + " giay ma dieu kien van chua dat.");
                }

                yield return null;
            }
        }

        private static string LabelText(Component owner, string fieldName)
        {
            FieldInfo field = owner.GetType().GetField(fieldName, BindingFlags.Instance | BindingFlags.NonPublic);
            Assert.IsNotNull(field, "Khong con truong " + fieldName + "; test va code lech nhau.");
            var label = (TextMeshProUGUI)field.GetValue(owner);
            Assert.IsNotNull(label, fieldName + " chua duoc gan.");
            return label.text;
        }
    }
}
