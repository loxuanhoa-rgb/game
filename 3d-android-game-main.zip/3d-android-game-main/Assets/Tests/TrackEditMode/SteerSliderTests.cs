using NUnit.Framework;
using RacingDemo.Runtime.Input;

namespace RacingDemo.Tests.TrackEditMode
{
    /// <summary>
    /// Thanh lai analog (gop y tren Xiaomi 14): do lech ngang -> steer. Vung chet quanh tam,
    /// tuyen tinh toi het lai, kep o +-1, giu dau. Cac so 115/10 la gia tri generator dang dung.
    /// </summary>
    public sealed class SteerSliderTests
    {
        private const float Full = 115f;
        private const float Dead = 10f;

        [Test]
        public void Center_IsZero()
        {
            Assert.That(SteerSlider.Evaluate(0f, Full, Dead), Is.EqualTo(0f));
        }

        [Test]
        public void InsideDeadZone_IsZero()
        {
            Assert.That(SteerSlider.Evaluate(9f, Full, Dead), Is.EqualTo(0f));
            Assert.That(SteerSlider.Evaluate(-10f, Full, Dead), Is.EqualTo(0f));
        }

        [Test]
        public void OldButtonCenters_AreFullSteer()
        {
            // Tam nut "<" va ">" cu cach tam thanh dung 115 don vi: van lai het co nhu truoc.
            Assert.That(SteerSlider.Evaluate(-115f, Full, Dead), Is.EqualTo(-1f).Within(1e-5f));
            Assert.That(SteerSlider.Evaluate(115f, Full, Dead), Is.EqualTo(1f).Within(1e-5f));
        }

        [Test]
        public void BeyondFullDistance_IsClamped()
        {
            Assert.That(SteerSlider.Evaluate(500f, Full, Dead), Is.EqualTo(1f));
            Assert.That(SteerSlider.Evaluate(-215f, Full, Dead), Is.EqualTo(-1f));
        }

        [Test]
        public void BetweenDeadZoneAndFull_IsLinear()
        {
            // Giua vung chet (10) va het lai (115) la 62,5 -> dung nua duong.
            Assert.That(SteerSlider.Evaluate(62.5f, Full, Dead), Is.EqualTo(0.5f).Within(1e-5f));
            Assert.That(SteerSlider.Evaluate(-62.5f, Full, Dead), Is.EqualTo(-0.5f).Within(1e-5f));
        }

        [Test]
        public void IsMonotonic()
        {
            float previous = -1f;
            for (float x = -200f; x <= 200f; x += 5f)
            {
                float value = SteerSlider.Evaluate(x, Full, Dead);
                Assert.That(value, Is.GreaterThanOrEqualTo(previous), "Khong don dieu tai x=" + x);
                Assert.That(value, Is.InRange(-1f, 1f));
                previous = value;
            }
        }

        [Test]
        public void DegenerateConfig_ActsLikeButtons()
        {
            // Het lai <= vung chet: ngoai vung chet la +-1, trong la 0. Khong chia cho 0.
            Assert.That(SteerSlider.Evaluate(50f, 10f, 10f), Is.EqualTo(1f));
            Assert.That(SteerSlider.Evaluate(-50f, 5f, 10f), Is.EqualTo(-1f));
            Assert.That(SteerSlider.Evaluate(3f, 5f, 10f), Is.EqualTo(0f));
            Assert.That(SteerSlider.Evaluate(50f, 0f, 0f), Is.EqualTo(1f));
        }

        [Test]
        public void NegativeDeadZone_IsTreatedAsZero()
        {
            Assert.That(SteerSlider.Evaluate(0f, Full, -5f), Is.EqualTo(0f));
            Assert.That(SteerSlider.Evaluate(57.5f, Full, -5f), Is.EqualTo(0.5f).Within(1e-5f));
        }
    }
}
