using System;
using NUnit.Framework;
using RacingDemo.Runtime.Track;
using UnityEngine;

namespace RacingDemo.Tests.TrackEditMode
{
    public sealed class StadiumGeometryTests
    {
        private StadiumGeometry _geometry;

        [SetUp]
        public void SetUp() => _geometry = new StadiumGeometry(80f, 30f, 12f);

        [Test]
        public void FixedStadiumHasSpecifiedLengthAndExtents()
        {
            Assert.That(_geometry.Length, Is.EqualTo(348.49556f).Within(0.0001f));
            AssertSample(0f, new Vector3(30f, 0f, 0f), Vector3.forward);
            AssertSample(40f, new Vector3(30f, 0f, 40f), Vector3.forward);
            AssertSample(40f + 15f * Mathf.PI, new Vector3(0f, 0f, 70f), Vector3.left);
            AssertSample(40f + 30f * Mathf.PI, new Vector3(-30f, 0f, 40f), Vector3.back);
            AssertSample(120f + 30f * Mathf.PI, new Vector3(-30f, 0f, -40f), Vector3.back);
            AssertSample(120f + 45f * Mathf.PI, new Vector3(0f, 0f, -70f), Vector3.right);
            AssertSample(120f + 60f * Mathf.PI, new Vector3(30f, 0f, -40f), Vector3.forward);
        }

        [Test]
        public void EveryStraightArcJoinIsContinuousInPositionAndTangent()
        {
            float[] joins = { 0f, 40f, 40f + 30f * Mathf.PI, 120f + 30f * Mathf.PI, 120f + 60f * Mathf.PI };
            foreach (float join in joins)
            {
                _geometry.Evaluate(join - 0.001f, out Vector3 before, out Vector3 beforeForward);
                _geometry.Evaluate(join + 0.001f, out Vector3 after, out Vector3 afterForward);
                Assert.That(Vector3.Distance(before, after), Is.LessThan(0.0022f), "Position join " + join);
                Assert.That(Vector3.Dot(beforeForward, afterForward), Is.GreaterThan(0.99999f), "Tangent join " + join);
            }
        }

        [Test]
        public void FinalMeshSampleExactlyClosesFirstSampleAndAllSegmentsAreBounded()
        {
            float[] samples = _geometry.CreateSampleDistances();
            Assert.That(samples[0], Is.Zero);
            Assert.That(samples[samples.Length - 1], Is.EqualTo(_geometry.Length));
            _geometry.Evaluate(samples[0], out Vector3 first, out Vector3 firstForward);
            _geometry.Evaluate(samples[samples.Length - 1], out Vector3 last, out Vector3 lastForward);
            Assert.That(last, Is.EqualTo(first));
            Assert.That(lastForward, Is.EqualTo(firstForward));

            for (int index = 1; index < samples.Length; index++)
            {
                Assert.That(samples[index] - samples[index - 1], Is.GreaterThan(0f).And.LessThanOrEqualTo(2.0001f));
                _geometry.Evaluate(samples[index], out Vector3 position, out Vector3 forward);
                Assert.That(position.y, Is.Zero);
                Assert.That(forward.magnitude, Is.EqualTo(1f).Within(0.00001f));
                Assert.That(_geometry.DistanceFromCenterline(position), Is.LessThan(0.0001f));
            }
        }

        [Test]
        public void BoundaryQueriesExcludeInfieldAndOutsideButIncludeAllRoadEdges()
        {
            Assert.That(_geometry.ContainsRoadPoint(Vector3.zero), Is.False);
            Assert.That(_geometry.ContainsRoadPoint(new Vector3(23.9f, 0f, 0f)), Is.False);
            Assert.That(_geometry.ContainsRoadPoint(new Vector3(36.1f, 0f, 0f)), Is.False);
            Assert.That(_geometry.ContainsRoadPoint(new Vector3(24f, 0f, 0f)), Is.True);
            Assert.That(_geometry.ContainsRoadPoint(new Vector3(36f, 0f, 0f)), Is.True);
            Assert.That(_geometry.ContainsRoadPoint(new Vector3(0f, 0f, 64f)), Is.True);
            Assert.That(_geometry.ContainsRoadPoint(new Vector3(0f, 0f, 76f)), Is.True);
            Assert.That(_geometry.ContainsRoadPoint(new Vector3(0f, 0f, -76.1f)), Is.False);
            Assert.That(_geometry.ContainsRoadPoint(new Vector3(30f, -0.11f, 0f)), Is.False);
            Assert.That(_geometry.ContainsRoadPoint(new Vector3(24.5f, 0f, 0f), lateralMargin: 1f), Is.False);
        }

        [Test]
        public void DistanceProjectionFindsSamePointAlongBothStraightsAndCurves()
        {
            foreach (float distance in new[] { 0f, 8f, 40f, 87f, 140f, 174f, 220f, 261f, 330f, 340f })
            {
                _geometry.Evaluate(distance, out Vector3 position, out Vector3 forward);
                Vector3 outsidePoint = position + Vector3.Cross(Vector3.up, forward) * 3f + Vector3.up * 7f;
                Assert.That(_geometry.GetDistanceAlongTrack(outsidePoint), Is.EqualTo(distance).Within(0.0001f));
                Assert.That(_geometry.DistanceFromCenterline(outsidePoint), Is.EqualTo(3f).Within(0.0001f));
            }
        }

        [Test]
        public void NegativeAndMultiLapDistanceWrapWithoutChangingPose()
        {
            _geometry.Evaluate(-8f, out Vector3 negative, out Vector3 negativeForward);
            _geometry.Evaluate(_geometry.Length - 8f, out Vector3 positive, out Vector3 positiveForward);
            _geometry.Evaluate(3f * _geometry.Length - 8f, out Vector3 multiple, out _);
            Assert.That(negative, Is.EqualTo(positive));
            Assert.That(negativeForward, Is.EqualTo(positiveForward));
            Assert.That(Vector3.Distance(multiple, positive), Is.LessThan(0.0001f));
        }

        [Test]
        public void InvalidAndUnboundedGeometryIsRejected()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() => new StadiumGeometry(0f, 30f, 12f));
            Assert.Throws<ArgumentOutOfRangeException>(() => new StadiumGeometry(80f, -30f, 12f));
            Assert.Throws<ArgumentOutOfRangeException>(() => new StadiumGeometry(80f, 30f, 60f));
            Assert.Throws<ArgumentOutOfRangeException>(() => new StadiumGeometry(80f, 30f, float.NaN));
            Assert.Throws<ArgumentOutOfRangeException>(() => new StadiumGeometry(80f, 30f, 12f, float.PositiveInfinity));
            Assert.Throws<ArgumentOutOfRangeException>(() => _geometry.Evaluate(float.NaN, out _, out _));
            Assert.Throws<ArgumentOutOfRangeException>(() => _geometry.CreateSampleDistances(0f));
            Assert.Throws<ArgumentOutOfRangeException>(() => _geometry.CreateSampleDistances(float.Epsilon));
        }

        private void AssertSample(float distance, Vector3 expectedPosition, Vector3 expectedForward)
        {
            _geometry.Evaluate(distance, out Vector3 position, out Vector3 forward);
            Assert.That(Vector3.Distance(position, expectedPosition), Is.LessThan(0.0001f));
            Assert.That(Vector3.Distance(forward, expectedForward), Is.LessThan(0.00001f));
        }
    }
}
