using System;
using NUnit.Framework;
using RacingDemo.Runtime.Track;
using RacingDemo.Runtime.Vehicle;
using UnityEditor;
using UnityEngine;
using Object = UnityEngine.Object;

namespace RacingDemo.Tests.TrackEditMode
{
    public sealed class TrackDefinitionTests
    {
        private CarConfig _car;
        private TrackDefinition _track;
        private GameObject _serviceObject;
        private RespawnService _service;

        [SetUp]
        public void SetUp()
        {
            _car = ScriptableObject.CreateInstance<CarConfig>();
            _track = TrackDefinition.CreateDemoDefault(_car);
            _serviceObject = new GameObject("RespawnServiceTest");
            _service = _serviceObject.AddComponent<RespawnService>();
            var serialized = new SerializedObject(_service);
            serialized.FindProperty("_track").objectReferenceValue = _track;
            serialized.ApplyModifiedPropertiesWithoutUndo();
        }

        [TearDown]
        public void TearDown()
        {
            Object.DestroyImmediate(_serviceObject);
            Object.DestroyImmediate(_track);
            Object.DestroyImmediate(_car);
        }

        [Test]
        public void DefaultTrackKeepsFinishLastAndFourEvenlySpacedCheckpoints()
        {
            var geometry = new StadiumGeometry(_track);
            Assert.That(_track.Checkpoints.Length, Is.EqualTo(4));
            Assert.That(_track.Checkpoints[3].Distance, Is.Zero);
            float previous = 0f;
            for (int index = 0; index < 4; index++)
            {
                TrackCheckpoint checkpoint = _track.Checkpoints[index];
                Assert.That(checkpoint.Order, Is.EqualTo(index));
                float distance = index == 3 ? geometry.Length : checkpoint.Distance;
                Assert.That(distance - previous, Is.EqualTo(geometry.Length / 4f).Within(0.0001f));
                previous = distance;
            }
            Assert.That(Vector3.Distance(_track.StartPose.Position, new Vector3(30f, 0.64f, -8f)), Is.LessThan(0.00001f));
        }

        [Test]
        public void DefaultSpawnAndRespawnsHaveSafeHeightFootprintAndDirection()
        {
            var geometry = new StadiumGeometry(_track);
            Assert.That(_track.TriggerDepth, Is.GreaterThan(120f / 3.6f / 60f * 4f));
            foreach (TrackCheckpoint checkpoint in _track.Checkpoints)
            {
                TrackPose pose = checkpoint.RespawnPose;
                Assert.That(pose.Position.y - _track.SurfaceHeight, Is.GreaterThan(_car.WheelRadius + _car.SuspensionDistance));
                Assert.That(geometry.DistanceFromCenterline(pose.Position), Is.LessThan(0.0001f));
                geometry.Evaluate(checkpoint.Distance + 8f, out _, out Vector3 forward);
                Assert.That(Vector3.Dot(forward, pose.Rotation * Vector3.forward), Is.GreaterThan(0.9999f));
                foreach (TrackCheckpoint gate in _track.Checkpoints)
                {
                    geometry.Evaluate(gate.Distance, out Vector3 gatePosition, out Vector3 gateForward);
                    Vector3 localOffset = Quaternion.Inverse(Quaternion.LookRotation(gateForward)) * (pose.Position - gatePosition);
                    // Whole 4m-long, 1.7m-wide body must fit beyond even the oblique gate plane.
                    if (Mathf.Abs(localOffset.x) <= _track.RoadWidth * 0.5f + 2f)
                        Assert.That(Mathf.Abs(localOffset.z), Is.GreaterThan(_track.TriggerDepth * 0.5f + 2.2f));
                }
            }
        }

        [Test]
        public void DefaultFactoryUsesCurrentWheelAndSuspensionDimensions()
        {
            _car.WheelRadius = 0.5f;
            _car.SuspensionDistance = 0.4f;
            TrackDefinition taller = TrackDefinition.CreateDemoDefault(_car);
            try
            {
                Assert.That(taller.StartPose.Position.y, Is.EqualTo(0.95f).Within(0.00001f));
                Assert.That(taller.Checkpoints[0].RespawnPose.Position.y, Is.EqualTo(0.95f).Within(0.00001f));
                Assert.That(_track.StartPose.Position.y, Is.EqualTo(0.64f).Within(0.00001f));
            }
            finally { Object.DestroyImmediate(taller); }
        }

        [Test]
        public void CoreConfigurationContainsOnlyNumericTrackRules()
        {
            _track.LapCount = 3;
            _track.CountdownSeconds = 2f;
            _track.RespawnLockSeconds = 1f;
            var config = _track.CreateRaceConfig();
            Assert.That(config.CheckpointCount, Is.EqualTo(4));
            Assert.That(config.LapCount, Is.EqualTo(3));
            Assert.That(config.CountdownSeconds, Is.EqualTo(2f));
            Assert.That(config.RespawnLockSeconds, Is.EqualTo(1f));
            Assert.That(_track.CreateMedalThresholds().GoldSeconds, Is.EqualTo(85f));
        }

        [Test]
        public void NullCheckpointReturnsStartAndAcceptedCheckpointReturnsItsOwnPose()
        {
            _service.GetRespawnPose(null, out Vector3 start, out Quaternion startRotation);
            Assert.That(start, Is.EqualTo(_track.StartPose.Position));
            Assert.That(startRotation, Is.EqualTo(_track.StartPose.Rotation));
            for (int index = 0; index < _track.Checkpoints.Length; index++)
            {
                _service.GetRespawnPose(index, out Vector3 position, out Quaternion rotation);
                Assert.That(position, Is.EqualTo(_track.Checkpoints[index].RespawnPose.Position));
                Assert.That(rotation, Is.EqualTo(_track.Checkpoints[index].RespawnPose.Rotation));
                Assert.That(position, Is.Not.EqualTo(start));
            }
        }

        [Test]
        public void RespawnUsesTunedPoseWithoutRecomputingItFromGeometry()
        {
            var tuned = new TrackPose(new Vector3(31f, 0.8f, 12f), Quaternion.Euler(0f, 5f, 0f));
            _track.Checkpoints[3].RespawnPose = tuned;
            _service.GetRespawnPose(3, out Vector3 position, out Quaternion rotation);
            Assert.That(position, Is.EqualTo(tuned.Position));
            Assert.That(Quaternion.Angle(rotation, tuned.Rotation), Is.LessThan(0.0001f));
        }

        [Test]
        public void MissingDataAndOutOfRangeRespawnIndexAreRejected()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() => _service.GetRespawnPose(-1, out _, out _));
            Assert.Throws<ArgumentOutOfRangeException>(() => _service.GetRespawnPose(4, out _, out _));
            _track.Checkpoints[0] = null;
            Assert.Throws<InvalidOperationException>(() => _service.GetRespawnPose(0, out _, out _));
            var serialized = new SerializedObject(_service);
            serialized.FindProperty("_track").objectReferenceValue = null;
            serialized.ApplyModifiedPropertiesWithoutUndo();
            Assert.Throws<InvalidOperationException>(() => _service.GetRespawnPose(null, out _, out _));
        }
    }
}
