using System.Collections.Generic;
using NUnit.Framework;
using RacingDemo.EditorTools;
using RacingDemo.Runtime.Track;
using RacingDemo.Runtime.Vehicle;
using UnityEngine;
using Object = UnityEngine.Object;

namespace RacingDemo.Tests.TrackEditMode
{
    /// <summary>
    /// Task 6: trang tri chi duoc la hinh anh. Bo test nay dung cay trang tri that trong bo nho
    /// (khong dung toi Race.unity) roi co tinh lam hong tung dieu kien mot, de chac chan
    /// validator that su bat duoc chu khong phai "dat" vi no khong kiem gi.
    /// </summary>
    public sealed class DecorValidationTests
    {
        private GameObject _root;
        private TrackDefinition _track;
        private CarConfig _car;

        [SetUp]
        public void SetUp()
        {
            _car = ScriptableObject.CreateInstance<CarConfig>();
            _track = TrackDefinition.CreateDemoDefault(_car);

            _root = new GameObject("__GeneratedScene");
            var trackRoot = new GameObject("Track");
            trackRoot.transform.SetParent(_root.transform, false);
            DecorBuilder.Build(trackRoot.transform, _track);
        }

        [TearDown]
        public void TearDown()
        {
            Object.DestroyImmediate(_root);
            Object.DestroyImmediate(_track);
            Object.DestroyImmediate(_car);
        }

        private List<string> Validate()
        {
            var errors = new List<string>();
            SceneValidator.ValidateDecor(_root.transform, _track, "test: ", errors);
            return errors;
        }

        private Transform FirstProp()
        {
            Transform decor = _root.transform.Find("Track/Decor");
            Assert.That(decor.childCount, Is.GreaterThan(0));
            return decor.GetChild(0);
        }

        [Test]
        public void GeneratedDecorPassesAndIsNotEmpty()
        {
            Transform decor = _root.transform.Find("Track/Decor");
            Assert.That(decor, Is.Not.Null, "DecorBuilder phai tao cay Track/Decor.");
            Assert.That(decor.childCount, Is.GreaterThan(20), "Bo trang tri qua it, co ve chua dung xong.");
            Assert.That(decor.GetComponentsInChildren<MeshFilter>(true).Length, Is.GreaterThan(0));

            Assert.That(Validate(), Is.Empty);
        }

        [Test]
        public void PropMovedOntoTheRoadIsReported()
        {
            Transform prop = FirstProp();
            // Tim duong o quang duong 0: giua mat duong ben +X.
            prop.position = new Vector3(_track.CenterRadius, _track.SurfaceHeight, 0f);

            List<string> errors = Validate();
            Assert.That(errors.Count, Is.EqualTo(1));
            Assert.That(errors[0], Does.Contain("lan ra mat duong"));
            Assert.That(errors[0], Does.Contain(prop.name));
        }

        /// <summary>
        /// Vat chi cham mep duong bang mot goc cung phai bi bat: xe di sat mep van dung vao.
        /// </summary>
        [Test]
        public void PropTouchingOnlyTheRoadEdgeIsReported()
        {
            Transform prop = FirstProp();
            Bounds bounds = KenneyBounds(prop);
            float halfWidth = _track.RoadWidth * 0.5f;

            // Dat sao cho canh trong cua bao hinh vua cham mep duong.
            float lateral = halfWidth + bounds.extents.x - 0.05f;
            prop.position = new Vector3(_track.CenterRadius + lateral, _track.SurfaceHeight, 0f);

            Assert.That(Validate(), Is.Not.Empty);
        }

        [Test]
        public void ColliderOnDecorIsReported()
        {
            FirstProp().gameObject.AddComponent<BoxCollider>();

            List<string> errors = Validate();
            Assert.That(errors.Count, Is.EqualTo(1));
            Assert.That(errors[0], Does.Contain("collider"));
        }

        /// <summary>
        /// Renderer khong co mesh la trang tri "tang hinh": build van chay, khong loi, chi thieu do.
        /// Truong hop that: nhan VenueDetails bake tu TMP, giu lai MeshFilter HideAndDontSave cua
        /// TMP nen scene da luu chi con MeshRenderer.
        /// </summary>
        [Test]
        public void RendererWithoutMeshFilterIsReported()
        {
            var ghost = new GameObject("GhostLabel");
            ghost.transform.SetParent(_root.transform.Find("Track/Decor"), false);
            ghost.transform.position = new Vector3(0f, _track.SurfaceHeight, 0f);
            ghost.AddComponent<MeshRenderer>();

            List<string> errors = Validate();
            Assert.That(errors.Count, Is.EqualTo(1));
            Assert.That(errors[0], Does.Contain("MeshFilter"));
            Assert.That(errors[0], Does.Contain("GhostLabel"));
        }

        [Test]
        public void DontSaveMeshFilterIsReported()
        {
            MeshFilter[] filters = FirstProp().GetComponentsInChildren<MeshFilter>(true);
            Assert.That(filters.Length, Is.GreaterThan(0));
            filters[0].hideFlags = HideFlags.HideAndDontSave;

            List<string> errors = Validate();
            Assert.That(errors.Count, Is.EqualTo(1));
            Assert.That(errors[0], Does.Contain("DontSave"));
        }

        [Test]
        public void MissingDecorTreeIsReported()
        {
            Object.DestroyImmediate(_root.transform.Find("Track/Decor").gameObject);

            List<string> errors = Validate();
            Assert.That(errors.Count, Is.EqualTo(1));
            Assert.That(errors[0], Does.Contain("Track/Decor"));
        }

        private static Bounds KenneyBounds(Transform prop)
        {
            MeshFilter[] filters = prop.GetComponentsInChildren<MeshFilter>(true);
            Assert.That(filters.Length, Is.GreaterThan(0));
            Bounds bounds = filters[0].sharedMesh.bounds;
            Vector3 scale = filters[0].transform.lossyScale;
            bounds.extents = new Vector3(
                bounds.extents.x * scale.x, bounds.extents.y * scale.y, bounds.extents.z * scale.z);
            return bounds;
        }
    }
}
