using System;
using System.Text;
using NUnit.Framework;
using RacingDemo.EditorTools;
using RacingDemo.Runtime.Audio;

namespace RacingDemo.Tests.TrackEditMode
{
    public sealed class EngineAudioCurveTests
    {
        [Test]
        public void SpeedRatioIsClampedAndUsesAbsoluteSpeed()
        {
            Assert.That(EngineAudioCurve.SpeedRatio(0f, 120f), Is.EqualTo(0f));
            Assert.That(EngineAudioCurve.SpeedRatio(60f, 120f), Is.EqualTo(0.5f).Within(0.0001f));
            Assert.That(EngineAudioCurve.SpeedRatio(120f, 120f), Is.EqualTo(1f));

            // Chay qua toc do toi da (do xuong doc) khong duoc lam cao do vot len vo han.
            Assert.That(EngineAudioCurve.SpeedRatio(400f, 120f), Is.EqualTo(1f));

            // Lui van no may.
            Assert.That(EngineAudioCurve.SpeedRatio(-20f, 120f), Is.EqualTo(EngineAudioCurve.SpeedRatio(20f, 120f)));
        }

        [Test]
        public void BadInputFallsBackToIdleInsteadOfBreakingTheSound()
        {
            Assert.That(EngineAudioCurve.SpeedRatio(float.NaN, 120f), Is.EqualTo(0f));
            Assert.That(EngineAudioCurve.SpeedRatio(float.PositiveInfinity, 120f), Is.EqualTo(0f));
            Assert.That(EngineAudioCurve.SpeedRatio(50f, 0f), Is.EqualTo(0f));
            Assert.That(EngineAudioCurve.SpeedRatio(50f, -120f), Is.EqualTo(0f));

            Assert.That(EngineAudioCurve.Pitch(float.NaN, 120f, 0.65f, 2.1f), Is.EqualTo(0.65f));
            Assert.That(EngineAudioCurve.Volume(50f, 0f, 0.35f, 0.85f), Is.EqualTo(0.35f));
        }

        [Test]
        public void PitchAndVolumeRiseWithSpeed()
        {
            float idle = EngineAudioCurve.Pitch(0f, 120f, 0.65f, 2.1f);
            float middle = EngineAudioCurve.Pitch(60f, 120f, 0.65f, 2.1f);
            float top = EngineAudioCurve.Pitch(120f, 120f, 0.65f, 2.1f);

            Assert.That(idle, Is.EqualTo(0.65f).Within(0.0001f));
            Assert.That(top, Is.EqualTo(2.1f).Within(0.0001f));
            Assert.That(middle, Is.GreaterThan(idle));
            Assert.That(middle, Is.LessThan(top));

            Assert.That(EngineAudioCurve.Volume(0f, 120f, 0.35f, 0.85f), Is.EqualTo(0.35f).Within(0.0001f));
            Assert.That(EngineAudioCurve.Volume(120f, 120f, 0.35f, 0.85f), Is.EqualTo(0.85f).Within(0.0001f));
        }

        [Test]
        public void VolumeStaysInsideTheRangeUnityAccepts()
        {
            Assert.That(EngineAudioCurve.Volume(120f, 120f, 0.5f, 4f), Is.EqualTo(1f));
            Assert.That(EngineAudioCurve.Volume(0f, 120f, -2f, 0.85f), Is.EqualTo(0f));
        }
    }

    public sealed class EngineClipBuilderTests
    {
        [Test]
        public void EngineCyclesDoNotContainBroadbandWindNoise()
        {
            float[] samples = EngineClipBuilder.BuildSamples();
            int cycleSamples = (int)(EngineClipBuilder.SampleRate / EngineClipBuilder.FundamentalHz);
            float largestDifference = 0f;
            for (int i = cycleSamples; i < samples.Length; i++)
                largestDifference = Math.Max(largestDifference, Math.Abs(samples[i] - samples[i - cycleSamples]));

            Assert.That(largestDifference, Is.LessThan(0.001f),
                "Engine harmonics should repeat cleanly without speed-amplified random wind hiss.");
        }

        [Test]
        public void SamplesAreDeterministic()
        {
            float[] first = EngineClipBuilder.BuildSamples();
            float[] second = EngineClipBuilder.BuildSamples();

            Assert.That(first.Length, Is.EqualTo(EngineClipBuilder.LoopSamples));
            CollectionAssert.AreEqual(first, second);
        }

        [Test]
        public void SignalStaysInsideRange()
        {
            float[] samples = EngineClipBuilder.BuildSamples();
            float loudest = 0f;
            for (int i = 0; i < samples.Length; i++)
            {
                loudest = Math.Max(loudest, Math.Abs(samples[i]));
            }

            Assert.That(loudest, Is.EqualTo(0.89f).Within(0.001f), "Clip phai duoc chuan hoa ve dinh 0,89.");
        }

        /// <summary>
        /// Moi hoa am deu la boi cua 50 Hz voi 22050 mau/giay nen mau cuoi phai noi lien mau dau.
        /// Neu khong, moi vong lap se nghe thay tieng "tach".
        /// </summary>
        [Test]
        public void LoopSeamIsNotAudible()
        {
            float[] samples = EngineClipBuilder.BuildSamples();
            float biggestStepInside = 0f;
            for (int i = 1; i < samples.Length; i++)
            {
                biggestStepInside = Math.Max(biggestStepInside, Math.Abs(samples[i] - samples[i - 1]));
            }

            float seamStep = Math.Abs(samples[0] - samples[samples.Length - 1]);
            Assert.That(seamStep, Is.LessThanOrEqualTo(biggestStepInside),
                "Buoc nhay tai diem noi vong lap lon hon moi buoc nhay ben trong clip.");
        }

        [Test]
        public void WavHeaderDescribesA16BitMonoClip()
        {
            byte[] wav = EngineClipBuilder.BuildWavBytes();
            int dataBytes = EngineClipBuilder.LoopSamples * 2;

            Assert.That(wav.Length, Is.EqualTo(44 + dataBytes));
            Assert.That(Encoding.ASCII.GetString(wav, 0, 4), Is.EqualTo("RIFF"));
            Assert.That(Encoding.ASCII.GetString(wav, 8, 4), Is.EqualTo("WAVE"));
            Assert.That(Encoding.ASCII.GetString(wav, 12, 4), Is.EqualTo("fmt "));
            Assert.That(Encoding.ASCII.GetString(wav, 36, 4), Is.EqualTo("data"));
            Assert.That(BitConverter.ToInt32(wav, 4), Is.EqualTo(36 + dataBytes));
            Assert.That(BitConverter.ToInt16(wav, 20), Is.EqualTo(1), "Phai la PCM khong nen.");
            Assert.That(BitConverter.ToInt16(wav, 22), Is.EqualTo(1), "Phai la mot kenh.");
            Assert.That(BitConverter.ToInt32(wav, 24), Is.EqualTo(EngineClipBuilder.SampleRate));
            Assert.That(BitConverter.ToInt16(wav, 34), Is.EqualTo(16));
            Assert.That(BitConverter.ToInt32(wav, 40), Is.EqualTo(dataBytes));
        }
    }
}
