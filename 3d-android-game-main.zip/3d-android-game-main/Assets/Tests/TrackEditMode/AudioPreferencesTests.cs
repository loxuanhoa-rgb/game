using System;
using System.Collections.Generic;
using NUnit.Framework;
using RacingDemo.Runtime.Audio;
using RacingDemo.EditorTools;

namespace RacingDemo.Tests.TrackEditMode
{
    public sealed class AudioPreferencesTests
    {
        [Test] public void ChoicesSurviveReloadWithoutRecordKeys()
        {
            var values = new Dictionary<string, int>();
            Func<AudioPreferences> make = () => new AudioPreferences((key, fallback) => values.ContainsKey(key) ? values[key] : fallback,
                (key, value) => values[key] = value, () => { });
            AudioPreferences first = make(); first.Load();
            Assert.IsTrue(first.MusicEnabled); Assert.IsTrue(first.EffectsEnabled);
            Assert.IsTrue(first.SetMusic(false)); Assert.IsTrue(first.SetEffects(false));
            AudioPreferences second = make(); second.Load();
            Assert.IsFalse(second.MusicEnabled); Assert.IsFalse(second.EffectsEnabled);
            CollectionAssert.AreEquivalent(new[] { AudioPreferences.MusicKey, AudioPreferences.EffectsKey }, values.Keys);
        }
        [Test] public void SaveFailureKeepsSessionChoiceAndReportsFailure()
        {
            var prefs = new AudioPreferences((key, fallback) => fallback, (key, value) => { }, () => throw new InvalidOperationException());
            prefs.Load(); Assert.IsFalse(prefs.SetMusic(false)); Assert.IsFalse(prefs.MusicEnabled);
            Assert.IsTrue(prefs.EffectsEnabled);
        }
        [Test] public void ReadFailureUsesAudibleDefaults()
        {
            var prefs = new AudioPreferences((key, fallback) => throw new InvalidOperationException(), (key, value) => { }, () => { });
            Assert.DoesNotThrow(prefs.Load); Assert.IsTrue(prefs.MusicEnabled); Assert.IsTrue(prefs.EffectsEnabled);
        }
        [TestCase(true)] [TestCase(false)] public void OriginalAudioIsDeterministicBoundedAndHasQuietSeam(bool music)
        {
            float[] samples = FestivalAudioBuilder.BuildSamples(music);
            CollectionAssert.AreEqual(samples, FestivalAudioBuilder.BuildSamples(music));
            float peak = 0;
            foreach (float sample in samples) { Assert.IsFalse(float.IsNaN(sample)); peak = Math.Max(peak, Math.Abs(sample)); }
            Assert.That(peak, Is.InRange(0.01f, 0.9f));
            Assert.That(Math.Abs(samples[0] - samples[samples.Length-1]), Is.LessThan(0.001f));
        }
    }
}
