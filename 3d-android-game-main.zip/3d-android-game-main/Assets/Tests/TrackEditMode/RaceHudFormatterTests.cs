using NUnit.Framework;
using RacingDemo.Core.Racing;
using RacingDemo.Core.Scoring;
using RacingDemo.Runtime.Race;

namespace RacingDemo.Tests.TrackEditMode
{
    /// <summary>
    /// Task 4: cac ham thuan sinh chuoi HUD/ket qua. Khong dung scene, khong dung dong ho.
    /// </summary>
    public sealed class RaceHudFormatterTests
    {
        [Test]
        public void LapTextCountsFromOneAndNeverExceedsLapCount()
        {
            Assert.AreEqual("VÒNG 1/2", RaceHudFormatter.FormatLap(1, 2));
            Assert.AreEqual("VÒNG 2/2", RaceHudFormatter.FormatLap(2, 2));
            Assert.AreEqual("VÒNG 2/2", RaceHudFormatter.FormatLap(3, 2), "Nhan khong duoc vuot so vong.");
            Assert.AreEqual("VÒNG 1/2", RaceHudFormatter.FormatLap(0, 2));
        }

        [Test]
        public void NextCheckpointTextIsOneBased()
        {
            Assert.AreEqual("CỔNG 1/4", RaceHudFormatter.FormatNextCheckpoint(0, 4));
            Assert.AreEqual("CỔNG 4/4", RaceHudFormatter.FormatNextCheckpoint(3, 4));
        }

        [Test]
        public void SpeedTextUsesAbsoluteValueSoReverseIsNotNegative()
        {
            Assert.AreEqual("12 KM/H", RaceHudFormatter.FormatSpeed(12.4f));
            Assert.AreEqual("12 KM/H", RaceHudFormatter.FormatSpeed(-12.4f));
            Assert.AreEqual("0 KM/H", RaceHudFormatter.FormatSpeed(float.NaN));
        }

        [Test]
        public void BannerCountsDownWholeSecondsThenClears()
        {
            Assert.AreEqual("3", RaceHudFormatter.FormatBanner(RacePhase.Countdown, 3f, false, 0f));
            Assert.AreEqual("3", RaceHudFormatter.FormatBanner(RacePhase.Countdown, 2.4f, false, 0f));
            Assert.AreEqual("1", RaceHudFormatter.FormatBanner(RacePhase.Countdown, 0.2f, false, 0f));
            Assert.AreEqual(string.Empty, RaceHudFormatter.FormatBanner(RacePhase.Running, 0f, false, 0f));
        }

        [Test]
        public void BannerShowsRespawnLockOnlyWhileRespawning()
        {
            Assert.AreEqual("ĐẶT LẠI XE  1.5", RaceHudFormatter.FormatBanner(RacePhase.Running, 0f, true, 1.5f));
            Assert.AreEqual(string.Empty, RaceHudFormatter.FormatBanner(RacePhase.Finished, 0f, true, 1.5f));
        }

        [Test]
        public void MedalTextCoversEveryValue()
        {
            Assert.AreEqual("HUY CHƯƠNG VÀNG", RaceHudFormatter.FormatMedal(Medal.Gold));
            Assert.AreEqual("HUY CHƯƠNG BẠC", RaceHudFormatter.FormatMedal(Medal.Silver));
            Assert.AreEqual("HUY CHƯƠNG ĐỒNG", RaceHudFormatter.FormatMedal(Medal.Bronze));
            Assert.AreEqual("CHƯA ĐẠT HUY CHƯƠNG", RaceHudFormatter.FormatMedal(Medal.None));
        }

        [Test]
        public void MissingRecordIsNotShownAsZero()
        {
            Assert.AreEqual(RaceHudFormatter.NoRecordText, RaceHudFormatter.FormatRecord(null));
            StringAssert.DoesNotContain(RaceTimeFormatter.ZeroText, RaceHudFormatter.FormatRecord(null));
            Assert.AreEqual("KỶ LỤC: 01:25.500", RaceHudFormatter.FormatRecord(85.5f));
        }

        [Test]
        public void NewRecordTextRequiresBothImprovedAndSaved()
        {
            Assert.AreEqual(RaceHudFormatter.NewRecordText, RaceHudFormatter.FormatSaveState(true, true, null));
            Assert.AreEqual(RaceHudFormatter.SaveFailedText, RaceHudFormatter.FormatSaveState(true, false, "loi ghi"));
            Assert.AreEqual(string.Empty, RaceHudFormatter.FormatSaveState(false, false, null),
                "Cham hon ky luc cu khong phai loi, khong hien gi ca.");
        }
    }
}
