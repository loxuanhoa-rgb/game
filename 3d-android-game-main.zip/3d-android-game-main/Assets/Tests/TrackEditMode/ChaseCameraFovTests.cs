using NUnit.Framework;
using RacingDemo.Runtime.CameraRig;

namespace RacingDemo.Tests.TrackEditMode
{
    /// <summary>
    /// Goc nhin noi theo toc do (gop y khi choi thu tren Xiaomi 14): tuyen tinh tu goc dung yen
    /// den goc o toc do toi da, kep o hai dau, khong phu thuoc chieu chay.
    /// </summary>
    public sealed class ChaseCameraFovTests
    {
        [Test]
        public void AtRest_UsesRestFov()
        {
            Assert.That(ChaseCamera.EvaluateFieldOfView(62f, 72f, 0f, 120f), Is.EqualTo(62f).Within(1e-5f));
        }

        [Test]
        public void AtMaxSpeed_UsesMaxSpeedFov()
        {
            Assert.That(ChaseCamera.EvaluateFieldOfView(62f, 72f, 120f, 120f), Is.EqualTo(72f).Within(1e-5f));
        }

        [Test]
        public void HalfSpeed_IsHalfway()
        {
            Assert.That(ChaseCamera.EvaluateFieldOfView(62f, 72f, 60f, 120f), Is.EqualTo(67f).Within(1e-5f));
        }

        [Test]
        public void OverMaxSpeed_IsClampedToMaxSpeedFov()
        {
            Assert.That(ChaseCamera.EvaluateFieldOfView(62f, 72f, 500f, 120f), Is.EqualTo(72f).Within(1e-5f));
        }

        [Test]
        public void Reverse_UsesAbsoluteSpeed()
        {
            Assert.That(ChaseCamera.EvaluateFieldOfView(62f, 72f, -60f, 120f), Is.EqualTo(67f).Within(1e-5f));
        }

        [Test]
        public void NonPositiveMaxSpeed_FallsBackToRestFov()
        {
            Assert.That(ChaseCamera.EvaluateFieldOfView(62f, 72f, 50f, 0f), Is.EqualTo(62f).Within(1e-5f));
            Assert.That(ChaseCamera.EvaluateFieldOfView(62f, 72f, 50f, -1f), Is.EqualTo(62f).Within(1e-5f));
        }

        [Test]
        public void EqualFovs_DisableTheEffect()
        {
            Assert.That(ChaseCamera.EvaluateFieldOfView(62f, 62f, 90f, 120f), Is.EqualTo(62f).Within(1e-5f));
        }
    }
}
