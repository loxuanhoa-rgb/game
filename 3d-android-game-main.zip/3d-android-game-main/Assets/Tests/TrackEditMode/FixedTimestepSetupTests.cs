using System.Collections.Generic;
using NUnit.Framework;
using RacingDemo.EditorTools;
using UnityEngine;

namespace RacingDemo.Tests.TrackEditMode
{
    /// <summary>
    /// Task 7: buoc vat ly phai la 1/60 giay theo ke hoach muc 2. Bo test nay giu hai viec:
    /// chot lai gia tri that cua project, va chung minh <see cref="FixedTimestepSetup.Verify"/>
    /// that su bat duoc khi gia tri sai (khong phai loai kiem tra luon "dat").
    /// </summary>
    public sealed class FixedTimestepSetupTests
    {
        private float _previous;

        [SetUp]
        public void SetUp()
        {
            _previous = Time.fixedDeltaTime;
        }

        [TearDown]
        public void TearDown()
        {
            Time.fixedDeltaTime = _previous;
        }

        [Test]
        public void ProjectRunsPhysicsAtSixtyHertz()
        {
            Assert.That(_previous, Is.EqualTo(1f / 60f).Within(1e-6f),
                "TimeManager cua project khong con dat 1/60 giay. Chay RacingDemo/Apply Fixed Timestep.");
        }

        [Test]
        public void VerifyAcceptsTheWantedValue()
        {
            Time.fixedDeltaTime = FixedTimestepSetup.WantedFixedDeltaTime;

            var errors = new List<string>();
            FixedTimestepSetup.Verify(errors);

            Assert.That(errors, Is.Empty);
        }

        [Test]
        public void VerifyReportsUnityDefaultOfFiftyHertz()
        {
            Time.fixedDeltaTime = 0.02f;

            var errors = new List<string>();
            FixedTimestepSetup.Verify(errors);

            Assert.That(errors.Count, Is.EqualTo(1));
            Assert.That(errors[0], Does.Contain("1/60"));
        }

        [Test]
        public void ApplyIsQuietWhenTheValueIsAlreadyRight()
        {
            Time.fixedDeltaTime = FixedTimestepSetup.WantedFixedDeltaTime;

            var changes = new List<string>();
            FixedTimestepSetup.Apply(changes);

            Assert.That(changes, Is.Empty, "Apply khong duoc bao thay doi khi gia tri da dung.");
        }
    }
}
