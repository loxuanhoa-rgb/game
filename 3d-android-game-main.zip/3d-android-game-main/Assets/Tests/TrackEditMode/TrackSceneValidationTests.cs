using System;
using System.Collections.Generic;
using NUnit.Framework;
using RacingDemo.EditorTools;
using RacingDemo.Runtime.Track;
using RacingDemo.Runtime.Vehicle;
using UnityEditor;
using UnityEngine;
using Object = UnityEngine.Object;

namespace RacingDemo.Tests.TrackEditMode
{
    /// <summary>Fixtures are built in memory from source: never mutate Race.unity or tuned assets.</summary>
    public sealed class TrackSceneValidationTests
    {
        private GameObject _root;
        private TrackDefinition _track;
        private CarConfig _car;
        private Mesh _road;
        private Mesh _inner;
        private Mesh _outer;
        private Material _material;
        private PhysicsMaterial _slide;
        private readonly List<Object> _extraObjects = new List<Object>();

        [SetUp]
        public void SetUp()
        {
            _car = ScriptableObject.CreateInstance<CarConfig>();
            _track = TrackDefinition.CreateDemoDefault(_car);
            _road = TrackBuilder.CreateRoadMesh(_track);
            _inner = TrackBuilder.CreateBarrierMesh(_track, true);
            _outer = TrackBuilder.CreateBarrierMesh(_track, false);
            Shader shader = Shader.Find("Universal Render Pipeline/Lit");
            Assert.That(shader, Is.Not.Null, "URP shader is a required generator dependency.");
            _material = new Material(shader);
            _slide = TrackBuilder.ConfigureSlideMaterial(new PhysicsMaterial("TestSlide"));
            _root = new GameObject("__GeneratedScene");
            var player = new GameObject("Car");
            player.transform.SetParent(_root.transform, false);
            player.transform.SetPositionAndRotation(_track.StartPose.Position, _track.StartPose.Rotation);
            Rigidbody body = player.AddComponent<Rigidbody>();
            body.isKinematic = true;
            player.AddComponent<BoxCollider>().sharedMaterial = _slide;
            CarController controller = player.AddComponent<CarController>();
            SetReference(controller, "_config", _car);
            TrackBuilder.Build(_root.transform, _track, body, _material, _material, _material, _material, _road, _inner, _outer, _slide);
        }

        [TearDown]
        public void TearDown()
        {
            Object.DestroyImmediate(_root);
            Object.DestroyImmediate(_road);
            Object.DestroyImmediate(_inner);
            Object.DestroyImmediate(_outer);
            Object.DestroyImmediate(_material);
            Object.DestroyImmediate(_slide);
            Object.DestroyImmediate(_track);
            Object.DestroyImmediate(_car);
            foreach (Object extra in _extraObjects) Object.DestroyImmediate(extra);
            _extraObjects.Clear();
        }

        [Test]
        public void SourceBuiltTrack_WithSharedSeamAndSafePoses_Passes()
        {
            Assert.That(SceneErrors(), Is.Empty);
        }

        [Test]
        public void Road_WithClosingPanelRemoved_IsRejected()
        {
            int[] indices = _road.triangles;
            Array.Resize(ref indices, indices.Length - 6);
            _road.triangles = indices;
            AssertError(SceneErrors(), "Road");
        }

        [Test]
        public void Road_WithRaisedJoinVertex_IsRejected()
        {
            Vector3[] vertices = _road.vertices;
            vertices[0] += Vector3.up * 0.1f;
            _road.vertices = vertices;
            AssertError(SceneErrors(), "Road");
        }

        [Test]
        public void Road_WithReverseWinding_IsRejected()
        {
            int[] indices = _road.triangles;
            int first = indices[0]; indices[0] = indices[1]; indices[1] = first;
            _road.triangles = indices;
            AssertError(SceneErrors(), "normal");
        }

        [Test]
        public void Road_ColliderUsingAnotherMesh_IsRejected()
        {
            Mesh copy = Object.Instantiate(_road);
            _extraObjects.Add(copy);
            _root.transform.Find("Track/Road").GetComponent<MeshCollider>().sharedMesh = copy;
            AssertError(SceneErrors(), "cung mesh");
        }

        [Test]
        public void Barrier_WithOpenClosingFace_IsRejected()
        {
            int[] indices = _inner.triangles;
            Array.Resize(ref indices, indices.Length - 6);
            _inner.triangles = indices;
            AssertError(SceneErrors(), "khe ho");
        }

        [Test]
        public void SlideMaterial_HasTunedFrictionAndMinimumCombine()
        {
            Assert.That(TrackBuilder.IsSlideMaterial(_slide), Is.True);
            Assert.That(_slide.dynamicFriction, Is.EqualTo(TrackBuilder.BarrierFriction).Within(1e-5f));
            Assert.That(_slide.staticFriction, Is.EqualTo(TrackBuilder.BarrierFriction).Within(1e-5f));
            Assert.That(_slide.bounciness, Is.EqualTo(0f));
            Assert.That(_slide.frictionCombine, Is.EqualTo(PhysicsMaterialCombine.Minimum));
            Assert.That(TrackBuilder.BarrierFriction, Is.GreaterThan(0f).And.LessThan(0.6f),
                "Gia tri tune phai nam giua 0 (co tuong khong mat toc) va 0,6 (dinh tuong).");
            Assert.That(TrackBuilder.IsSlideMaterial(null), Is.False);
        }

        [Test]
        public void SlideMaterial_RejectsUnityDefaultAndFrictionless()
        {
            var unityDefault = new PhysicsMaterial("Default");
            _extraObjects.Add(unityDefault);
            Assert.That(TrackBuilder.IsSlideMaterial(unityDefault), Is.False, "Mac dinh 0,6: xe dinh tuong.");

            var frictionless = new PhysicsMaterial("Ice") { dynamicFriction = 0f, staticFriction = 0f,
                frictionCombine = PhysicsMaterialCombine.Minimum };
            _extraObjects.Add(frictionless);
            Assert.That(TrackBuilder.IsSlideMaterial(frictionless), Is.False, "Ma sat 0: xe co tuong khong mat toc.");
        }

        [Test]
        public void Barrier_WithoutSlidePhysics_IsRejected()
        {
            _root.transform.Find("Track/InnerBarrier").GetComponent<MeshCollider>().sharedMaterial = null;
            AssertError(SceneErrors(), "InnerBarrier can PhysicsMaterial ma sat");
        }

        [Test]
        public void Barrier_WithDefaultFriction_IsRejected()
        {
            var sticky = new PhysicsMaterial("Sticky") { dynamicFriction = 0.6f, staticFriction = 0.6f,
                frictionCombine = PhysicsMaterialCombine.Minimum };
            _extraObjects.Add(sticky);
            _root.transform.Find("Track/OuterBarrier").GetComponent<MeshCollider>().sharedMaterial = sticky;
            AssertError(SceneErrors(), "OuterBarrier can PhysicsMaterial ma sat");
        }

        [Test]
        public void Barrier_WithAverageFrictionCombine_IsRejected()
        {
            // Dung ma sat nhung Average voi collider khac (0,6) se ra gia tri khac: phai la Minimum.
            var average = new PhysicsMaterial("Average") { dynamicFriction = TrackBuilder.BarrierFriction,
                staticFriction = TrackBuilder.BarrierFriction, frictionCombine = PhysicsMaterialCombine.Average };
            _extraObjects.Add(average);
            _root.transform.Find("Track/InnerBarrier").GetComponent<MeshCollider>().sharedMaterial = average;
            AssertError(SceneErrors(), "InnerBarrier can PhysicsMaterial ma sat");
        }

        [Test]
        public void CarBody_WithoutSlidePhysics_IsRejected()
        {
            _root.transform.Find("Car").GetComponent<BoxCollider>().sharedMaterial = null;
            AssertError(SceneErrors(), "Than xe can PhysicsMaterial ma sat");
        }

        [Test]
        public void MissingCheckpoint_IsRejected()
        {
            Object.DestroyImmediate(Volume(1).gameObject);
            AssertError(SceneErrors(), "4 CheckpointVolume");
        }

        [Test]
        public void DuplicateCheckpointOrder_IsRejected()
        {
            var serialized = new SerializedObject(Volume(1));
            serialized.FindProperty("_order").intValue = 0;
            serialized.ApplyModifiedPropertiesWithoutUndo();
            AssertError(SceneErrors(), "order");
        }

        [Test]
        public void CheckpointMovedOutsideRoad_IsRejected()
        {
            Volume(0).transform.position += Vector3.right * 30f;
            AssertError(SceneErrors(), "vi tri tren mat duong");
        }

        [Test]
        public void CheckpointFacingBackwards_IsRejected()
        {
            Volume(2).transform.Rotate(Vector3.up, 180f);
            AssertError(SceneErrors(), "sai chieu chay");
        }

        [Test]
        public void CheckpointReferencingAnotherBody_IsRejected()
        {
            var other = new GameObject("OtherCar");
            _extraObjects.Add(other);
            SetReference(Volume(0), "_playerBody", other.AddComponent<Rigidbody>());
            AssertError(SceneErrors(), "Rigidbody xe nguoi choi");
        }

        [Test]
        public void CheckpointTooThin_IsRejected()
        {
            Volume(0).GetComponent<BoxCollider>().size = new Vector3(12f, 4f, 0.1f);
            AssertError(SceneErrors(), "trigger");
        }

        [Test]
        public void RespawnRootOutsideGate_ButCarOverlapping_IsRejected()
        {
            _track.Checkpoints[0].RespawnPose = PoseAt(_track.Checkpoints[0].Distance + 3f);
            AssertError(DefinitionErrors(), "chong lan trigger checkpoint 0");
        }

        [Test]
        public void RespawnWheelBelowRoad_IsRejected()
        {
            TrackPose pose = _track.Checkpoints[0].RespawnPose;
            pose.Position.y = _track.SurfaceHeight + _car.WheelRadius - 0.05f;
            _track.Checkpoints[0].RespawnPose = pose;
            AssertError(DefinitionErrors(), "do cao an toan");
        }

        [Test]
        public void RespawnRootOnRoad_ButWholeCarOutside_IsRejected()
        {
            TrackPose pose = _track.Checkpoints[3].RespawnPose;
            pose.Position.x += 5.8f;
            _track.Checkpoints[3].RespawnPose = pose;
            AssertError(DefinitionErrors(), "phan xe ngoai");
        }

        [Test]
        public void RespawnBeforeOwnGate_IsRejected()
        {
            _track.Checkpoints[1].RespawnPose = PoseAt(_track.Checkpoints[1].Distance - 8f);
            AssertError(DefinitionErrors(), "phai nam sau cong");
        }

        [Test]
        public void StartAfterFinish_IsRejected()
        {
            _track.StartPose = PoseAt(8f);
            AssertError(DefinitionErrors(), "StartPose phai o truoc");
        }

        [Test]
        public void NonFiniteCheckpointDistance_ReportsErrorWithoutThrowing()
        {
            _track.Checkpoints[1].Distance = float.NaN;
            AssertError(DefinitionErrors(), "Distance");
        }

        [Test]
        public void DuplicateDefinitionOrder_IsRejected()
        {
            _track.Checkpoints[2].Order = 1;
            AssertError(DefinitionErrors(), "lien tuc va duy nhat");
        }

        [Test]
        public void FinishNotAtLastQuarter_IsRejected()
        {
            _track.Checkpoints[3].Distance = 20f;
            AssertError(DefinitionErrors(), "index 3 phai la vach ket thuc");
        }

        [Test]
        public void MissingConfig_IsReportedWithoutNullDereference()
        {
            var errors = new List<string>();
            TrackSceneValidation.ValidateDefinition(null, _car, errors);
            AssertError(errors, "TrackDefinition");
        }

        private TrackPose PoseAt(float distance)
        {
            new StadiumGeometry(_track).Evaluate(distance, out Vector3 position, out Vector3 forward);
            position.y = _track.StartPose.Position.y;
            return new TrackPose(position, Quaternion.LookRotation(forward));
        }

        private CheckpointVolume Volume(int order)
        {
            foreach (CheckpointVolume volume in _root.GetComponentsInChildren<CheckpointVolume>())
                if (volume.Order == order) return volume;
            throw new InvalidOperationException("Fixture missing checkpoint " + order);
        }

        private List<string> SceneErrors()
        {
            var errors = new List<string>();
            TrackSceneValidation.ValidateGeneratedTrack(_root.transform, _track, _car, errors);
            return errors;
        }

        private List<string> DefinitionErrors()
        {
            var errors = new List<string>();
            TrackSceneValidation.ValidateDefinition(_track, _car, errors);
            return errors;
        }

        private static void AssertError(List<string> errors, string fragment)
        {
            Assert.That(errors.Exists(error => error.Contains(fragment)), Is.True,
                "Expected '" + fragment + "' in:\n" + string.Join("\n", errors));
        }

        private static void SetReference(Object target, string field, Object value)
        {
            var serialized = new SerializedObject(target);
            serialized.FindProperty(field).objectReferenceValue = value;
            serialized.ApplyModifiedPropertiesWithoutUndo();
        }
    }
}
