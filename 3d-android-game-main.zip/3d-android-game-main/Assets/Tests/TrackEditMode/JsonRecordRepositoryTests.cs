using System;
using System.Collections.Generic;
using System.IO;
using NUnit.Framework;
using RacingDemo.Core.Persistence;
using RacingDemo.Core.Scoring;
using RacingDemo.Runtime.Persistence;

namespace RacingDemo.Tests.TrackEditMode
{
    public sealed class JsonRecordRepositoryTests
    {
        private string _directory;
        private string _path;
        [SetUp] public void SetUp()
        {
            _directory = Path.Combine(Path.GetTempPath(), "RacingDemoRecords-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(_directory);
            _path = Path.Combine(_directory, "records.json");
        }
        [TearDown] public void TearDown() { Directory.Delete(_directory, true); }
        private RecordStore Open() { return new RecordStore(new JsonRecordRepository(new JsonFileStore(_path))); }

        [Test] public void MissingFileFirstSaveUpdateAndMultipleTracksSurviveReload()
        {
            var store = Open();
            Assert.IsFalse(store.TryGetBest("track", out _));
            Assert.IsFalse(File.Exists(_path));
            Assert.IsTrue(store.Submit("track", 110, Medal.Bronze).Saved);
            Assert.IsTrue(Open().Submit("track", 90, Medal.Silver).Saved);
            Assert.IsTrue(Open().Submit("other", 80, Medal.Gold).Saved);
            var reopened = Open();
            Assert.IsTrue(reopened.TryGetBest("track", out RecordData best));
            Assert.AreEqual(90, best.TimeSeconds);
            Assert.IsTrue(reopened.TryGetBest("other", out _));
            string original = File.ReadAllText(_path);
            Assert.IsFalse(reopened.Submit("track", 90, Medal.Silver).Saved);
            Assert.IsFalse(reopened.Submit("track", 120, Medal.None).Saved);
            Assert.AreEqual(original, File.ReadAllText(_path));
            Assert.IsEmpty(Directory.GetFiles(_directory, "*.tmp-*"));
        }

        [TestCase("not json")]
        [TestCase("")]
        [TestCase("{\"version\":1}")]
        [TestCase("{\"version\":1,\"records\":[")]
        public void CorruptFileIsBackedUpBeforeNewRecord(string corrupt)
        {
            File.WriteAllText(_path, corrupt);
            var store = Open();
            store.EnsureLoaded();
            Assert.IsFalse(store.WritesDisabled);
            string[] backups = Directory.GetFiles(_directory, "*.corrupt-*");
            Assert.AreEqual(1, backups.Length);
            Assert.AreEqual(corrupt, File.ReadAllText(backups[0]));
            Assert.AreEqual(corrupt, File.ReadAllText(_path));
            Assert.IsTrue(store.Submit("track", 90, Medal.Silver).Saved);
            Assert.IsTrue(Open().TryGetBest("track", out _));
        }

        [TestCase(2)] [TestCase(0)] [TestCase(-1)]
        public void UnsupportedVersionNeverOverwritesOriginal(int version)
        {
            string original = "{\"version\":" + version + ",\"records\":[]}";
            File.WriteAllText(_path, original);
            var result = Open().Submit("track", 90, Medal.Gold);
            Assert.IsFalse(result.Saved);
            Assert.IsTrue(result.HasError);
            Assert.AreEqual(original, File.ReadAllText(_path));
            Assert.AreEqual(1, Directory.GetFiles(_directory).Length);
        }

        [Test] public void InvalidRecordsAreDiscardedAndDuplicatesKeepFastest()
        {
            File.WriteAllText(_path, "{\"version\":1,\"records\":[" +
                "{\"trackId\":\"a\",\"timeSeconds\":110,\"medal\":1}," +
                "{\"trackId\":\"a\",\"timeSeconds\":90,\"medal\":2}," +
                "{\"trackId\":\"\",\"timeSeconds\":30,\"medal\":3}," +
                "{\"trackId\":\"bad\",\"timeSeconds\":-1,\"medal\":3}," +
                "{\"trackId\":\"bad2\",\"timeSeconds\":50,\"medal\":99}]}");
            var repo = new JsonRecordRepository(new JsonFileStore(_path));
            Assert.IsTrue(repo.TryLoad(out IReadOnlyList<RecordData> records, out _));
            Assert.AreEqual(1, records.Count);
            Assert.AreEqual(90, records[0].TimeSeconds);
        }

        [Test] public void ReadFailureBlocksWritesUntilNewSession()
        {
            var files = new FaultFiles { ReadError = true };
            var store = new RecordStore(new JsonRecordRepository(files));
            Assert.IsFalse(store.Submit("a", 90, Medal.Gold).Saved);
            files.ReadError = false;
            Assert.IsFalse(store.Submit("a", 80, Medal.Gold).Saved);
            Assert.AreEqual(0, files.Writes);
            Assert.IsTrue(new RecordStore(new JsonRecordRepository(files)).Submit("a", 80, Medal.Gold).Saved);
        }

        [Test] public void BackupFailureBlocksWritesAndPreservesCorruptData()
        {
            var files = new FaultFiles { Text = "broken", BackupError = true };
            var store = new RecordStore(new JsonRecordRepository(files));
            Assert.IsTrue(store.Submit("a", 90, Medal.Gold).HasError);
            files.BackupError = false;
            Assert.IsFalse(store.Submit("a", 80, Medal.Gold).Saved);
            Assert.AreEqual("broken", files.Text);
            Assert.AreEqual(0, files.Writes);
        }

        [Test] public void WriteFailurePreservesCacheAndAllowsRetry()
        {
            var files = new FaultFiles();
            var store = new RecordStore(new JsonRecordRepository(files));
            Assert.IsTrue(store.Submit("a", 100, Medal.Silver).Saved);
            string original = files.Text;
            files.WriteError = true;
            var failed = store.Submit("a", 90, Medal.Gold);
            Assert.IsFalse(failed.Saved);
            Assert.AreEqual(100, failed.BestPersisted);
            Assert.AreEqual(original, files.Text);
            files.WriteError = false;
            Assert.IsTrue(store.Submit("a", 90, Medal.Gold).Saved);
        }

        [Test] public void AtomicWriteFailureLeavesOldDestinationIntact()
        {
            new JsonFileStore(_path).WriteAtomic("old");
            using (var locked = new FileStream(_path, FileMode.Open, FileAccess.Read, FileShare.None))
                Assert.Throws<IOException>(() => new JsonFileStore(_path).WriteAtomic("new"));
            Assert.AreEqual("old", File.ReadAllText(_path));
            Assert.IsEmpty(Directory.GetFiles(_directory, "*.tmp-*"));
        }

        private sealed class FaultFiles : IJsonFileStore
        {
            public string Text;
            public bool ReadError, BackupError, WriteError;
            public int Writes;
            public string Read() { if (ReadError) throw new IOException("read failure"); return Text; }
            public void BackupCorrupt() { if (BackupError) throw new IOException("backup failure"); }
            public void WriteAtomic(string json) { Writes++; if (WriteError) throw new IOException("write failure"); Text = json; }
        }
    }
}
