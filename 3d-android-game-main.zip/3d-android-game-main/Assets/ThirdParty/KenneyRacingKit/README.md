# Kenney Racing Kit — nguồn và giấy phép

| Mục | Giá trị |
|---|---|
| Gói | Racing Kit **2.0** (ngày tạo ghi trong `License.txt`: 07-11-2018) |
| Tác giả | Kenney — <https://kenney.nl> |
| Trang gói | <https://kenney.nl/assets/racing-kit> |
| File tải | <https://kenney.nl/media/pages/assets/racing-kit/933b8fd9fd-1677580949/kenney_racing-kit.zip> |
| Kích thước | 5,8 MB |
| SHA256 của zip | `8A71EA16219315A01D00D5A90C4F6B5C090FADDBC56D80ECF727E2B3B853C6C0` |
| Ngày tải về | 09/09/2026 |
| Giấy phép | **CC0 1.0 (Creative Commons Zero)** — xem `License.txt` đi kèm |

CC0 cho phép dùng trong dự án cá nhân, giáo dục và thương mại, không bắt buộc ghi công.
Repo này vẫn ghi công Kenney theo đề nghị của tác giả.

## Những gì được chép vào repo

Chỉ chép **11 model FBX** thực sự dùng trong demo, không chép cả gói (gói gốc có 110 model,
kèm bản DAE/GLTF/OBJ/STL và ảnh isometric/side mà demo không dùng):

| File | Dùng ở đâu |
|---|---|
| `raceCarRed.fbx` | Thân xe người chơi (thay khối hộp prototype của Task 2) |
| `pylon.fbx` | Cọc tiêu viền đường |
| `treeSmall.fbx`, `treeLarge.fbx` | Cây ngoài rào và trong lòng sân |
| `grandStandCovered.fbx` | Khán đài dọc đoạn thẳng |
| `tentLong.fbx` | Lều khu kỹ thuật |
| `flagCheckers.fbx` | Cờ ca-rô ở vạch đích |
| `lightPostModern.fbx` | Cột đèn |
| `billboard.fbx` | Biển quảng cáo |
| `barrierRed.fbx`, `barrierWhite.fbx` | Khối chắn đỏ/trắng xen kẽ ở hai cua, phía trong sân |

Hai texture trong `Models/Textures` (`checkers.png`, `tankco.png`) là texture gốc của gói, cần cho
cờ ca-rô và biển quảng cáo.

## Ranh giới

- Thư mục này là **asset bên thứ ba, không sửa nội dung file gốc**. Muốn đổi màu hay tỉ lệ thì
  làm ở generator (`Assets/Scripts/Editor`), không chỉnh FBX.
- Model chỉ là hình ảnh. Va chạm của xe và đường vẫn do collider tự sinh của Task 2/3 đảm nhiệm —
  xem `AGENTS.md` mục 4.
- Mọi vật trang trí do generator đặt vào cây `__GeneratedScene`, nên rebuild dựng lại được
  và không đụng đồ người dùng tự thêm.
