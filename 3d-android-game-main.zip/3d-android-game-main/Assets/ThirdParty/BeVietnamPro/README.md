# Be Vietnam Pro

Regular typeface by The Be Vietnam Pro Project Authors, Copyright 2021.
Source: https://github.com/google/fonts/tree/main/ofl/bevietnampro
Upstream: https://github.com/bettergui/BeVietnamPro
Downloaded 2026-09-17. Distributed under SIL Open Font License 1.1; see OFL.txt.

The unmodified TTF is used by ApexFontAssets to bake a shared static SDF atlas for Vietnamese UI and world signs. No runtime font download is required.
