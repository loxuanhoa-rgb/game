using System;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace RacingDemo.EditorTools
{
    /// <summary>
    /// Sinh tieng dong co lap vong thanh file WAV trong Assets/Generated.
    ///
    /// Vi sao tu sinh thay vi tai clip ve: nguon goc va giay phep ro rang tuyet doi
    /// (am thanh nay do chinh du an tao ra, khong keo theo rang buoc cua ben thu ba),
    /// va file chi nang vai chuc KB.
    ///
    /// Vong lap lien mach: tan so co ban 50 Hz voi 22050 mau/giay cho dung 50 chu ky tron
    /// trong mot giay, nen mau cuoi noi lien mau dau. Moi hoa am deu la boi cua 50 Hz.
    /// Chi giu hoa am tuan hoan; khong tron nhieu gio vao clip tang cao do theo toc do xe.
    /// </summary>
    public static class EngineClipBuilder
    {
        public const int SampleRate = 22050;
        public const float FundamentalHz = 50f;
        public const int LoopSamples = SampleRate; // Dung 1,0 giay = 50 chu ky.

        /// <summary>Tao/cap nhat file WAV. Tra ve true neu file tren dia thay doi.</summary>
        public static bool EnsureClip(string assetPath)
        {
            if (string.IsNullOrEmpty(assetPath))
            {
                throw new ArgumentException("Thieu duong dan asset.", nameof(assetPath));
            }

            byte[] wanted = BuildWavBytes();
            string absolute = DemoEditorPaths.ToAbsoluteProjectPath(assetPath);
            bool changed = !File.Exists(absolute) || !SameBytes(File.ReadAllBytes(absolute), wanted);
            if (changed)
            {
                // Ghi de tai cho: giu nguyen GUID nen reference trong scene khong dut.
                File.WriteAllBytes(absolute, wanted);
                AssetDatabase.ImportAsset(assetPath, ImportAssetOptions.ForceUpdate);
            }

            changed |= ApplyImportSettings(assetPath);
            return changed;
        }

        /// <summary>Mot chu ky mau tin hieu trong [-1, 1]. Tach rieng de kiem tra duoc.</summary>
        public static float[] BuildSamples()
        {
            var samples = new float[LoopSamples];

            // Hoa am giam dan: nghe ra tieng may nhieu xi-lanh chu khong phai tieng coi.
            float[] harmonicGains = { 1.00f, 0.62f, 0.38f, 0.24f, 0.15f, 0.10f, 0.06f, 0.04f };
            float[] harmonicPhases = { 0.00f, 0.35f, 1.10f, 2.40f, 0.80f, 1.90f, 2.90f, 0.50f };

            for (int i = 0; i < samples.Length; i++)
            {
                float phase = 2f * Mathf.PI * FundamentalHz * i / SampleRate;
                float value = 0f;
                for (int h = 0; h < harmonicGains.Length; h++)
                {
                    value += harmonicGains[h] * Mathf.Sin((h + 1) * phase + harmonicPhases[h]);
                }

                // Bien do dap theo chu ky no may, cho tieng "bung bung" thay vi mot not dan deu.
                value *= 0.75f + 0.25f * Mathf.Sin(phase);

                samples[i] = value;
            }

            Normalize(samples, 0.89f);
            return samples;
        }

        private static void Normalize(float[] samples, float peak)
        {
            float loudest = 0f;
            for (int i = 0; i < samples.Length; i++)
            {
                float magnitude = Mathf.Abs(samples[i]);
                if (magnitude > loudest)
                {
                    loudest = magnitude;
                }
            }

            if (loudest <= 0f)
            {
                throw new InvalidOperationException("Tin hieu rong; kiem tra lai tham so sinh am.");
            }

            float scale = peak / loudest;
            for (int i = 0; i < samples.Length; i++)
            {
                samples[i] *= scale;
            }
        }

        /// <summary>WAV PCM 16-bit, mot kenh. Viet tay de khong keo them thu vien nao.</summary>
        public static byte[] BuildWavBytes()
        {
            float[] samples = BuildSamples();
            int dataBytes = samples.Length * 2;
            var stream = new MemoryStream(44 + dataBytes);
            using (var writer = new BinaryWriter(stream))
            {
                writer.Write(new[] { 'R', 'I', 'F', 'F' });
                writer.Write(36 + dataBytes);
                writer.Write(new[] { 'W', 'A', 'V', 'E' });
                writer.Write(new[] { 'f', 'm', 't', ' ' });
                writer.Write(16);                     // Kich thuoc khoi fmt
                writer.Write((short)1);               // PCM khong nen
                writer.Write((short)1);               // Mot kenh
                writer.Write(SampleRate);
                writer.Write(SampleRate * 2);         // Byte moi giay
                writer.Write((short)2);               // Byte moi khung
                writer.Write((short)16);              // Bit moi mau
                writer.Write(new[] { 'd', 'a', 't', 'a' });
                writer.Write(dataBytes);
                for (int i = 0; i < samples.Length; i++)
                {
                    writer.Write((short)Mathf.Clamp(Mathf.RoundToInt(samples[i] * 32767f), -32768, 32767));
                }
            }

            return stream.ToArray();
        }

        /// <summary>Cai dat import cho clip nho tren dien thoai. Tra ve true neu co gi doi.</summary>
        private static bool ApplyImportSettings(string assetPath)
        {
            var importer = AssetImporter.GetAtPath(assetPath) as AudioImporter;
            if (importer == null)
            {
                throw new InvalidOperationException("Khong doc duoc AudioImporter tai " + assetPath);
            }

            AudioImporterSampleSettings settings = importer.defaultSampleSettings;
            bool changed = importer.forceToMono != true ||
                           importer.loadInBackground != false ||
                           settings.loadType != AudioClipLoadType.DecompressOnLoad ||
                           settings.compressionFormat != AudioCompressionFormat.PCM;
            if (!changed)
            {
                return false;
            }

            importer.forceToMono = true;
            importer.loadInBackground = false;
            settings.loadType = AudioClipLoadType.DecompressOnLoad;
            settings.compressionFormat = AudioCompressionFormat.PCM;
            importer.defaultSampleSettings = settings;
            importer.SaveAndReimport();
            return true;
        }

        private static bool SameBytes(byte[] left, byte[] right)
        {
            if (left.Length != right.Length)
            {
                return false;
            }

            for (int i = 0; i < left.Length; i++)
            {
                if (left[i] != right[i])
                {
                    return false;
                }
            }

            return true;
        }
    }
}
