using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace RacingDemo.EditorTools
{
    /// <summary>
    /// Gan gia tri vao truong [SerializeField] private cua component bang SerializedObject,
    /// de code runtime khong phai mo public setter chi vi generator.
    ///
    /// Ten truong sai se nem loi ngay. Sau khi Apply, moi truong deu duoc DOC LAI de xac nhan
    /// gia tri that su da ghi duoc: SerializedProperty.objectReferenceValue co the am tham
    /// bo qua gia tri (vi du sai kieu), va mot reference null trong scene rat kho truy nguoc.
    /// </summary>
    internal sealed class FieldBinder : IDisposable
    {
        private readonly UnityEngine.Object _target;
        private readonly SerializedObject _serializedObject;
        private readonly string _targetName;
        private readonly Dictionary<string, UnityEngine.Object> _expectedObjects =
            new Dictionary<string, UnityEngine.Object>(StringComparer.Ordinal);
        private readonly Dictionary<string, UnityEngine.Object[]> _expectedArrays =
            new Dictionary<string, UnityEngine.Object[]>(StringComparer.Ordinal);

        public FieldBinder(UnityEngine.Object target)
        {
            if (target == null)
            {
                throw new ArgumentNullException(nameof(target));
            }

            _target = target;
            _serializedObject = new SerializedObject(target);
            _targetName = target.GetType().Name;
        }

        public FieldBinder SetObject(string fieldName, UnityEngine.Object value)
        {
            if (value == null)
            {
                throw new InvalidOperationException(
                    "Gan null vao " + _targetName + "." + fieldName + "; generator dang thieu doi tuong.");
            }

            Find(fieldName).objectReferenceValue = value;
            _expectedObjects[fieldName] = value;
            return this;
        }

        /// <summary>
        /// Gan mang reference (vi du CanvasGroup[] hay TMP_Text[]). Moi phan tu deu bi cam null
        /// va duoc doc lai sau Apply nhu SetObject.
        /// </summary>
        public FieldBinder SetObjects(string fieldName, IReadOnlyList<UnityEngine.Object> values)
        {
            if (values == null)
            {
                throw new InvalidOperationException(
                    "Gan mang null vao " + _targetName + "." + fieldName + "; generator dang thieu doi tuong.");
            }

            SerializedProperty property = Find(fieldName);
            if (!property.isArray)
            {
                throw new InvalidOperationException(
                    _targetName + "." + fieldName + " khong phai mang; dung SetObject.");
            }

            var copy = new UnityEngine.Object[values.Count];
            property.arraySize = values.Count;
            for (int i = 0; i < values.Count; i++)
            {
                if (values[i] == null)
                {
                    throw new InvalidOperationException(
                        "Gan null vao " + _targetName + "." + fieldName + "[" + i + "]; generator dang thieu doi tuong.");
                }

                property.GetArrayElementAtIndex(i).objectReferenceValue = values[i];
                copy[i] = values[i];
            }

            _expectedArrays[fieldName] = copy;
            return this;
        }

        public FieldBinder SetVector3(string fieldName, Vector3 value)
        {
            Find(fieldName).vector3Value = value;
            return this;
        }

        public FieldBinder SetFloat(string fieldName, float value)
        {
            Find(fieldName).floatValue = value;
            return this;
        }

        public FieldBinder SetInt(string fieldName, int value)
        {
            Find(fieldName).intValue = value;
            return this;
        }

        public FieldBinder SetBool(string fieldName, bool value)
        {
            Find(fieldName).boolValue = value;
            return this;
        }

        public void Dispose()
        {
            _serializedObject.ApplyModifiedPropertiesWithoutUndo();
            EditorUtility.SetDirty(_target);
            VerifyObjectReferences();
        }

        /// <summary>Doc lai tu mot SerializedObject moi de chac chan gia tri da nam trong data that.</summary>
        private void VerifyObjectReferences()
        {
            if (_expectedObjects.Count == 0 && _expectedArrays.Count == 0)
            {
                return;
            }

            var verification = new SerializedObject(_target);

            foreach (KeyValuePair<string, UnityEngine.Object[]> pair in _expectedArrays)
            {
                SerializedProperty property = verification.FindProperty(pair.Key);
                if (property == null || !property.isArray || property.arraySize != pair.Value.Length)
                {
                    throw new InvalidOperationException(
                        "Gan mang " + _targetName + "." + pair.Key + " that bai: mong doi " + pair.Value.Length +
                        " phan tu nhung doc lai duoc " + (property == null ? "null" : property.arraySize.ToString()) + ".");
                }

                for (int i = 0; i < pair.Value.Length; i++)
                {
                    if (property.GetArrayElementAtIndex(i).objectReferenceValue != pair.Value[i])
                    {
                        throw new InvalidOperationException(
                            "Gan " + _targetName + "." + pair.Key + "[" + i + "] that bai: mong doi \"" +
                            pair.Value[i].name + "\" nhung doc lai khong khop.");
                    }
                }
            }

            foreach (KeyValuePair<string, UnityEngine.Object> pair in _expectedObjects)
            {
                SerializedProperty property = verification.FindProperty(pair.Key);
                if (property == null)
                {
                    throw new InvalidOperationException(
                        "Khong doc lai duoc truong \"" + pair.Key + "\" tren " + _targetName + ".");
                }

                if (property.objectReferenceValue == pair.Value)
                {
                    continue;
                }

                string actual = property.objectReferenceValue == null
                    ? "null"
                    : property.objectReferenceValue.name + " (" + property.objectReferenceValue.GetType().Name + ")";

                throw new InvalidOperationException(
                    "Gan " + _targetName + "." + pair.Key + " that bai: mong doi \"" + pair.Value.name +
                    "\" (" + pair.Value.GetType().Name + ") nhung doc lai duoc " + actual +
                    ". Kiem tra kieu cua truong va doi tuong duoc gan.");
            }
        }

        private SerializedProperty Find(string fieldName)
        {
            SerializedProperty property = _serializedObject.FindProperty(fieldName);
            if (property == null)
            {
                throw new InvalidOperationException(
                    "Khong tim thay truong \"" + fieldName + "\" tren " + _targetName +
                    ". Ten truong trong generator khong khop voi code runtime.");
            }

            return property;
        }
    }
}
