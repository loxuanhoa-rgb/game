using System;
using RacingDemo.Runtime.Track;
using UnityEngine;

namespace RacingDemo.EditorTools
{
    /// <summary>
    /// Trang tri quanh duong dua bang model Kenney: khan dai, cay, cot den, bien quang cao,
    /// coc tieu, khoi chan do/trang va co ca-ro o vach dich.
    ///
    /// Ba quy tac cua Task 6:
    /// - Chi la HINH ANH: khong vat nao co collider, khong vat nao nam tren mat duong.
    ///   Va cham cua duong/rao van do mesh collider cua Task 3 lo.
    /// - Vi tri tinh tu hinh hoc duong dua, khong dung so ngau nhien, nen rebuild hai lan
    ///   ra dung mot ket qua.
    /// - Toan bo nam trong cay __GeneratedScene, nen rebuild dung lai duoc va khong dung
    ///   toi do nguoi dung tu them.
    ///
    /// Bo trang tri co y giu it (khoang 70 vat) — ke hoach yeu cau chi them trang tri sau khi
    /// co so do hieu nang tren may that.
    /// </summary>
    public static class DecorBuilder
    {
        // Khoang cach ngang tinh tu tim duong (m). Duong rong 12 m nen mep o 6 m, rao them 0,4 m.
        private const float PylonOffset = 7.3f;
        private const float CurbOffset = 7.2f;
        private const float FlagOffset = 8.2f;
        private const float LightPostOffset = 9.5f;
        private const float GrandStandOffset = 13f;
        private const float BillboardOffset = 17f;
        private const float TreeOuterOffset = 22f;
        private const float TreeInnerOffset = 20f;
        private const float TentOffset = 18f;

        /// <summary>
        /// Vai model Kenney quay mat ve -Z trong file goc: khan dai ho phia -Z, canh den vuon ra
        /// -Z, mat bien quang cao (material "tankco") co phap tuyen -Z. Nhung vat do can quay
        /// them 180 do de nhin ve phia duong dua thay vi quay lung lai.
        /// </summary>
        private const float FacesBackwardYaw = 180f;

        public static GameObject Build(Transform parent, TrackDefinition track)
        {
            if (parent == null) throw new ArgumentNullException(nameof(parent));
            if (track == null) throw new ArgumentNullException(nameof(track));

            var root = new GameObject("Decor");
            root.transform.SetParent(parent, false);

            var path = new StadiumGeometry(track);
            BuildPylons(root.transform, path);
            BuildCurbs(root.transform, path);
            BuildGrandStands(root.transform, path);
            BuildTents(root.transform, path);
            BuildTrees(root.transform, path);
            BuildLightPosts(root.transform, path);
            BuildBillboards(root.transform, path);
            BuildFinishFlags(root.transform, path);
            return root;
        }

        /// <summary>Coc tieu chay deu ca vong, ngay ben ngoai rao — vien mep duong cho de doc.</summary>
        private static void BuildPylons(Transform root, StadiumGeometry path)
        {
            GameObject model = KenneyKit.Load(KenneyKit.Pylon);
            int index = 0;
            for (float distance = 0f; distance < path.Length - 1f; distance += 20f, index++)
            {
                Place(root, path, model, "Pylon" + index, distance, PylonOffset);
            }
        }

        /// <summary>Khoi do/trang xen ke o hai cua, phia trong san.</summary>
        private static void BuildCurbs(Transform root, StadiumGeometry path)
        {
            GameObject red = KenneyKit.Load(KenneyKit.BarrierRed);
            GameObject white = KenneyKit.Load(KenneyKit.BarrierWhite);
            float halfStraight = path.StraightLength * 0.5f;
            float halfArc = Mathf.PI * path.CenterRadius;
            float[] arcStarts = { halfStraight, halfStraight + halfArc + path.StraightLength };

            int index = 0;
            for (int arc = 0; arc < arcStarts.Length; arc++)
            {
                for (float along = 6f; along < halfArc - 6f; along += 10f, index++)
                {
                    Place(root, path, index % 2 == 0 ? red : white, "Curb" + index,
                        arcStarts[arc] + along, -CurbOffset);
                }
            }
        }

        /// <summary>Ba khan dai lien nhau tren doan thang chinh, nhin ve phia vach dich.</summary>
        private static void BuildGrandStands(Transform root, StadiumGeometry path)
        {
            GameObject model = KenneyKit.Load(KenneyKit.GrandStand);
            for (int index = 0; index < 3; index++)
            {
                Place(root, path, model, "GrandStand" + index, 8f + index * 6.5f, GrandStandOffset,
                    FacesBackwardYaw);
            }
        }

        private static void BuildTents(Transform root, StadiumGeometry path)
        {
            GameObject model = KenneyKit.Load(KenneyKit.Tent);
            Place(root, path, model, "Tent0", 12f, -TentOffset);
            Place(root, path, model, "Tent1", 30f, -TentOffset);
        }

        private static void BuildTrees(Transform root, StadiumGeometry path)
        {
            GameObject small = KenneyKit.Load(KenneyKit.TreeSmall);
            GameObject large = KenneyKit.Load(KenneyKit.TreeLarge);

            int index = 0;
            for (float distance = 55f; distance < path.Length - 10f; distance += 30f, index++)
            {
                Place(root, path, index % 2 == 0 ? large : small, "TreeOuter" + index, distance, TreeOuterOffset);
            }

            for (int corner = 0; corner < 4; corner++)
            {
                Place(root, path, corner % 2 == 0 ? small : large, "TreeInner" + corner,
                    60f + corner * path.Length / 4f, -TreeInnerOffset);
            }

            // Small groves frame the venue without closing sight lines across a corner.
            for (int cluster = 0; cluster < 8; cluster++)
                for (int tree = 0; tree < 3; tree++)
                    Place(root, path, tree == 1 ? large : small, "Grove" + cluster + "_" + tree,
                        38f + cluster * path.Length / 8f + tree * 5f, 29f + tree % 2 * 7f);
        }

        private static void BuildLightPosts(Transform root, StadiumGeometry path)
        {
            GameObject model = KenneyKit.Load(KenneyKit.LightPost);
            for (int index = 0; index < 8; index++)
            {
                Place(root, path, model, "LightPost" + index, index * path.Length / 8f, LightPostOffset,
                    FacesBackwardYaw);
            }
        }

        private static void BuildBillboards(Transform root, StadiumGeometry path)
        {
            GameObject model = KenneyKit.Load(KenneyKit.Billboard);
            float[] distances = { 100f, 200f, 300f };
            for (int index = 0; index < distances.Length; index++)
            {
                Place(root, path, model, "Billboard" + index, distances[index], BillboardOffset,
                    FacesBackwardYaw);
            }
        }

        /// <summary>Co ca-ro hai ben vach dich (checkpoint cuoi nam o quang duong 0).</summary>
        private static void BuildFinishFlags(Transform root, StadiumGeometry path)
        {
            GameObject model = KenneyKit.Load(KenneyKit.FlagCheckers);
            Place(root, path, model, "FinishFlagOuter", 0f, FlagOffset);
            Place(root, path, model, "FinishFlagInner", 0f, -FlagOffset);
        }

        /// <summary>
        /// Dat vat theo quang duong doc tim duong va do lech ngang.
        /// Lech duong la phia NGOAI duong dua, lech am la phia trong long san; vat luon quay mat
        /// vao duong.
        /// </summary>
        private static void Place(
            Transform root, StadiumGeometry path, GameObject model, string name, float distance,
            float lateralOffset, float extraYawDegrees = 0f)
        {
            path.Evaluate(distance, out Vector3 position, out Vector3 forward);
            Vector3 right = Vector3.Cross(Vector3.up, forward);
            Vector3 placement = position + right * lateralOffset;
            placement.y = path.SurfaceHeight;

            Vector3 facing = lateralOffset >= 0f ? -right : right;
            Quaternion rotation = Quaternion.LookRotation(facing, Vector3.up) *
                                  Quaternion.Euler(0f, extraYawDegrees, 0f);
            KenneyKit.Place(root, model, name, placement, rotation, KenneyKit.PropScale);
        }
    }
}
