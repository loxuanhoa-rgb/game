using System;
using System.Text;
using TMPro;
using UnityEditor;
using UnityEngine;
using UnityEngine.TextCore.LowLevel;

namespace RacingDemo.EditorTools
{
    /// <summary>One baked Vietnamese atlas shared by the UI and venue signs.</summary>
    internal static class ApexFontAssets
    {
        private const string FontPath = "Assets/ThirdParty/BeVietnamPro/BeVietnamPro-Regular.ttf";
        private const string AssetPath = "Assets/Generated/Fonts/BeVietnamPro SDF.asset";

        internal static TMP_FontAsset EnsureFont()
        {
            var existing = AssetDatabase.LoadAssetAtPath<TMP_FontAsset>(AssetPath);
            if (existing != null) return existing;
            DemoEditorPaths.EnsureAssetFolder("Assets/Generated/Fonts");
            var source = AssetDatabase.LoadAssetAtPath<Font>(FontPath);
            if (source == null) throw new InvalidOperationException("Missing Be Vietnam Pro font: " + FontPath);
            var font = TMP_FontAsset.CreateFontAsset(source, 64, 6, GlyphRenderMode.SDFAA,
                2048, 2048, AtlasPopulationMode.Dynamic, false);
            font.name = "BeVietnamPro SDF";
            var characters = new StringBuilder();
            for (int i = 32; i <= 126; i++) characters.Append((char)i);
            characters.Append("ÀÁÂÃÈÉÊÌÍÒÓÔÕÙÚÝàáâãèéêìíòóôõùúýĂăĐđĨĩŨũƠơƯư");
            for (int i = 0x1EA0; i <= 0x1EF9; i++) characters.Append((char)i);
            characters.Append("–—·");
            if (!font.TryAddCharacters(characters.ToString(), out string missing))
                throw new InvalidOperationException("Be Vietnam Pro atlas missing glyphs: " + missing);
            font.atlasPopulationMode = AtlasPopulationMode.Static;
            AssetDatabase.CreateAsset(font, AssetPath);
            font.material.name = "BeVietnamPro SDF Material";
            AssetDatabase.AddObjectToAsset(font.material, font);
            foreach (Texture2D texture in font.atlasTextures)
            {
                texture.name = "BeVietnamPro SDF Atlas";
                AssetDatabase.AddObjectToAsset(texture, font);
                EditorUtility.SetDirty(texture);
            }
            EditorUtility.SetDirty(font);
            AssetDatabase.SaveAssets();
            return font;
        }
    }
}
