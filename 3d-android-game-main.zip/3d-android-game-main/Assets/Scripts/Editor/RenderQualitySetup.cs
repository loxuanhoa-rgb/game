using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering.Universal;

namespace RacingDemo.EditorTools
{
    /// <summary>
    /// Cau hinh URP ban dau cho ban Android theo Task 6: HDR off, MSAA 2x, soft shadow off,
    /// shadow distance 40 m, 1 cascade, additional light off, render scale 1.0.
    ///
    /// Chi dong vao asset URP cua muc chat luong "Mobile" (Android dung muc nay).
    /// Sua qua SerializedObject — khong sua YAML bang tay, dung quy tac o AGENTS.md muc 4.
    /// Chay lai nhieu lan khong doi them gi: chi ghi khi gia tri thuc su lech.
    /// </summary>
    public static class RenderQualitySetup
    {
        public const string MobileAssetPath = "Assets/Settings/Mobile_RPAsset.asset";

        [MenuItem("RacingDemo/Apply Mobile Render Settings", false, 20)]
        public static void ApplyMobileSettings()
        {
            var changes = new List<string>();
            Apply(MobileAssetPath, changes);
            Debug.Log(changes.Count == 0
                ? "[RacingDemo] Cau hinh URP da dung yeu cau Task 6, khong phai doi gi."
                : "[RacingDemo] Da cap nhat URP: " + string.Join(", ", changes));
        }

        /// <summary>Tra ve danh sach truong da doi (rong nghia la khong co gi thay doi).</summary>
        public static void Apply(string assetPath, List<string> changes)
        {
            if (changes == null)
            {
                throw new ArgumentNullException(nameof(changes));
            }

            var asset = AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>(assetPath);
            if (asset == null)
            {
                throw new InvalidOperationException(
                    "Khong tim thay UniversalRenderPipelineAsset tai " + assetPath + ".");
            }

            var serialized = new SerializedObject(asset);
            SetBool(serialized, "m_SupportsHDR", false, changes);
            SetInt(serialized, "m_MSAA", 2, changes);
            SetFloat(serialized, "m_RenderScale", 1f, changes);
            SetInt(serialized, "m_AdditionalLightsRenderingMode", (int)LightRenderingMode.Disabled, changes);
            SetFloat(serialized, "m_ShadowDistance", 40f, changes);
            SetInt(serialized, "m_ShadowCascadeCount", 1, changes);
            SetBool(serialized, "m_SoftShadowsSupported", false, changes);

            // Ke hoach khong noi den hai gia tri duoi, nhung voi mot cascade phu 40 m thi
            // shadow map 1024 cho texel ~8 cm: than xe tu dam bong len chinh no thanh vet
            // rang cua. 2048 + normal bias 2 lam sach ma van re tren dien thoai.
            SetInt(serialized, "m_MainLightShadowmapResolution", 2048, changes);
            SetFloat(serialized, "m_ShadowNormalBias", 2f, changes);

            if (changes.Count != 0)
            {
                serialized.ApplyModifiedPropertiesWithoutUndo();
                EditorUtility.SetDirty(asset);
            }
        }

        /// <summary>Doc lai tu asset de kiem chung; validator dung ham nay.</summary>
        public static void Verify(string assetPath, List<string> errors)
        {
            if (errors == null)
            {
                throw new ArgumentNullException(nameof(errors));
            }

            var asset = AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>(assetPath);
            if (asset == null)
            {
                errors.Add("Khong tim thay UniversalRenderPipelineAsset tai " + assetPath + ".");
                return;
            }

            var serialized = new SerializedObject(asset);
            ExpectBool(serialized, "m_SupportsHDR", false, errors);
            ExpectInt(serialized, "m_MSAA", 2, errors);
            ExpectFloat(serialized, "m_RenderScale", 1f, errors);
            ExpectInt(serialized, "m_AdditionalLightsRenderingMode", (int)LightRenderingMode.Disabled, errors);
            ExpectFloat(serialized, "m_ShadowDistance", 40f, errors);
            ExpectInt(serialized, "m_ShadowCascadeCount", 1, errors);
            ExpectBool(serialized, "m_SoftShadowsSupported", false, errors);
            ExpectInt(serialized, "m_MainLightShadowmapResolution", 2048, errors);
            ExpectFloat(serialized, "m_ShadowNormalBias", 2f, errors);
        }

        private static SerializedProperty Require(SerializedObject serialized, string path)
        {
            SerializedProperty property = serialized.FindProperty(path);
            if (property == null)
            {
                throw new InvalidOperationException(
                    "URP asset khong con truong \"" + path + "\". Kiem tra lai phien ban URP truoc khi sua.");
            }

            return property;
        }

        private static void SetBool(SerializedObject serialized, string path, bool wanted, List<string> changes)
        {
            SerializedProperty property = Require(serialized, path);
            if (property.boolValue == wanted) return;
            changes.Add(path + ": " + property.boolValue + " -> " + wanted);
            property.boolValue = wanted;
        }

        private static void SetInt(SerializedObject serialized, string path, int wanted, List<string> changes)
        {
            SerializedProperty property = Require(serialized, path);
            if (property.intValue == wanted) return;
            changes.Add(path + ": " + property.intValue + " -> " + wanted);
            property.intValue = wanted;
        }

        private static void SetFloat(SerializedObject serialized, string path, float wanted, List<string> changes)
        {
            SerializedProperty property = Require(serialized, path);
            if (Mathf.Approximately(property.floatValue, wanted)) return;
            changes.Add(path + ": " + property.floatValue + " -> " + wanted);
            property.floatValue = wanted;
        }

        private static void ExpectBool(SerializedObject serialized, string path, bool wanted, List<string> errors)
        {
            SerializedProperty property = Require(serialized, path);
            if (property.boolValue != wanted)
            {
                errors.Add("URP " + path + " phai la " + wanted + ", dang la " + property.boolValue + ".");
            }
        }

        private static void ExpectInt(SerializedObject serialized, string path, int wanted, List<string> errors)
        {
            SerializedProperty property = Require(serialized, path);
            if (property.intValue != wanted)
            {
                errors.Add("URP " + path + " phai la " + wanted + ", dang la " + property.intValue + ".");
            }
        }

        private static void ExpectFloat(SerializedObject serialized, string path, float wanted, List<string> errors)
        {
            SerializedProperty property = Require(serialized, path);
            if (!Mathf.Approximately(property.floatValue, wanted))
            {
                errors.Add("URP " + path + " phai la " + wanted + ", dang la " + property.floatValue + ".");
            }
        }
    }
}
