using System;
using System.Collections.Generic;
using RacingDemo.Runtime.Track;
using RacingDemo.Runtime.Vehicle;
using UnityEngine;

namespace RacingDemo.EditorTools
{
    /// <summary>
    /// Kiem tra ca du lieu truoc rebuild va mesh/collider that sau khi dung scene.
    /// Khong sua scene hay asset; cac ham public cung duoc dung trong test bien doi du lieu.
    /// </summary>
    public static class TrackSceneValidation
    {
        private const float PositionTolerance = 0.025f;
        // Cung hinh hoc voi CarBuilder: than 1.7 x 4 m, truc banh (+/-0.75, +/-1.3), banh rong .22 m.
        private const float CarHalfWidth = 0.86f;
        private const float CarBodyHalfLength = 2f;
        private const float CarHalfWheelBase = 1.3f;
        private const float SpawnMargin = 0.05f;

        public static void ValidateDefinition(TrackDefinition track, CarConfig car, List<string> errors)
        {
            if (errors == null) throw new ArgumentNullException(nameof(errors));
            if (track == null) { errors.Add("TrackDefinition chua duoc gan."); return; }
            if (car == null) { errors.Add("CarConfig chua duoc gan."); return; }
            if (string.IsNullOrWhiteSpace(track.TrackId)) errors.Add("TrackDefinition.TrackId rong.");
            if (track.Checkpoints == null || track.Checkpoints.Length != 4)
                errors.Add("TrackDefinition phai co dung 4 checkpoint.");

            try { track.CreateRaceConfig(); }
            catch (Exception exception) when (exception is ArgumentException || exception is NullReferenceException)
            { errors.Add("Cau hinh luat dua khong hop le: " + exception.Message); }
            try { track.CreateMedalThresholds(); }
            catch (ArgumentException exception) { errors.Add("Nguong huy chuong khong hop le: " + exception.Message); }

            StadiumGeometry geometry;
            try { geometry = new StadiumGeometry(track); }
            catch (ArgumentException exception)
            { errors.Add("Hinh hoc TrackDefinition khong hop le: " + exception.Message); return; }
            if (Mathf.Abs(track.StraightLength - 80f) > 0.01f || Mathf.Abs(track.CenterRadius - 30f) > 0.01f ||
                Mathf.Abs(track.RoadWidth - 12f) > 0.01f)
                errors.Add("Task 3 yeu cau hai doan thang 80 m, ban kinh tim 30 m, mat duong rong 12 m.");

            if (!Finite(car.WheelRadius) || car.WheelRadius <= 0f || !Finite(car.SuspensionDistance) ||
                car.SuspensionDistance < 0f || !Finite(car.MaxSpeedKph) || car.MaxSpeedKph <= 0f)
            { errors.Add("CarConfig ban kinh banh/hanh trinh giam xoc/toc do khong hop le."); return; }
            float minimumDepth = Mathf.Max(2f, car.MaxSpeedKph / 3.6f * Time.fixedDeltaTime * 4f);
            if (!Finite(track.TriggerDepth) || track.TriggerDepth < minimumDepth)
                errors.Add("TriggerDepth qua mong: can it nhat " + minimumDepth + " m cho 4 buoc vat ly.");
            if (!Finite(track.TriggerHeight) || track.TriggerHeight < car.WheelRadius + car.SuspensionDistance + 1.3f)
                errors.Add("TriggerHeight khong phu du chieu cao xe.");

            bool gatesValid = track.Checkpoints != null && track.Checkpoints.Length == 4 &&
                              Finite(track.TriggerDepth) && track.TriggerDepth > 0f &&
                              Finite(track.TriggerHeight) && track.TriggerHeight > 0f;
            if (track.Checkpoints != null)
            {
                var orders = new HashSet<int>();
                for (int i = 0; i < track.Checkpoints.Length; i++)
                {
                    TrackCheckpoint checkpoint = track.Checkpoints[i];
                    if (checkpoint == null)
                    { errors.Add("Checkpoint " + i + " bi thieu."); gatesValid = false; continue; }
                    if (!orders.Add(checkpoint.Order) || checkpoint.Order != i || checkpoint.Order < 0 || checkpoint.Order > 3)
                        errors.Add("Checkpoint order phai lien tuc va duy nhat 0-3; sai tai index " + i + ".");
                    if (!Finite(checkpoint.Distance) || checkpoint.Distance < 0f || checkpoint.Distance >= geometry.Length)
                    { errors.Add("Checkpoint " + i + " co Distance ngoai [0, chieu dai duong)."); gatesValid = false; continue; }
                    float expectedDistance = i == 3 ? 0f : geometry.Length * (i + 1) * 0.25f;
                    if (CircularDifference(checkpoint.Distance, expectedDistance, geometry.Length) > 2f)
                        errors.Add("Checkpoint " + i + " khong o moc mot phan tu; index 3 phai la vach ket thuc tai moc 0.");
                }
            }
            if (!gatesValid) return;

            ValidatePose("StartPose", track.StartPose, track, car, geometry, errors);
            if (Finite(track.StartPose.Position))
            {
                float beforeFinish = ForwardDistance(geometry.GetDistanceAlongTrack(track.StartPose.Position),
                    track.Checkpoints[3].Distance, geometry.Length);
                if (beforeFinish <= PositionTolerance || beforeFinish >= geometry.Length * 0.125f)
                    errors.Add("StartPose phai o truoc vach ket thuc theo chieu chay, gan vach dich.");
            }
            for (int i = 0; i < track.Checkpoints.Length; i++)
            {
                TrackCheckpoint checkpoint = track.Checkpoints[i];
                ValidatePose("RespawnPose " + i, checkpoint.RespawnPose, track, car, geometry, errors);
                if (!Finite(checkpoint.RespawnPose.Position)) continue;
                float afterGate = ForwardDistance(checkpoint.Distance,
                    geometry.GetDistanceAlongTrack(checkpoint.RespawnPose.Position), geometry.Length);
                if (afterGate <= PositionTolerance || afterGate >= geometry.Length * 0.125f)
                    errors.Add("RespawnPose " + i + " phai nam sau cong cua no theo chieu chay.");
            }
        }

        public static void ValidateGeneratedTrack(Transform generatedRoot, TrackDefinition track, CarConfig car, List<string> errors)
        {
            int initialErrorCount = errors.Count;
            ValidateDefinition(track, car, errors);
            // Du lieu hong khong duoc gay exception thu cap trong qua trinh kiem mesh.
            if (generatedRoot == null) errors.Add("Thieu cay __GeneratedScene.");
            if (errors.Count != initialErrorCount) return;
            var geometry = new StadiumGeometry(track);
            Transform trackRoot = generatedRoot.Find("Track");
            if (trackRoot == null) { errors.Add("Thieu __GeneratedScene/Track."); return; }
            if (trackRoot.GetComponentsInChildren<Rigidbody>(true).Length != 0)
                errors.Add("Duong va rao phai la collider tinh, khong co Rigidbody.");
            if (trackRoot.GetComponentsInChildren<Collider>(true).Length != 7)
                errors.Add("Track can dung 7 collider: mat duong, hai rao va bon trigger.");

            MeshFilter road = RequireStaticMesh(trackRoot.Find("Road"), "Road", errors);
            if (road != null) ValidateRoadMesh(road, geometry, errors);
            MeshFilter inner = RequireStaticMesh(trackRoot.Find("InnerBarrier"), "InnerBarrier", errors);
            MeshFilter outer = RequireStaticMesh(trackRoot.Find("OuterBarrier"), "OuterBarrier", errors);
            if (inner != null) ValidateBarrierMesh(inner, geometry, true, errors);
            if (outer != null) ValidateBarrierMesh(outer, geometry, false, errors);
            if (inner != null) RequireSlidePhysics(inner.GetComponent<Collider>(), "InnerBarrier", errors);
            if (outer != null) RequireSlidePhysics(outer.GetComponent<Collider>(), "OuterBarrier", errors);

            CheckpointVolume[] volumes = trackRoot.GetComponentsInChildren<CheckpointVolume>(true);
            var orders = new HashSet<int>();
            CarController playerCar = generatedRoot.GetComponentInChildren<CarController>(true);
            Rigidbody playerBody = playerCar == null ? null : playerCar.GetComponent<Rigidbody>();
            if (playerCar != null) RequireSlidePhysics(playerCar.GetComponent<BoxCollider>(), "Than xe", errors);
            if (volumes.Length != 4) errors.Add("Scene phai co dung 4 CheckpointVolume.");
            foreach (CheckpointVolume volume in volumes)
            {
                int order = volume.Order;
                if (order < 0 || order > 3 || !orders.Add(order))
                { errors.Add("Checkpoint scene trung/thieu/sai order 0-3."); continue; }
                if (volume.PlayerBody == null || volume.PlayerBody != playerBody)
                    errors.Add("Checkpoint " + order + " khong tro dung Rigidbody xe nguoi choi.");
                geometry.Evaluate(track.Checkpoints[order].Distance, out Vector3 position, out Vector3 forward);
                if (Vector3.Distance(volume.transform.position, position) > PositionTolerance)
                    errors.Add("Checkpoint " + order + " khong dung vi tri tren mat duong.");
                if (Vector3.Dot(volume.transform.forward, forward) < 0.999f ||
                    Vector3.Dot(volume.transform.up, Vector3.up) < 0.999f)
                    errors.Add("Checkpoint " + order + " sai chieu chay.");
                BoxCollider gate = volume.GetComponent<BoxCollider>();
                if (gate == null || !gate.enabled || !gate.isTrigger ||
                    Vector3.Distance(gate.size, new Vector3(track.RoadWidth, track.TriggerHeight, track.TriggerDepth)) > PositionTolerance ||
                    Vector3.Distance(gate.center, new Vector3(0f, track.TriggerHeight * 0.5f, 0f)) > PositionTolerance ||
                    Vector3.Distance(volume.transform.lossyScale, Vector3.one) > 0.001f)
                    errors.Add("Checkpoint " + order + " trigger phai phu du rong/cao/day va scale 1.");
                if (order == 3 && volume.name.IndexOf("Finish", StringComparison.Ordinal) < 0)
                    errors.Add("Checkpoint index cuoi (3) phai la vach ket thuc Finish.");
            }
            if (playerCar != null && (Vector3.Distance(playerCar.transform.position, track.StartPose.Position) > PositionTolerance ||
                Quaternion.Angle(playerCar.transform.rotation, track.StartPose.Rotation) > 0.1f))
                errors.Add("Xe trong scene khong o StartPose cua TrackDefinition.");
        }

        private static void ValidatePose(string label, TrackPose pose, TrackDefinition track, CarConfig car,
            StadiumGeometry geometry, List<string> errors)
        {
            if (!Finite(pose.Position) || !Finite(pose.EulerAngles))
            { errors.Add(label + " co vi tri/huong khong huu han."); return; }
            Quaternion rotation = pose.Rotation;
            float distance = geometry.GetDistanceAlongTrack(pose.Position);
            geometry.Evaluate(distance, out _, out Vector3 expectedForward);
            if (Vector3.Dot(rotation * Vector3.forward, expectedForward) < 0.995f ||
                Vector3.Dot(rotation * Vector3.up, Vector3.up) < 0.999f)
                errors.Add(label + " sai chieu chay hoac bi nghieng.");

            float minimumHeight = track.SurfaceHeight + car.WheelRadius + car.SuspensionDistance;
            if (pose.Position.y < minimumHeight + 0.01f || pose.Position.y > minimumHeight + 0.5f)
                errors.Add(label + " khong o do cao an toan: banh/giam xoc xuyen nen hoac xe lo lung.");
            float halfLength = Mathf.Max(CarBodyHalfLength, CarHalfWheelBase + car.WheelRadius);
            bool outsideRoad = false;
            for (int side = -1; side <= 1; side += 2)
            for (int end = -1; end <= 1; end += 2)
            {
                Vector3 corner = pose.Position + rotation * new Vector3(side * CarHalfWidth, 0f, end * halfLength);
                if (geometry.DistanceFromCenterline(corner) > track.RoadWidth * 0.5f - SpawnMargin)
                    outsideRoad = true;
            }
            if (outsideRoad) errors.Add(label + " co mot phan xe ngoai mat duong/va rao.");

            // Mo rong hop trigger bang hinh chieu toan bo xe, khong chi kiem tra diem goc xe.
            for (int i = 0; i < track.Checkpoints.Length; i++)
            {
                geometry.Evaluate(track.Checkpoints[i].Distance, out Vector3 gatePosition, out Vector3 gateForward);
                Vector3 gateRight = Vector3.Cross(Vector3.up, gateForward);
                Vector3 delta = pose.Position - gatePosition;
                Vector3 carRight = rotation * Vector3.right;
                Vector3 carForward = rotation * Vector3.forward;
                float halfDepth = track.TriggerDepth * 0.5f + Mathf.Abs(Vector3.Dot(carRight, gateForward)) * CarHalfWidth +
                                  Mathf.Abs(Vector3.Dot(carForward, gateForward)) * halfLength + SpawnMargin;
                float halfWidth = track.RoadWidth * 0.5f + Mathf.Abs(Vector3.Dot(carRight, gateRight)) * CarHalfWidth +
                                  Mathf.Abs(Vector3.Dot(carForward, gateRight)) * halfLength + SpawnMargin;
                if (Mathf.Abs(Vector3.Dot(delta, gateForward)) <= halfDepth && Mathf.Abs(Vector3.Dot(delta, gateRight)) <= halfWidth)
                    errors.Add(label + " chong lan trigger checkpoint " + i + " (kiem ca chieu dai xe).");
            }
        }

        /// <summary>
        /// Rao va than xe phai mang vat lieu vat ly ma sat <see cref="TrackBuilder.BarrierFriction"/> / Minimum:
        /// mac dinh 0,6 lam xe dinh tuong, 0 lam xe co tuong khong mat toc (ca hai deu da thu tren Xiaomi 14).
        /// </summary>
        private static void RequireSlidePhysics(Collider collider, string label, List<string> errors)
        {
            if (collider == null) { errors.Add(label + " thieu collider."); return; }
            if (!TrackBuilder.IsSlideMaterial(collider.sharedMaterial))
                errors.Add(label + " can PhysicsMaterial ma sat " + TrackBuilder.BarrierFriction +
                    " va frictionCombine Minimum (gia tri da tune tren may that).");
        }

        private static MeshFilter RequireStaticMesh(Transform transform, string label, List<string> errors)
        {
            if (transform == null) { errors.Add("Thieu " + label + "."); return null; }
            MeshFilter filter = transform.GetComponent<MeshFilter>();
            MeshCollider collider = transform.GetComponent<MeshCollider>();
            MeshRenderer renderer = transform.GetComponent<MeshRenderer>();
            if (filter == null || filter.sharedMesh == null)
            { errors.Add(label + " thieu mesh."); return null; }
            if (collider == null || !collider.enabled || collider.convex || collider.isTrigger ||
                collider.sharedMesh != filter.sharedMesh || collider.attachedRigidbody != null || !transform.gameObject.isStatic)
                errors.Add(label + " can static MeshCollider dung cung mesh voi hinh ve.");
            if (renderer == null || !renderer.enabled || renderer.sharedMaterial == null)
                errors.Add(label + " thieu renderer/material.");
            return filter;
        }

        private static void ValidateRoadMesh(MeshFilter filter, StadiumGeometry geometry, List<string> errors)
        {
            Mesh mesh = filter.sharedMesh;
            Vector3[] vertices = WorldVertices(filter);
            int[] triangles = mesh.triangles;
            if (vertices.Length < 8 || vertices.Length % 2 != 0)
            { errors.Add("Road khong phai dai mesh hai dinh moi mat cat."); return; }
            int rings = vertices.Length / 2;
            if (triangles.Length != rings * 6) errors.Add("Road bi ho/du tam: moi cap mat cat phai co hai tam giac, gom moi noi vong.");
            var edges = new Dictionary<ulong, int>();
            bool malformed = CollectTriangleEdges(vertices, triangles, edges, true, errors, "Road");
            if (malformed) return;

            var distances = new float[rings];
            float perimeter = 0f;
            for (int ring = 0; ring < rings; ring++)
            {
                int next = (ring + 1) % rings;
                Vector3 a = vertices[ring * 2];
                Vector3 b = vertices[ring * 2 + 1];
                if (!Finite(a) || !Finite(b)) { errors.Add("Road co dinh khong huu han."); return; }
                Vector3 center = (a + b) * 0.5f;
                Vector3 nextCenter = (vertices[next * 2] + vertices[next * 2 + 1]) * 0.5f;
                distances[ring] = geometry.GetDistanceAlongTrack(center);
                geometry.Evaluate(distances[ring], out Vector3 expectedCenter, out Vector3 forward);
                if (Vector3.Distance(center, expectedCenter) > PositionTolerance ||
                    Mathf.Abs(Vector3.Distance(a, b) - geometry.RoadWidth) > PositionTolerance ||
                    Mathf.Abs(a.y - geometry.SurfaceHeight) > 0.001f || Mathf.Abs(b.y - geometry.SurfaceHeight) > 0.001f ||
                    Mathf.Abs(Vector3.Dot((b - a).normalized, forward)) > 0.002f)
                { errors.Add("Road sai vi tri/rong/do phang tai mat cat " + ring + "."); return; }
                float segmentLength = Vector3.Distance(center, nextCenter);
                perimeter += segmentLength;
                if (segmentLength < 0.0001f || segmentLength > 1.025f || Vector3.Dot((nextCenter - center).normalized, forward) < 0.995f)
                { errors.Add("Road co moi noi dut/buoc qua lon/sai chieu tai mat cat " + ring + "."); return; }
                if (EdgeCount(edges, ring * 2, ring * 2 + 1) != 2 ||
                    EdgeCount(edges, ring * 2, next * 2) != 1 ||
                    EdgeCount(edges, ring * 2 + 1, next * 2 + 1) != 1)
                { errors.Add("Road khong ghep lien tuc bang dinh chung tai mat cat " + ring + "."); return; }
            }
            if (Mathf.Abs(perimeter - geometry.Length) > 0.1f)
                errors.Add("Road khong bao phu dung mot vong theo hinh hoc tim duong.");
            foreach (int uses in edges.Values)
                if (uses < 1 || uses > 2) { errors.Add("Road co canh khong hop le/mesh chong lap."); break; }

            float halfStraight = geometry.StraightLength * 0.5f;
            float halfArc = Mathf.PI * geometry.CenterRadius;
            float[] joins = { 0f, halfStraight, halfStraight + halfArc, halfStraight + halfArc + geometry.StraightLength,
                halfStraight + halfArc * 2f + geometry.StraightLength };
            foreach (float join in joins)
            {
                bool found = false;
                foreach (float distance in distances)
                    if (CircularDifference(distance, join, geometry.Length) < 0.005f) { found = true; break; }
                if (!found) errors.Add("Road thieu mat cat tai moi noi thang-cung/vong kin " + join + " m.");
            }
        }

        private static void ValidateBarrierMesh(MeshFilter filter, StadiumGeometry geometry, bool inner, List<string> errors)
        {
            Vector3[] vertices = WorldVertices(filter);
            int[] triangles = filter.sharedMesh.triangles;
            var edges = new Dictionary<ulong, int>();
            if (CollectTriangleEdges(vertices, triangles, edges, false, errors, filter.name)) return;
            if (vertices.Length < 16 || vertices.Length % 4 != 0)
            { errors.Add(filter.name + " khong du hinh hoc rao kin."); return; }
            foreach (int uses in edges.Values)
                if (uses != 2) { errors.Add(filter.name + " co khe ho tai moi noi rao/collider."); break; }
            int rings = vertices.Length / 4;
            if (triangles.Length != rings * 24)
                errors.Add(filter.name + " thieu/du mat ghep cua rao kin.");
            float perimeter = 0f;
            for (int ring = 0; ring < rings; ring++)
            {
                int next = (ring + 1) % rings;
                Vector3 middle = (vertices[ring * 4] + vertices[ring * 4 + 2]) * 0.5f;
                Vector3 nextMiddle = (vertices[next * 4] + vertices[next * 4 + 2]) * 0.5f;
                if (!Finite(middle) || !Finite(nextMiddle))
                { errors.Add(filter.name + " co dinh khong huu han."); return; }
                geometry.Evaluate(geometry.GetDistanceAlongTrack(middle), out Vector3 center, out Vector3 forward);
                geometry.Evaluate(geometry.GetDistanceAlongTrack(nextMiddle), out Vector3 nextCenter, out _);
                float segment = Vector3.Distance(center, nextCenter);
                perimeter += segment;
                if (segment < 0.0001f || segment > 1.025f || Vector3.Dot((nextCenter - center).normalized, forward) < 0.995f)
                { errors.Add(filter.name + " co moi noi dut/sai chieu quanh duong."); return; }
                for (int side = 0; side < 4; side++)
                {
                    if (EdgeCount(edges, ring * 4 + side, ring * 4 + (side + 1) % 4) != 2 ||
                        EdgeCount(edges, ring * 4 + side, next * 4 + side) != 2)
                    { errors.Add(filter.name + " khong ghep lien tuc bang dinh chung tai moi noi rao."); return; }
                }
            }
            if (Mathf.Abs(perimeter - geometry.Length) > 0.1f)
                errors.Add(filter.name + " khong phu du mot vong duong dua.");
            float minY = float.PositiveInfinity;
            float maxY = float.NegativeInfinity;
            float minimumOffset = float.PositiveInfinity;
            float maximumOffset = float.NegativeInfinity;
            foreach (Vector3 vertex in vertices)
            {
                if (!Finite(vertex)) { errors.Add(filter.name + " co dinh khong huu han."); return; }
                float distance = geometry.GetDistanceAlongTrack(vertex);
                geometry.Evaluate(distance, out Vector3 center, out Vector3 forward);
                Vector3 right = Vector3.Cross(Vector3.up, forward);
                float offset = Vector3.Dot(vertex - center, right) * (inner ? -1f : 1f);
                minimumOffset = Mathf.Min(minimumOffset, offset);
                maximumOffset = Mathf.Max(maximumOffset, offset);
                minY = Mathf.Min(minY, vertex.y);
                maxY = Mathf.Max(maxY, vertex.y);
            }
            if (minimumOffset < geometry.RoadWidth * 0.5f - PositionTolerance ||
                maximumOffset > geometry.RoadWidth * 0.5f + 0.4f + PositionTolerance ||
                maximumOffset - minimumOffset < 0.35f || minY > geometry.SurfaceHeight + 0.001f ||
                Mathf.Abs(maxY - geometry.SurfaceHeight - 1.2f) > PositionTolerance)
                errors.Add(filter.name + " sai bien/rong/cao: rao rong .4 m, cao 1.2 m va nam ngoai mat duong.");
        }

        private static bool CollectTriangleEdges(Vector3[] vertices, int[] triangles, Dictionary<ulong, int> edges,
            bool requireUpward, List<string> errors, string label)
        {
            if (triangles.Length == 0 || triangles.Length % 3 != 0)
            { errors.Add(label + " thieu tam giac."); return true; }
            for (int i = 0; i < triangles.Length; i += 3)
            {
                int a = triangles[i], b = triangles[i + 1], c = triangles[i + 2];
                if (a < 0 || b < 0 || c < 0 || a >= vertices.Length || b >= vertices.Length || c >= vertices.Length)
                { errors.Add(label + " index mesh sai."); return true; }
                Vector3 normal = Vector3.Cross(vertices[b] - vertices[a], vertices[c] - vertices[a]);
                if (!Finite(normal) || normal.sqrMagnitude < 0.00000001f || (requireUpward && normal.normalized.y < 0.999f))
                { errors.Add(label + " tam giac suy bien/normal khong huong len."); return true; }
                AddEdge(edges, a, b); AddEdge(edges, b, c); AddEdge(edges, c, a);
            }
            return false;
        }

        private static Vector3[] WorldVertices(MeshFilter filter)
        {
            Vector3[] vertices = filter.sharedMesh.vertices;
            for (int i = 0; i < vertices.Length; i++) vertices[i] = filter.transform.TransformPoint(vertices[i]);
            return vertices;
        }

        private static ulong EdgeKey(int a, int b) => ((ulong)(uint)Mathf.Min(a, b) << 32) | (uint)Mathf.Max(a, b);
        private static void AddEdge(Dictionary<ulong, int> edges, int a, int b)
        {
            ulong key = EdgeKey(a, b);
            edges.TryGetValue(key, out int count);
            edges[key] = count + 1;
        }
        private static int EdgeCount(Dictionary<ulong, int> edges, int a, int b) => edges.TryGetValue(EdgeKey(a, b), out int count) ? count : 0;
        private static float ForwardDistance(float from, float to, float length) => Mathf.Repeat(to - from, length);
        private static float CircularDifference(float a, float b, float length)
        {
            float distance = Mathf.Repeat(Mathf.Abs(a - b), length);
            return Mathf.Min(distance, length - distance);
        }
        private static bool Finite(float value) => StadiumGeometry.IsFinite(value);
        private static bool Finite(Vector3 value) => Finite(value.x) && Finite(value.y) && Finite(value.z);
    }
}
