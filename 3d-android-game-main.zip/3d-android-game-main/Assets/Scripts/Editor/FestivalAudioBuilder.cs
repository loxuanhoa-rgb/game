using System;
using System.IO;
using RacingDemo.Runtime.Audio;
using UnityEditor;
using UnityEngine;

namespace RacingDemo.EditorTools
{
    /// <summary>Original synthesized pentatonic plucks and soft wind. No third-party samples.</summary>
    public static class FestivalAudioBuilder
    {
        public const int SampleRate = 22050;
        public const int DurationSeconds = 16;
        public static FestivalAudio Build(Transform parent, EngineAudio engine)
        {
            var root = new GameObject("FestivalAudio");
            root.transform.SetParent(parent, false);
            AudioSource music = MakeSource(root.transform, "Music", EnsureClip("FestivalMusic", true));
            AudioSource ambience = MakeSource(root.transform, "Ambience", EnsureClip("HighlandWind", false));
            FestivalAudio audio = root.AddComponent<FestivalAudio>();
            using (var bind = new FieldBinder(audio))
                bind.SetObject("_music", music).SetObject("_ambience", ambience).SetObject("_engine", engine);
            return audio;
        }
        private static AudioSource MakeSource(Transform parent, string name, AudioClip clip)
        {
            var go = new GameObject(name); go.transform.SetParent(parent, false);
            AudioSource source = go.AddComponent<AudioSource>();
            source.clip = clip; source.loop = true; source.playOnAwake = false; source.spatialBlend = 0f;
            return source;
        }
        private static AudioClip EnsureClip(string name, bool music)
        {
            const string folder = "Assets/Generated/Audio";
            Directory.CreateDirectory(DemoEditorPaths.ToAbsoluteProjectPath(folder));
            string path = folder + "/" + name + ".wav";
            byte[] wanted = BuildWavBytes(music);
            string absolute = DemoEditorPaths.ToAbsoluteProjectPath(path);
            if (!File.Exists(absolute) || !SameBytes(File.ReadAllBytes(absolute), wanted))
            {
                File.WriteAllBytes(absolute, wanted);
                AssetDatabase.ImportAsset(path, ImportAssetOptions.ForceUpdate);
            }
            var importer = (AudioImporter)AssetImporter.GetAtPath(path);
            var settings = importer.defaultSampleSettings;
            bool changed = settings.loadType != AudioClipLoadType.DecompressOnLoad ||
                settings.compressionFormat != AudioCompressionFormat.Vorbis ||
                Math.Abs(settings.quality - 0.7f) > 0.001f || !importer.forceToMono;
            settings.loadType = AudioClipLoadType.DecompressOnLoad;
            settings.compressionFormat = AudioCompressionFormat.Vorbis;
            settings.quality = 0.7f;
            importer.defaultSampleSettings = settings;
            importer.forceToMono = true;
            if (changed) importer.SaveAndReimport();
            return AssetDatabase.LoadAssetAtPath<AudioClip>(path);
        }
        public static float[] BuildSamples(bool music)
        {
            var samples = new float[SampleRate * DurationSeconds];
            double[] melody = { 261.63, 329.63, 392.00, 440.00, 392.00, 329.63, 293.66, 261.63,
                                329.63, 392.00, 523.25, 440.00, 392.00, 329.63, 293.66, 261.63 };
            uint noise = 982451653;
            double wind = 0;
            for (int i = 0; i < samples.Length; i++)
            {
                double t = (double)i / SampleRate;
                if (music)
                {
                    int beat = (int)t;
                    double local = t - beat;
                    double envelope;
                    // Short soft attack, exponential decay, then silence at each beat boundary.
                    envelope = Math.Min(1, local / 0.015) * Math.Exp(-local * 5) * Math.Min(1, (1-local) / 0.06);
                    double phase = 2 * Math.PI * melody[beat % melody.Length] * local;
                    samples[i] = (float)(0.42 * envelope * (Math.Sin(phase) + 0.25 * Math.Sin(phase * 2)));
                }
                else
                {
                    noise = unchecked(noise * 1664525u + 1013904223u);
                    double white = (noise >> 8) / 8388608.0 - 1;
                    wind += (white - wind) * 0.012;
                    double edge = Math.Min(1, Math.Min(t, DurationSeconds - t) / 0.3);
                    samples[i] = (float)(wind * 1.5 * edge * (0.75 + 0.25 * Math.Sin(2*Math.PI*t/8)));
                }
            }
            return samples;
        }
        public static byte[] BuildWavBytes(bool music)
        {
            float[] samples = BuildSamples(music);
            using (var stream = new MemoryStream())
            {
                using (var writer = new BinaryWriter(stream, System.Text.Encoding.UTF8, true))
                {
                    writer.Write(System.Text.Encoding.ASCII.GetBytes("RIFF")); writer.Write(36 + samples.Length * 2);
                    writer.Write(System.Text.Encoding.ASCII.GetBytes("WAVEfmt ")); writer.Write(16);
                    writer.Write((short)1); writer.Write((short)1); writer.Write(SampleRate); writer.Write(SampleRate * 2);
                    writer.Write((short)2); writer.Write((short)16);
                    writer.Write(System.Text.Encoding.ASCII.GetBytes("data")); writer.Write(samples.Length * 2);
                    foreach (float value in samples) writer.Write((short)Mathf.Clamp(Mathf.RoundToInt(value * 32767), -32768, 32767));
                }
                return stream.ToArray();
            }
        }
        private static bool SameBytes(byte[] left, byte[] right)
        {
            if (left.Length != right.Length) return false;
            for (int i = 0; i < left.Length; i++) if (left[i] != right[i]) return false;
            return true;
        }
    }
}
