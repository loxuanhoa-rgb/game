using System.Collections.Generic;
using RacingDemo.Runtime.Track;
using TMPro;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

namespace RacingDemo.EditorTools
{
    /// <summary>Visual-only venue details, combined by local cluster so bounds remain useful for culling/validation.</summary>
    internal static class VenueDetails
    {
        private static Material cream, teal, orange, rubber, skin, leaves, sage, stone, paving;
        private static Mesh cube, octa, cylinder;

        public static void Build(Transform decor, TrackDefinition track)
        {
            cream = FestivalVisuals.Material("VenueCream", new Color(.88f, .83f, .68f));
            teal = FestivalVisuals.Material("VenueTeal", new Color(.055f, .24f, .25f));
            orange = FestivalVisuals.Material("VenueOrange", new Color(.92f, .34f, .08f));
            rubber = FestivalVisuals.Material("VenueRubber", new Color(.045f, .055f, .06f));
            skin = FestivalVisuals.Material("VenueSkin", new Color(.65f, .4f, .23f));
            leaves = FestivalVisuals.Material("VenueLeaves", new Color(.17f, .3f, .14f));
            sage = FestivalVisuals.Material("VenueSage", new Color(.39f, .49f, .24f));
            stone = FestivalVisuals.Material("VenueStone", new Color(.46f, .45f, .36f));
            paving = FestivalVisuals.Material("VenuePaving", new Color(.34f, .36f, .31f));
            cube = PrimitiveMesh(PrimitiveType.Cube);
            cylinder = PrimitiveMesh(PrimitiveType.Cylinder);
            octa = Octahedron();
            var root = new GameObject("VenueDetails").transform;
            root.SetParent(decor, false);
            root.localPosition = Vector3.up * track.SurfaceHeight;
            for (int i = 0; i < 3; i++) Pit(root, i);
            Tower(root);
            Podium(root);
            Crowd(root);
            Landscaping(root, new StadiumGeometry(track));
            Flags(root, new StadiumGeometry(track));
            HighlandPlaces(root, new StadiumGeometry(track));
            Object.DestroyImmediate(octa);
        }

        private static void Pit(Transform root, int index)
        {
            var b = new Cluster(root, "Pit" + index, new Vector3(12f, 0, -24f + index * 9f), -90f);
            b.Box(new Vector3(0, .03f, 0), new Vector3(8.4f, .06f, 10f), paving);
            b.Box(new Vector3(0, 1.55f, 2.8f), new Vector3(7.2f, 3.1f, .25f), cream);
            foreach (int side in new[] { -1, 1 })
                b.Box(new Vector3(side * 3.5f, 1.55f, .8f), new Vector3(.25f, 3.1f, 4f), cream);
            b.Box(new Vector3(0, 3.25f, .8f), new Vector3(7.8f, .3f, 4.8f), teal);
            b.Box(new Vector3(0, 2.85f, -1.35f), new Vector3(7.1f, .65f, .22f), index == 1 ? orange : teal);
            // Open bays: workbench, tool cabinet and three stacks of spare tyres.
            b.Box(new Vector3(-1.3f, .85f, 2f), new Vector3(3f, .16f, .9f), rubber);
            b.Box(new Vector3(2.5f, .65f, 1.7f), new Vector3(.9f, 1.3f, .8f), orange);
            for (int drawer = 0; drawer < 4; drawer++)
                b.Box(new Vector3(2.5f, .3f + drawer * .27f, 1.28f), new Vector3(.6f, .035f, .03f), cream);
            for (int stack = 0; stack < 3; stack++)
                for (int tyre = 0; tyre < 3; tyre++)
                {
                    Vector3 p = new Vector3(-2.7f + stack * .95f, .15f + tyre * .3f, stack == 2 ? -2.8f : .5f);
                    b.Shape(cylinder, p, new Vector3(.78f, .14f, .78f), rubber);
                    b.Shape(cylinder, p + Vector3.up * .145f, new Vector3(.36f, .012f, .36f), stone);
                }
            // Painted service box markings remain entirely in the infield.
            foreach (int side in new[] { -1, 1 })
                b.Box(new Vector3(side * 2.5f, .07f, -3f), new Vector3(.1f, .015f, 3.4f), cream);
            b.Box(new Vector3(0, .07f, -4.7f), new Vector3(5.1f, .015f, .1f), orange);
            Person(b, new Vector3(1.9f, .08f, -2.5f), index, false);
            b.Finish();
            Label(b.Root, index == 0 ? "GARAGE MÂY" : index == 1 ? "AN · THỢ MÁY" : "HẸN VÒNG SAU", new Vector3(0, 2.85f, -1.48f), .4f);
        }

        private static void Tower(Transform root)
        {
            var b = new Cluster(root, "RaceControl", new Vector3(-1, 0, -8), -90f);
            b.Box(new Vector3(0, .1f, 0), new Vector3(6f, .2f, 6f), paving);
            b.Box(new Vector3(0, 2.8f, 0), new Vector3(3.8f, 5.6f, 3.8f), cream);
            b.Box(new Vector3(0, 6.4f, 0), new Vector3(5.2f, 1.8f, 4.8f), teal);
            b.Box(new Vector3(0, 7.45f, 0), new Vector3(5.8f, .3f, 5.3f), orange);
            for (int i = -1; i <= 1; i++)
                b.Box(new Vector3(i * 1.55f, 6.5f, -2.42f), new Vector3(1.35f, 1.05f, .06f), rubber);
            b.Box(new Vector3(0, 8.4f, 0), new Vector3(.09f, 1.6f, .09f), rubber);
            b.Box(new Vector3(.6f, 8.8f, 0), new Vector3(1.2f, .6f, .06f), orange);
            b.Box(new Vector3(0, 4.7f, -1.96f), new Vector3(3.5f, .85f, .1f), teal);
            b.Finish();
            Label(b.Root, "SÂN HỘI", new Vector3(0, 4.7f, -2.03f), .26f);
        }

        private static void Podium(Transform root)
        {
            var b = new Cluster(root, "Podium", new Vector3(0, 0, 25), -90f);
            b.Box(new Vector3(0, .03f, 0), new Vector3(10, .06f, 7), paving);
            b.Box(new Vector3(0, 2f, 2f), new Vector3(9, 4, .15f), teal);
            b.Box(new Vector3(0, 3.8f, 1.9f), new Vector3(9, .15f, .12f), orange);
            for (int i = -1; i <= 1; i++)
            {
                float h = i == 0 ? 1.2f : i == -1 ? .85f : .55f;
                b.Box(new Vector3(i * 2f, h / 2f, -.3f), new Vector3(1.9f, h, 1.8f), i == 0 ? orange : cream);
            }
            // Chequered top corners on the presentation wall.
            for (int side = -1; side <= 1; side += 2)
                for (int row = 0; row < 4; row++)
                    for (int col = 0; col < 3; col++)
                        b.Box(new Vector3(side * (3f + col * .4f), 1.4f + row * .4f, 1.9f), new Vector3(.4f, .4f, .05f), (row + col) % 2 == 0 ? cream : rubber);
            // Original town emblem: a sun behind two hills, merged into the existing podium.
            b.Shape(cylinder, new Vector3(0, 1.7f, 1.83f), new Vector3(1.3f, .025f, 1.3f), orange, Quaternion.Euler(90, 0, 0));
            b.Shape(octa, new Vector3(-.42f, 1.35f, 1.72f), new Vector3(1.9f, .85f, .13f), sage);
            b.Shape(octa, new Vector3(.5f, 1.25f, 1.69f), new Vector3(1.8f, .7f, .13f), cream);
            b.Finish();
            Label(b.Root, "APEX\nMÙA NẮNG", new Vector3(0, 2.8f, 1.8f), .42f);
        }

        private static void Crowd(Transform root)
        {
            for (int stand = 0; stand < 3; stand++)
            {
                var b = new Cluster(root, "StandFans" + stand, new Vector3(0, 0, 8 + stand * 6.5f));
                for (int row = 0; row < 3; row++)
                    for (int col = -2; col <= 2; col++)
                        Person(b, new Vector3(41.2f + row * .65f, .8f + row * .5f, col * .85f), stand + row + col + 4, true);
                b.Finish(false);
            }
        }

        private static void Person(Cluster b, Vector3 p, int variation, bool seated)
        {
            var shirt = variation % 3 == 0 ? orange : variation % 3 == 1 ? teal : cream;
            float legs = seated ? .25f : .6f;
            b.Box(p + Vector3.up * (legs / 2), new Vector3(.28f, legs, .22f), rubber);
            b.Box(p + Vector3.up * (legs + .25f), new Vector3(.4f, .5f, .26f), shirt);
            b.Shape(octa, p + Vector3.up * (legs + .68f), new Vector3(.27f, .33f, .28f), skin);
            // One raised arm among the seated fans provides varied silhouettes.
            if (seated && variation % 3 == 0)
                b.Box(p + new Vector3(0, legs + .52f, .28f), new Vector3(.14f, .55f, .14f), shirt);
        }

        private static void Landscaping(Transform root, StadiumGeometry path)
        {
            for (int i = 0; i < 24; i++)
            {
                float distance = 37f + i * path.Length / 24f;
                path.Evaluate(distance, out Vector3 p, out Vector3 f);
                Vector3 right = Vector3.Cross(Vector3.up, f);
                p.y = 0;
                var b = new Cluster(root, "Garden" + i, p + right * (i % 2 == 0 ? 14f : -13.5f), Quaternion.LookRotation(f).eulerAngles.y);
                b.Shape(octa, new Vector3(0, -.1f, 0), new Vector3(5.5f, .4f, 7), sage);
                for (int j = 0; j < 4; j++)
                {
                    float x = (j % 2 - .5f) * 2.4f, z = (j / 2 - .5f) * 3f;
                    b.Shape(octa, new Vector3(x, .38f, z), new Vector3(1.3f + j * .15f, .8f + j * .12f, 1.4f), j % 2 == 0 ? leaves : sage);
                }
                b.Shape(octa, new Vector3(2f, .36f, .8f), new Vector3(1.4f, 1.05f, 1.3f), stone, Quaternion.Euler(10, i * 31, 18));
                b.Shape(octa, new Vector3(1.6f, .18f, -1f), new Vector3(.9f, .5f, .8f), stone);
                b.Finish(false);
            }
        }

        private static void Flags(Transform root, StadiumGeometry path)
        {
            for (int i = 0; i < 10; i++)
            {
                path.Evaluate(-17f + i * 7f, out Vector3 p, out Vector3 f);
                Vector3 right = Vector3.Cross(Vector3.up, f);
                p.y = 0;
                var b = new Cluster(root, "SponsorFlag" + i, p + right * 8.8f, Quaternion.LookRotation(right).eulerAngles.y);
                b.Box(new Vector3(0, 2.5f, 0), new Vector3(.07f, 5f, .07f), cream);
                b.Box(new Vector3(.5f, 3.7f, 0), new Vector3(1f, 2.5f, .05f), i % 2 == 0 ? orange : teal);
                b.Box(new Vector3(.5f, 2.7f, -.035f), new Vector3(.8f, .08f, .02f), cream);
                b.Finish();
                Label(b.Root, "A\nP\nE\nX", new Vector3(.5f, 3.9f, -.04f), .32f);
            }
        }

        private static void HighlandPlaces(Transform root, StadiumGeometry path)
        {
            // Local clusters keep culling bounds useful and remain well outside the road.
            path.Evaluate(path.Length * .5f, out Vector3 cafePosition, out Vector3 cafeForward);
            Vector3 cafeRight = Vector3.Cross(Vector3.up, cafeForward);
            cafePosition.y = 0;
            var cafe = new Cluster(root, "QuanDocNang", cafePosition + cafeRight * 22f,
                Quaternion.LookRotation(cafeRight).eulerAngles.y);
            cafe.Box(new Vector3(0, .05f, 0), new Vector3(8, .1f, 7), stone);
            cafe.Box(new Vector3(0, 1.6f, 1.6f), new Vector3(6, 3.2f, .2f), cream);
            cafe.Box(new Vector3(0, 3.2f, .5f), new Vector3(7, .3f, 4), orange);
            cafe.Box(new Vector3(0, 2.65f, -1.5f), new Vector3(6.2f, .8f, .15f), teal);
            foreach (int side in new[] { -1, 1 })
            {
                cafe.Box(new Vector3(side * 2.7f, 1.5f, -.9f), new Vector3(.15f, 3, .15f), cream);
                cafe.Shape(cylinder, new Vector3(side * 1.9f, .8f, -2.5f), new Vector3(1.1f, .07f, 1.1f), cream);
                cafe.Box(new Vector3(side * 1.9f, .4f, -2.5f), new Vector3(.15f, .8f, .15f), teal);
                cafe.Box(new Vector3(side * 2.9f, .35f, -2.5f), new Vector3(.65f, .7f, .65f), orange);
            }
            cafe.Finish(false);
            Label(cafe.Root, "QUÁN DỐC NẮNG", new Vector3(0, 2.65f, -1.6f), .34f);

            for (int i = 0; i < 3; i++)
            {
                path.Evaluate(path.Length * .25f + (i - 1) * 11f, out Vector3 p, out Vector3 f);
                Vector3 right = Vector3.Cross(Vector3.up, f);
                p.y = 0;
                var grove = new Cluster(root, "DoiThong" + i, p + right * 28f);
                for (int j = 0; j < 3; j++)
                {
                    Vector3 at = new Vector3((j - 1) * 3.2f, 0, j % 2 * 3f);
                    grove.Box(at + Vector3.up * 1.8f, new Vector3(.28f, 3.6f, .28f), stone);
                    grove.Shape(octa, at + Vector3.up * 3.7f, new Vector3(2.7f, 5.8f, 2.7f), leaves);
                    grove.Shape(octa, at + Vector3.up * 5.1f, new Vector3(1.8f, 4.6f, 1.8f), sage);
                }
                grove.Finish(false);
            }
            path.Evaluate(path.Length * .25f, out Vector3 signPosition, out Vector3 signForward);
            Vector3 signRight = Vector3.Cross(Vector3.up, signForward);
            signPosition.y = 0;
            var sign = new Cluster(root, "DoiThongSign", signPosition + signRight * 15f,
                Quaternion.LookRotation(signRight).eulerAngles.y);
            sign.Box(new Vector3(0, 1.6f, 0), new Vector3(.15f, 3.2f, .15f), stone);
            sign.Box(new Vector3(0, 2.6f, 0), new Vector3(4.2f, .9f, .15f), teal);
            sign.Finish(false);
            Label(sign.Root, "ĐỒI THÔNG", new Vector3(0, 2.6f, -.1f), .32f);
        }

        private static void Label(Transform root, string text, Vector3 p, float size)
        {
            // These signs never change. Bake the generated glyph mesh: TMP's transient mesh
            // is empty when a saved scene is opened for validation without a render frame.
            // Bake on a THROWAWAY object: TMP marks the MeshFilter it adds as HideAndDontSave,
            // so reusing that component leaves a renderer with no mesh in the saved scene.
            var scratch = new GameObject("LabelScratch");
            scratch.transform.SetParent(root, false);
            var label = scratch.AddComponent<TextMeshPro>(); label.font = ApexFontAssets.EnsureFont(); label.text = text; label.fontSize = size * 10;
            label.alignment = TextAlignmentOptions.Center; label.color = new Color(1, .94f, .78f);
            label.rectTransform.sizeDelta = new Vector2(7, 3);
            label.ForceMeshUpdate();
            Mesh mesh = Object.Instantiate(label.mesh);
            mesh.name = "VenueLabel" + root.name;
            Material font = label.fontSharedMaterial;
            Object.DestroyImmediate(scratch);
            if (mesh.vertexCount == 0)
                throw new System.InvalidOperationException("TMP khong sinh duoc mesh cho nhan " + mesh.name);
            string path = "Assets/Generated/Meshes/" + mesh.name + ".asset";
            Mesh existing = AssetDatabase.LoadAssetAtPath<Mesh>(path);
            if (existing == null) { AssetDatabase.CreateAsset(mesh, path); existing = mesh; }
            else { EditorUtility.CopySerialized(mesh, existing); Object.DestroyImmediate(mesh); EditorUtility.SetDirty(existing); }
            var go = new GameObject("Label"); go.transform.SetParent(root, false); go.transform.localPosition = p;
            go.AddComponent<MeshFilter>().sharedMesh = existing;
            var renderer = go.AddComponent<MeshRenderer>();
            renderer.sharedMaterial = font;
            renderer.shadowCastingMode = ShadowCastingMode.Off;
            go.isStatic = true;
        }

        private static Mesh PrimitiveMesh(PrimitiveType type)
        {
            var go = GameObject.CreatePrimitive(type);
            Mesh mesh = go.GetComponent<MeshFilter>().sharedMesh;
            Object.DestroyImmediate(go); return mesh;
        }

        private static Mesh Octahedron()
        {
            var points = new[] { Vector3.up * .5f, Vector3.down * .5f, Vector3.left * .5f, Vector3.forward * .5f, Vector3.right * .5f, Vector3.back * .5f };
            var vertices = new List<Vector3>();
            for (int i = 0; i < 4; i++)
            {
                int a = 2 + i, b = 2 + (i + 1) % 4;
                vertices.AddRange(new[] { points[0], points[a], points[b], points[1], points[b], points[a] });
            }
            var indices = new int[vertices.Count]; for (int i = 0; i < indices.Length; i++) indices[i] = i;
            var mesh = new Mesh { vertices = vertices.ToArray(), triangles = indices };
            mesh.RecalculateNormals(); return mesh;
        }

        private sealed class Cluster
        {
            public readonly Transform Root;
            private readonly List<Material> materials = new List<Material>();
            private readonly List<List<CombineInstance>> parts = new List<List<CombineInstance>>();
            public Cluster(Transform parent, string name, Vector3 p, float yaw = 0)
            {
                Root = new GameObject(name).transform; Root.SetParent(parent, false);
                Root.localPosition = p; Root.localRotation = Quaternion.Euler(0, yaw, 0);
            }
            public void Box(Vector3 p, Vector3 scale, Material material) { Shape(cube, p, scale, material); }
            public void Shape(Mesh mesh, Vector3 p, Vector3 scale, Material material, Quaternion? rotation = null)
            {
                int index = materials.IndexOf(material);
                if (index < 0) { index = materials.Count; materials.Add(material); parts.Add(new List<CombineInstance>()); }
                parts[index].Add(new CombineInstance { mesh = mesh, transform = Matrix4x4.TRS(p, rotation ?? Quaternion.identity, scale) });
            }
            public void Finish(bool shadows = true)
            {
                var merged = new CombineInstance[parts.Count];
                for (int i = 0; i < parts.Count; i++)
                {
                    var mesh = new Mesh(); mesh.CombineMeshes(parts[i].ToArray(), true, true);
                    merged[i] = new CombineInstance { mesh = mesh, transform = Matrix4x4.identity };
                }
                var result = new Mesh { name = "Venue" + Root.name };
                result.CombineMeshes(merged, false, false); result.RecalculateBounds();
                foreach (var part in merged) Object.DestroyImmediate(part.mesh);
                string path = "Assets/Generated/Meshes/" + result.name + ".asset";
                var existing = AssetDatabase.LoadAssetAtPath<Mesh>(path);
                if (existing == null) { AssetDatabase.CreateAsset(result, path); existing = result; }
                else { EditorUtility.CopySerialized(result, existing); Object.DestroyImmediate(result); EditorUtility.SetDirty(existing); }
                Root.gameObject.AddComponent<MeshFilter>().sharedMesh = existing;
                var renderer = Root.gameObject.AddComponent<MeshRenderer>(); renderer.sharedMaterials = materials.ToArray();
                renderer.shadowCastingMode = shadows ? ShadowCastingMode.On : ShadowCastingMode.Off;
                Root.gameObject.isStatic = true;
            }
        }
    }
}
