using System;
using System.Collections.Generic;
using System.Text;
using RacingDemo.Runtime.Audio;
using RacingDemo.Runtime.Bootstrap;
using RacingDemo.Runtime.CameraRig;
using RacingDemo.Runtime.Input;
using RacingDemo.Runtime.Race;
using RacingDemo.Runtime.Track;
using RacingDemo.Runtime.Vehicle;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace RacingDemo.EditorTools
{
    /// <summary>
    /// Kiem tra cac scene DA LUU duoc chon lam dau vao build (khong lay active scene lam dai dien).
    /// Muc Task 4: references, duong kin, checkpoint, pose hoi xe an toan, va toan bo vong choi
    /// (dung mot RaceDirector, du presenter, nut menu noi dung dich).
    /// </summary>
    public static class SceneValidator
    {
        [MenuItem("RacingDemo/Validate Build Scenes", false, 20)]
        public static void ValidateBuildScenesMenu()
        {
            ValidateBuildScenes();
            EditorUtility.DisplayDialog("RacingDemo", "Scene build hop le.", "OK");
        }

        /// <summary>Nem <see cref="InvalidOperationException"/> kem toan bo loi tim duoc.</summary>
        public static void ValidateBuildScenes()
        {
            DemoEditorPaths.EnsureNoUnsavedSceneChanges();
            var errors = new List<string>();
            string[] scenePaths = GetEnabledBuildScenePaths();

            if (scenePaths.Length == 0)
            {
                errors.Add("Build settings chua co scene nao duoc bat. Chay RacingDemo/Rebuild Demo truoc.");
                ThrowIfAny(errors);
                return;
            }

            if (scenePaths.Length != 1 || scenePaths[0] != DemoEditorPaths.RaceScenePath)
            {
                errors.Add("Demo chi duoc co dung mot scene build la " + DemoEditorPaths.RaceScenePath +
                           ", dang co: " + string.Join(", ", scenePaths));
            }

            // Task 6/7: cau hinh URP va buoc vat ly thuoc ve project chu khong thuoc scene.
            RenderQualitySetup.Verify(RenderQualitySetup.MobileAssetPath, errors);
            FixedTimestepSetup.Verify(errors);

            for (int i = 0; i < scenePaths.Length; i++)
            {
                ValidateSceneFile(scenePaths[i], errors);
            }

            ThrowIfAny(errors);

            // In ca khi DAT: chay CLI ma khong co dong nao thi exit code 0 khong phan biet
            // duoc "da kiem va dung" voi "khong kiem gi".
            Debug.Log("[RacingDemo] Scene build hop le: " + string.Join(", ", scenePaths));
        }

        public static string[] GetEnabledBuildScenePaths()
        {
            var paths = new List<string>();
            EditorBuildSettingsScene[] scenes = EditorBuildSettings.scenes;

            for (int i = 0; i < scenes.Length; i++)
            {
                if (scenes[i] != null && scenes[i].enabled && !string.IsNullOrEmpty(scenes[i].path))
                {
                    paths.Add(scenes[i].path);
                }
            }

            return paths.ToArray();
        }

        private static void ValidateSceneFile(string scenePath, List<string> errors)
        {
            string absolutePath = DemoEditorPaths.ToAbsoluteProjectPath(scenePath);
            if (!System.IO.File.Exists(absolutePath))
            {
                errors.Add("Khong tim thay file scene: " + scenePath);
                return;
            }

            // Luon doc ban da luu, ke ca khi Race dang mo. Khong lay scene dirty trong RAM
            // thay cho file ma BuildPlayer se su dung. Preview khong doi scene setup cua nguoi dung.
            Scene scene = EditorSceneManager.OpenPreviewScene(scenePath);

            try
            {
                ValidateSceneContent(scene, errors);
            }
            finally
            {
                EditorSceneManager.ClosePreviewScene(scene);
            }
        }

        public static void ValidateSceneContent(Scene scene, List<string> errors)
        {
            string prefix = scene.path + ": ";

            int generatedRootCount = 0;
            foreach (GameObject root in scene.GetRootGameObjects())
                if (root.name == DemoEditorPaths.GeneratedSceneRootName) generatedRootCount++;
            if (generatedRootCount > 1)
                errors.Add(prefix + "co nhieu hon mot cay " + DemoEditorPaths.GeneratedSceneRootName + ".");
            if (FindRoot(scene, DemoEditorPaths.GeneratedSceneRootName) == null)
            {
                errors.Add(prefix + "thieu cay " + DemoEditorPaths.GeneratedSceneRootName +
                           ". Chay RacingDemo/Rebuild Demo.");
            }

            RequireExactly<Camera>(scene, 1, "Camera", prefix, errors);
            RequireExactly<AudioListener>(scene, 1, "AudioListener", prefix, errors);

            // --- Task 6: am thanh ---
            RequireExactly<EngineAudio>(scene, 1, "EngineAudio", prefix, errors);
            RequireExactly<AudioSource>(scene, 3, "AudioSource", prefix, errors);
            RequireExactly<FestivalAudio>(scene, 1, "FestivalAudio", prefix, errors);
            ValidateEngineAudio(scene, prefix, errors);
            RequireExactly<AppBootstrap>(scene, 1, "AppBootstrap", prefix, errors);

            RequireExactly<Light>(scene, 1, "Light", prefix, errors);

            // --- Task 2: xe, camera bam sau, dieu khien ---
            RequireExactly<CarController>(scene, 1, "CarController", prefix, errors);
            RequireExactly<ChaseCamera>(scene, 1, "ChaseCamera", prefix, errors);
            RequireExactly<CarInputRelay>(scene, 1, "CarInputRelay", prefix, errors);
            RequireExactly<TouchControlPad>(scene, 1, "TouchControlPad", prefix, errors);
            RequireExactly<EventSystem>(scene, 1, "EventSystem", prefix, errors);

            // --- Task 4: vong choi ---
            RequireExactly<RaceDirector>(scene, 1, "RaceDirector", prefix, errors);
            RequireExactly<HudPresenter>(scene, 1, "HudPresenter", prefix, errors);
            RequireExactly<PausePresenter>(scene, 1, "PausePresenter", prefix, errors);
            RequireExactly<ResultsPresenter>(scene, 1, "ResultsPresenter", prefix, errors);
            RequireExactly<FestivalPresenter>(scene, 1, "FestivalPresenter", prefix, errors);

            ValidateSerializedReferences(scene, prefix, errors);
            ValidateRaceLoop(scene, prefix, errors);

            RequireExactly<CheckpointVolume>(scene, 4, "CheckpointVolume", prefix, errors);
            RequireExactly<RespawnService>(scene, 1, "RespawnService", prefix, errors);
            GameObject generatedRoot = FindRoot(scene, DemoEditorPaths.GeneratedSceneRootName);
            if (generatedRoot != null)
            {
                var respawn = generatedRoot.GetComponentInChildren<RespawnService>(true);
                var car = generatedRoot.GetComponentInChildren<CarController>(true);
                if (respawn != null && car != null)
                {
                    TrackSceneValidation.ValidateGeneratedTrack(generatedRoot.transform, respawn.Track, car.Config, errors);
                    ValidateDecor(generatedRoot.transform, respawn.Track, prefix, errors);
                    if (respawn.Track != null)
                    {
                        var director = generatedRoot.GetComponentInChildren<RaceDirector>(true);
                        if (director != null)
                        {
                            var serialized = new SerializedObject(director);
                            SerializedProperty trackReference = serialized.FindProperty("_track");
                            SerializedProperty respawnReference = serialized.FindProperty("_respawn");
                            if (trackReference == null || respawnReference == null ||
                                trackReference.objectReferenceValue != respawn.Track ||
                                respawnReference.objectReferenceValue != respawn)
                            {
                                errors.Add(prefix + "RaceDirector va RespawnService phai dung cung TrackDefinition.");
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Task 6: clip phai co that va phai lap vong, khong duoc tu phat luc Awake
        /// (RaceDirector moi la noi quyet dinh khi nao co tieng).
        /// </summary>
        private static void ValidateEngineAudio(Scene scene, string prefix, List<string> errors)
        {
            EngineAudio engineAudio = FindSingle<EngineAudio>(scene);
            if (engineAudio == null)
            {
                return;
            }

            var source = engineAudio.GetComponent<AudioSource>();
            if (source == null)
            {
                errors.Add(prefix + "EngineAudio thieu AudioSource cung object.");
                return;
            }

            if (source.clip == null)
            {
                errors.Add(prefix + "AudioSource cua EngineAudio chua co clip; chay RacingDemo/Rebuild Demo.");
            }

            if (!source.loop)
            {
                errors.Add(prefix + "Tieng dong co phai bat loop.");
            }

            if (source.playOnAwake)
            {
                errors.Add(prefix + "AudioSource khong duoc playOnAwake; EngineAudio goi Play sau khi co clip.");
            }
        }

        /// <summary>
        /// Task 6: vat trang tri chi duoc la hinh anh. Khong vat nao duoc co collider, va khong
        /// vat nao duoc lan ra mat duong — kiem bang bao hinh that trong scene, khong tin vao
        /// so lieu dat trong generator.
        /// </summary>
        public static void ValidateDecor(Transform generatedRoot, TrackDefinition track, string prefix, List<string> errors)
        {
            Transform decor = generatedRoot.Find("Track/Decor");
            if (decor == null)
            {
                errors.Add(prefix + "thieu cay Track/Decor. Chay RacingDemo/Rebuild Demo.");
                return;
            }

            Collider[] colliders = decor.GetComponentsInChildren<Collider>(true);
            if (colliders.Length != 0)
            {
                errors.Add(prefix + "vat trang tri co " + colliders.Length +
                           " collider; trang tri khong duoc tham gia va cham.");
            }

            // Renderer nao cung phai co MeshFilter mang mesh that, va khong component nao duoc
            // mang co DontSave: TMP gan MeshFilter HideAndDontSave, giu lai no sau khi xoa TMP
            // thi scene da luu chi con MeshRenderer trong — nhan bien mat ma khong ai bao loi.
            // Nhan TMP song (con component TextMeshPro) tu sinh mesh luc chay nen duoc bo qua.
            foreach (MeshRenderer renderer in decor.GetComponentsInChildren<MeshRenderer>(true))
            {
                if (renderer.GetComponent<TMPro.TextMeshPro>() != null) continue;
                string name = DescribePath(renderer.transform, decor);
                var filter = renderer.GetComponent<MeshFilter>();
                if (filter == null || filter.sharedMesh == null)
                {
                    errors.Add(prefix + "vat trang tri " + name +
                               " co MeshRenderer ma khong co MeshFilter/mesh; se khong hien gi trong build.");
                    continue;
                }

                const HideFlags dontSave = HideFlags.DontSaveInEditor | HideFlags.DontSaveInBuild;
                if ((filter.hideFlags & dontSave) != 0 || (renderer.hideFlags & dontSave) != 0)
                {
                    errors.Add(prefix + "vat trang tri " + name +
                               " co MeshFilter/MeshRenderer mang co DontSave; se mat khi luu scene.");
                }
            }

            // Do bao hinh tu mesh + ma tran cua chinh object, khong dung Renderer.bounds:
            // trong preview scene, bao hinh cua renderer co the chua duoc cap nhat va se
            // ra hop rong o goc toa do, khien phep kiem duoi day luon "dat" ma khong kiem gi.
            MeshFilter[] filters = decor.GetComponentsInChildren<MeshFilter>(true);
            if (filters.Length == 0)
            {
                errors.Add(prefix + "Track/Decor khong co vat nao.");
                return;
            }

            var geometry = new StadiumGeometry(track);
            float roadHalfWidth = track.RoadWidth * 0.5f;
            for (int i = 0; i < filters.Length; i++)
            {
                Mesh mesh = filters[i].sharedMesh;
                if (mesh == null)
                {
                    errors.Add(prefix + "vat trang tri " + DescribePath(filters[i].transform, decor) +
                               " khong co mesh.");
                    continue;
                }

                Bounds local = mesh.bounds;
                if (local.size.sqrMagnitude <= 0f)
                {
                    errors.Add(prefix + "vat trang tri " + DescribePath(filters[i].transform, decor) +
                               " co mesh rong; khong kiem duoc no co lan ra duong hay khong.");
                    continue;
                }

                Matrix4x4 toWorld = filters[i].transform.localToWorldMatrix;
                for (int corner = 0; corner < 8; corner++)
                {
                    var offset = new Vector3(
                        (corner & 1) == 0 ? local.min.x : local.max.x,
                        (corner & 2) == 0 ? local.min.y : local.max.y,
                        (corner & 4) == 0 ? local.min.z : local.max.z);
                    Vector3 point = toWorld.MultiplyPoint3x4(offset);
                    point.y = track.SurfaceHeight;
                    if (geometry.DistanceFromCenterline(point) <= roadHalfWidth)
                    {
                        errors.Add(prefix + "vat trang tri " + DescribePath(filters[i].transform, decor) +
                                   " lan ra mat duong.");
                        break;
                    }
                }
            }
        }

        private static string DescribePath(Transform node, Transform stopAt)
        {
            string path = node.name;
            for (Transform current = node.parent; current != null && current != stopAt; current = current.parent)
            {
                path = current.name + "/" + path;
            }

            return path;
        }

        /// <summary>
        /// Task 4: presenter phai dat duoc trang thai UI ban dau, va moi nut menu phai noi
        /// dung dich. Reference trong Inspector dung ma nut khong goi ai la loi im lang nhat.
        /// </summary>
        private static void ValidateRaceLoop(Scene scene, string prefix, List<string> errors)
        {
            RaceDirector director = FindSingle<RaceDirector>(scene);
            PausePresenter pauseMenu = FindSingle<PausePresenter>(scene);
            ResultsPresenter results = FindSingle<ResultsPresenter>(scene);
            HudPresenter hud = FindSingle<HudPresenter>(scene);
            FestivalPresenter festival = FindSingle<FestivalPresenter>(scene);

            RequireAlwaysActive(hud, prefix, errors);
            RequireControlledPanel(pauseMenu, prefix, errors);
            RequireControlledPanel(results, prefix, errors);
            RequireControlledPanel(festival, prefix, errors);

            if (director == null)
            {
                return;
            }

            // Reset/Pause tren HUD di qua CarInputRelay; Resume/Restart goi thang director.
            CarInputRelay input = FindSingle<CarInputRelay>(scene);
            GameObject generatedRoot = FindRoot(scene, DemoEditorPaths.GeneratedSceneRootName);
            if (generatedRoot != null && input != null)
            {
                RequireListener(FindButton(generatedRoot.transform, "HudCanvas/SafeArea/PauseButton", prefix, errors),
                    input, "RequestPause", "PauseButton", prefix, errors);
                RequireListener(FindButton(generatedRoot.transform, "HudCanvas/SafeArea/ResetButton", prefix, errors),
                    input, "RequestReset", "ResetButton", prefix, errors);
            }

            if (pauseMenu != null)
            {
                RequireListener(FindButton(pauseMenu.transform, "Panel/ResumeButton", prefix, errors),
                    director, "Resume", "PauseMenu/ResumeButton", prefix, errors);
                RequireListener(FindButton(pauseMenu.transform, "Panel/RestartButton", prefix, errors),
                    director, "Restart", "PauseMenu/RestartButton", prefix, errors);
                RequireListener(FindButton(pauseMenu.transform, "Panel/FestivalButton", prefix, errors),
                    director, "ReturnToFestival", "PauseMenu/FestivalButton", prefix, errors);
            }

            if (results != null)
            {
                RequireListener(FindButton(results.transform, "Panel/RestartButton", prefix, errors),
                    director, "Restart", "ResultsScreen/RestartButton", prefix, errors);
                RequireListener(FindButton(results.transform, "Panel/FestivalButton", prefix, errors),
                    director, "ReturnToFestival", "ResultsScreen/FestivalButton", prefix, errors);
            }
            if (festival != null)
                RequireListener(FindButton(festival.transform, "Panel/StartButton", prefix, errors),
                    director, "StartRace", "Festival/StartButton", prefix, errors);
        }

        /// <summary>
        /// Panel phai la object KHAC presenter va phai dong san trong scene da luu: presenter
        /// nam tren chinh panel thi Show() khong bao gio chay lai sau lan an dau tien.
        /// </summary>
        private static void RequireControlledPanel(Component presenter, string prefix, List<string> errors)
        {
            if (presenter == null)
            {
                return;
            }

            RequireAlwaysActive(presenter, prefix, errors);

            var serialized = new SerializedObject(presenter);
            SerializedProperty property = serialized.FindProperty("_panel");
            var panel = property != null ? property.objectReferenceValue as GameObject : null;
            if (panel == null)
            {
                return;
            }

            if (panel == presenter.gameObject)
            {
                errors.Add(prefix + presenter.GetType().Name +
                           " nam tren chinh panel; panel bi an mot lan la khong bat lai duoc.");
            }

            if (panel.activeSelf)
            {
                errors.Add(prefix + presenter.GetType().Name +
                           " co panel dang mo trong scene da luu; RaceDirector moi la noi dat trang thai dau.");
            }
        }

        private static void RequireAlwaysActive(Component presenter, string prefix, List<string> errors)
        {
            if (presenter == null)
            {
                return;
            }

            for (Transform current = presenter.transform; current != null; current = current.parent)
            {
                if (!current.gameObject.activeSelf)
                {
                    errors.Add(prefix + presenter.GetType().Name + " nam duoi object dang tat (" +
                               current.name + "); presenter phai luon active.");
                    return;
                }
            }
        }

        private static Button FindButton(Transform owner, string relativePath, string prefix, List<string> errors)
        {
            Transform found = owner.Find(relativePath);
            if (found == null)
            {
                errors.Add(prefix + "khong tim thay nut " + owner.name + "/" + relativePath + ".");
                return null;
            }

            var button = found.GetComponent<Button>();
            if (button == null)
            {
                errors.Add(prefix + owner.name + "/" + relativePath + " khong co Button.");
            }

            return button;
        }

        /// <summary>
        /// Dung mot listener duy nhat toi dung ham. Nhieu hon mot nghia la nut se goi lap;
        /// khong co cai nao nghia la nut chi la hinh trang tri.
        /// </summary>
        private static void RequireListener(
            Button button, UnityEngine.Object target, string methodName, string label, string prefix, List<string> errors)
        {
            if (button == null)
            {
                return;
            }

            int count = button.onClick.GetPersistentEventCount();
            int matches = 0;
            for (int i = 0; i < count; i++)
            {
                if (button.onClick.GetPersistentTarget(i) == target &&
                    button.onClick.GetPersistentMethodName(i) == methodName)
                {
                    matches++;
                }
            }

            if (matches == 0)
            {
                errors.Add(prefix + label + " chua duoc noi toi " + target.GetType().Name + "." + methodName + "().");
                return;
            }

            if (count != 1)
            {
                errors.Add(prefix + label + " co " + count + " listener; chi duoc co dung mot.");
            }
        }

        private static T FindSingle<T>(Scene scene) where T : Component
        {
            GameObject[] roots = scene.GetRootGameObjects();
            for (int i = 0; i < roots.Length; i++)
            {
                T[] found = roots[i].GetComponentsInChildren<T>(true);
                if (found.Length != 0)
                {
                    return found[0];
                }
            }

            return null;
        }

        /// <summary>
        /// Kiem tra cac truong [SerializeField] private bat buoc da duoc gan.
        /// Reference bi thieu la loi hay gap nhat khi dung scene bang code.
        /// </summary>
        private static void ValidateSerializedReferences(Scene scene, string prefix, List<string> errors)
        {
            RequireFields(scene, prefix, errors, typeof(CarController), new[]
            {
                "_config",
                "_frontLeftWheel", "_frontRightWheel", "_rearLeftWheel", "_rearRightWheel",
                "_frontLeftPivot", "_frontRightPivot", "_rearLeftPivot", "_rearRightPivot"
            });

            RequireFields(scene, prefix, errors, typeof(ChaseCamera), new[] { "_target", "_car" });

            RequireFields(scene, prefix, errors, typeof(CarInputRelay), new[] { "_car", "_touchPad" });

            RequireFields(scene, prefix, errors, typeof(TouchControlPad), new[]
            {
                "_steerSlider", "_throttleButton", "_brakeButton"
            });

            RequireFields(scene, prefix, errors, typeof(SteerSlider), new[] { "_knob" });

            RequireFields(scene, prefix, errors, typeof(RaceDirector), new[]
            {
                "_car", "_input", "_chaseCamera", "_track", "_respawn", "_hud", "_pauseMenu", "_results",
                "_engineAudio", "_festival", "_festivalAudio"
            });

            // Cac CanvasGroup an dieu khien lai khi vao le hoi/menu: phai co du va khong phan tu nao null.
            RequireReferenceArray(scene, prefix, errors, typeof(RaceDirector), "_drivingGroups", 6);

            RequireFields(scene, prefix, errors, typeof(EngineAudio), new[] { "_car", "_source" });
            RequireFields(scene, prefix, errors, typeof(FestivalAudio), new[] { "_music", "_ambience", "_engine" });
            RequireFields(scene, prefix, errors, typeof(FestivalPresenter), new[] { "_panel", "_audio", "_recordLabel" });
            RequireReferenceArray(scene, prefix, errors, typeof(FestivalPresenter), "_musicLabels", 1);
            RequireReferenceArray(scene, prefix, errors, typeof(FestivalPresenter), "_effectsLabels", 1);

            RequireFields(scene, prefix, errors, typeof(HudPresenter), new[]
            {
                "_timeLabel", "_lapLabel", "_checkpointLabel", "_speedLabel", "_bannerLabel"
            });

            RequireFields(scene, prefix, errors, typeof(PausePresenter), new[] { "_panel", "_titleLabel" });

            RequireFields(scene, prefix, errors, typeof(ResultsPresenter), new[]
            {
                "_panel", "_timeLabel", "_medalLabel", "_recordLabel", "_saveStateLabel"
            });
            RequireFields(scene, prefix, errors, typeof(RespawnService), new[] { "_track" });
            RequireFields(scene, prefix, errors, typeof(CheckpointVolume), new[] { "_playerBody" });
        }

        private static void RequireFields(
            Scene scene, string prefix, List<string> errors, Type componentType, string[] fieldNames)
        {
            GameObject[] roots = scene.GetRootGameObjects();

            for (int i = 0; i < roots.Length; i++)
            {
                Component[] components = roots[i].GetComponentsInChildren(componentType, true);

                for (int c = 0; c < components.Length; c++)
                {
                    var serialized = new SerializedObject(components[c]);

                    for (int f = 0; f < fieldNames.Length; f++)
                    {
                        SerializedProperty property = serialized.FindProperty(fieldNames[f]);

                        if (property == null)
                        {
                            errors.Add(prefix + componentType.Name + " khong con truong \"" +
                                       fieldNames[f] + "\"; validator va code runtime lech nhau.");
                            continue;
                        }

                        if (property.objectReferenceValue == null)
                        {
                            errors.Add(prefix + componentType.Name + "." + fieldNames[f] + " chua duoc gan.");
                        }
                    }
                }
            }
        }

        /// <summary>Mang reference phai co it nhat minCount phan tu va khong phan tu nao null.</summary>
        private static void RequireReferenceArray(
            Scene scene, string prefix, List<string> errors, Type componentType, string fieldName, int minCount)
        {
            GameObject[] roots = scene.GetRootGameObjects();

            for (int i = 0; i < roots.Length; i++)
            {
                Component[] components = roots[i].GetComponentsInChildren(componentType, true);

                for (int c = 0; c < components.Length; c++)
                {
                    SerializedProperty property = new SerializedObject(components[c]).FindProperty(fieldName);

                    if (property == null || !property.isArray)
                    {
                        errors.Add(prefix + componentType.Name + " khong con mang \"" + fieldName +
                                   "\"; validator va code runtime lech nhau.");
                        continue;
                    }

                    if (property.arraySize < minCount)
                    {
                        errors.Add(prefix + componentType.Name + "." + fieldName + " can it nhat " + minCount +
                                   " phan tu, dang co " + property.arraySize + ".");
                    }

                    for (int e = 0; e < property.arraySize; e++)
                    {
                        if (property.GetArrayElementAtIndex(e).objectReferenceValue == null)
                        {
                            errors.Add(prefix + componentType.Name + "." + fieldName + "[" + e + "] chua duoc gan.");
                        }
                    }
                }
            }
        }

        private static void RequireExactly<T>(Scene scene, int expected, string label, string prefix, List<string> errors)
            where T : Component
        {
            int count = CountComponents<T>(scene);
            if (count != expected)
            {
                errors.Add(prefix + "can dung " + expected + " " + label + ", dang co " + count + ".");
            }
        }

        private static int CountComponents<T>(Scene scene) where T : Component
        {
            int count = 0;
            GameObject[] roots = scene.GetRootGameObjects();

            for (int i = 0; i < roots.Length; i++)
            {
                count += roots[i].GetComponentsInChildren<T>(true).Length;
            }

            return count;
        }

        private static GameObject FindRoot(Scene scene, string name)
        {
            GameObject[] roots = scene.GetRootGameObjects();
            for (int i = 0; i < roots.Length; i++)
            {
                if (roots[i].name == name)
                {
                    return roots[i];
                }
            }

            return null;
        }

        private static void ThrowIfAny(List<string> errors)
        {
            if (errors.Count == 0)
            {
                return;
            }

            var builder = new StringBuilder();
            builder.AppendLine("Scene build khong hop le (" + errors.Count + " loi):");
            for (int i = 0; i < errors.Count; i++)
            {
                builder.AppendLine("  - " + errors[i]);
            }

            throw new InvalidOperationException(builder.ToString());
        }
    }
}
