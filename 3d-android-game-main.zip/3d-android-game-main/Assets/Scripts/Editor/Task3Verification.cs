using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using RacingDemo.Runtime.Track;
using RacingDemo.Runtime.Vehicle;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;

namespace RacingDemo.EditorTools
{
    /// <summary>
    /// Kiem chung rebuild that qua Editor API. Tu khoi phuc tuning va chi xoa sentinel cua lan chay nay.
    /// Chay CLI: -executeMethod RacingDemo.EditorTools.Task3Verification.RunRebuildChecks
    /// </summary>
    public static class Task3Verification
    {
        private const string CarPath = DemoEditorPaths.GeneratedConfig + "/CarConfig.asset";
        private const string TrackPath = DemoEditorPaths.GeneratedConfig + "/TrackDefinition.asset";

        public static void RunRebuildChecks()
        {
            DemoEditorPaths.EnsureNoUnsavedSceneChanges();
            DemoProjectGenerator.RebuildDemo();
            SceneValidator.ValidateBuildScenes();

            var report = new StringBuilder("Task 3 rebuild verification\n");
            string originalCar = EditorJsonUtility.ToJson(Load<CarConfig>(CarPath));
            string originalTrack = EditorJsonUtility.ToJson(Load<TrackDefinition>(TrackPath));
            string carGuid = AssetDatabase.AssetPathToGUID(CarPath);
            string trackGuid = AssetDatabase.AssetPathToGUID(TrackPath);
            string markerName = "__Task3Verification_" + Guid.NewGuid().ToString("N");
            string rootName = FindRoot(SceneManager.GetActiveScene(), "Main Camera") == null
                ? "Main Camera" : "Main Camera " + markerName;
            string sentinelId = null;
            string sentinelChildId = null;
            bool passed = false;

            try
            {
                CarConfig car = Load<CarConfig>(CarPath);
                TrackDefinition track = Load<TrackDefinition>(TrackPath);
                car.MotorTorque += 17f;
                track.GoldSeconds += (track.SilverSeconds - track.GoldSeconds) * 0.125f;
                EditorUtility.SetDirty(car);
                EditorUtility.SetDirty(track);
                AssetDatabase.SaveAssets();
                string tunedCar = EditorJsonUtility.ToJson(car);
                string tunedTrack = EditorJsonUtility.ToJson(track);
                byte[] tunedCarBytes = File.ReadAllBytes(DemoEditorPaths.ToAbsoluteProjectPath(CarPath));
                byte[] tunedTrackBytes = File.ReadAllBytes(DemoEditorPaths.ToAbsoluteProjectPath(TrackPath));

                Scene scene = SceneManager.GetActiveScene();
                var sentinel = new GameObject(rootName);
                SceneManager.MoveGameObjectToScene(sentinel, scene);
                sentinel.transform.SetPositionAndRotation(new Vector3(102f, 4f, -87f), Quaternion.Euler(12f, 34f, 5f));
                sentinel.transform.localScale = new Vector3(1.2f, 0.8f, 1.4f);
                var child = new GameObject(markerName);
                child.transform.SetParent(sentinel.transform, false);
                child.transform.localPosition = new Vector3(2f, 3f, 4f);
                SaveScene(scene);
                sentinelId = GlobalObjectId.GetGlobalObjectIdSlow(sentinel).ToString();
                sentinelChildId = GlobalObjectId.GetGlobalObjectIdSlow(child).ToString();
                string sentinelSnapshot = Snapshot(sentinel);

                DemoProjectGenerator.RebuildDemo();
                SceneValidator.ValidateBuildScenes();
                VerifyTuning(tunedCar, tunedTrack, tunedCarBytes, tunedTrackBytes, carGuid, trackGuid);
                VerifySentinel(rootName, markerName, sentinelId, sentinelChildId, sentinelSnapshot);
                GameObject generated = RequireGeneratedRoot();
                string firstSnapshot = Snapshot(generated);
                string firstCounts = CountSummary(SceneManager.GetActiveScene());

                DemoProjectGenerator.RebuildDemo();
                SceneValidator.ValidateBuildScenes();
                VerifyTuning(tunedCar, tunedTrack, tunedCarBytes, tunedTrackBytes, carGuid, trackGuid);
                VerifySentinel(rootName, markerName, sentinelId, sentinelChildId, sentinelSnapshot);
                Require(Snapshot(RequireGeneratedRoot()) == firstSnapshot,
                    "Generated hierarchy, transforms, components, collider data or mesh geometry changed on repeated rebuild.");
                Require(CountSummary(SceneManager.GetActiveScene()) == firstCounts,
                    "Scene component counts changed on repeated rebuild.");

                report.AppendLine("PASS: two consecutive rebuilds validate and have identical generated hierarchy/geometry.");
                report.AppendLine("PASS: tuned CarConfig and TrackDefinition JSON, asset bytes and GUIDs remain unchanged.");
                report.AppendLine("PASS: external root named '" + rootName + "', child, transforms and saved local IDs survive both rebuilds.");
                report.AppendLine(firstCounts);
                report.AppendLine("Generated semantic SHA256: " + firstSnapshot);
                passed = true;
            }
            finally
            {
                // Reload after every OpenScene: pre-open asset references may have been unloaded.
                RestoreAsset(CarPath, originalCar);
                RestoreAsset(TrackPath, originalTrack);
                AssetDatabase.SaveAssets();
                Scene scene = SceneManager.GetActiveScene();
                GameObject sentinel = FindRoot(scene, rootName);
                if (sentinel != null && sentinel.transform.Find(markerName) != null &&
                    (sentinelId == null || GlobalObjectId.GetGlobalObjectIdSlow(sentinel).ToString() == sentinelId))
                    Object.DestroyImmediate(sentinel);
                SaveScene(scene);
                DemoProjectGenerator.RebuildDemo();
                SceneValidator.ValidateBuildScenes();
                Require(EditorJsonUtility.ToJson(Load<CarConfig>(CarPath)) == originalCar, "Original CarConfig restoration failed.");
                Require(EditorJsonUtility.ToJson(Load<TrackDefinition>(TrackPath)) == originalTrack, "Original TrackDefinition restoration failed.");
                report.AppendLine("Original configurations restored; test-owned external sentinel removed; normal rebuild validates.");
                if (!passed) report.AppendLine("FAILED: read the Unity log for the original assertion.");
                string output = DemoEditorPaths.ToAbsoluteProjectPath("Artifacts/task3-rebuild-verification.txt");
                Directory.CreateDirectory(Path.GetDirectoryName(output));
                File.WriteAllText(output, report.ToString());
            }

            Debug.Log("[RacingDemo] " + report);
        }

        private static void VerifyTuning(string carJson, string trackJson, byte[] carBytes, byte[] trackBytes,
            string carGuid, string trackGuid)
        {
            Require(EditorJsonUtility.ToJson(Load<CarConfig>(CarPath)) == carJson, "Tuned CarConfig was overwritten.");
            Require(EditorJsonUtility.ToJson(Load<TrackDefinition>(TrackPath)) == trackJson, "Tuned TrackDefinition was overwritten.");
            Require(AssetDatabase.AssetPathToGUID(CarPath) == carGuid, "CarConfig GUID changed.");
            Require(AssetDatabase.AssetPathToGUID(TrackPath) == trackGuid, "TrackDefinition GUID changed.");
            Require(SameBytes(carBytes, File.ReadAllBytes(DemoEditorPaths.ToAbsoluteProjectPath(CarPath))), "CarConfig asset bytes changed.");
            Require(SameBytes(trackBytes, File.ReadAllBytes(DemoEditorPaths.ToAbsoluteProjectPath(TrackPath))), "TrackDefinition asset bytes changed.");
        }

        private static void VerifySentinel(string rootName, string markerName, string rootId, string childId, string snapshot)
        {
            GameObject sentinel = FindRoot(SceneManager.GetActiveScene(), rootName);
            Require(sentinel != null, "Generator removed the external sentinel root.");
            Transform child = sentinel.transform.Find(markerName);
            Require(child != null, "Generator removed the external sentinel child.");
            Require(GlobalObjectId.GetGlobalObjectIdSlow(sentinel).ToString() == rootId, "External root saved local ID changed.");
            Require(GlobalObjectId.GetGlobalObjectIdSlow(child.gameObject).ToString() == childId, "External child saved local ID changed.");
            Require(Snapshot(sentinel) == snapshot, "External sentinel hierarchy/pose changed.");
        }

        private static string Snapshot(GameObject root)
        {
            using (var buffer = new MemoryStream())
            using (var writer = new BinaryWriter(buffer))
            {
                foreach (Transform transform in root.GetComponentsInChildren<Transform>(true))
                {
                    writer.Write(RelativePath(transform, root.transform));
                    writer.Write(transform.gameObject.activeSelf);
                    writer.Write(transform.gameObject.layer);
                    writer.Write(transform.gameObject.tag);
                    WriteVector(writer, transform.localPosition);
                    WriteVector(writer, transform.localScale);
                    Quaternion rotation = transform.localRotation;
                    writer.Write(rotation.x); writer.Write(rotation.y); writer.Write(rotation.z); writer.Write(rotation.w);
                    Component[] components = transform.GetComponents<Component>();
                    writer.Write(components.Length);
                    foreach (Component component in components)
                    {
                        Require(component != null, "Missing script in generated hierarchy.");
                        writer.Write(component.GetType().FullName);
                        if (component is Behaviour behaviour) writer.Write(behaviour.enabled);
                        if (component is Collider collider)
                        {
                            writer.Write(collider.enabled);
                            writer.Write(collider.isTrigger);
                            if (collider is BoxCollider box)
                            {
                                WriteVector(writer, box.center);
                                WriteVector(writer, box.size);
                            }
                            if (collider is MeshCollider meshCollider)
                            {
                                writer.Write(meshCollider.convex);
                                WriteMesh(writer, meshCollider.sharedMesh);
                            }
                        }
                        if (component is MeshFilter filter) WriteMesh(writer, filter.sharedMesh);
                    }
                }
                writer.Flush();
                using (SHA256 hash = SHA256.Create())
                    return BitConverter.ToString(hash.ComputeHash(buffer.ToArray())).Replace("-", "");
            }
        }

        private static void WriteMesh(BinaryWriter writer, Mesh mesh)
        {
            writer.Write(mesh != null);
            if (mesh == null) return;
            AssetDatabase.TryGetGUIDAndLocalFileIdentifier(mesh, out string guid, out long localId);
            writer.Write(guid ?? "");
            writer.Write(localId);
            Vector3[] vertices = mesh.vertices;
            int[] triangles = mesh.triangles;
            writer.Write(vertices.Length);
            foreach (Vector3 vertex in vertices) WriteVector(writer, vertex);
            writer.Write(triangles.Length);
            foreach (int index in triangles) writer.Write(index);
        }

        private static string RelativePath(Transform transform, Transform root)
        {
            string path = transform.name;
            while (transform != root)
            {
                transform = transform.parent;
                path = transform.name + "/" + path;
            }
            return path;
        }

        private static void WriteVector(BinaryWriter writer, Vector3 value)
        {
            writer.Write(value.x); writer.Write(value.y); writer.Write(value.z);
        }

        private static string CountSummary(Scene scene)
        {
            return "Camera=" + Count<Camera>(scene) + ", Light=" + Count<Light>(scene) +
                   ", AudioListener=" + Count<AudioListener>(scene) + ", EventSystem=" + Count<EventSystem>(scene) +
                   ", Collider=" + Count<Collider>(scene) + ", CheckpointVolume=" + Count<CheckpointVolume>(scene);
        }

        private static int Count<T>(Scene scene) where T : Component
        {
            int total = 0;
            foreach (GameObject root in scene.GetRootGameObjects()) total += root.GetComponentsInChildren<T>(true).Length;
            return total;
        }

        private static bool SameBytes(byte[] first, byte[] second)
        {
            if (first.Length != second.Length) return false;
            for (int i = 0; i < first.Length; i++) if (first[i] != second[i]) return false;
            return true;
        }

        private static GameObject RequireGeneratedRoot()
        {
            GameObject root = FindRoot(SceneManager.GetActiveScene(), DemoEditorPaths.GeneratedSceneRootName);
            Require(root != null, "Generated scene root is missing.");
            return root;
        }

        private static GameObject FindRoot(Scene scene, string name)
        {
            foreach (GameObject root in scene.GetRootGameObjects()) if (root.name == name) return root;
            return null;
        }

        private static T Load<T>(string path) where T : Object
        {
            T asset = AssetDatabase.LoadAssetAtPath<T>(path);
            if (asset == null) throw new InvalidOperationException("Missing " + typeof(T).Name + " at " + path);
            return asset;
        }

        private static void RestoreAsset(string path, string json)
        {
            Object asset = AssetDatabase.LoadMainAssetAtPath(path);
            Require(asset != null, "Cannot restore missing config " + path);
            EditorJsonUtility.FromJsonOverwrite(json, asset);
            EditorUtility.SetDirty(asset);
        }

        private static void SaveScene(Scene scene)
        {
            EditorSceneManager.MarkSceneDirty(scene);
            Require(EditorSceneManager.SaveScene(scene), "Could not save verification scene.");
        }

        private static void Require(bool condition, string error)
        {
            if (!condition) throw new InvalidOperationException("Task 3 rebuild check: " + error);
        }
    }
}
