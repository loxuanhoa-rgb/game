using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using RacingDemo.Core.Scoring;
using RacingDemo.Runtime.Track;
using UnityEditor;
using UnityEngine;

namespace RacingDemo.EditorTools
{
    /// <summary>
    /// Task 6: chot nguong huy chuong tu thoi gian cua cac luot chay that.
    ///
    /// File dau vao la danh sach so giay, moi dong mot so (do
    /// <c>Tools/mtinject/medal-calibration.ps1</c> sinh ra tu log cua ban Development).
    /// Cong thuc nam trong Core (<see cref="MedalThresholdCalibrator"/>) va co test rieng;
    /// o day chi lo doc file va ghi vao asset.
    ///
    /// TrackDefinition la asset da tune nen generator khong bao gio ghi de. Chi lenh nay moi
    /// duoc doi nguong, va van di qua SerializedObject chu khong sua YAML bang tay.
    /// </summary>
    public static class MedalCalibration
    {
        public const string DefaultLapTimesPath = "Artifacts/task6-calibration/lap-times.txt";
        private const string LapTimesArgument = "-lapTimes";

        /// <summary>Diem vao cho Unity CLI: <c>-executeMethod ... -lapTimes &lt;duong dan&gt;</c>.</summary>
        public static void ApplyFromFile()
        {
            string path = ReadPathArgument();
            MedalThresholds thresholds = Calibrate(path, out int sampleCount);
            Apply(DemoProjectGenerator.TrackConfigPath, thresholds, sampleCount);
        }

        public static MedalThresholds Calibrate(string lapTimesPath, out int sampleCount)
        {
            string absolute = DemoEditorPaths.ToAbsoluteProjectPath(lapTimesPath);
            if (!File.Exists(absolute))
            {
                throw new InvalidOperationException(
                    "Khong tim thay file thoi gian: " + lapTimesPath +
                    ". Chay Tools/mtinject/medal-calibration.ps1 truoc.");
            }

            var seconds = new List<float>();
            foreach (string line in File.ReadAllLines(absolute))
            {
                string trimmed = line.Trim();
                if (trimmed.Length == 0 || trimmed.StartsWith("#", StringComparison.Ordinal))
                {
                    continue;
                }

                if (!float.TryParse(trimmed, NumberStyles.Float, CultureInfo.InvariantCulture, out float value))
                {
                    throw new InvalidOperationException(
                        "Dong khong doc duoc trong " + lapTimesPath + ": \"" + trimmed + "\".");
                }

                seconds.Add(value);
            }

            sampleCount = seconds.Count;
            return MedalThresholdCalibrator.Calibrate(seconds);
        }

        public static void Apply(string trackAssetPath, MedalThresholds thresholds, int sampleCount)
        {
            if (thresholds == null)
            {
                throw new ArgumentNullException(nameof(thresholds));
            }

            var track = AssetDatabase.LoadAssetAtPath<TrackDefinition>(trackAssetPath);
            if (track == null)
            {
                throw new InvalidOperationException("Khong tim thay TrackDefinition tai " + trackAssetPath + ".");
            }

            var serialized = new SerializedObject(track);
            string before = Describe(track);
            SetFloat(serialized, "GoldSeconds", thresholds.GoldSeconds);
            SetFloat(serialized, "SilverSeconds", thresholds.SilverSeconds);
            SetFloat(serialized, "BronzeSeconds", thresholds.BronzeSeconds);
            serialized.ApplyModifiedPropertiesWithoutUndo();
            EditorUtility.SetDirty(track);
            AssetDatabase.SaveAssets();

            Debug.Log("[RacingDemo] Nguong huy chuong tu " + sampleCount + " luot: " +
                      before + " -> " + Describe(track));
        }

        private static string Describe(TrackDefinition track)
        {
            return string.Format(CultureInfo.InvariantCulture, "gold={0:F3} silver={1:F3} bronze={2:F3}",
                track.GoldSeconds, track.SilverSeconds, track.BronzeSeconds);
        }

        private static void SetFloat(SerializedObject serialized, string fieldName, float value)
        {
            SerializedProperty property = serialized.FindProperty(fieldName);
            if (property == null)
            {
                throw new InvalidOperationException("TrackDefinition khong con truong \"" + fieldName + "\".");
            }

            property.floatValue = value;
        }

        private static string ReadPathArgument()
        {
            string[] arguments = Environment.GetCommandLineArgs();
            for (int i = 0; i < arguments.Length - 1; i++)
            {
                if (string.Equals(arguments[i], LapTimesArgument, StringComparison.Ordinal))
                {
                    return arguments[i + 1];
                }
            }

            return DefaultLapTimesPath;
        }
    }
}
