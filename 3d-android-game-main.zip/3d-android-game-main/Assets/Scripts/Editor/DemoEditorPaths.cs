using System;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace RacingDemo.EditorTools
{
    /// <summary>
    /// Duong dan va tien ich dung chung cho cac cong cu Editor cua demo.
    /// </summary>
    public static class DemoEditorPaths
    {
        public const string GeneratedRoot = "Assets/Generated";
        public const string GeneratedMaterials = GeneratedRoot + "/Materials";
        public const string GeneratedConfig = GeneratedRoot + "/Config";
        public const string ScenesRoot = "Assets/Scenes";
        public const string ArtRoot = "Assets/Art";
        public const string ThirdPartyRoot = "Assets/ThirdParty";
        public const string RaceScenePath = ScenesRoot + "/Race.unity";

        /// <summary>Ten object goc chua toan bo noi dung do generator quan ly.</summary>
        public const string GeneratedSceneRootName = "__GeneratedScene";

        public const string DevelopmentApkPath = "Builds/Android/racing-demo-development.apk";
        public const string ReleaseApkPath = "Builds/Android/racing-demo.apk";

        /// <summary>Tao thu muc asset (va cac thu muc cha) neu chua co.</summary>
        public static void EnsureAssetFolder(string folderPath)
        {
            if (string.IsNullOrEmpty(folderPath))
            {
                throw new ArgumentException("folderPath rong.", nameof(folderPath));
            }

            folderPath = folderPath.Replace('\\', '/').TrimEnd('/');

            if (AssetDatabase.IsValidFolder(folderPath))
            {
                return;
            }

            int lastSlash = folderPath.LastIndexOf('/');
            if (lastSlash <= 0)
            {
                throw new ArgumentException("Duong dan phai bat dau bang Assets/: " + folderPath, nameof(folderPath));
            }

            string parent = folderPath.Substring(0, lastSlash);
            string leaf = folderPath.Substring(lastSlash + 1);

            EnsureAssetFolder(parent);
            AssetDatabase.CreateFolder(parent, leaf);
        }

        /// <summary>
        /// Bao ve thay doi chua luu: trong Editor thi hoi nguoi dung, trong batch thi dung han.
        /// Khong bao gio tu y mo scene khac de tranh mat viec dang lam.
        /// </summary>
        public static void EnsureNoUnsavedSceneChanges()
        {
            bool anyDirty = false;
            for (int i = 0; i < SceneManager.sceneCount; i++)
            {
                if (SceneManager.GetSceneAt(i).isDirty)
                {
                    anyDirty = true;
                    break;
                }
            }

            if (!anyDirty)
            {
                return;
            }

            if (Application.isBatchMode)
            {
                throw new InvalidOperationException(
                    "Scene dang co thay doi chua luu. Luu hoac bo thay doi trong Editor roi chay lai lenh CLI.");
            }

            if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo())
            {
                throw new OperationCanceledException("Nguoi dung da huy thao tac vi con thay doi chua luu.");
            }
        }

        /// <summary>Duong dan tuyet doi tu duong dan tuong doi so voi thu muc goc project.</summary>
        public static string ToAbsoluteProjectPath(string relativePath)
        {
            string projectRoot = Directory.GetParent(Application.dataPath).FullName;
            return Path.GetFullPath(Path.Combine(projectRoot, relativePath));
        }
    }
}
