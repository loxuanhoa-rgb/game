using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using TMPro;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.SceneManagement;

namespace RacingDemo.EditorTools
{
    /// <summary>
    /// Ngan sach hinh anh cua scene build (ke hoach muc 8: "khi khong dat, xu ly theo bang chung:
    /// shadow distance, so object/vat lieu..."). Doc scene DA LUU qua preview scene, khong doi gi.
    ///
    /// Dem tu MeshFilter.sharedMesh + MeshRenderer that trong scene, khong tin so lieu dat trong
    /// generator. Nhan TextMeshPro song (mesh sinh luc chay) chi duoc dem so luong, khong dem tam giac.
    ///
    /// CLI: -executeMethod RacingDemo.EditorTools.SceneStats.Report [-statsOut Artifacts/x.txt]
    /// </summary>
    public static class SceneStats
    {
        private const string DefaultOutput = "Artifacts/scene-stats.txt";

        [MenuItem("RacingDemo/Scene Stats", false, 21)]
        public static void ReportMenu()
        {
            Report();
        }

        public static void Report()
        {
            DemoEditorPaths.EnsureNoUnsavedSceneChanges();
            string output = ArgumentAfter("-statsOut") ?? DefaultOutput;
            Scene scene = EditorSceneManager.OpenPreviewScene(DemoEditorPaths.RaceScenePath);
            string text;
            try
            {
                text = Describe(scene);
            }
            finally
            {
                EditorSceneManager.ClosePreviewScene(scene);
            }

            string absolute = DemoEditorPaths.ToAbsoluteProjectPath(output);
            Directory.CreateDirectory(Path.GetDirectoryName(absolute));
            File.WriteAllText(absolute, text);
            Debug.Log("[RacingDemo] Scene stats -> " + output + "\n" + text);
        }

        /// <summary>Bang markdown: tong toan scene, roi tung nhom theo cay object.</summary>
        public static string Describe(Scene scene)
        {
            var groups = new SortedDictionary<string, Bucket>(StringComparer.Ordinal);
            var total = new Bucket();
            var textures = new HashSet<Texture>();
            var shaders = new HashSet<Shader>();
            int liveLabels = 0, skinned = 0, particles = 0, canvases = 0, lights = 0;
            LightShadows lightShadows = LightShadows.None;

            foreach (GameObject root in scene.GetRootGameObjects())
            {
                foreach (MeshRenderer renderer in root.GetComponentsInChildren<MeshRenderer>(true))
                {
                    string group = GroupOf(renderer.transform);
                    if (!groups.TryGetValue(group, out Bucket bucket)) groups[group] = bucket = new Bucket();
                    var filter = renderer.GetComponent<MeshFilter>();
                    Mesh mesh = filter != null ? filter.sharedMesh : null;
                    bool live = renderer.GetComponent<TextMeshPro>() != null;
                    if (live) liveLabels++;
                    bucket.Add(renderer, mesh, live);
                    total.Add(renderer, mesh, live);
                    foreach (Material material in renderer.sharedMaterials)
                    {
                        if (material == null) continue;
                        if (material.shader != null) shaders.Add(material.shader);
                        foreach (string property in material.GetTexturePropertyNames())
                        {
                            Texture texture = material.GetTexture(property);
                            if (texture != null) textures.Add(texture);
                        }
                    }
                }

                skinned += root.GetComponentsInChildren<SkinnedMeshRenderer>(true).Length;
                particles += root.GetComponentsInChildren<ParticleSystem>(true).Length;
                canvases += root.GetComponentsInChildren<Canvas>(true).Length;
                foreach (Light light in root.GetComponentsInChildren<Light>(true))
                {
                    lights++;
                    lightShadows = light.shadows;
                }
            }

            var builder = new StringBuilder();
            builder.AppendLine("Scene: " + scene.path);
            builder.AppendLine();
            builder.AppendLine("| Nhom | Renderer | Tam giac | Dinh | Submesh (draw truoc batching) | Mesh rieng | Material rieng | Do bong | Tam giac do bong | Khong static | Nhan TMP song | Renderer khong mesh |");
            builder.AppendLine("|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|");
            builder.AppendLine(Row("**Toan scene**", total));
            foreach (KeyValuePair<string, Bucket> pair in groups) builder.AppendLine(Row(pair.Key, pair.Value));
            builder.AppendLine();
            builder.AppendLine("Shader rieng: " + shaders.Count + " | Texture rieng: " + textures.Count +
                               " | SkinnedMeshRenderer: " + skinned + " | ParticleSystem: " + particles +
                               " | Canvas: " + canvases + " | Light: " + lights + " (shadows=" + lightShadows + ")" +
                               " | Nhan TMP song (mesh sinh luc chay, khong dem tam giac): " + liveLabels);
            builder.AppendLine(DescribeUrp());
            return builder.ToString();
        }

        private static string Row(string name, Bucket b)
        {
            return string.Format("| {0} | {1} | {2:N0} | {3:N0} | {4} | {5} | {6} | {7} | {8:N0} | {9} | {10} | {11} |",
                name, b.Renderers, b.Triangles, b.Vertices, b.Submeshes, b.Meshes.Count, b.Materials.Count,
                b.ShadowCasters, b.ShadowTriangles, b.NonStatic, b.LiveLabels, b.NoMesh);
        }

        /// <summary>
        /// Nhom = ba tang dau cua duong dan (root/Track/Decor); rieng cay VenueDetails duoi Decor
        /// tach thanh nhom rieng de so "truoc/sau" doc thang tu mot bang.
        /// </summary>
        private static string GroupOf(Transform transform)
        {
            var segments = new List<string>();
            for (Transform t = transform; t != null; t = t.parent) segments.Insert(0, t.name);
            int depth = Math.Min(3, segments.Count);
            if (segments.Count > 3 && segments[3] == "VenueDetails") depth = 4;
            return string.Join("/", segments.GetRange(0, depth));
        }

        private static string DescribeUrp()
        {
            var asset = AssetDatabase.LoadMainAssetAtPath(RenderQualitySetup.MobileAssetPath);
            if (asset == null) return "URP: khong tim thay " + RenderQualitySetup.MobileAssetPath;
            var serialized = new SerializedObject(asset);
            return "URP Mobile: shadowDistance=" + serialized.FindProperty("m_ShadowDistance").floatValue +
                   " cascades=" + serialized.FindProperty("m_ShadowCascadeCount").intValue +
                   " shadowmap=" + serialized.FindProperty("m_MainLightShadowmapResolution").intValue +
                   " msaa=" + serialized.FindProperty("m_MSAA").intValue +
                   " renderScale=" + serialized.FindProperty("m_RenderScale").floatValue +
                   " hdr=" + serialized.FindProperty("m_SupportsHDR").boolValue;
        }

        private static string ArgumentAfter(string flag)
        {
            string[] arguments = Environment.GetCommandLineArgs();
            for (int i = 0; i + 1 < arguments.Length; i++)
                if (arguments[i] == flag) return arguments[i + 1];
            return null;
        }

        private sealed class Bucket
        {
            public int Renderers, Submeshes, ShadowCasters, NonStatic, LiveLabels, NoMesh;
            public long Triangles, Vertices, ShadowTriangles;
            public readonly HashSet<Mesh> Meshes = new HashSet<Mesh>();
            public readonly HashSet<Material> Materials = new HashSet<Material>();

            public void Add(MeshRenderer renderer, Mesh mesh, bool liveLabel)
            {
                Renderers++;
                if (liveLabel) LiveLabels++;
                if (!renderer.gameObject.isStatic) NonStatic++;
                foreach (Material material in renderer.sharedMaterials) if (material != null) Materials.Add(material);
                bool castsShadow = renderer.shadowCastingMode != ShadowCastingMode.Off;
                if (castsShadow) ShadowCasters++;
                if (mesh == null || mesh.vertexCount == 0) { if (!liveLabel) NoMesh++; return; }
                Meshes.Add(mesh);
                Vertices += mesh.vertexCount;
                long triangles = 0;
                int submeshes = Math.Min(mesh.subMeshCount, renderer.sharedMaterials.Length);
                for (int i = 0; i < mesh.subMeshCount; i++) triangles += mesh.GetIndexCount(i) / 3;
                Submeshes += submeshes;
                Triangles += triangles;
                if (castsShadow) ShadowTriangles += triangles;
            }
        }
    }
}
