using System;
using RacingDemo.Runtime.Vehicle;
using UnityEngine;

namespace RacingDemo.EditorTools
{
    /// <summary>
    /// Dung xe: mot Rigidbody, collider than xe don gian, bon WheelCollider dat dung vi tri,
    /// cong them hinh anh.
    ///
    /// Task 6 thay khoi hop prototype bang model Kenney (CC0). Vat ly KHONG doi:
    /// BoxCollider, WheelCollider va CarConfig van y nguyen — model chi la hinh.
    /// Model duoc chuan hoa theo chieu dai co so cua WheelCollider chu khong theo ti le rieng
    /// cua bo Kenney, nen banh hinh nam dung cho banh vat ly.
    /// </summary>
    internal static class CarBuilder
    {
        // Kich thuoc than xe (met).
        private const float BodyLength = 4.0f;
        private const float BodyWidth = 1.7f;
        private const float BodyHeight = 0.7f;

        // Vi tri banh so voi goc xe. Goc xe nam ngang tam truc banh.
        private const float HalfWheelBase = 1.3f;
        private const float HalfTrackWidth = 0.75f;

        // Ten node trong file FBX cua Kenney.
        private const string BodyNode = "body";
        private const string FrontLeftNode = "wheelFrontLeft";
        private const string FrontRightNode = "wheelFrontRight";
        private const string RearLeftNode = "wheelBackLeft";
        private const string RearRightNode = "wheelBackRight";

        public static CarController Build(Transform parent, CarConfig config, PhysicsMaterial bodyPhysics)
        {
            var carObject = new GameObject("Car");
            carObject.transform.SetParent(parent, false);

            var body = carObject.AddComponent<BoxCollider>();
            body.center = new Vector3(0f, 0.45f, 0f);
            body.size = new Vector3(BodyWidth, BodyHeight, BodyLength);
            // Ma sat thap + Minimum: cham rao thi truot doc tuong nhung van bi ham (xem TrackBuilder.BarrierFriction).
            body.sharedMaterial = bodyPhysics;

            var rigidbody = carObject.AddComponent<Rigidbody>();
            rigidbody.mass = config.Mass;
            rigidbody.linearDamping = config.LinearDamping;
            rigidbody.angularDamping = config.AngularDamping;
            rigidbody.centerOfMass = config.CenterOfMass;
            rigidbody.interpolation = RigidbodyInterpolation.Interpolate;
            rigidbody.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;

            var collidersRoot = new GameObject("WheelColliders");
            collidersRoot.transform.SetParent(carObject.transform, false);

            var visualsRoot = new GameObject("WheelVisuals");
            visualsRoot.transform.SetParent(carObject.transform, false);

            WheelCollider frontLeft = CreateWheelCollider(collidersRoot.transform, "FrontLeft", -HalfTrackWidth, HalfWheelBase, config);
            WheelCollider frontRight = CreateWheelCollider(collidersRoot.transform, "FrontRight", HalfTrackWidth, HalfWheelBase, config);
            WheelCollider rearLeft = CreateWheelCollider(collidersRoot.transform, "RearLeft", -HalfTrackWidth, -HalfWheelBase, config);
            WheelCollider rearRight = CreateWheelCollider(collidersRoot.transform, "RearRight", HalfTrackWidth, -HalfWheelBase, config);

            Transform frontLeftPivot = CreateWheelPivot(visualsRoot.transform, "FrontLeftPivot", -HalfTrackWidth, HalfWheelBase);
            Transform frontRightPivot = CreateWheelPivot(visualsRoot.transform, "FrontRightPivot", HalfTrackWidth, HalfWheelBase);
            Transform rearLeftPivot = CreateWheelPivot(visualsRoot.transform, "RearLeftPivot", -HalfTrackWidth, -HalfWheelBase);
            Transform rearRightPivot = CreateWheelPivot(visualsRoot.transform, "RearRightPivot", HalfTrackWidth, -HalfWheelBase);

            AttachKenneyVisual(carObject.transform, config,
                frontLeftPivot, frontRightPivot, rearLeftPivot, rearRightPivot);

            var controller = carObject.AddComponent<CarController>();
            using (var binder = new FieldBinder(controller))
            {
                binder
                    .SetObject("_config", config)
                    .SetObject("_frontLeftWheel", frontLeft)
                    .SetObject("_frontRightWheel", frontRight)
                    .SetObject("_rearLeftWheel", rearLeft)
                    .SetObject("_rearRightWheel", rearRight)
                    .SetObject("_frontLeftPivot", frontLeftPivot)
                    .SetObject("_frontRightPivot", frontRightPivot)
                    .SetObject("_rearLeftPivot", rearLeftPivot)
                    .SetObject("_rearRightPivot", rearRightPivot);
            }

            return controller;
        }

        /// <summary>
        /// Tach model Kenney thanh hai phan: than xe di theo cay "Visual" cua xe, con bon banh
        /// duoc gan vao dung pivot de nhan pose tu WheelCollider (quay va danh lai that).
        ///
        /// Model Kenney quay dau ve -Z, nen ca than lan banh deu xoay 180 do quanh Y.
        /// </summary>
        private static void AttachKenneyVisual(
            Transform carRoot, CarConfig config,
            Transform frontLeftPivot, Transform frontRightPivot, Transform rearLeftPivot, Transform rearRightPivot)
        {
            GameObject model = KenneyKit.Load(KenneyKit.Car);
            var instance = (GameObject)UnityEngine.Object.Instantiate(model);
            try
            {
                Transform modelRoot = instance.transform;
                Transform bodyNode = RequireNode(modelRoot, BodyNode);
                Transform modelFrontLeft = RequireNode(modelRoot, FrontLeftNode);
                Transform modelFrontRight = RequireNode(modelRoot, FrontRightNode);
                Transform modelRearLeft = RequireNode(modelRoot, RearLeftNode);
                Transform modelRearRight = RequireNode(modelRoot, RearRightNode);

                // Goc xe cua ta nam giua truc banh; goc cua model thi khong. Lay tam bon banh
                // cua model lam moc de hai he trung nhau.
                Vector3 modelWheelCenter = (modelFrontLeft.localPosition + modelFrontRight.localPosition +
                                            modelRearLeft.localPosition + modelRearRight.localPosition) * 0.25f;
                float modelWheelBase = Mathf.Abs(modelRearLeft.localPosition.z - modelFrontLeft.localPosition.z);
                if (modelWheelBase <= 0.001f)
                {
                    throw new InvalidOperationException(
                        "Model xe Kenney khong doc duoc chieu dai co so; kiem tra lai file FBX.");
                }

                float bodyScale = 2f * HalfWheelBase / modelWheelBase;
                var flip = Quaternion.Euler(0f, 180f, 0f);

                var visualRoot = new GameObject("Visual");
                visualRoot.transform.SetParent(carRoot, false);
                visualRoot.transform.localRotation = flip;
                visualRoot.transform.localScale = new Vector3(bodyScale, bodyScale, bodyScale);

                bodyNode.SetParent(visualRoot.transform, false);
                bodyNode.localPosition -= modelWheelCenter;

                AttachWheel(modelFrontLeft, frontLeftPivot, config, flip);
                AttachWheel(modelFrontRight, frontRightPivot, config, flip);
                AttachWheel(modelRearLeft, rearLeftPivot, config, flip);
                AttachWheel(modelRearRight, rearRightPivot, config, flip);
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(instance);
            }
        }

        /// <summary>
        /// Gan hinh banh vao pivot: ti le theo dung ban kinh trong CarConfig (khong theo ti le
        /// rieng cua model), roi day mesh ve tam pivot vi goc toa do banh cua Kenney nam o
        /// mep trong.
        /// </summary>
        private static void AttachWheel(Transform wheelNode, Transform pivot, CarConfig config, Quaternion flip)
        {
            wheelNode.SetParent(pivot, false);
            wheelNode.localPosition = Vector3.zero;
            wheelNode.localRotation = flip;
            wheelNode.localScale = Vector3.one;

            Bounds unscaled = KenneyKit.LocalBounds(wheelNode);
            float modelRadius = Mathf.Max(unscaled.extents.y, unscaled.extents.z);
            if (modelRadius <= 0.001f)
            {
                throw new InvalidOperationException("Banh xe trong model Kenney khong co kich thuoc.");
            }

            float wheelScale = config.WheelRadius / modelRadius;
            wheelNode.localScale = new Vector3(wheelScale, wheelScale, wheelScale);

            // Do lai trong he cua pivot sau khi da xoay/thu nho, roi bu lech de tam banh
            // trung tam pivot; neu khong, banh se lech ra ngoai nua be rong cua no.
            Bounds placed = KenneyKit.LocalBounds(pivot);
            wheelNode.localPosition = -placed.center;
        }

        private static Transform RequireNode(Transform modelRoot, string name)
        {
            foreach (Transform child in modelRoot.GetComponentsInChildren<Transform>(true))
            {
                if (child.name == name)
                {
                    return child;
                }
            }

            throw new InvalidOperationException(
                "Model xe Kenney thieu node \"" + name + "\". File FBX da bi thay doi?");
        }

        private static WheelCollider CreateWheelCollider(
            Transform parent, string name, float x, float z, CarConfig config)
        {
            var wheelObject = new GameObject(name);
            wheelObject.transform.SetParent(parent, false);
            wheelObject.transform.localPosition = new Vector3(x, 0f, z);

            var wheel = wheelObject.AddComponent<WheelCollider>();
            wheel.radius = config.WheelRadius;
            wheel.mass = config.WheelMass;
            wheel.suspensionDistance = config.SuspensionDistance;
            wheel.forceAppPointDistance = 0f;

            JointSpring spring = wheel.suspensionSpring;
            spring.spring = config.SuspensionSpring;
            spring.damper = config.SuspensionDamper;
            spring.targetPosition = config.SuspensionTargetPosition;
            wheel.suspensionSpring = spring;

            WheelFrictionCurve forward = wheel.forwardFriction;
            forward.stiffness = config.ForwardFrictionStiffness;
            wheel.forwardFriction = forward;

            WheelFrictionCurve sideways = wheel.sidewaysFriction;
            sideways.stiffness = config.SidewaysFrictionStiffness;
            wheel.sidewaysFriction = sideways;

            return wheel;
        }

        /// <summary>Pivot nhan pose tu WheelCollider; hinh banh la con cua no.</summary>
        private static Transform CreateWheelPivot(Transform parent, string name, float x, float z)
        {
            var pivot = new GameObject(name);
            pivot.transform.SetParent(parent, false);
            pivot.transform.localPosition = new Vector3(x, 0f, z);
            return pivot.transform;
        }
    }
}
