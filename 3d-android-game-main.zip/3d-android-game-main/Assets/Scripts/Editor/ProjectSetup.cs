using TMPro;
using UnityEditor;
using UnityEngine;

namespace RacingDemo.EditorTools
{
    /// <summary>
    /// Cac buoc chuan bi project chi phai chay mot lan, goi duoc tu menu hoac CLI
    /// de khong phai bam tay trong Editor.
    /// </summary>
    public static class ProjectSetup
    {
        /// <summary>
        /// Import TMP Essential Resources (font mac dinh + shader). Khong co no thi moi
        /// TextMeshProUGUI tao bang code deu khong co font.
        ///
        /// LUU Y: import package la thao tac bat dong bo va keo theo domain reload, nen
        /// phien Unity dang chay CHUA chac thay ngay ket qua. Cach dung dung tu CLI la chay
        /// lenh nay mot lan (Unity se giai nen file ra Assets/TextMesh Pro), roi chay tiep
        /// mot phien Unity KHAC de xac nhan. Khong dung vong cho EditorApplication.update:
        /// domain reload sau import se huy dang ky delegate va batch Unity treo vinh vien.
        /// </summary>
        [MenuItem("RacingDemo/Import TMP Essentials", false, 60)]
        public static void ImportTextMeshProEssentials()
        {
            if (HasTextMeshProEssentials())
            {
                Debug.Log("[RacingDemo] TMP Essentials da co san (font mac dinh: " +
                          TMP_Settings.defaultFontAsset.name + ").");
                return;
            }

            Debug.Log("[RacingDemo] Bat dau import TMP Essential Resources...");
            TMP_PackageResourceImporter.ImportResources(true, false, false);
            Debug.Log("[RacingDemo] Da goi import. Chay lai lenh nay o phien Unity moi de xac nhan.");
        }

        /// <summary>
        /// Kiem tra dieu kien du de tao TextMeshProUGUI bang code. Nem loi (exit code khac 0
        /// khi chay CLI) neu chua du, de khong build tiep voi UI khong co chu.
        /// </summary>
        [MenuItem("RacingDemo/Verify TMP Essentials", false, 61)]
        public static void VerifyTextMeshProEssentials()
        {
            if (!HasTextMeshProEssentials())
            {
                throw new System.InvalidOperationException(
                    "Thieu TMP Essential Resources. Chay RacingDemo/Import TMP Essentials roi mo lai Unity.");
            }

            Debug.Log("[RacingDemo] TMP Essentials OK: " + TMP_Settings.defaultFontAsset.name);
        }

        private static bool HasTextMeshProEssentials()
        {
            // TMP_Settings phai ton tai VA co font mac dinh thi text moi hien duoc.
            if (AssetDatabase.FindAssets("t:TMP_Settings").Length == 0)
            {
                return false;
            }

            return TMP_Settings.defaultFontAsset != null;
        }
    }
}
