using System;
using System.Collections.Generic;
using UnityEditor;
using RacingDemo.Runtime.Input;
using RacingDemo.Runtime.Race;
using TMPro;
using UnityEditor.Events;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem.UI;
using UnityEngine.UI;

namespace RacingDemo.EditorTools
{
    /// <summary>
    /// Dung canvas dieu khien cam ung: thanh lai analog ben trai, ga/phanh ben phai,
    /// nut reset va pause, HUD trong luc dua, panel tam dung va man ket qua.
    ///
    /// Quy tac: nhan chu khong nhan raycast, nhan nam trong nut, rect cac nut khong chong lan,
    /// va toan bo nam trong safe area.
    ///
    /// Thu tu tao quyet dinh thu tu ve: HUD truoc, roi menu tam dung, roi ket qua, roi thiep le hoi tren cung.
    /// Moi presenter nam tren mot object LUON ACTIVE; panel la object con do presenter bat/tat,
    /// nen Show() van chay duoc sau khi panel da bi an.
    /// </summary>
    internal static class UiBuilder
    {
        private const float ReferenceWidth = 1920f;
        private const float ReferenceHeight = 1080f;

        private static readonly Vector2 DriveButtonSize = new Vector2(200f, 200f);
        private static readonly Vector2 SmallButtonSize = new Vector2(200f, 110f);
        private static readonly Vector2 MenuButtonSize = new Vector2(380f, 130f);

        // Thanh lai trai dung tu mep ngoai nut "<" cu (x = 100) den mep ngoai nut ">" cu (x = 530):
        // tam 315, rong 430. Tam hai nut cu (200 va 430) cach tam 115 = vi tri lai het co, nen cho
        // quen tay va script lai tu dong tren emulator (nhan dung tam nut cu) van cho steer +-1.
        private static readonly Vector2 SteerSliderSize = new Vector2(430f, 200f);
        private static readonly Vector2 SteerSliderPosition = new Vector2(315f, 190f);
        private const float SteerFullDistance = 115f;
        private const float SteerDeadZone = 10f;
        private static readonly Vector2 SteerKnobSize = new Vector2(72f, 110f);

        private static readonly Color SteerColor = new Color(0.035f, 0.13f, 0.16f, 0.86f);
        private static readonly Color ThrottleColor = new Color(0.86f, 0.34f, 0.12f, 0.92f);
        private static readonly Color BrakeColor = new Color(0.22f, 0.29f, 0.3f, 0.86f);
        private static readonly Color NeutralColor = new Color(0.035f, 0.105f, 0.13f, 0.86f);

        internal sealed class Result
        {
            public TouchControlPad TouchPad;
            public Button PauseButton;
            public Button ResetButton;

            public HudPresenter Hud;

            public PausePresenter PauseMenu;
            public Button ResumeButton;
            public Button PauseRestartButton;

            public ResultsPresenter Results;
            public Button ResultsRestartButton;
            public Button PauseFestivalButton, ResultsFestivalButton, StartButton;
            public FestivalPresenter Festival;
            public CanvasGroup[] DrivingGroups;
            public readonly List<Button> MusicButtons = new List<Button>();
            public readonly List<Button> EffectsButtons = new List<Button>();
            public readonly List<TMP_Text> MusicLabels = new List<TMP_Text>();
            public readonly List<TMP_Text> EffectsLabels = new List<TMP_Text>();
        }

        public static Result Build(Transform parent, CarInputRelay inputRelay)
        {
            EnsureEventSystem(parent);

            GameObject canvasObject = CreateCanvas(parent);
            RectTransform safeArea = CreateSafeArea(canvasObject.transform);

            SteerSlider steer = CreateSteerSlider(safeArea, "SteerSlider", new Vector2(0f, 0f), SteerSliderPosition);

            HoldButton brake = CreateHoldButton(
                safeArea, "BrakeButton", new Vector2(1f, 0f), new Vector2(-430f, 190f),
                DriveButtonSize, "PHANH", BrakeColor);

            HoldButton throttle = CreateHoldButton(
                safeArea, "ThrottleButton", new Vector2(1f, 0f), new Vector2(-200f, 190f),
                DriveButtonSize, "GA", ThrottleColor);

            Button resetButton = CreateClickButton(
                safeArea, "ResetButton", new Vector2(1f, 0f), new Vector2(-200f, 420f),
                SmallButtonSize, "GỠ KẸT", NeutralColor);

            Button pauseButton = CreateClickButton(
                safeArea, "PauseButton", new Vector2(1f, 1f), new Vector2(-130f, -90f),
                SmallButtonSize, "II", NeutralColor);

            var touchPad = canvasObject.AddComponent<TouchControlPad>();
            using (var binder = new FieldBinder(touchPad))
            {
                binder
                    .SetObject("_steerSlider", steer)
                    .SetObject("_throttleButton", throttle)
                    .SetObject("_brakeButton", brake);
            }

            var result = new Result
            {
                TouchPad = touchPad,
                PauseButton = pauseButton,
                ResetButton = resetButton
            };

            BuildHud(safeArea, result);
            BuildPauseMenu(safeArea, result);
            BuildResultsScreen(safeArea, result);
            BuildFestivalScreen(safeArea, result);
            result.DrivingGroups = new[] { steer.gameObject.AddComponent<CanvasGroup>(), brake.gameObject.AddComponent<CanvasGroup>(), throttle.gameObject.AddComponent<CanvasGroup>(), resetButton.gameObject.AddComponent<CanvasGroup>(), pauseButton.gameObject.AddComponent<CanvasGroup>(), result.Hud.gameObject.AddComponent<CanvasGroup>() };

            UnityEventTools.AddVoidPersistentListener(
                pauseButton.onClick, inputRelay.RequestPause);
            UnityEventTools.AddVoidPersistentListener(
                resetButton.onClick, inputRelay.RequestReset);

            return result;
        }

        /// <summary>
        /// HUD trong luc dua: thoi gian, vong, checkpoint ke tiep, toc do va dong bao lon
        /// cho countdown / khoa reset. Tat ca deu doc tu Core, khong giu dong ho rieng.
        /// </summary>
        private static void BuildHud(RectTransform safeArea, Result result)
        {
            // HUD khong ke chuyen khi lai: thuong hieu da co o thiep le hoi va man ket qua,
            // nen ClockCard chi con dong ho, khong co dong brand phia tren.
            RectTransform hudRoot = CreateGroup(safeArea, "Hud");
            HudCard(hudRoot, "LapCard", new Vector2(0f, 1f), new Vector2(260f, -110f), new Vector2(455f, 180f));
            HudCard(hudRoot, "ClockCard", new Vector2(0.5f, 1f), new Vector2(0f, -76f), new Vector2(470f, 120f));
            HudCard(hudRoot, "SpeedCard", new Vector2(0.5f, 0f), new Vector2(0f, 90f), new Vector2(330f, 100f));

            TextMeshProUGUI time = CreateLabel(
                hudRoot, "TimeLabel", new Vector2(0.5f, 1f), new Vector2(0f, -76f),
                new Vector2(700f, 110f), "00:00.000", 62f, TextAlignmentOptions.Center);

            TextMeshProUGUI lap = CreateLabel(
                hudRoot, "LapLabel", new Vector2(0f, 1f), new Vector2(260f, -70f),
                new Vector2(420f, 70f), "VÒNG 1/2", 44f, TextAlignmentOptions.Left);

            TextMeshProUGUI checkpoint = CreateLabel(
                hudRoot, "CheckpointLabel", new Vector2(0f, 1f), new Vector2(260f, -140f),
                new Vector2(420f, 60f), "CỔNG 1/4", 32f, TextAlignmentOptions.Left);

            TextMeshProUGUI speed = CreateLabel(
                hudRoot, "SpeedLabel", new Vector2(0.5f, 0f), new Vector2(0f, 90f),
                new Vector2(500f, 80f), "0 KM/H", 48f, TextAlignmentOptions.Center);

            TextMeshProUGUI banner = CreateLabel(
                hudRoot, "BannerLabel", new Vector2(0.5f, 0.5f), new Vector2(0f, 40f),
                new Vector2(1200f, 220f), string.Empty, 120f, TextAlignmentOptions.Center);

            time.fontStyle = FontStyles.Bold;
            speed.fontStyle = FontStyles.Bold;
            checkpoint.color = new Color(.62f, .78f, .79f);
            banner.fontStyle = FontStyles.Bold;
            var hud = hudRoot.gameObject.AddComponent<HudPresenter>();
            using (var binder = new FieldBinder(hud))
            {
                binder
                    .SetObject("_timeLabel", time)
                    .SetObject("_lapLabel", lap)
                    .SetObject("_checkpointLabel", checkpoint)
                    .SetObject("_speedLabel", speed)
                    .SetObject("_bannerLabel", banner);
            }

            result.Hud = hud;
        }

        private static void BuildPauseMenu(RectTransform safeArea, Result result)
        {
            RectTransform menuRoot = CreateGroup(safeArea, "PauseMenu");
            RectTransform panel = CreatePanel(menuRoot, "Panel");
            MenuCard(panel, new Vector2(1360f, 800f));
            Eyebrow(panel, "ĐỒI MÂY   /   NGHỈ CHÂN", 300f);
            // Rong 600 de rect Hint (x +-300) khong giao voi nut am thanh ben trai (x -620..-300).
            CreateLabel(panel, "Hint", new Vector2(.5f, .5f), new Vector2(0f, 105f),
                new Vector2(600f, 44f), "Đường đua vẫn đang chờ bạn.", 27f, TextAlignmentOptions.Center);
            Eyebrow(panel, "KÉO ĐỂ LÁI    /    GIỮ GA ĐỂ TĂNG TỐC", -280f);

            TextMeshProUGUI title = CreateLabel(
                panel, "Title", new Vector2(0.5f, 0.5f), new Vector2(0f, 190f),
                new Vector2(900f, 160f), "TẠM DỪNG", 80f, TextAlignmentOptions.Center);

            Button resume = CreateClickButton(
                panel, "ResumeButton", new Vector2(0.5f, 0.5f), new Vector2(0f, 0f),
                MenuButtonSize, "CHƠI TIẾP  >", ThrottleColor);

            Button restart = CreateClickButton(
                panel, "RestartButton", new Vector2(0.5f, 0.5f), new Vector2(0f, -160f),
                MenuButtonSize, "ĐUA LẠI", NeutralColor);

            result.PauseFestivalButton = CreateClickButton(panel, "FestivalButton", new Vector2(.5f, .5f), new Vector2(460f, -80f), new Vector2(320f, 110f), "VỀ LỄ HỘI", NeutralColor);
            BuildAudioOptions(panel, result, -460f, 0f);
            var presenter = menuRoot.gameObject.AddComponent<PausePresenter>();
            using (var binder = new FieldBinder(presenter))
            {
                binder
                    .SetObject("_panel", panel.gameObject)
                    .SetObject("_titleLabel", title);
            }

            // Director dat trang thai dau khi chay; trong scene da luu thi panel dong san
            // de khong nhay mot khung hinh luc vua load.
            panel.gameObject.SetActive(false);

            result.PauseMenu = presenter;
            result.ResumeButton = resume;
            result.PauseRestartButton = restart;
        }

        /// <summary>Man ket qua: thoi gian, huy chuong, ky luc, trang thai luu va nut choi lai.</summary>
        private static void BuildResultsScreen(RectTransform safeArea, Result result)
        {
            RectTransform screenRoot = CreateGroup(safeArea, "ResultsScreen");
            RectTransform panel = CreatePanel(screenRoot, "Panel");
            MenuCard(panel, new Vector2(1160f, 900f));
            Eyebrow(panel, "A P E X   /   MÙA NẮNG", 370f);

            CreateLabel(panel, "Title", new Vector2(0.5f, 0.5f), new Vector2(0f, 300f),
                new Vector2(900f, 120f), "TRỌN HAI VÒNG", 38f, TextAlignmentOptions.Center);

            TextMeshProUGUI time = CreateLabel(
                panel, "TimeLabel", new Vector2(0.5f, 0.5f), new Vector2(0f, 185f),
                new Vector2(900f, 130f), "00:00.000", 96f, TextAlignmentOptions.Center);

            TextMeshProUGUI medal = CreateLabel(
                panel, "MedalLabel", new Vector2(0.5f, 0.5f), new Vector2(0f, 75f),
                new Vector2(900f, 90f), "CHƯA ĐẠT HUY CHƯƠNG", 44f, TextAlignmentOptions.Center);

            TextMeshProUGUI record = CreateLabel(
                panel, "RecordLabel", new Vector2(0.5f, 0.5f), new Vector2(0f, 5f),
                new Vector2(900f, 60f), RaceHudFormatter.NoRecordText, 44f, TextAlignmentOptions.Center);

            TextMeshProUGUI saveState = CreateLabel(
                panel, "SaveStateLabel", new Vector2(0.5f, 0.5f), new Vector2(0f, -55f),
                new Vector2(900f, 50f), string.Empty, 36f, TextAlignmentOptions.Center);

            Button restart = CreateClickButton(
                panel, "RestartButton", new Vector2(0.5f, 0.5f), new Vector2(0f, -200f),
                MenuButtonSize, "ĐUA LẠI  >", ThrottleColor);

            result.ResultsFestivalButton = CreateClickButton(panel, "FestivalButton", new Vector2(.5f, .5f), new Vector2(0f, -350f), new Vector2(380f, 100f), "VỀ LỄ HỘI", NeutralColor);
            var message = CreateLabel(panel, "AnMessage", new Vector2(.5f, .5f), new Vector2(0f, -105f), new Vector2(1060f, 36f), string.Empty, 24f, TextAlignmentOptions.Center);
            var presenter = screenRoot.gameObject.AddComponent<ResultsPresenter>();
            using (var binder = new FieldBinder(presenter))
            {
                binder
                    .SetObject("_panel", panel.gameObject)
                    .SetObject("_timeLabel", time)
                    .SetObject("_medalLabel", medal)
                    .SetObject("_recordLabel", record)
                    .SetObject("_saveStateLabel", saveState).SetObject("_messageLabel", message);
            }

            panel.gameObject.SetActive(false);

            result.Results = presenter;
            result.ResultsRestartButton = restart;
        }

        /// <summary>
        /// Thiep le hoi (trang thai Idle): thuong hieu, bon khu vuc, loi An, ky luc, nut VAO DUA
        /// va widget am thanh. Nen panel mo hon cac menu khac de thay canh nang chieu phia sau.
        ///
        /// Toa do trong card 1320x800 (y duong len tren), da kiem khong chong nhau:
        ///   Eyebrow      y=330   720x36    -> y 312..348
        ///   Title        y=250   1000x120  -> y 190..310
        ///   Places       y=168   1100x40   -> y 148..188
        ///   AnMessage    y=80    1100x90   -> y  35..125
        ///   RecordLabel  y=-10   900x60    -> y -40..20
        ///   StartButton  (300,-140) 440x140 -> x 80..520,   y -210..-70
        ///   MusicButton  (-400,-85) 320x90  -> x -560..-240, y -130..-40
        ///   EffectsButton(-400,-195) 320x90 -> x -560..-240, y -240..-150
        ///   Eyebrow      y=-330  720x36    -> y -348..-312
        /// </summary>
        private static void BuildFestivalScreen(RectTransform safeArea, Result result)
        {
            RectTransform screenRoot = CreateGroup(safeArea, "Festival");
            RectTransform panel = CreatePanel(screenRoot, "Panel");
            panel.GetComponent<Image>().color = new Color(0.025f, 0.075f, 0.095f, 0.55f);
            MenuCard(panel, new Vector2(1320f, 800f));
            Eyebrow(panel, "ĐỒI MÂY   /   LỄ HỘI MÙA NẮNG", 330f);

            TextMeshProUGUI title = CreateLabel(
                panel, "Title", new Vector2(0.5f, 0.5f), new Vector2(0f, 250f),
                new Vector2(1000f, 120f), "APEX — MÙA NẮNG", 72f, TextAlignmentOptions.Center);
            title.fontStyle = FontStyles.Bold;
            title.color = new Color(1f, 0.76f, 0.43f);

            TextMeshProUGUI places = CreateLabel(
                panel, "Places", new Vector2(0.5f, 0.5f), new Vector2(0f, 168f),
                new Vector2(1100f, 40f), "SÂN HỘI · GARAGE MÂY · ĐỒI THÔNG · QUÁN DỐC NẮNG", 24f,
                TextAlignmentOptions.Center);
            places.color = new Color(.62f, .78f, .79f);

            // Loi An do FestivalPresenter.Show() dat theo co/khong ky luc; cho phep xuong dong.
            TextMeshProUGUI message = CreateLabel(
                panel, "AnMessage", new Vector2(0.5f, 0.5f), new Vector2(0f, 80f),
                new Vector2(1100f, 90f), string.Empty, 28f, TextAlignmentOptions.Center);
            message.textWrappingMode = TextWrappingModes.Normal;

            TextMeshProUGUI record = CreateLabel(
                panel, "RecordLabel", new Vector2(0.5f, 0.5f), new Vector2(0f, -10f),
                new Vector2(900f, 60f), RaceHudFormatter.NoRecordText, 40f, TextAlignmentOptions.Center);
            record.fontStyle = FontStyles.Bold;

            // Validator tim "Panel/StartButton": ten va vi tri trong hierarchy la hop dong.
            result.StartButton = CreateClickButton(
                panel, "StartButton", new Vector2(0.5f, 0.5f), new Vector2(300f, -140f),
                new Vector2(440f, 140f), "VÀO ĐUA  >", ThrottleColor);

            BuildAudioOptions(panel, result, -400f, -140f);
            Eyebrow(panel, "KÉO ĐỂ LÁI    /    GIỮ GA ĐỂ TĂNG TỐC", -330f);

            // Bind SAU BuildAudioOptions cua thiep de danh sach nhan gom ca Pause (dung truoc)
            // lan Festival; _audio do DemoProjectGenerator gan.
            var presenter = screenRoot.gameObject.AddComponent<FestivalPresenter>();
            using (var binder = new FieldBinder(presenter))
            {
                binder
                    .SetObject("_panel", panel.gameObject)
                    .SetObject("_recordLabel", record)
                    .SetObject("_messageLabel", message)
                    .SetObjects("_musicLabels", result.MusicLabels)
                    .SetObjects("_effectsLabels", result.EffectsLabels);
            }

            // RaceDirector.Start -> ReturnToFestival mo lai; trong scene da luu panel dong san.
            panel.gameObject.SetActive(false);

            result.Festival = presenter;
        }

        /// <summary>
        /// Hai nut bat/tat nhac va am thanh xep doc quanh (x, y): Music o tren, Effects o duoi.
        /// Caption duoc FestivalPresenter doi chu theo trang thai, nen gom vao Result de bind chung.
        /// </summary>
        private static void BuildAudioOptions(RectTransform panel, Result result, float x, float y)
        {
            var size = new Vector2(320f, 90f);

            Button music = CreateClickButton(
                panel, "MusicButton", new Vector2(0.5f, 0.5f), new Vector2(x, y + 55f),
                size, "NHẠC: BẬT", NeutralColor);
            TextMeshProUGUI musicCaption = music.GetComponentInChildren<TextMeshProUGUI>();
            musicCaption.fontSizeMax = 30f;
            result.MusicButtons.Add(music);
            result.MusicLabels.Add(musicCaption);

            Button effects = CreateClickButton(
                panel, "EffectsButton", new Vector2(0.5f, 0.5f), new Vector2(x, y - 55f),
                size, "ÂM THANH: BẬT", NeutralColor);
            TextMeshProUGUI effectsCaption = effects.GetComponentInChildren<TextMeshProUGUI>();
            effectsCaption.fontSizeMax = 30f;
            result.EffectsButtons.Add(effects);
            result.EffectsLabels.Add(effectsCaption);
        }

        private static void EnsureEventSystem(Transform parent)
        {
            var eventSystemObject = new GameObject("EventSystem");
            eventSystemObject.transform.SetParent(parent, false);
            eventSystemObject.AddComponent<EventSystem>();
            eventSystemObject.AddComponent<InputSystemUIInputModule>();
        }

        private static GameObject CreateCanvas(Transform parent)
        {
            var canvasObject = new GameObject("HudCanvas");
            canvasObject.transform.SetParent(parent, false);

            var canvas = canvasObject.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;

            var scaler = canvasObject.AddComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(ReferenceWidth, ReferenceHeight);
            scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            scaler.matchWidthOrHeight = 0.5f;

            canvasObject.AddComponent<GraphicRaycaster>();
            return canvasObject;
        }

        private static RectTransform CreateSafeArea(Transform parent)
        {
            var safeAreaObject = new GameObject("SafeArea", typeof(RectTransform));
            safeAreaObject.transform.SetParent(parent, false);

            var rect = (RectTransform)safeAreaObject.transform;
            rect.anchorMin = Vector2.zero;
            rect.anchorMax = Vector2.one;
            rect.offsetMin = Vector2.zero;
            rect.offsetMax = Vector2.zero;

            // Dung component SafeArea san co cua uGUI (co DrivenRectTransformTracker
            // va xu ly doi huong man hinh), khong tu viet lai.
            safeAreaObject.AddComponent<UnityEngine.UI.SafeArea>();
            return rect;
        }

        /// <summary>
        /// Object trong suot phu toan man, LUON ACTIVE. Khong co Image nen khong chan raycast;
        /// presenter dat o day de con bat lai duoc panel da an.
        /// </summary>
        private static RectTransform CreateGroup(RectTransform parent, string name)
        {
            var groupObject = new GameObject(name, typeof(RectTransform));
            groupObject.transform.SetParent(parent, false);

            var rect = (RectTransform)groupObject.transform;
            rect.anchorMin = Vector2.zero;
            rect.anchorMax = Vector2.one;
            rect.offsetMin = Vector2.zero;
            rect.offsetMax = Vector2.zero;
            return rect;
        }

        /// <summary>Nen mo phu toan man, chan input xuong cac nut lai phia sau.</summary>
        private static RectTransform CreatePanel(RectTransform parent, string name)
        {
            RectTransform rect = CreateGroup(parent, name);

            var background = rect.gameObject.AddComponent<Image>();
            background.color = new Color(0.025f, 0.075f, 0.095f, 0.94f);
            background.raycastTarget = true;
            return rect;
        }

        /// <summary>
        /// Thanh lai analog: nen nhan raycast (chinh la vung cham), hai nhan "<" ">" o hai dau va
        /// mot vach tam, num chay theo ngon. Nhan va num KHONG nhan raycast de su kien luon ve thanh.
        /// </summary>
        private static SteerSlider CreateSteerSlider(
            RectTransform parent, string name, Vector2 anchor, Vector2 anchoredPosition)
        {
            var sliderObject = new GameObject(name, typeof(RectTransform));
            sliderObject.transform.SetParent(parent, false);

            var rect = (RectTransform)sliderObject.transform;
            rect.anchorMin = anchor;
            rect.anchorMax = anchor;
            rect.pivot = new Vector2(0.5f, 0.5f);
            rect.sizeDelta = SteerSliderSize;
            rect.anchoredPosition = anchoredPosition;

            var background = sliderObject.AddComponent<Image>();
            background.color = SteerColor;
            background.raycastTarget = true;

            // Vach tam de nguoi choi thay diem 0.
            CreateDecorImage(rect, "Rail", Vector2.zero, new Vector2(310f, 4f), new Color(.6f, .78f, .8f, .4f));
            CreateLabel(rect, "SteerHint", new Vector2(.5f, .5f), new Vector2(0f, 76f),
                new Vector2(300f, 30f), "L Á I", 19f, TextAlignmentOptions.Center);
            CreateDecorImage(rect, "CenterMark", Vector2.zero, new Vector2(4f, 38f), new Color(1f, 1f, 1f, 0.35f));

            // Num chay theo ngon; tao TRUOC nhan de nhan ve len tren num.
            RectTransform knob = CreateDecorImage(rect, "Knob", Vector2.zero, SteerKnobSize, new Color(1f, 0.68f, 0.29f, 0.9f));

            TextMeshProUGUI left = CreateButtonLabel(rect, "<");
            left.name = "LabelLeft";
            left.alignment = TextAlignmentOptions.Left;
            left.margin = new Vector4(28f, 0f, 0f, 0f);

            TextMeshProUGUI right = CreateButtonLabel(rect, ">");
            right.name = "LabelRight";
            right.alignment = TextAlignmentOptions.Right;
            right.margin = new Vector4(0f, 0f, 28f, 0f);

            var slider = sliderObject.AddComponent<SteerSlider>();
            using (var binder = new FieldBinder(slider))
            {
                binder
                    .SetObject("_knob", knob)
                    .SetFloat("_fullSteerDistance", SteerFullDistance)
                    .SetFloat("_deadZone", SteerDeadZone);
            }

            return slider;
        }

        /// <summary>Hinh trang tri trong thanh lai: khong nhan raycast.</summary>
        private static RectTransform CreateDecorImage(
            RectTransform parent, string name, Vector2 anchoredPosition, Vector2 size, Color color)
        {
            var imageObject = new GameObject(name, typeof(RectTransform));
            imageObject.transform.SetParent(parent, false);

            var rect = (RectTransform)imageObject.transform;
            rect.anchorMin = new Vector2(0.5f, 0.5f);
            rect.anchorMax = new Vector2(0.5f, 0.5f);
            rect.pivot = new Vector2(0.5f, 0.5f);
            rect.sizeDelta = size;
            rect.anchoredPosition = anchoredPosition;

            var image = imageObject.AddComponent<Image>();
            image.color = color;
            image.raycastTarget = false;
            return rect;
        }

        private static HoldButton CreateHoldButton(
            RectTransform parent, string name, Vector2 anchor, Vector2 anchoredPosition,
            Vector2 size, string label, Color color)
        {
            GameObject buttonObject = CreateButtonBase(parent, name, anchor, anchoredPosition, size, label, color);
            return buttonObject.AddComponent<HoldButton>();
        }

        private static Button CreateClickButton(
            RectTransform parent, string name, Vector2 anchor, Vector2 anchoredPosition,
            Vector2 size, string label, Color color)
        {
            GameObject buttonObject = CreateButtonBase(parent, name, anchor, anchoredPosition, size, label, color);

            var button = buttonObject.AddComponent<Button>();
            button.targetGraphic = buttonObject.GetComponent<Image>();
            return button;
        }

        private static GameObject CreateButtonBase(
            RectTransform parent, string name, Vector2 anchor, Vector2 anchoredPosition,
            Vector2 size, string label, Color color)
        {
            var buttonObject = new GameObject(name, typeof(RectTransform));
            buttonObject.transform.SetParent(parent, false);

            var rect = (RectTransform)buttonObject.transform;
            rect.anchorMin = anchor;
            rect.anchorMax = anchor;
            rect.pivot = new Vector2(0.5f, 0.5f);
            rect.sizeDelta = size;
            rect.anchoredPosition = anchoredPosition;

            var image = buttonObject.AddComponent<Image>();
            image.color = color;
            image.raycastTarget = true;

            CreateDecorImage(rect, "Accent", new Vector2(0, -size.y * 0.5f + 5f), new Vector2(size.x - 24f, 3f), new Color(1f, 0.7f, 0.34f, 0.85f));
            var caption = CreateButtonLabel(rect, label);
            caption.fontStyle = FontStyles.Bold;
            if (name == "ThrottleButton" || name == "BrakeButton")
            {
                caption.margin = new Vector4(0f, 20f, 0f, 0f);
                CreateLabel(rect, "PedalHint", new Vector2(.5f, .5f), new Vector2(0f, -56f),
                    new Vector2(180f, 34f), name == "ThrottleButton" ? "GIỮ ĐỂ TĂNG TỐC" : "PHANH / LÙI",
                    17f, TextAlignmentOptions.Center);
                for (int i = 0; i < 3; i++)
                    CreateDecorImage(rect, "Grip" + i, new Vector2(0f, 50f + i * 12f),
                        new Vector2(48f, 4f), new Color(1f, .95f, .83f, .5f));
            }
            return buttonObject;
        }

        /// <summary>Nhan chu nam TRONG nut va khong nhan raycast, de khong chan input.</summary>
        private static TextMeshProUGUI CreateButtonLabel(RectTransform parent, string text)
        {
            var labelObject = new GameObject("Label", typeof(RectTransform));
            labelObject.transform.SetParent(parent, false);

            var rect = (RectTransform)labelObject.transform;
            rect.anchorMin = Vector2.zero;
            rect.anchorMax = Vector2.one;
            rect.offsetMin = Vector2.zero;
            rect.offsetMax = Vector2.zero;

            var label = labelObject.AddComponent<TextMeshProUGUI>();
            label.text = text;
            label.alignment = TextAlignmentOptions.Center;
            label.enableAutoSizing = true;
            label.fontSizeMin = 18f;
            label.fontSizeMax = 44f;
            label.color = new Color(1f, 0.95f, 0.83f);
            label.raycastTarget = false;

            RequireFont(label);
            return label;
        }

        /// <summary>Nhan HUD/menu: khong nhan raycast de khong chan nut phia duoi.</summary>
        private static TextMeshProUGUI CreateLabel(
            RectTransform parent, string name, Vector2 anchor, Vector2 anchoredPosition,
            Vector2 size, string text, float fontSize, TextAlignmentOptions alignment)
        {
            var labelObject = new GameObject(name, typeof(RectTransform));
            labelObject.transform.SetParent(parent, false);

            var rect = (RectTransform)labelObject.transform;
            rect.anchorMin = anchor;
            rect.anchorMax = anchor;
            rect.pivot = new Vector2(0.5f, 0.5f);
            rect.sizeDelta = size;
            rect.anchoredPosition = anchoredPosition;

            var label = labelObject.AddComponent<TextMeshProUGUI>();
            label.text = text;
            label.alignment = alignment;
            label.fontSize = fontSize;
            label.color = new Color(1f, 0.95f, 0.83f);
            label.raycastTarget = false;

            RequireFont(label);
            return label;
        }

        private static void HudCard(RectTransform parent, string name, Vector2 anchor, Vector2 position, Vector2 size)
        {
            var rect = CreateDecorImage(parent, name, position, size, new Color(0.025f, 0.09f, 0.115f, 0.85f));
            rect.anchorMin = anchor; rect.anchorMax = anchor;
            CreateDecorImage(rect, "Accent", new Vector2(-size.x * 0.5f + 2f, 0), new Vector2(4f, size.y), new Color(1f, 0.65f, 0.24f));
        }

        private static void MenuCard(RectTransform panel, Vector2 size)
        {
            CreateDecorImage(panel, "CardShadow", new Vector2(0f, -12f), size + new Vector2(18f, 18f), new Color(0f, 0f, 0f, .25f));
            var card = CreateDecorImage(panel, "MenuCard", Vector2.zero, size, new Color(.035f, .095f, .12f, 1f));
            CreateDecorImage(card, "TopRule", new Vector2(0f, size.y * .5f - 3f), new Vector2(size.x, 6f), new Color(1f, .56f, .22f));
            CreateDecorImage(card, "BottomRule", new Vector2(0f, -size.y * .5f + 28f), new Vector2(80f, 4f), new Color(.4f, .62f, .65f));
        }

        private static void Eyebrow(RectTransform parent, string text, float y)
        {
            var label = CreateLabel(parent, "Eyebrow", new Vector2(.5f, .5f), new Vector2(0f, y),
                new Vector2(720f, 36f), text, 21f, TextAlignmentOptions.Center);
            label.color = new Color(.95f, .67f, .36f);
        }

        private static void RequireFont(TextMeshProUGUI label)
        {
            label.font = ApexFontAssets.EnsureFont();
            if (label.font == null)
            {
                throw new InvalidOperationException(
                    "TextMeshPro chua co font mac dinh. Mo Window > TextMeshPro > Import TMP Essential Resources roi chay lai.");
            }
        }
    }
}
