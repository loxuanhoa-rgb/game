using System;
using UnityEditor;
using UnityEngine;

namespace RacingDemo.EditorTools
{
    /// <summary>
    /// Cau noi toi bo model Kenney Racing Kit (CC0) trong Assets/ThirdParty.
    ///
    /// Model goc khong duoc sua: moi chinh sua ti le, huong va vi tri deu lam o day.
    /// Model Kenney co goc toa do dat tuy y (co cai o goc khoi, co cai o tam), nen truoc khi
    /// dung deu di qua <see cref="Place"/> de dua ve chuan chung: tam theo X/Z, day cham y = 0.
    /// </summary>
    internal static class KenneyKit
    {
        private const string ModelFolder = "Assets/ThirdParty/KenneyRacingKit/Models/";

        public const string Car = ModelFolder + "raceCarRed.fbx";
        public const string Pylon = ModelFolder + "pylon.fbx";
        public const string TreeSmall = ModelFolder + "treeSmall.fbx";
        public const string TreeLarge = ModelFolder + "treeLarge.fbx";
        public const string GrandStand = ModelFolder + "grandStandCovered.fbx";
        public const string Tent = ModelFolder + "tentLong.fbx";
        public const string FlagCheckers = ModelFolder + "flagCheckers.fbx";
        public const string LightPost = ModelFolder + "lightPostModern.fbx";
        public const string Billboard = ModelFolder + "billboard.fbx";
        public const string BarrierRed = ModelFolder + "barrierRed.fbx";
        public const string BarrierWhite = ModelFolder + "barrierWhite.fbx";
        public const string Fence = ModelFolder + "fenceStraight.fbx";

        /// <summary>
        /// He so quy doi don vi Kenney sang met cho vat trang tri: hang rao 10 don vi thanh 5 m,
        /// cay treeLarge cao 15 don vi thanh 7,5 m. Xe KHONG dung he so nay — xe khop theo
        /// chieu dai co so cua WheelCollider, xem <see cref="CarBuilder"/>.
        /// </summary>
        public const float PropScale = 0.5f;

        public static GameObject Load(string assetPath)
        {
            var model = AssetDatabase.LoadAssetAtPath<GameObject>(assetPath);
            if (model == null)
            {
                throw new InvalidOperationException(
                    "Khong load duoc model " + assetPath + ". Kiem tra Assets/ThirdParty/KenneyRacingKit " +
                    "(file FBX luu qua Git LFS, checkout thieu se ra file con tro).");
            }

            return model;
        }

        /// <summary>
        /// Dat mot vat trang tri: tao object bao ngoai o dung vi tri/huong/ti le, roi gan
        /// instance prefab cua model vao trong va bu lech goc toa do cua model.
        ///
        /// Dung prefab instance (khong phai ban sao roi) de doi model trong ThirdParty la
        /// toan bo vat trang tri doi theo — dung tinh than "thay visual qua prefab tham chieu".
        /// </summary>
        public static GameObject Place(
            Transform parent, GameObject model, string name, Vector3 localPosition, Quaternion localRotation,
            float scale)
        {
            if (parent == null) throw new ArgumentNullException(nameof(parent));
            if (model == null) throw new ArgumentNullException(nameof(model));
            if (!(scale > 0f)) throw new ArgumentOutOfRangeException(nameof(scale), scale, "Ti le phai duong.");

            var holder = new GameObject(name);
            holder.transform.SetParent(parent, false);
            holder.transform.localPosition = localPosition;
            holder.transform.localRotation = localRotation;
            holder.transform.localScale = new Vector3(scale, scale, scale);

            var instance = (GameObject)PrefabUtility.InstantiatePrefab(model, holder.transform);
            instance.transform.localPosition = Vector3.zero;
            instance.transform.localRotation = Quaternion.identity;
            instance.transform.localScale = Vector3.one;

            Bounds bounds = LocalBounds(instance.transform);
            instance.transform.localPosition = new Vector3(-bounds.center.x, -bounds.min.y, -bounds.center.z);

            MarkStaticRecursively(holder);
            return holder;
        }

        /// <summary>Bao hinh cua ca cay con, do trong he toa do cua chinh <paramref name="root"/>.</summary>
        public static Bounds LocalBounds(Transform root)
        {
            if (root == null) throw new ArgumentNullException(nameof(root));

            MeshFilter[] filters = root.GetComponentsInChildren<MeshFilter>(true);
            bool started = false;
            var bounds = new Bounds();
            for (int i = 0; i < filters.Length; i++)
            {
                Mesh mesh = filters[i].sharedMesh;
                if (mesh == null) continue;

                Bounds local = mesh.bounds;
                for (int corner = 0; corner < 8; corner++)
                {
                    var offset = new Vector3(
                        (corner & 1) == 0 ? local.min.x : local.max.x,
                        (corner & 2) == 0 ? local.min.y : local.max.y,
                        (corner & 4) == 0 ? local.min.z : local.max.z);
                    Vector3 point = root.InverseTransformPoint(filters[i].transform.TransformPoint(offset));
                    if (!started)
                    {
                        bounds = new Bounds(point, Vector3.zero);
                        started = true;
                    }
                    else
                    {
                        bounds.Encapsulate(point);
                    }
                }
            }

            if (!started)
            {
                throw new InvalidOperationException("Model " + root.name + " khong co mesh nao de do kich thuoc.");
            }

            return bounds;
        }

        public static void MarkStaticRecursively(GameObject root)
        {
            if (root == null) throw new ArgumentNullException(nameof(root));

            foreach (Transform child in root.GetComponentsInChildren<Transform>(true))
            {
                child.gameObject.isStatic = true;
            }
        }
    }
}
