using System.Collections.Generic;
using RacingDemo.Runtime.Track;
using TMPro;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

namespace RacingDemo.EditorTools
{
    /// <summary>Deterministic, visual-only festival art. All assets belong to the generator.</summary>
    internal static class FestivalVisuals
    {
        private const string Folder = "Assets/Generated/Materials/";
        internal static Material Material(string name, Color color)
        {
            string path = Folder + name + ".mat";
            var value = AssetDatabase.LoadAssetAtPath<Material>(path);
            if (value == null)
            {
                value = new Material(Shader.Find("Universal Render Pipeline/Lit"));
                AssetDatabase.CreateAsset(value, path);
            }
            value.SetColor("_BaseColor", color);
            value.SetFloat("_Smoothness", 0.05f);
            EditorUtility.SetDirty(value);
            return value;
        }

        public static void Build(Transform trackRoot, TrackDefinition track)
        {
            var root = new GameObject("FestivalVisuals").transform;
            root.SetParent(trackRoot, false);
            var cream = Material("FestivalCream", new Color(0.96f, 0.9f, 0.74f));
            var coral = Material("FestivalCoral", new Color(0.88f, 0.24f, 0.105f));
            var ink = Material("FestivalInk", new Color(0.035f, 0.105f, 0.13f));
            Atmosphere();
            Asphalt();
            var path = new StadiumGeometry(track);
            // Four combined mesh strips, not hundreds of individual curb renderers.
            for (int side = -1; side <= 1; side += 2)
            {
                Ribbon(root, path, side, cream, coral);
            }
            path.Evaluate(0f, out Vector3 finish, out Vector3 forward);
            var gate = new GameObject("FinishBranding").transform;
            gate.SetParent(root, false);
            gate.SetPositionAndRotation(finish, Quaternion.LookRotation(forward));
            Box(gate, "Header", new Vector3(0, 5.35f, 0), new Vector3(track.RoadWidth + 0.8f, 1.1f, 0.5f), ink);
            Box(gate, "Accent", new Vector3(0, 5.95f, 0), new Vector3(track.RoadWidth + 0.8f, 0.12f, 0.55f), coral);
            Text(gate, "APEX  /  MÙA NẮNG", new Vector3(0, 5.35f, -0.27f), 0.66f, cream.color);
            for (int row = 0; row < 2; row++)
                for (int col = 0; col < 16; col++)
                    Box(gate, "FinishTile", new Vector3((col + 0.5f) * track.RoadWidth / 16f - track.RoadWidth / 2f, 0.032f, (row - 0.5f) * 0.6f),
                        new Vector3(track.RoadWidth / 16f, 0.015f, 0.6f), (row + col) % 2 == 0 ? cream : ink);
            foreach (var cp in track.Checkpoints)
            {
                if (cp.Order == 3) continue;
                path.Evaluate(cp.Distance, out Vector3 p, out Vector3 f);
                var sign = new GameObject("SectorSign" + cp.Order).transform;
                sign.SetParent(root, false);
                sign.SetPositionAndRotation(p, Quaternion.LookRotation(f));
                Box(sign, "Panel", new Vector3(0, 5.2f, 0), new Vector3(5f, 0.8f, 0.35f), ink);
                Text(sign, cp.Order == 0 ? "ĐỒI THÔNG" : cp.Order == 1 ? "QUÁN DỐC NẮNG" : "SÂN HỘI", new Vector3(0, 5.2f, -0.19f), 0.52f, new Color(1f, 0.72f, 0.34f));
            }
            // Repeated trackside chevrons communicate the two left-hand bends.
            for (int bend = 0; bend < 2; bend++)
                for (int i = 0; i < 5; i++)
                {
                    float d = path.StraightLength / 2f + 10f + i * 16f + bend * path.Length / 2f;
                    path.Evaluate(d, out Vector3 p, out Vector3 f);
                    var sign = new GameObject("TurnChevron").transform;
                    sign.SetParent(root, false);
                    sign.SetPositionAndRotation(p + Vector3.Cross(Vector3.up, f) * (track.RoadWidth / 2f + 1f), Quaternion.LookRotation(f));
                    Box(sign, "Board", new Vector3(0, 2.3f, 0), new Vector3(2.7f, 1.3f, 0.15f), ink);
                    Text(sign, "<<<", new Vector3(0, 2.3f, -0.09f), 1.05f, new Color(1f, 0.65f, 0.22f));
                }
            Mountains(trackRoot.Find("Decor"), track);
            VenueDetails.Build(trackRoot.Find("Decor"), track);
        }

        private static void Atmosphere()
        {
            const string skyPath = Folder + "GoldenSky.mat";
            var sky = AssetDatabase.LoadAssetAtPath<Material>(skyPath);
            if (sky == null)
            {
                sky = new Material(Shader.Find("Skybox/Procedural"));
                AssetDatabase.CreateAsset(sky, skyPath);
            }
            sky.SetColor("_SkyTint", new Color(0.48f, 0.57f, 0.59f));
            sky.SetColor("_GroundColor", new Color(0.48f, 0.44f, 0.33f));
            sky.SetFloat("_AtmosphereThickness", 1.25f);
            sky.SetFloat("_Exposure", 1.1f);
            sky.SetFloat("_SunSize", 0.045f);
            EditorUtility.SetDirty(sky);
            RenderSettings.skybox = sky;
            RenderSettings.ambientMode = AmbientMode.Trilight;
            RenderSettings.ambientSkyColor = new Color(0.58f, 0.67f, 0.72f);
            RenderSettings.ambientEquatorColor = new Color(0.43f, 0.46f, 0.42f);
            RenderSettings.ambientGroundColor = new Color(0.23f, 0.25f, 0.24f);
            RenderSettings.fog = true;
            RenderSettings.fogMode = FogMode.Linear;
            RenderSettings.fogColor = new Color(0.72f, 0.73f, 0.64f);
            RenderSettings.fogStartDistance = 95f;
            RenderSettings.fogEndDistance = 340f;
        }

        private static void Ribbon(Transform root, StadiumGeometry path, int side, Material cream, Material coral)
        {
            var vertices = new List<Vector3>();
            var white = new List<int>();
            var red = new List<int>();
            int count = Mathf.CeilToInt(path.Length / 2f);
            for (int i = 0; i < count; i++)
            {
                path.Evaluate(i * path.Length / count, out Vector3 p, out Vector3 f);
                path.Evaluate((i + 1) * path.Length / count, out Vector3 q, out Vector3 g);
                Vector3 a = Vector3.Cross(Vector3.up, f), b = Vector3.Cross(Vector3.up, g);
                float outer = side * (path.RoadWidth / 2f - 0.03f), inner = outer - side * 0.65f;
                int n = vertices.Count;
                vertices.Add(p + a * Mathf.Min(inner, outer) + Vector3.up * 0.026f);
                vertices.Add(p + a * Mathf.Max(inner, outer) + Vector3.up * 0.026f);
                vertices.Add(q + b * Mathf.Min(inner, outer) + Vector3.up * 0.026f);
                vertices.Add(q + b * Mathf.Max(inner, outer) + Vector3.up * 0.026f);
                (i % 2 == 0 ? white : red).AddRange(new[] { n, n + 2, n + 1, n + 1, n + 2, n + 3 });
            }
            var mesh = new Mesh { vertices = vertices.ToArray(), subMeshCount = 2 };
            mesh.SetTriangles(white, 0); mesh.SetTriangles(red, 1);
            mesh.RecalculateNormals(); mesh.RecalculateBounds();
            mesh = SaveMesh("FestivalCurb" + side, mesh);
            var go = new GameObject("RacingCurb" + side);
            go.transform.SetParent(root, false);
            go.AddComponent<MeshFilter>().sharedMesh = mesh;
            go.AddComponent<MeshRenderer>().sharedMaterials = new[] { cream, coral };
            go.isStatic = true;
        }

        private static void Mountains(Transform decor, TrackDefinition track)
        {
            // Flat-shaded, irregular seven-sided peaks; same mesh shared by every mountain.
            var vertices = new List<Vector3>();
            var triangles = new List<int>();
            for (int i = 0; i < 7; i++)
            {
                float a = i * Mathf.PI * 2 / 7, b = (i + 1) * Mathf.PI * 2 / 7;
                int n = vertices.Count;
                vertices.Add(new Vector3(Mathf.Cos(a), 0, Mathf.Sin(a)));
                vertices.Add(new Vector3(-0.2f, 1f, 0.1f));
                vertices.Add(new Vector3(Mathf.Cos(b), 0, Mathf.Sin(b)));
                triangles.AddRange(new[] { n, n + 1, n + 2 });
            }
            var mesh = new Mesh { vertices = vertices.ToArray(), triangles = triangles.ToArray() };
            mesh.RecalculateNormals(); mesh.RecalculateBounds();
            mesh = SaveMesh("FestivalPeak", mesh);
            var materials = new[] {
                Material("PeakSage", new Color(0.33f, 0.43f, 0.39f)),
                Material("PeakBlue", new Color(0.35f, 0.46f, 0.47f)),
                Material("PeakSand", new Color(0.5f, 0.49f, 0.36f)) };
            for (int i = 0; i < 18; i++)
            {
                float angle = i * Mathf.PI * 2 / 18;
                var go = new GameObject("HorizonPeak" + i);
                go.transform.SetParent(decor, false);
                go.transform.localPosition = new Vector3(Mathf.Cos(angle) * 190f, track.SurfaceHeight - 3f, Mathf.Sin(angle) * 220f);
                go.transform.localScale = new Vector3(60f + i % 3 * 9f, 19f + i % 5 * 6f, 48f + i % 4 * 6f);
                go.AddComponent<MeshFilter>().sharedMesh = mesh;
                var renderer = go.AddComponent<MeshRenderer>();
                renderer.sharedMaterial = materials[i % 3];
                renderer.shadowCastingMode = ShadowCastingMode.Off;
                go.isStatic = true;
            }
        }

        private static void Asphalt()
        {
            const string path = "Assets/Generated/Materials/AsphaltGrain.asset";
            var texture = AssetDatabase.LoadAssetAtPath<Texture2D>(path);
            if (texture == null)
            {
                texture = new Texture2D(128, 128, TextureFormat.RGB24, true);
                texture.name = "AsphaltGrain";
                AssetDatabase.CreateAsset(texture, path);
            }
            var random = new System.Random(741);
            var pixels = new Color[128 * 128];
            for (int i = 0; i < pixels.Length; i++)
            {
                float value = 0.82f + (float)random.NextDouble() * 0.18f;
                pixels[i] = new Color(value, value, value);
            }
            texture.SetPixels(pixels); texture.Apply(true);
            texture.wrapMode = TextureWrapMode.Repeat;
            texture.filterMode = FilterMode.Trilinear;
            texture.anisoLevel = 4;
            EditorUtility.SetDirty(texture);
            var road = AssetDatabase.LoadAssetAtPath<Material>(Folder + "DemoGround.mat");
            road.SetTexture("_BaseMap", texture);
            road.SetTextureScale("_BaseMap", new Vector2(6f, 4f));
            EditorUtility.SetDirty(road);
        }

        internal static void PaintCar(Transform car)
        {
            var red = Material("CarVermilion", new Color(0.8f, 0.065f, 0.025f));
            red.SetFloat("_Smoothness", 0.45f);
            var rubber = Material("CarRubber", new Color(0.035f, 0.042f, 0.045f));
            var trim = Material("CarGraphite", new Color(0.1f, 0.135f, 0.15f));
            var glass = Material("CarGlass", new Color(0.045f, 0.19f, 0.24f));
            glass.SetFloat("_Smoothness", 0.65f);
            foreach (var renderer in car.GetComponentsInChildren<MeshRenderer>())
            {
                var materials = renderer.sharedMaterials;
                for (int i = 0; i < materials.Length; i++)
                {
                    switch (materials[i].name)
                    {
                        case "red": materials[i] = red; break;
                        case "carTire": materials[i] = rubber; break;
                        case "grey": materials[i] = trim; break;
                        case "glass": materials[i] = glass; break;
                    }
                }
                renderer.sharedMaterials = materials;
            }
        }

        private static Mesh SaveMesh(string name, Mesh mesh)
        {
            mesh.name = name;
            string path = "Assets/Generated/Meshes/" + name + ".asset";
            var existing = AssetDatabase.LoadAssetAtPath<Mesh>(path);
            if (existing == null) { AssetDatabase.CreateAsset(mesh, path); return mesh; }
            EditorUtility.CopySerialized(mesh, existing);
            Object.DestroyImmediate(mesh); EditorUtility.SetDirty(existing); return existing;
        }

        private static void Box(Transform parent, string name, Vector3 p, Vector3 size, Material material)
        {
            var go = GameObject.CreatePrimitive(PrimitiveType.Cube);
            go.name = name; go.transform.SetParent(parent, false);
            go.transform.localPosition = p; go.transform.localScale = size;
            Object.DestroyImmediate(go.GetComponent<Collider>());
            go.GetComponent<MeshRenderer>().sharedMaterial = material;
            go.isStatic = true;
        }

        private static void Text(Transform parent, string text, Vector3 position, float size, Color color)
        {
            var go = new GameObject("SignText");
            go.transform.SetParent(parent, false);
            go.transform.localPosition = position;
            var label = go.AddComponent<TextMeshPro>();
            label.font = ApexFontAssets.EnsureFont(); label.text = text; label.fontSize = size * 10f;
            label.alignment = TextAlignmentOptions.Center;
            label.color = color;
            label.rectTransform.sizeDelta = new Vector2(12f, 1.4f);
            label.GetComponent<MeshRenderer>().shadowCastingMode = ShadowCastingMode.Off;
        }
    }
}
