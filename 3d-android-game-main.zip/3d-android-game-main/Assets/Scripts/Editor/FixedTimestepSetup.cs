using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace RacingDemo.EditorTools
{
    /// <summary>
    /// Dat buoc vat ly ve 1/60 giay dung nhu ke hoach muc 2 ("buoc vat ly ban dau 1/60 giay").
    ///
    /// Vi sao phai co lenh nay: Unity mac dinh 0,02 giay (50 Hz). Du an dat
    /// <c>targetFrameRate = 60</c> nen de mac dinh thi vat ly va khung hinh khong khop nhau —
    /// co khung khong chay buoc vat ly nao, co khung chay hai buoc. Sai lech nay ton tai am tham
    /// tu Task 1 den khi nghiem thu Task 7 moi phat hien.
    ///
    /// Doc/ghi qua <see cref="Time.fixedDeltaTime"/> chu khong qua SerializedProperty: Unity 6
    /// luu truong nay trong TimeManager.asset duoi dang phan so (m_Count/m_Rate), khong phai
    /// float, nen doc bang float se ra 0 va kiem tra se sai.
    ///
    /// ProjectSettings khong nam trong AssetDatabase nen <c>AssetDatabase.SaveAssets()</c> khong
    /// ghi no; phai luu ca project. <see cref="Verify"/> chay o mot phien Unity khac, nen no
    /// dong thoi la phep kiem tra "da ghi xuong dia that chua".
    /// </summary>
    public static class FixedTimestepSetup
    {
        /// <summary>1/60 giay. Viet thanh hang so de generator va validator dung chung mot con so.</summary>
        public const float WantedFixedDeltaTime = 1f / 60f;

        private const float Tolerance = 1e-6f;
        private const string SaveProjectMenuItem = "File/Save Project";

        [MenuItem("RacingDemo/Apply Fixed Timestep", false, 21)]
        public static void ApplyMenu()
        {
            var changes = new List<string>();
            Apply(changes);
            Debug.Log(changes.Count == 0
                ? "[RacingDemo] Buoc vat ly da dung 1/60 giay."
                : "[RacingDemo] Da cap nhat buoc vat ly: " + string.Join(", ", changes));
        }

        /// <summary>Ghi vao <paramref name="changes"/> neu thuc su phai doi gia tri.</summary>
        public static void Apply(List<string> changes)
        {
            if (changes == null)
            {
                throw new ArgumentNullException(nameof(changes));
            }

            if (IsWanted(Time.fixedDeltaTime))
            {
                return;
            }

            changes.Add("Fixed Timestep: " + Time.fixedDeltaTime + " -> " + WantedFixedDeltaTime);
            Time.fixedDeltaTime = WantedFixedDeltaTime;

            if (!EditorApplication.ExecuteMenuItem(SaveProjectMenuItem))
            {
                throw new InvalidOperationException(
                    "Da doi buoc vat ly trong bo nho nhung khong luu duoc project settings. " +
                    "Mo Project Settings > Time va dat Fixed Timestep = " + WantedFixedDeltaTime + " bang tay.");
            }
        }

        /// <summary>Kiem tra gia tri TimeManager dang dung. Validator goi ham nay.</summary>
        public static void Verify(List<string> errors)
        {
            if (errors == null)
            {
                throw new ArgumentNullException(nameof(errors));
            }

            if (!IsWanted(Time.fixedDeltaTime))
            {
                errors.Add("Buoc vat ly phai la 1/60 giay (" + WantedFixedDeltaTime + "), dang la " +
                           Time.fixedDeltaTime + ". Chay RacingDemo/Apply Fixed Timestep.");
            }
        }

        private static bool IsWanted(float value)
        {
            return Math.Abs(value - WantedFixedDeltaTime) <= Tolerance;
        }
    }
}
