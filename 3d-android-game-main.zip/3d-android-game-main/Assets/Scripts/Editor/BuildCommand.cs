using System;
using System.IO;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEngine;
using UnityEngine.Rendering;

namespace RacingDemo.EditorTools
{
    /// <summary>
    /// Build APK Android. Ca hai lenh dung chung mot danh sach scene voi
    /// <see cref="SceneValidator"/> va cung mot bo cau hinh Player.
    /// </summary>
    public static class BuildCommand
    {
        public const string ApplicationIdentifier = "com.vuit.racingdemo";
        public const string ProductName = "APEX — Mùa Nắng";
        public const string CompanyName = "VuIT";

        [MenuItem("RacingDemo/Build/Android Development", false, 40)]
        public static void BuildAndroidDevelopment()
        {
            Build(DemoEditorPaths.DevelopmentApkPath, development: true);
        }

        [MenuItem("RacingDemo/Build/Android Release", false, 41)]
        public static void BuildAndroidRelease()
        {
            Build(DemoEditorPaths.ReleaseApkPath, development: false);
        }

        /// <summary>Ap cau hinh Android chot trong AGENTS.md. Goi rieng duoc tu menu.</summary>
        [MenuItem("RacingDemo/Apply Android Player Settings", false, 43)]
        public static void ApplyAndroidPlayerSettings()
        {
            PlayerSettings.companyName = CompanyName;
            PlayerSettings.productName = ProductName;

            NamedBuildTarget android = NamedBuildTarget.Android;
            PlayerSettings.SetApplicationIdentifier(android, ApplicationIdentifier);
            PlayerSettings.SetScriptingBackend(android, ScriptingImplementation.IL2CPP);
            // Unity 6 dat ten la NET_Standard (khong con NET_Standard_2_1).
            PlayerSettings.SetApiCompatibilityLevel(android, ApiCompatibilityLevel.NET_Standard);

            PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
            PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel26;
            PlayerSettings.Android.targetSdkVersion = AndroidSdkVersions.AndroidApiLevelAuto;
            PlayerSettings.Android.forceInternetPermission = false;

            PlayerSettings.defaultInterfaceOrientation = UIOrientation.LandscapeLeft;
            PlayerSettings.allowedAutorotateToPortrait = false;
            PlayerSettings.allowedAutorotateToPortraitUpsideDown = false;
            PlayerSettings.allowedAutorotateToLandscapeLeft = true;
            PlayerSettings.allowedAutorotateToLandscapeRight = false;

            PlayerSettings.SetUseDefaultGraphicsAPIs(BuildTarget.Android, false);
            PlayerSettings.SetGraphicsAPIs(BuildTarget.Android, new[] { GraphicsDeviceType.OpenGLES3 });

            // Cai truc tiep bang APK, khong dung app bundle.
            EditorUserBuildSettings.buildAppBundle = false;
            PlayerSettings.Android.useCustomKeystore = false;

            AssetDatabase.SaveAssets();
            Debug.Log("[RacingDemo] Da ap cau hinh Player cho Android.");
        }

        private static void Build(string outputPath, bool development)
        {
            DemoEditorPaths.EnsureNoUnsavedSceneChanges();
            EnsureAndroidBuildTarget();
            ApplyAndroidPlayerSettings();

            // Cung mot danh sach scene cho validator va BuildPlayerOptions.
            SceneValidator.ValidateBuildScenes();
            string[] scenes = SceneValidator.GetEnabledBuildScenePaths();

            string absoluteOutput = DemoEditorPaths.ToAbsoluteProjectPath(outputPath);
            string outputDirectory = Path.GetDirectoryName(absoluteOutput);
            if (!string.IsNullOrEmpty(outputDirectory))
            {
                Directory.CreateDirectory(outputDirectory);
            }

            EditorUserBuildSettings.development = development;
            EditorUserBuildSettings.allowDebugging = false;
            EditorUserBuildSettings.connectProfiler = false;
            EditorUserBuildSettings.buildWithDeepProfilingSupport = false;

            var options = new BuildPlayerOptions
            {
                scenes = scenes,
                locationPathName = absoluteOutput,
                target = BuildTarget.Android,
                targetGroup = BuildTargetGroup.Android,
                options = development ? BuildOptions.Development : BuildOptions.None
            };

            BuildReport report = BuildPipeline.BuildPlayer(options);
            BuildSummary summary = report.summary;

            if (summary.result != BuildResult.Succeeded)
            {
                throw new InvalidOperationException(
                    "Build that bai (" + summary.result + ", " + summary.totalErrors + " loi). Doc log build de biet loi dau tien.");
            }

            // summary.totalSize khong phai dung luong file APK; doc kich thuoc that tren dia.
            var apkFile = new FileInfo(absoluteOutput);
            string apkSize = apkFile.Exists
                ? string.Format("{0:0.0} MB", apkFile.Length / (1024f * 1024f))
                : "khong tim thay file";

            Debug.Log(string.Format(
                "[RacingDemo] Build xong: {0} ({1}, {2}, {3:0} giay).",
                outputPath,
                PlayerSettings.Android.targetArchitectures,
                apkSize,
                summary.totalTime.TotalSeconds));
        }

        private static void EnsureAndroidBuildTarget()
        {
            if (EditorUserBuildSettings.activeBuildTarget == BuildTarget.Android)
            {
                return;
            }

            Debug.Log("[RacingDemo] Chuyen build target sang Android...");
            if (!EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Android, BuildTarget.Android))
            {
                throw new InvalidOperationException(
                    "Khong chuyen duoc build target sang Android. Kiem tra module Android Build Support da cai chua.");
            }
        }
    }
}
