using System.Collections.Generic;
using RacingDemo.Runtime.Track;
using UnityEngine;

namespace RacingDemo.EditorTools
{
    /// <summary>Only the fixed stadium: shared seam vertices, flat road and continuous walls.</summary>
    public static class TrackBuilder
    {
        public const float MaximumSegmentLength = 1f;
        public const float BarrierWidth = 0.4f;
        public const float BarrierHeight = 1.2f;

        /// <summary>Nua canh tham co (m). Duong dua rong nhat khoang 76 m nen 150 m la du xa.</summary>
        public const float GroundHalfSize = 150f;

        /// <summary>
        /// Ma sat giua than xe va rao. Tune khi choi that tren Xiaomi 14: mac dinh 0,6 lam xe dam
        /// tuong goc ~15 do bi khung lai, phai lui moi di tiep; 0 thi xe co tuong khong mat toc nen
        /// de vang ra khoi duong. 0,2 la muc giua: truot doc tuong nhung van bi ham.
        /// </summary>
        public const float BarrierFriction = 0.2f;

        /// <summary>
        /// Vat lieu vat ly cho rao va than xe: ma sat <see cref="BarrierFriction"/>, ket hop Minimum
        /// de gia tri nay thang moi collider khac (mat duong, vat trang tri) va khong nay.
        /// </summary>
        public static PhysicsMaterial ConfigureSlideMaterial(PhysicsMaterial material)
        {
            material.dynamicFriction = BarrierFriction;
            material.staticFriction = BarrierFriction;
            material.bounciness = 0f;
            material.frictionCombine = PhysicsMaterialCombine.Minimum;
            material.bounceCombine = PhysicsMaterialCombine.Minimum;
            return material;
        }

        /// <summary>Dung cho validator: vat lieu co dung gia tri da tune khong (ca 0 lan 0,6 deu sai).</summary>
        public static bool IsSlideMaterial(PhysicsMaterial material)
        {
            return material != null
                && Mathf.Approximately(material.dynamicFriction, BarrierFriction)
                && Mathf.Approximately(material.staticFriction, BarrierFriction)
                && material.frictionCombine == PhysicsMaterialCombine.Minimum;
        }

        public static Mesh CreateRoadMesh(TrackDefinition track)
        {
            return CreateRibbon(track, -track.RoadWidth * 0.5f, track.RoadWidth * 0.5f, 0f, "StadiumRoad");
        }

        private static Mesh CreateRibbon(TrackDefinition track, float a, float b, float elevation, string name)
        {
            var path = new StadiumGeometry(track);
            var distances = path.CreateSampleDistances(MaximumSegmentLength);
            int count = distances.Length - 1; // Last distance repeats the first position: share its vertices.
            var vertices = new Vector3[count * 2];
            var uv = new Vector2[vertices.Length];
            var indices = new List<int>(count * 6);
            for (int i = 0; i < count; i++)
            {
                path.Evaluate(distances[i], out Vector3 p, out Vector3 forward);
                Vector3 right = Vector3.Cross(Vector3.up, forward);
                vertices[2 * i] = p + right * a + Vector3.up * elevation;
                vertices[2 * i + 1] = p + right * b + Vector3.up * elevation;
                uv[2 * i] = new Vector2(0, distances[i] / 8f);
                uv[2 * i + 1] = new Vector2(1, distances[i] / 8f);
                int next = 2 * ((i + 1) % count);
                indices.AddRange(new[] { 2 * i, next, 2 * i + 1, 2 * i + 1, next, next + 1 });
            }
            return MeshFrom(name, vertices, indices, uv);
        }

        public static Mesh CreateBarrierMesh(TrackDefinition track, bool inner)
        {
            var path = new StadiumGeometry(track);
            var distances = path.CreateSampleDistances(MaximumSegmentLength);
            int count = distances.Length - 1;
            float a = inner ? -track.RoadWidth * 0.5f - BarrierWidth : track.RoadWidth * 0.5f;
            float b = a + BarrierWidth;
            var vertices = new Vector3[count * 4];
            var indices = new List<int>(count * 24);
            for (int i = 0; i < count; i++)
            {
                path.Evaluate(distances[i], out Vector3 p, out Vector3 forward);
                Vector3 right = Vector3.Cross(Vector3.up, forward);
                vertices[4 * i] = p + right * a - Vector3.up * 0.15f;
                vertices[4 * i + 1] = p + right * b - Vector3.up * 0.15f;
                vertices[4 * i + 2] = p + right * b + Vector3.up * BarrierHeight;
                vertices[4 * i + 3] = p + right * a + Vector3.up * BarrierHeight;
                for (int side = 0; side < 4; side++)
                {
                    int current = 4 * i + side, across = 4 * i + (side + 1) % 4;
                    int next = 4 * ((i + 1) % count) + side;
                    int nextAcross = 4 * ((i + 1) % count) + (side + 1) % 4;
                    indices.AddRange(new[] { current, across, next, across, nextAcross, next });
                }
            }
            return MeshFrom(inner ? "StadiumInnerBarrier" : "StadiumOuterBarrier", vertices, indices, null);
        }

        private static Mesh MeshFrom(string name, Vector3[] vertices, List<int> indices, Vector2[] uv)
        {
            var mesh = new Mesh { name = name, vertices = vertices };
            mesh.SetTriangles(indices, 0);
            if (uv != null) mesh.uv = uv;
            mesh.RecalculateNormals();
            mesh.RecalculateBounds();
            return mesh;
        }

        public static GameObject Build(Transform parent, TrackDefinition track, Rigidbody player,
            Material road, Material barrier, Material markings, Material grass,
            Mesh roadMesh, Mesh innerMesh, Mesh outerMesh, PhysicsMaterial barrierPhysics)
        {
            var root = new GameObject("Track");
            root.transform.SetParent(parent, false);
            CreateGround(root.transform, track, grass);
            CreateMeshObject(root.transform, "Road", roadMesh, road, true, null);
            CreateMeshObject(root.transform, "InnerBarrier", innerMesh, barrier, true, barrierPhysics);
            CreateMeshObject(root.transform, "OuterBarrier", outerMesh, barrier, true, barrierPhysics);
            var path = new StadiumGeometry(track);
            foreach (TrackCheckpoint checkpoint in track.Checkpoints)
            {
                var gate = new GameObject("Checkpoint" + checkpoint.Order + (checkpoint.Order == 3 ? "_Finish" : ""));
                gate.transform.SetParent(root.transform, false);
                path.Evaluate(checkpoint.Distance, out Vector3 p, out Vector3 forward);
                gate.transform.SetPositionAndRotation(p, Quaternion.LookRotation(forward));
                var box = gate.AddComponent<BoxCollider>();
                box.isTrigger = true;
                box.center = Vector3.up * (track.TriggerHeight * 0.5f);
                box.size = new Vector3(track.RoadWidth, track.TriggerHeight, track.TriggerDepth);
                var volume = gate.AddComponent<CheckpointVolume>();
                using (var binder = new FieldBinder(volume))
                    binder.SetObject("_playerBody", player).SetInt("_order", checkpoint.Order);
                // Visual-only line and posts. They add no obstacles/colliders to the road.
                CreateBox(gate.transform, "Line", new Vector3(0, 0.012f, 0),
                    new Vector3(track.RoadWidth, 0.02f, checkpoint.Order == 3 ? 1.2f : 0.35f), markings);
                foreach (float side in new[] { -1f, 1f })
                    CreateBox(gate.transform, "Post", new Vector3(side * (track.RoadWidth / 2 + 0.2f), 2.5f, 0),
                        new Vector3(0.25f, 5f, 0.25f), markings);
                CreateBox(gate.transform, "Crossbar", new Vector3(0, 5f, 0),
                    new Vector3(track.RoadWidth + 0.65f, 0.25f, 0.25f), markings);
            }
            // Sparse center dashes show the curve and travel direction at prototype quality.
            for (float d = 4; d < path.Length; d += 8f)
            {
                path.Evaluate(d, out Vector3 p, out Vector3 f);
                GameObject dash = CreateBox(root.transform, "CenterDash", p + Vector3.up * 0.012f,
                    new Vector3(0.14f, 0.02f, 2f), markings);
                dash.transform.rotation = Quaternion.LookRotation(f);
            }
            return root;
        }

        /// <summary>
        /// Nen co phang duoi ca san van dong, CHI DE NHIN: khong co collider nen khong doi
        /// hanh vi "roi khoi duong thi tu reset" cua Task 4. Ha thap 2 cm de khong tranh chap
        /// be mat voi mat duong.
        /// </summary>
        private static void CreateGround(Transform parent, TrackDefinition track, Material grass)
        {
            GameObject ground = GameObject.CreatePrimitive(PrimitiveType.Plane);
            ground.name = "Ground";
            ground.transform.SetParent(parent, false);
            ground.transform.localPosition = new Vector3(0f, track.SurfaceHeight - 0.02f, 0f);
            ground.transform.localScale = new Vector3(GroundHalfSize / 5f, 1f, GroundHalfSize / 5f);
            Object.DestroyImmediate(ground.GetComponent<Collider>());
            ground.GetComponent<MeshRenderer>().sharedMaterial = grass;
            ground.isStatic = true;
        }

        private static void CreateMeshObject(Transform parent, string name, Mesh mesh, Material material, bool collider,
            PhysicsMaterial physics)
        {
            var go = new GameObject(name);
            go.transform.SetParent(parent, false);
            go.isStatic = true;
            go.AddComponent<MeshFilter>().sharedMesh = mesh;
            go.AddComponent<MeshRenderer>().sharedMaterial = material;
            if (!collider) return;
            MeshCollider meshCollider = go.AddComponent<MeshCollider>();
            meshCollider.sharedMesh = mesh;
            meshCollider.sharedMaterial = physics;
        }

        private static GameObject CreateBox(Transform parent, string name, Vector3 position, Vector3 scale, Material material)
        {
            var go = GameObject.CreatePrimitive(PrimitiveType.Cube);
            go.name = name;
            go.transform.SetParent(parent, false);
            go.transform.localPosition = position;
            go.transform.localScale = scale;
            Object.DestroyImmediate(go.GetComponent<Collider>());
            go.GetComponent<MeshRenderer>().sharedMaterial = material;
            go.isStatic = true;
            return go;
        }
    }
}
