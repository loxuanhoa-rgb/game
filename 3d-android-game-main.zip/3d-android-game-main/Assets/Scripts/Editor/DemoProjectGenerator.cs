using System;
using System.Collections.Generic;
using RacingDemo.Runtime.Audio;
using RacingDemo.Runtime.Bootstrap;
using RacingDemo.Runtime.CameraRig;
using RacingDemo.Runtime.Input;
using RacingDemo.Runtime.Race;
using RacingDemo.Runtime.Track;
using RacingDemo.Runtime.Vehicle;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace RacingDemo.EditorTools
{
    /// <summary>
    /// Dung lai toan bo phan demo do cong cu quan ly: thu muc, material, config, scene Race.unity
    /// va cay <see cref="DemoEditorPaths.GeneratedSceneRootName"/>.
    ///
    /// Nguyen tac:
    /// - Chi cham vao Assets/Generated, Assets/Scenes/Race.unity va cay __GeneratedScene.
    /// - Do nguoi dung tu them nam ngoai cay do se duoc giu nguyen.
    /// - Asset da tune (CarConfig) chi tao khi CHUA co, khong bao gio ghi de.
    /// - Chay hai lan phai ra ket qua giong het lan dau (khong nhan doi camera/den/collider).
    ///
    /// Task 4: san van dong, checkpoint, respawn, RaceDirector va cac presenter HUD/pause/ket qua.
    /// </summary>
    public static class DemoProjectGenerator
    {
        private const string GroundMaterialPath = DemoEditorPaths.GeneratedMaterials + "/DemoGround.mat";
        private const string GrassMaterialPath = DemoEditorPaths.GeneratedMaterials + "/DemoGrass.mat";
        private const string CarConfigPath = DemoEditorPaths.GeneratedConfig + "/CarConfig.asset";
        public const string TrackConfigPath = DemoEditorPaths.GeneratedConfig + "/TrackDefinition.asset";
        private const string BarrierMaterialPath = DemoEditorPaths.GeneratedMaterials + "/DemoBarrier.mat";
        private const string MarkingMaterialPath = DemoEditorPaths.GeneratedMaterials + "/DemoMarkings.mat";

        /// <summary>Vat lieu vat ly ma sat 0 cho rao va than xe. Duoi ".asset" vi CreateAsset chi nhan duoi nay cho asset native khac Material.</summary>
        private const string SlidePhysicsPath = DemoEditorPaths.GeneratedMaterials + "/DemoSlide.asset";
        private const string MeshFolder = DemoEditorPaths.GeneratedRoot + "/Meshes";
        private const string AudioFolder = DemoEditorPaths.GeneratedRoot + "/Audio";
        private const string EngineClipPath = AudioFolder + "/EngineLoop.wav";

        /// <summary>
        /// Material cua Task 2 khong con ai dung sau khi xe chuyen sang model Kenney.
        /// Generator so huu Assets/Generated nen phai tu don, khong de lai asset mo coi.
        /// </summary>
        private static readonly string[] ObsoleteAssets =
        {
            DemoEditorPaths.GeneratedMaterials + "/DemoCarBody.mat",
            DemoEditorPaths.GeneratedMaterials + "/DemoWheel.mat",
            DemoEditorPaths.GeneratedMaterials + "/FestivalGold.mat"
        };

        private const string UrpLitShaderName = "Universal Render Pipeline/Lit";

        [MenuItem("RacingDemo/Rebuild Demo", false, 0)]
        public static void RebuildDemo()
        {
            DemoEditorPaths.EnsureNoUnsavedSceneChanges();

            EnsureFolders();
            ProjectSetup.VerifyTextMeshProEssentials();
            DeleteObsoleteAssets();

            // Task 6: cau hinh URP cho ban Android truoc khi dung scene.
            var renderChanges = new List<string>();
            RenderQualitySetup.Apply(RenderQualitySetup.MobileAssetPath, renderChanges);
            if (renderChanges.Count != 0)
                Debug.Log("[RacingDemo] Da cap nhat URP: " + string.Join(", ", renderChanges));

            // Task 7: buoc vat ly 1/60 giay theo ke hoach muc 2.
            var timestepChanges = new List<string>();
            FixedTimestepSetup.Apply(timestepChanges);
            if (timestepChanges.Count != 0)
                Debug.Log("[RacingDemo] Da cap nhat buoc vat ly: " + string.Join(", ", timestepChanges));

            EnsureMaterial(GroundMaterialPath, new Color(0.105f, 0.14f, 0.16f), 0.08f);
            EnsureMaterial(GrassMaterialPath, new Color(0.38f, 0.46f, 0.29f), 0.02f);
            EnsureMaterial(BarrierMaterialPath, new Color(0.075f, 0.23f, 0.25f), 0.15f);
            EnsureMaterial(MarkingMaterialPath, new Color(0.96f, 0.91f, 0.77f), 0.1f);
            EnsureSlidePhysicsMaterial(SlidePhysicsPath);
            if (EngineClipBuilder.EnsureClip(EngineClipPath))
                Debug.Log("[RacingDemo] Da sinh lai tieng dong co: " + EngineClipPath);
            EnsureCarConfig();
            EnsureTrackConfig();
            // Preflight BEFORE opening/replacing scene content. Tuned invalid data is reported,
            // never silently overwritten by defaults.
            var preflightErrors = new List<string>();
            TrackDefinition definition = LoadRequired<TrackDefinition>(TrackConfigPath);
            TrackSceneValidation.ValidateDefinition(definition, LoadRequired<CarConfig>(CarConfigPath), preflightErrors);
            if (preflightErrors.Count != 0)
                throw new InvalidOperationException(string.Join("\n", preflightErrors));
            EnsureMesh(MeshFolder + "/Road.asset", TrackBuilder.CreateRoadMesh(definition));
            EnsureMesh(MeshFolder + "/InnerBarrier.asset", TrackBuilder.CreateBarrierMesh(definition, true));
            EnsureMesh(MeshFolder + "/OuterBarrier.asset", TrackBuilder.CreateBarrierMesh(definition, false));
            AssetDatabase.SaveAssets();

            Scene scene = OpenOrCreateRaceScene();

            // QUAN TRONG: OpenScene/NewScene keo theo Resources.UnloadUnusedAssets, lam cac asset
            // vua load nhung chua ai tham chieu bi unload. Khi do bien C# con lai la "fake null":
            // doc field thuong van ra gia tri, nhung gan vao SerializedProperty se ghi fileID 0.
            // Vi vay phai load lai reference SAU khi scene da mo.
            Material groundMaterial = LoadRequired<Material>(GroundMaterialPath);
            Material grassMaterial = LoadRequired<Material>(GrassMaterialPath);
            AudioClip engineClip = LoadRequired<AudioClip>(EngineClipPath);
            CarConfig carConfig = LoadRequired<CarConfig>(CarConfigPath);
            TrackDefinition track = LoadRequired<TrackDefinition>(TrackConfigPath);
            Material barrier = LoadRequired<Material>(BarrierMaterialPath);
            Material markings = LoadRequired<Material>(MarkingMaterialPath);
            PhysicsMaterial slide = LoadRequired<PhysicsMaterial>(SlidePhysicsPath);
            Mesh roadMesh = LoadRequired<Mesh>(MeshFolder + "/Road.asset");
            Mesh innerMesh = LoadRequired<Mesh>(MeshFolder + "/InnerBarrier.asset");
            Mesh outerMesh = LoadRequired<Mesh>(MeshFolder + "/OuterBarrier.asset");

            GameObject generatedRoot = ResetGeneratedRoot(scene);

            BuildGeneratedContent(generatedRoot.transform, carConfig, groundMaterial, grassMaterial, engineClip,
                track, barrier, markings, roadMesh, innerMesh, outerMesh, slide);

            var sceneErrors = new List<string>();
            SceneValidator.ValidateSceneContent(scene, sceneErrors);
            if (sceneErrors.Count != 0)
                throw new InvalidOperationException(string.Join("\n", sceneErrors));

            EditorSceneManager.MarkSceneDirty(scene);
            if (!EditorSceneManager.SaveScene(scene, DemoEditorPaths.RaceScenePath))
            {
                throw new InvalidOperationException("Khong luu duoc " + DemoEditorPaths.RaceScenePath);
            }

            EnsureBuildSceneList();

            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();

            Debug.Log("[RacingDemo] RebuildDemo xong: " + DemoEditorPaths.RaceScenePath);
        }

        private static void EnsureFolders()
        {
            DemoEditorPaths.EnsureAssetFolder(DemoEditorPaths.GeneratedRoot);
            DemoEditorPaths.EnsureAssetFolder(DemoEditorPaths.GeneratedMaterials);
            DemoEditorPaths.EnsureAssetFolder(DemoEditorPaths.GeneratedConfig);
            DemoEditorPaths.EnsureAssetFolder(MeshFolder);
            DemoEditorPaths.EnsureAssetFolder(AudioFolder);
            DemoEditorPaths.EnsureAssetFolder(DemoEditorPaths.ScenesRoot);
        }

        /// <summary>Xoa asset generator tung sinh nhung nay khong con dung toi nua.</summary>
        private static void DeleteObsoleteAssets()
        {
            for (int i = 0; i < ObsoleteAssets.Length; i++)
            {
                if (AssetDatabase.LoadMainAssetAtPath(ObsoleteAssets[i]) == null) continue;
                if (!AssetDatabase.DeleteAsset(ObsoleteAssets[i]))
                    throw new InvalidOperationException("Khong xoa duoc asset cu " + ObsoleteAssets[i]);
                Debug.Log("[RacingDemo] Da xoa asset khong con dung: " + ObsoleteAssets[i]);
            }
        }

        /// <summary>
        /// Tao material neu chua co; neu da co thi cap nhat tai cho de giu nguyen GUID
        /// (khong pha reference cua scene/prefab dang tro toi no).
        /// </summary>
        private static void EnsureMaterial(string path, Color baseColor, float smoothness)
        {
            Shader shader = Shader.Find(UrpLitShaderName);
            if (shader == null)
            {
                throw new InvalidOperationException(
                    "Khong tim thay shader \"" + UrpLitShaderName + "\". Project phai dung URP.");
            }

            Material material = AssetDatabase.LoadAssetAtPath<Material>(path);
            if (material == null)
            {
                if (AssetDatabase.LoadMainAssetAtPath(path) != null)
                    throw new InvalidOperationException("Sai loai asset tai " + path);
                material = new Material(shader);
                AssetDatabase.CreateAsset(material, path);
            }
            else if (material.shader != shader)
            {
                material.shader = shader;
            }

            material.SetColor("_BaseColor", baseColor);
            material.SetFloat("_Smoothness", smoothness);
            EditorUtility.SetDirty(material);
        }

        /// <summary>
        /// PhysicsMaterial ma sat 0 cho rao va than xe. Tao neu chua co, co roi thi dat lai gia tri
        /// tai cho (giu GUID) vi day la cau hinh cua generator, khong phai asset de tune.
        /// </summary>
        private static void EnsureSlidePhysicsMaterial(string path)
        {
            PhysicsMaterial material = AssetDatabase.LoadAssetAtPath<PhysicsMaterial>(path);
            if (material == null)
            {
                if (AssetDatabase.LoadMainAssetAtPath(path) != null)
                    throw new InvalidOperationException("Sai loai asset tai " + path);
                material = new PhysicsMaterial("DemoSlide");
                TrackBuilder.ConfigureSlideMaterial(material);
                AssetDatabase.CreateAsset(material, path);
                return;
            }

            TrackBuilder.ConfigureSlideMaterial(material);
            EditorUtility.SetDirty(material);
        }

        /// <summary>
        /// CarConfig la asset de tune bang tay: chi tao khi chua co, tuyet doi khong ghi de
        /// gia tri nguoi dung da chinh.
        /// </summary>
        private static void EnsureCarConfig()
        {
            if (AssetDatabase.LoadAssetAtPath<CarConfig>(CarConfigPath) != null)
            {
                return;
            }

            var config = ScriptableObject.CreateInstance<CarConfig>();
            if (AssetDatabase.LoadMainAssetAtPath(CarConfigPath) != null)
                throw new InvalidOperationException("Sai loai asset tai " + CarConfigPath);
            AssetDatabase.CreateAsset(config, CarConfigPath);
            Debug.Log("[RacingDemo] Da tao CarConfig moi: " + CarConfigPath);
        }

        private static void EnsureTrackConfig()
        {
            if (AssetDatabase.LoadAssetAtPath<TrackDefinition>(TrackConfigPath) != null) return;
            if (AssetDatabase.LoadMainAssetAtPath(TrackConfigPath) != null)
                throw new InvalidOperationException("Sai loai asset tai " + TrackConfigPath);
            TrackDefinition track = TrackDefinition.CreateDemoDefault(LoadRequired<CarConfig>(CarConfigPath));
            AssetDatabase.CreateAsset(track, TrackConfigPath);
        }

        private static void EnsureMesh(string path, Mesh generated)
        {
            // Ten asset phai trung ten file: nhanh tao moi lay ten tu file, nhanh cap nhat giu
            // ten cua mesh nguon, nen neu lech thi Unity canh bao "Main Object Name ... does not
            // match filename" moi lan rebuild va hai duong dan cho ra byte khac nhau.
            generated.name = System.IO.Path.GetFileNameWithoutExtension(path);

            Mesh existing = AssetDatabase.LoadAssetAtPath<Mesh>(path);
            if (existing == null)
            {
                if (AssetDatabase.LoadMainAssetAtPath(path) != null)
                    throw new InvalidOperationException("Sai loai asset tai " + path);
                AssetDatabase.CreateAsset(generated, path);
            }
            else
            {
                EditorUtility.CopySerialized(generated, existing);
                UnityEngine.Object.DestroyImmediate(generated);
                EditorUtility.SetDirty(existing);
            }
        }

        /// <summary>
        /// Load asset bat buoc phai co. Nem loi ro rang thay vi de reference null lot vao scene.
        /// </summary>
        private static T LoadRequired<T>(string path) where T : UnityEngine.Object
        {
            T asset = AssetDatabase.LoadAssetAtPath<T>(path);
            if (asset == null)
            {
                throw new InvalidOperationException(
                    "Khong load duoc " + typeof(T).Name + " tai " + path + ".");
            }

            return asset;
        }

        private static Scene OpenOrCreateRaceScene()
        {
            if (System.IO.File.Exists(DemoEditorPaths.ToAbsoluteProjectPath(DemoEditorPaths.RaceScenePath)))
            {
                return EditorSceneManager.OpenScene(DemoEditorPaths.RaceScenePath, OpenSceneMode.Single);
            }

            // Tao scene rong: khong lay template de khong dinh camera/den mac dinh.
            Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            if (!EditorSceneManager.SaveScene(scene, DemoEditorPaths.RaceScenePath))
            {
                throw new InvalidOperationException("Khong tao duoc " + DemoEditorPaths.RaceScenePath);
            }

            return scene;
        }

        /// <summary>Xoa toan bo cay do generator quan ly roi tao lai rong.</summary>
        private static GameObject ResetGeneratedRoot(Scene scene)
        {
            GameObject[] roots = scene.GetRootGameObjects();
            for (int i = 0; i < roots.Length; i++)
            {
                if (roots[i].name == DemoEditorPaths.GeneratedSceneRootName)
                {
                    UnityEngine.Object.DestroyImmediate(roots[i]);
                }
            }

            var generatedRoot = new GameObject(DemoEditorPaths.GeneratedSceneRootName);
            SceneManager.MoveGameObjectToScene(generatedRoot, scene);
            return generatedRoot;
        }

        private static void BuildGeneratedContent(
            Transform root,
            CarConfig carConfig,
            Material groundMaterial,
            Material grassMaterial,
            AudioClip engineClip, TrackDefinition track, Material barrier, Material markings,
            Mesh roadMesh, Mesh innerMesh, Mesh outerMesh, PhysicsMaterial slide)
        {
            CreateBootstrap(root);
            CreateDirectionalLight(root);

            CarController car = CarBuilder.Build(root, carConfig, slide);
            FestivalVisuals.PaintCar(car.transform);
            car.transform.SetPositionAndRotation(track.StartPose.Position, track.StartPose.Rotation);
            GameObject trackRoot = TrackBuilder.Build(root, track, car.GetComponent<Rigidbody>(), groundMaterial,
                barrier, markings, grassMaterial, roadMesh, innerMesh, outerMesh, slide);
            var respawn = trackRoot.AddComponent<RespawnService>();
            using (var binder = new FieldBinder(respawn)) binder.SetObject("_track", track);
            DecorBuilder.Build(trackRoot.transform, track);
            FestivalVisuals.Build(trackRoot.transform, track);

            ChaseCamera chaseCamera = CreateCamera(root, car);
            EngineAudio engineAudio = CreateEngineAudio(car, engineClip);
            FestivalAudio festivalAudio = FestivalAudioBuilder.Build(root, engineAudio);
            CarInputRelay inputRelay = CreateInputRelay(root, car);
            UiBuilder.Result ui = UiBuilder.Build(root, inputRelay);

            using (var binder = new FieldBinder(inputRelay))
            {
                binder.SetObject("_touchPad", ui.TouchPad);
            }

            CreateRaceDirector(root, car, inputRelay, chaseCamera, ui, track, respawn, engineAudio, festivalAudio);
        }

        /// <summary>
        /// Tieng dong co gan tren xe. AudioListener van chi co dung mot cai tren camera —
        /// khong them listener o day.
        /// </summary>
        private static EngineAudio CreateEngineAudio(CarController car, AudioClip clip)
        {
            var audioObject = new GameObject("EngineAudio");
            audioObject.transform.SetParent(car.transform, false);

            var source = audioObject.AddComponent<AudioSource>();
            source.clip = clip;
            source.loop = true;
            source.playOnAwake = false;
            source.spatialBlend = 0f;

            var engineAudio = audioObject.AddComponent<EngineAudio>();
            using (var binder = new FieldBinder(engineAudio))
            {
                binder.SetObject("_car", car).SetObject("_source", source);
            }

            return engineAudio;
        }

        private static void CreateBootstrap(Transform root)
        {
            var bootstrap = new GameObject("AppBootstrap");
            bootstrap.transform.SetParent(root, false);
            bootstrap.AddComponent<AppBootstrap>();
        }

        private static void CreateDirectionalLight(Transform root)
        {
            var lightObject = new GameObject("Directional Light");
            lightObject.transform.SetParent(root, false);
            lightObject.transform.rotation = Quaternion.Euler(28f, -38f, 0f);

            Light light = lightObject.AddComponent<Light>();
            light.type = LightType.Directional;
            light.color = new Color(1f, 0.83f, 0.64f);
            light.intensity = 1.25f;
            light.shadows = LightShadows.Hard;
            RenderSettings.sun = light;
        }

        private static ChaseCamera CreateCamera(Transform root, CarController car)
        {
            Transform target = car.transform;
            var cameraObject = new GameObject("Main Camera");
            cameraObject.tag = "MainCamera";
            cameraObject.transform.SetParent(root, false);

            Camera camera = cameraObject.AddComponent<Camera>();
            camera.fieldOfView = 62f;
            camera.nearClipPlane = 0.2f;
            camera.farClipPlane = 400f;
            camera.clearFlags = CameraClearFlags.Skybox;

            cameraObject.AddComponent<AudioListener>();

            var chaseCamera = cameraObject.AddComponent<ChaseCamera>();
            using (var binder = new FieldBinder(chaseCamera))
            {
                // _car cap toc do de noi goc nhin theo van toc (gop y tren Xiaomi 14).
                binder.SetObject("_target", target).SetObject("_car", car);
            }

            return chaseCamera;
        }

        private static CarInputRelay CreateInputRelay(Transform root, CarController car)
        {
            var inputObject = new GameObject("Input");
            inputObject.transform.SetParent(root, false);

            var relay = inputObject.AddComponent<CarInputRelay>();
            using (var binder = new FieldBinder(relay))
            {
                binder.SetObject("_car", car);
            }

            return relay;
        }

        /// <summary>
        /// Task 4: mot RaceDirector duy nhat noi Core voi xe, camera, checkpoint, timeScale,
        /// respawn va UI. Moi nut menu duoc noi ngay tai day de reference trong Inspector
        /// va thao tac that luon khop nhau.
        /// </summary>
        private static void CreateRaceDirector(
            Transform root,
            CarController car,
            CarInputRelay inputRelay,
            ChaseCamera chaseCamera,
            UiBuilder.Result ui, TrackDefinition track, RespawnService respawn, EngineAudio engineAudio, FestivalAudio festivalAudio)
        {
            var directorObject = new GameObject("RaceDirector");
            directorObject.transform.SetParent(root, false);

            var director = directorObject.AddComponent<RaceDirector>();
            using (var binder = new FieldBinder(director))
            {
                binder
                    .SetObject("_car", car)
                    .SetObject("_input", inputRelay)
                    .SetObject("_chaseCamera", chaseCamera)
                    .SetObject("_track", track)
                    .SetObject("_respawn", respawn)
                    .SetObject("_hud", ui.Hud)
                    .SetObject("_pauseMenu", ui.PauseMenu)
                    .SetObject("_results", ui.Results)
                    .SetObject("_engineAudio", engineAudio)
                    .SetObject("_festival", ui.Festival)
                    .SetObject("_festivalAudio", festivalAudio)
                    .SetObjects("_drivingGroups", ui.DrivingGroups);
            }

            using (var binder = new FieldBinder(ui.Festival))
            {
                binder.SetObject("_audio", festivalAudio);
            }

            UnityEditor.Events.UnityEventTools.AddVoidPersistentListener(ui.StartButton.onClick, director.StartRace);
            UnityEditor.Events.UnityEventTools.AddVoidPersistentListener(ui.PauseFestivalButton.onClick, director.ReturnToFestival);
            UnityEditor.Events.UnityEventTools.AddVoidPersistentListener(ui.ResultsFestivalButton.onClick, director.ReturnToFestival);
            foreach (var button in ui.MusicButtons)
                UnityEditor.Events.UnityEventTools.AddVoidPersistentListener(button.onClick, festivalAudio.ToggleMusic);
            foreach (var button in ui.EffectsButtons)
                UnityEditor.Events.UnityEventTools.AddVoidPersistentListener(button.onClick, festivalAudio.ToggleEffects);

            UnityEditor.Events.UnityEventTools.AddVoidPersistentListener(
                ui.ResumeButton.onClick, director.Resume);
            UnityEditor.Events.UnityEventTools.AddVoidPersistentListener(
                ui.PauseRestartButton.onClick, director.Restart);
            UnityEditor.Events.UnityEventTools.AddVoidPersistentListener(
                ui.ResultsRestartButton.onClick, director.Restart);
        }

        private static void EnsureBuildSceneList()
        {
            var scenes = new List<EditorBuildSettingsScene>
            {
                new EditorBuildSettingsScene(DemoEditorPaths.RaceScenePath, true)
            };

            EditorBuildSettings.scenes = scenes.ToArray();
        }
    }
}
