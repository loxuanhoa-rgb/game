using System;
using System.Collections.Generic;
using UnityEngine;

namespace RacingDemo.Runtime.Track
{
    /// <summary>
    /// Reports a player's forward traversal of the gate's local Z=centre plane.
    /// Race phase and checkpoint order are deliberately left to Core.
    /// The coordinator must call ClearTraversal before teleporting the car.
    /// </summary>
    [RequireComponent(typeof(BoxCollider))]
    [DisallowMultipleComponent]
    public sealed class CheckpointVolume : MonoBehaviour
    {
        private static readonly Predicate<Collider> MissingColliderPredicate = IsMissingCollider;

        [SerializeField] private Rigidbody _playerBody;
        [SerializeField] private int _order;

        private readonly HashSet<Collider> _overlaps = new HashSet<Collider>();
        private BoxCollider _trigger;
        private Rigidbody _cachedBody;
        private Collider[] _playerColliders;
        private Vector3 _previousLocalPosition;
        private bool _hasPreviousPosition;
        private bool _armed;
        private bool _enteredFromApproach;
        private bool _passedThisTraversal;

        public Rigidbody PlayerBody { get { return _playerBody; } }
        public int Order { get { return _order; } }
        public event Action<int> Passed;

        private void Awake()
        {
            _trigger = GetComponent<BoxCollider>();
        }

        private void OnDisable()
        {
            ClearTraversal();
        }

        private void FixedUpdate()
        {
            if (_playerBody == null || _playerBody.isKinematic || _trigger == null ||
                !_trigger.enabled || !_trigger.isTrigger)
            {
                ClearTraversal();
                return;
            }

            if (_cachedBody != _playerBody)
            {
                ClearTraversal();
                _cachedBody = _playerBody;
                _playerColliders = _playerBody.GetComponentsInChildren<Collider>();
            }

            _overlaps.RemoveWhere(MissingColliderPredicate);
            Vector3 localPosition = LocalPosition();

            // Re-arm only while the WHOLE car is outside the approach face. A car
            // spawned inside, or unlocked inside after respawn, cannot earn a pass.
            if (_overlaps.Count == 0)
            {
                // Keep a valid approach latched across the contact boundary: Unity may
                // report Enter one simulation step after the leading collider touches it.
                // Requiring the whole car to STILL be outside then loses every pass.
                if (!IsWithinOpening(localPosition) || localPosition.z >= -_trigger.size.z * 0.5f)
                    _armed = false;
                else if (EntireBodyBehindApproach())
                    _armed = true;
                _enteredFromApproach = false;
                _passedThisTraversal = false;
            }

            // FixedUpdate samples before physics. Events below run in physics
            // callbacks, after the director has ticked Core for this same step.
            _previousLocalPosition = localPosition;
            _hasPreviousPosition = true;
        }

        private void OnTriggerEnter(Collider other)
        {
            ObserveOverlap(other);
        }

        private void OnTriggerStay(Collider other)
        {
            ObserveOverlap(other);
        }

        private void OnTriggerExit(Collider other)
        {
            if (!IsPlayerCollider(other))
            {
                return;
            }

            _overlaps.Remove(other);
            if (_overlaps.Count == 0)
            {
                _armed = false;
                _enteredFromApproach = false;
                _passedThisTraversal = false;
            }
        }

        /// <summary>
        /// Discards overlaps and pre-teleport samples. Call for every gate BEFORE
        /// ResetTo/Restart; no automatic pass is inferred from a teleport.
        /// </summary>
        public void ClearTraversal()
        {
            _overlaps.Clear();
            _hasPreviousPosition = false;
            _armed = false;
            _enteredFromApproach = false;
            _passedThisTraversal = false;
        }

        private void ObserveOverlap(Collider other)
        {
            if (!isActiveAndEnabled || !IsPlayerCollider(other))
            {
                return;
            }

            if (_playerBody.isKinematic)
            {
                ClearTraversal();
                return;
            }

            if (_overlaps.Count == 0)
            {
                // Do not arm from a lateral entry or from an existing overlap.
                _enteredFromApproach = _armed && _hasPreviousPosition &&
                    _previousLocalPosition.z < -_trigger.size.z * 0.5f &&
                    IsWithinOpening(_previousLocalPosition);
                _armed = false;
            }

            _overlaps.Add(other);
            if (!_enteredFromApproach || _passedThisTraversal || !_hasPreviousPosition)
            {
                return;
            }

            Vector3 currentLocalPosition = LocalPosition();
            if (_previousLocalPosition.z < 0f && currentLocalPosition.z >= 0f &&
                IsWithinOpening(currentLocalPosition))
            {
                // Latch BEFORE invoking subscribers: all colliders share one
                // Rigidbody traversal, even when several callbacks arrive now.
                _passedThisTraversal = true;
                Passed?.Invoke(_order);
            }
        }

        private bool IsPlayerCollider(Collider other)
        {
            return _playerBody != null && other != null && !other.isTrigger &&
                other.attachedRigidbody == _playerBody;
        }

        private Vector3 LocalPosition()
        {
            return transform.InverseTransformPoint(_playerBody.position) - _trigger.center;
        }

        private bool IsWithinOpening(Vector3 point)
        {
            Vector3 halfSize = _trigger.size * 0.5f;
            return Mathf.Abs(point.x) <= halfSize.x && Mathf.Abs(point.y) <= halfSize.y;
        }

        private bool EntireBodyBehindApproach()
        {
            Vector3 forward = transform.forward;
            Vector3 absoluteForward = new Vector3(
                Mathf.Abs(forward.x), Mathf.Abs(forward.y), Mathf.Abs(forward.z));
            Vector3 gateCenter = transform.TransformPoint(_trigger.center);
            float approachPlane = -_trigger.size.z * Mathf.Abs(transform.lossyScale.z) * 0.5f;
            bool foundSolidCollider = false;
            foreach (Collider collider in _playerColliders)
            {
                if (IsMissingCollider(collider) || collider.isTrigger ||
                    collider.attachedRigidbody != _playerBody)
                {
                    continue;
                }

                foundSolidCollider = true;
                Bounds bounds = collider.bounds;
                // Conservative projection of each world AABB handles compound
                // colliders and avoids treating an overlapping bumper as outside.
                float leadingEdge = Vector3.Dot(bounds.center - gateCenter, forward) +
                    Vector3.Dot(bounds.extents, absoluteForward);
                if (leadingEdge >= approachPlane)
                {
                    return false;
                }
            }

            return foundSolidCollider;
        }

        private static bool IsMissingCollider(Collider collider)
        {
            return collider == null || !collider.enabled || !collider.gameObject.activeInHierarchy;
        }
    }
}
