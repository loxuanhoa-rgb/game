using System;
using UnityEngine;

namespace RacingDemo.Runtime.Track
{
    /// <summary>Chi tra pose tu du lieu. Core quyet dinh khi nao reset duoc chap nhan.</summary>
    public sealed class RespawnService : MonoBehaviour
    {
        [SerializeField] private TrackDefinition _track;

        public TrackDefinition Track => _track;

        public void GetRespawnPose(int? lastAcceptedCheckpointIndex, out Vector3 position, out Quaternion rotation)
        {
            if (_track == null)
                throw new InvalidOperationException("RespawnService chua duoc gan TrackDefinition.");

            TrackPose pose = _track.StartPose;
            if (lastAcceptedCheckpointIndex.HasValue)
            {
                int index = lastAcceptedCheckpointIndex.Value;
                if (_track.Checkpoints == null || index < 0 || index >= _track.Checkpoints.Length)
                    throw new ArgumentOutOfRangeException(nameof(lastAcceptedCheckpointIndex));
                TrackCheckpoint checkpoint = _track.Checkpoints[index];
                if (checkpoint == null)
                    throw new InvalidOperationException("Checkpoint " + index + " bi thieu trong TrackDefinition.");
                pose = checkpoint.RespawnPose;
            }

            position = pose.Position;
            rotation = pose.Rotation;
        }
    }
}
