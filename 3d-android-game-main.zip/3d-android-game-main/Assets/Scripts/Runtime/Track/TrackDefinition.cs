using System;
using RacingDemo.Core.Racing;
using RacingDemo.Core.Scoring;
using RacingDemo.Runtime.Vehicle;
using UnityEngine;

namespace RacingDemo.Runtime.Track
{
    [Serializable]
    public struct TrackPose
    {
        public Vector3 Position;
        public Vector3 EulerAngles;

        public TrackPose(Vector3 position, Quaternion rotation)
        {
            Position = position;
            EulerAngles = rotation.eulerAngles;
        }

        public Quaternion Rotation => Quaternion.Euler(EulerAngles);
    }

    [Serializable]
    public sealed class TrackCheckpoint
    {
        public int Order;
        [Tooltip("Khoang cach doc tim duong theo chieu chay, tinh tu vach dich (m).")]
        public float Distance;
        public TrackPose RespawnPose;
    }

    /// <summary>
    /// Du lieu Unity duoc tune trong Inspector; Core chi nhan so checkpoint va cac so luat dua.
    /// Generator chi tao asset khi chua co, khong dat lai cac gia tri khi rebuild.
    /// </summary>
    [CreateAssetMenu(menuName = "RacingDemo/Track Definition", fileName = "TrackDefinition")]
    public sealed class TrackDefinition : ScriptableObject
    {
        [Header("Dinh danh va luat dua")]
        public string TrackId = "stadium-80-r30-v1";
        public int LapCount = 2;
        public float CountdownSeconds = 3f;
        public float RespawnLockSeconds = 1.5f;

        [Header("Huy chuong tam, chua tune (giay)")]
        public float GoldSeconds = 85f;
        public float SilverSeconds = 100f;
        public float BronzeSeconds = 120f;

        [Header("San van dong phang (met)")]
        public float StraightLength = 80f;
        public float CenterRadius = 30f;
        public float RoadWidth = 12f;
        public float SurfaceHeight;

        [Header("Cong checkpoint (met)")]
        public float TriggerDepth = 4f;
        public float TriggerHeight = 4f;

        [Header("Pose trong toa do scene; checkpoint cuoi la vach dich")]
        public TrackPose StartPose;
        public TrackCheckpoint[] Checkpoints = Array.Empty<TrackCheckpoint>();

        public RaceConfig CreateRaceConfig()
        {
            return new RaceConfig(Checkpoints.Length, LapCount, CountdownSeconds, RespawnLockSeconds);
        }

        public MedalThresholds CreateMedalThresholds()
        {
            return new MedalThresholds(GoldSeconds, SilverSeconds, BronzeSeconds);
        }

        /// <summary>
        /// Tao mot instance MOI cho generator. Khong goi tren asset da co de giu nguyen tuning.
        /// Goc xe o truc banh; them du hanh trinh giam xoc de banh khong xuyen nen luc teleport.
        /// </summary>
        public static TrackDefinition CreateDemoDefault(CarConfig car)
        {
            if (car == null) throw new ArgumentNullException(nameof(car));
            if (!StadiumGeometry.IsFinite(car.WheelRadius) || car.WheelRadius <= 0f)
                throw new ArgumentOutOfRangeException(nameof(car), "Ban kinh banh phai huu han va duong.");
            if (!StadiumGeometry.IsFinite(car.SuspensionDistance) || car.SuspensionDistance < 0f)
                throw new ArgumentOutOfRangeException(nameof(car), "Hanh trinh giam xoc phai huu han va khong am.");

            var track = CreateInstance<TrackDefinition>();
            var geometry = new StadiumGeometry(track);
            float spawnHeight = track.SurfaceHeight + car.WheelRadius + car.SuspensionDistance + 0.05f;
            track.StartPose = CreatePose(geometry, geometry.Length - 8f, spawnHeight);
            track.Checkpoints = new TrackCheckpoint[4];
            for (int index = 0; index < track.Checkpoints.Length; index++)
            {
                float distance = index == 3 ? 0f : geometry.Length * (index + 1) / 4f;
                track.Checkpoints[index] = new TrackCheckpoint
                {
                    Order = index,
                    Distance = distance,
                    RespawnPose = CreatePose(geometry, distance + 8f, spawnHeight)
                };
            }

            return track;
        }

        private static TrackPose CreatePose(StadiumGeometry geometry, float distance, float height)
        {
            geometry.Evaluate(distance, out Vector3 position, out Vector3 forward);
            position.y = height;
            return new TrackPose(position, Quaternion.LookRotation(forward, Vector3.up));
        }
    }
}
