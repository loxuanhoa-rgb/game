using System;
using System.Collections.Generic;
using UnityEngine;

namespace RacingDemo.Runtime.Track
{
    /// <summary>
    /// Hinh hoc xac dinh, khong dung scene hay dong ho. Moc 0 o giua doan thang ben +X,
    /// huong +Z; hai cung re trai. Moi khoang cach deu duoc lap lai theo chu vi.
    /// </summary>
    public sealed class StadiumGeometry
    {
        public float StraightLength { get; }
        public float CenterRadius { get; }
        public float RoadWidth { get; }
        public float SurfaceHeight { get; }
        public float Length { get; }

        public StadiumGeometry(TrackDefinition track)
            : this(RequireTrack(track).StraightLength, track.CenterRadius, track.RoadWidth, track.SurfaceHeight)
        {
        }

        public StadiumGeometry(float straightLength, float centerRadius, float roadWidth, float surfaceHeight = 0f)
        {
            RequirePositive(straightLength, nameof(straightLength));
            RequirePositive(centerRadius, nameof(centerRadius));
            RequirePositive(roadWidth, nameof(roadWidth));
            RequireFinite(surfaceHeight, nameof(surfaceHeight));
            if (roadWidth >= 2f * centerRadius)
                throw new ArgumentOutOfRangeException(nameof(roadWidth), "Bien trong phai co ban kinh duong.");

            StraightLength = straightLength;
            CenterRadius = centerRadius;
            RoadWidth = roadWidth;
            SurfaceHeight = surfaceHeight;
            Length = 2f * straightLength + 2f * Mathf.PI * centerRadius;
            RequireFinite(Length, nameof(straightLength));
        }

        public void Evaluate(float distance, out Vector3 position, out Vector3 forward)
        {
            RequireFinite(distance, nameof(distance));
            float along = WrapDistance(distance);
            float halfStraight = StraightLength * 0.5f;
            float halfArc = Mathf.PI * CenterRadius;

            if (along < halfStraight)
            {
                position = new Vector3(CenterRadius, SurfaceHeight, along);
                forward = Vector3.forward;
            }
            else if (along < halfStraight + halfArc)
            {
                float angle = (along - halfStraight) / CenterRadius;
                float sine = Mathf.Sin(angle);
                float cosine = Mathf.Cos(angle);
                position = new Vector3(CenterRadius * cosine, SurfaceHeight, halfStraight + CenterRadius * sine);
                forward = new Vector3(-sine, 0f, cosine);
            }
            else if (along < halfStraight + halfArc + StraightLength)
            {
                position = new Vector3(-CenterRadius, SurfaceHeight, halfStraight - (along - halfStraight - halfArc));
                forward = Vector3.back;
            }
            else if (along < halfStraight + 2f * halfArc + StraightLength)
            {
                float angle = Mathf.PI + (along - halfStraight - halfArc - StraightLength) / CenterRadius;
                float sine = Mathf.Sin(angle);
                float cosine = Mathf.Cos(angle);
                position = new Vector3(CenterRadius * cosine, SurfaceHeight, -halfStraight + CenterRadius * sine);
                forward = new Vector3(-sine, 0f, cosine);
            }
            else
            {
                position = new Vector3(CenterRadius, SurfaceHeight, along - Length);
                forward = Vector3.forward;
            }
        }

        /// <summary>Co mau o moi diem tiep tuyen va lap lai diem dau o cuoi de ghep mesh kin.</summary>
        public float[] CreateSampleDistances(float maxSegmentLength = 2f)
        {
            RequirePositive(maxSegmentLength, nameof(maxSegmentLength));
            float halfStraight = StraightLength * 0.5f;
            float halfArc = Mathf.PI * CenterRadius;
            float[] boundaries =
            {
                0f, halfStraight, halfStraight + halfArc,
                halfStraight + halfArc + StraightLength,
                halfStraight + 2f * halfArc + StraightLength, Length
            };
            var distances = new List<float> { 0f };
            for (int section = 0; section < boundaries.Length - 1; section++)
            {
                float start = boundaries[section];
                float end = boundaries[section + 1];
                double requestedCount = Math.Ceiling((double)(end - start) / maxSegmentLength);
                if (requestedCount > 100000 || distances.Count + requestedCount > 100000)
                    throw new ArgumentOutOfRangeException(nameof(maxSegmentLength), "Qua nhieu phan doan duong.");
                int count = (int)requestedCount;
                for (int step = 1; step <= count; step++)
                    distances.Add(step == count ? end : Mathf.Lerp(start, end, (float)step / count));
            }
            return distances.ToArray();
        }

        /// <summary>Khoang cach ngang toi tim duong; bo qua do cao.</summary>
        public float DistanceFromCenterline(Vector3 point)
        {
            RequireFinite(point);
            float beyondStraight = Mathf.Max(Mathf.Abs(point.z) - StraightLength * 0.5f, 0f);
            return Mathf.Abs(Mathf.Sqrt(point.x * point.x + beyondStraight * beyondStraight) - CenterRadius);
        }

        public bool ContainsRoadPoint(Vector3 point, float lateralMargin = 0f, float heightTolerance = 0.1f)
        {
            RequireFinite(point);
            RequireNonNegative(lateralMargin, nameof(lateralMargin));
            RequireNonNegative(heightTolerance, nameof(heightTolerance));
            return Mathf.Abs(point.y - SurfaceHeight) <= heightTolerance &&
                   DistanceFromCenterline(point) <= RoadWidth * 0.5f - lateralMargin;
        }

        /// <summary>Chieu diem len tim duong va tra khoang cach [0, Length), huu ich cho validator.</summary>
        public float GetDistanceAlongTrack(Vector3 point)
        {
            RequireFinite(point);
            float halfStraight = StraightLength * 0.5f;
            float halfArc = Mathf.PI * CenterRadius;
            if (point.z > halfStraight)
                return halfStraight + CenterRadius * Mathf.Atan2(point.z - halfStraight, point.x);
            if (point.z < -halfStraight)
            {
                float bottomAngle = Mathf.Atan2(point.z + halfStraight, point.x) + Mathf.PI;
                return halfStraight + halfArc + StraightLength + CenterRadius * bottomAngle;
            }
            return point.x >= 0f ? WrapDistance(point.z) : halfStraight + halfArc + halfStraight - point.z;
        }

        public static bool IsFinite(float value) => !float.IsNaN(value) && !float.IsInfinity(value);

        private float WrapDistance(float distance)
        {
            float wrapped = distance % Length;
            return wrapped < 0f ? wrapped + Length : wrapped;
        }

        private static TrackDefinition RequireTrack(TrackDefinition track)
        {
            if (track == null) throw new ArgumentNullException(nameof(track));
            return track;
        }

        private static void RequireFinite(Vector3 point)
        {
            if (!IsFinite(point.x) || !IsFinite(point.y) || !IsFinite(point.z))
                throw new ArgumentOutOfRangeException(nameof(point), "Vi tri phai huu han.");
        }

        private static void RequireFinite(float value, string name)
        {
            if (!IsFinite(value)) throw new ArgumentOutOfRangeException(name, "Gia tri phai huu han.");
        }

        private static void RequirePositive(float value, string name)
        {
            RequireFinite(value, name);
            if (value <= 0f) throw new ArgumentOutOfRangeException(name, "Gia tri phai duong.");
        }

        private static void RequireNonNegative(float value, string name)
        {
            RequireFinite(value, name);
            if (value < 0f) throw new ArgumentOutOfRangeException(name, "Gia tri phai khong am.");
        }
    }
}
