using RacingDemo.Runtime.Vehicle;
using UnityEngine;

namespace RacingDemo.Runtime.CameraRig
{
    /// <summary>
    /// Camera bam sau xe. Bam trong LateUpdate de doc pose xe sau khi da noi suy.
    /// <see cref="SnapToTarget"/> dat dung vi tri va huong ngay lap tuc: tinh vi tri moi truoc,
    /// roi tinh huong nhin TU vi tri moi, va xoa gia tri lam muot cu.
    /// Goc nhin noi rong theo toc do (tu <see cref="_fieldOfView"/> luc dung yen len
    /// <see cref="_fieldOfViewAtMaxSpeed"/> o MaxSpeedKph) de tang cam giac toc do.
    /// </summary>
    public sealed class ChaseCamera : MonoBehaviour
    {
        [SerializeField] private Transform _target;

        [Tooltip("Xe cap toc do de noi goc nhin. Bo trong thi goc nhin co dinh.")]
        [SerializeField] private CarController _car;

        [Tooltip("Vi tri camera trong he toa do cua xe.")]
        [SerializeField] private Vector3 _localOffset = new Vector3(0f, 3.2f, -7.5f);

        [Tooltip("Diem nhin cao hon goc xe bao nhieu met.")]
        [SerializeField] private float _lookAtHeight = 1.4f;

        [SerializeField] private float _positionSmoothTime = 0.12f;
        [SerializeField] private float _rotationLerpSpeed = 8f;

        [Tooltip("Goc nhin khi xe dung yen (do).")]
        [SerializeField] private float _fieldOfView = 62f;

        [Tooltip("Goc nhin khi xe dat CarConfig.MaxSpeedKph (do). Bang _fieldOfView thi tat hieu ung.")]
        [SerializeField] private float _fieldOfViewAtMaxSpeed = 72f;

        [Tooltip("Toc do bam cua goc nhin (1/giay), cung cach lam muot voi huong nhin.")]
        [SerializeField] private float _fieldOfViewLerpSpeed = 4f;

        private Camera _camera;
        private Vector3 _smoothVelocity;

        public Transform Target
        {
            get { return _target; }
        }

        public void SetTarget(Transform target)
        {
            _target = target;
        }

        private void Awake()
        {
            _camera = GetComponent<Camera>();
            if (_camera != null)
            {
                _camera.fieldOfView = _fieldOfView;
            }
        }

        private void LateUpdate()
        {
            if (_target == null)
            {
                return;
            }

            Vector3 desiredPosition = ComputeDesiredPosition();
            transform.position = Vector3.SmoothDamp(
                transform.position, desiredPosition, ref _smoothVelocity, _positionSmoothTime);

            Quaternion desiredRotation = ComputeLookRotation(transform.position);

            // Lam muot theo thoi gian, khong phu thuoc frame rate.
            float t = 1f - Mathf.Exp(-_rotationLerpSpeed * Time.deltaTime);
            transform.rotation = Quaternion.Slerp(transform.rotation, desiredRotation, t);

            if (_camera != null)
            {
                float fovT = 1f - Mathf.Exp(-_fieldOfViewLerpSpeed * Time.deltaTime);
                _camera.fieldOfView = Mathf.Lerp(_camera.fieldOfView, TargetFieldOfView(), fovT);
            }
        }

        /// <summary>
        /// Ham thuan de test: goc nhin tuyen tinh theo |toc do| / toc do toi da, kep trong [0, 1].
        /// Toc do toi da khong duong thi tra ve goc dung yen.
        /// </summary>
        public static float EvaluateFieldOfView(float restFov, float maxSpeedFov, float speedKph, float maxSpeedKph)
        {
            if (maxSpeedKph <= 0f)
            {
                return restFov;
            }

            float t = Mathf.Clamp01(Mathf.Abs(speedKph) / maxSpeedKph);
            return Mathf.Lerp(restFov, maxSpeedFov, t);
        }

        private float TargetFieldOfView()
        {
            if (_car == null || _car.Config == null)
            {
                return _fieldOfView;
            }

            return EvaluateFieldOfView(_fieldOfView, _fieldOfViewAtMaxSpeed, _car.SpeedKph, _car.Config.MaxSpeedKph);
        }

        /// <summary>Dat camera dung cho ngay, khong noi suy tu pose cu (dung khi reset xe).</summary>
        public void SnapToTarget()
        {
            if (_target == null)
            {
                return;
            }

            Vector3 desiredPosition = ComputeDesiredPosition();
            transform.position = desiredPosition;
            transform.rotation = ComputeLookRotation(desiredPosition);
            _smoothVelocity = Vector3.zero;
            if (_camera != null)
            {
                _camera.fieldOfView = TargetFieldOfView();
            }
        }

        private Vector3 ComputeDesiredPosition()
        {
            return _target.TransformPoint(_localOffset);
        }

        private Quaternion ComputeLookRotation(Vector3 fromPosition)
        {
            Vector3 lookTarget = _target.position + Vector3.up * _lookAtHeight;
            Vector3 direction = lookTarget - fromPosition;

            if (direction.sqrMagnitude < 0.0001f)
            {
                return transform.rotation;
            }

            return Quaternion.LookRotation(direction, Vector3.up);
        }
    }
}
