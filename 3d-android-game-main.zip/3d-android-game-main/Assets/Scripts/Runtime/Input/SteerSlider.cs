using UnityEngine;
using UnityEngine.EventSystems;

namespace RacingDemo.Runtime.Input
{
    /// <summary>
    /// Thanh lai analog thay cho hai nut trai/phai (gop y khi choi that tren Xiaomi 14).
    /// Cham hoac keo ngon tren thanh: do lech ngang so voi tam quyet dinh steer trong [-1, 1],
    /// co vung chet quanh tam va kep o +-1 khi qua <see cref="_fullSteerDistance"/>.
    /// Theo doi dung mot pointer nhu <see cref="HoldButton"/>; nha ngon, tat object, mat focus
    /// hay pause deu tra ve 0 de khong ket lai.
    /// </summary>
    public sealed class SteerSlider : MonoBehaviour,
        IPointerDownHandler, IDragHandler, IPointerUpHandler, IEndDragHandler
    {
        [Tooltip("Khoang cach (don vi UI) tu tam den vi tri lai het co. Xa hon thi kep o +-1.")]
        [SerializeField] private float _fullSteerDistance = 115f;

        [Tooltip("Ban kinh vung chet quanh tam (don vi UI): cham dung giua thi khong lai.")]
        [SerializeField] private float _deadZone = 10f;

        [Tooltip("Num hien vi tri ngon; tuy chon. Chay theo ngon, kep trong +-_fullSteerDistance.")]
        [SerializeField] private RectTransform _knob;

        private RectTransform _rect;
        private int _heldPointerId;
        private bool _isHeld;
        private float _value;

        /// <summary>True khi dang co ngon tren thanh.</summary>
        public bool IsHeld
        {
            get { return _isHeld; }
        }

        /// <summary>[-1, 1]: duong la lai phai, am la lai trai; 0 khi khong cham.</summary>
        public float Value
        {
            get { return _value; }
        }

        /// <summary>
        /// Ham thuan: do lech ngang (don vi UI) -> steer. Trong vung chet tra ve 0; tu bien vung chet
        /// den <paramref name="fullSteerDistance"/> tang tuyen tinh toi 1; xa hon kep o 1. Giu dau.
        /// </summary>
        public static float Evaluate(float localX, float fullSteerDistance, float deadZone)
        {
            deadZone = Mathf.Max(0f, deadZone);
            if (fullSteerDistance <= deadZone)
            {
                // Cau hinh vo nghia: coi moi cham ngoai vung chet la het lai.
                return Mathf.Abs(localX) <= deadZone ? 0f : Mathf.Sign(localX);
            }

            float distance = Mathf.Abs(localX);
            if (distance <= deadZone)
            {
                return 0f;
            }

            float t = Mathf.Clamp01((distance - deadZone) / (fullSteerDistance - deadZone));
            return Mathf.Sign(localX) * t;
        }

        private void Awake()
        {
            _rect = (RectTransform)transform;
            MoveKnob(0f);
        }

        public void OnPointerDown(PointerEventData eventData)
        {
            if (_isHeld)
            {
                // Da co ngon khac tren thanh; bo qua de khong mat dau pointer dau tien.
                return;
            }

            _isHeld = true;
            _heldPointerId = eventData.pointerId;
            UpdateFromPointer(eventData);
        }

        public void OnDrag(PointerEventData eventData)
        {
            if (_isHeld && eventData.pointerId == _heldPointerId)
            {
                UpdateFromPointer(eventData);
            }
        }

        public void OnPointerUp(PointerEventData eventData)
        {
            // uGUI gui PointerUp ve object da nhan PointerDown ke ca khi ngon da re ra ngoai rect.
            if (_isHeld && eventData.pointerId == _heldPointerId)
            {
                ClearHeldState();
            }
        }

        public void OnEndDrag(PointerEventData eventData)
        {
            if (_isHeld && eventData.pointerId == _heldPointerId)
            {
                ClearHeldState();
            }
        }

        /// <summary>Tra thanh ve 0 va num ve tam. Resume chi nhan lan cham moi.</summary>
        public void ClearHeldState()
        {
            _isHeld = false;
            _heldPointerId = 0;
            _value = 0f;
            MoveKnob(0f);
        }

        private void UpdateFromPointer(PointerEventData eventData)
        {
            Vector2 local;
            if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(
                    _rect, eventData.position, eventData.pressEventCamera, out local))
            {
                return;
            }

            _value = Evaluate(local.x, _fullSteerDistance, _deadZone);
            MoveKnob(Mathf.Clamp(local.x, -_fullSteerDistance, _fullSteerDistance));
        }

        private void MoveKnob(float localX)
        {
            if (_knob != null)
            {
                _knob.anchoredPosition = new Vector2(localX, 0f);
            }
        }

        private void OnDisable()
        {
            ClearHeldState();
        }

        private void OnApplicationFocus(bool hasFocus)
        {
            if (!hasFocus)
            {
                ClearHeldState();
            }
        }

        private void OnApplicationPause(bool isPaused)
        {
            if (isPaused)
            {
                ClearHeldState();
            }
        }
    }
}
