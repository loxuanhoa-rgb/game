using System;
using RacingDemo.Runtime.Vehicle;
using UnityEngine;
using UnityEngine.InputSystem;

namespace RacingDemo.Runtime.Input
{
    /// <summary>
    /// Doc input (ban phim tren may tinh, pad cam ung tren dien thoai) va chuyen cho xe.
    /// Chi dung MOT nguon input moi luc de hai nguon khong cong don gia tri.
    /// Cac su kien Pause/Reset duoc phat len cho director xu ly.
    /// </summary>
    public sealed class CarInputRelay : MonoBehaviour
    {
        [SerializeField] private CarController _car;
        [SerializeField] private TouchControlPad _touchPad;

        [Tooltip("Bo qua nhan dang thiet bi va ep dung pad cam ung (de thu trong Editor).")]
        [SerializeField] private bool _forceTouchControls;

        private bool _inputEnabled = true;

        /// <summary>Nguoi choi bam nut pause (nut tren man hinh hoac phim Escape).</summary>
        public event Action PauseRequested;

        /// <summary>Nguoi choi bam nut reset xe (nut tren man hinh hoac phim R).</summary>
        public event Action ResetRequested;

        /// <summary>True khi dang dung pad cam ung thay vi ban phim.</summary>
        public bool UsesTouchControls
        {
            get { return _forceTouchControls || Application.isMobilePlatform; }
        }

        public bool IsInputEnabled
        {
            get { return _inputEnabled; }
        }

        /// <summary>Bat/tat doc input. Tat se xoa luon trang thai nut dang giu.</summary>
        public void SetInputEnabled(bool enabled)
        {
            _inputEnabled = enabled;
            ClearHeldState();

            if (_car != null)
            {
                _car.SetInput(0f, 0f);
            }
        }

        /// <summary>Xoa moi nut dang giu; nguoi choi phai nhan lai sau khi resume.</summary>
        public void ClearHeldState()
        {
            if (_touchPad != null)
            {
                _touchPad.ClearHeldState();
            }
        }

        /// <summary>Duoc nut Pause tren man hinh goi qua UnityEvent.</summary>
        public void RequestPause()
        {
            Action handler = PauseRequested;
            if (handler != null)
            {
                handler();
            }
        }

        /// <summary>Duoc nut Reset tren man hinh goi qua UnityEvent.</summary>
        public void RequestReset()
        {
            Action handler = ResetRequested;
            if (handler != null)
            {
                handler();
            }
        }

        private void Update()
        {
            // Menu commands remain available while driving input is locked.
            Keyboard keyboard = UsesTouchControls ? null : Keyboard.current;
            if (keyboard != null)
            {
                if (keyboard.escapeKey.wasPressedThisFrame) RequestPause();
                if (keyboard.rKey.wasPressedThisFrame) RequestReset();
            }
            if (_car == null)
            {
                return;
            }

            if (!_inputEnabled)
            {
                _car.SetInput(0f, 0f);
                return;
            }

            float throttle;
            float steer;

            if (UsesTouchControls)
            {
                throttle = _touchPad != null ? _touchPad.Throttle : 0f;
                steer = _touchPad != null ? _touchPad.Steer : 0f;
            }
            else
            {
                ReadKeyboard(out throttle, out steer);
            }

            _car.SetInput(throttle, steer);
        }

        /// <summary>
        /// Input System (Legacy Input da tat trong Project Settings).
        /// W/S hoac Up/Down cho ga, A/D hoac Left/Right cho lai, Escape pause, R reset.
        /// </summary>
        private void ReadKeyboard(out float throttle, out float steer)
        {
            throttle = 0f;
            steer = 0f;

            Keyboard keyboard = Keyboard.current;
            if (keyboard == null)
            {
                return;
            }

            bool forward = keyboard.wKey.isPressed || keyboard.upArrowKey.isPressed;
            bool backward = keyboard.sKey.isPressed || keyboard.downArrowKey.isPressed;
            bool left = keyboard.aKey.isPressed || keyboard.leftArrowKey.isPressed;
            bool right = keyboard.dKey.isPressed || keyboard.rightArrowKey.isPressed;

            throttle = (forward ? 1f : 0f) - (backward ? 1f : 0f);
            steer = (right ? 1f : 0f) - (left ? 1f : 0f);

        }
    }
}
