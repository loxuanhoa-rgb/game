using UnityEngine;
using UnityEngine.EventSystems;

namespace RacingDemo.Runtime.Input
{
    /// <summary>
    /// Nut giu (ga, phanh, lai). Theo doi dung mot pointer dang giu de hai ngon khong
    /// lam ket trang thai. Nha ngon, tat object hoac mat focus deu xoa trang thai giu.
    /// </summary>
    public sealed class HoldButton : MonoBehaviour, IPointerDownHandler, IPointerUpHandler
    {
        private int _heldPointerId;
        private bool _isHeld;

        /// <summary>True khi dang co ngon giu nut nay.</summary>
        public bool IsHeld
        {
            get { return _isHeld; }
        }

        /// <summary>Gia tri tien dung cho phep tinh: 1 khi dang giu, 0 khi khong.</summary>
        public float Value
        {
            get { return _isHeld ? 1f : 0f; }
        }

        public void OnPointerDown(PointerEventData eventData)
        {
            if (_isHeld)
            {
                // Da co ngon khac giu; bo qua de khong mat dau pointer dau tien.
                return;
            }

            _isHeld = true;
            _heldPointerId = eventData.pointerId;
        }

        public void OnPointerUp(PointerEventData eventData)
        {
            // uGUI luon gui PointerUp ve object da nhan PointerDown, ke ca khi ngon
            // da re ra ngoai rect, nen nut khong bi ket ga.
            if (_isHeld && eventData.pointerId == _heldPointerId)
            {
                ClearHeldState();
            }
        }

        /// <summary>Xoa trang thai giu. Resume chi nhan lan nhan moi.</summary>
        public void ClearHeldState()
        {
            _isHeld = false;
            _heldPointerId = 0;
        }

        private void OnDisable()
        {
            ClearHeldState();
        }

        private void OnApplicationFocus(bool hasFocus)
        {
            if (!hasFocus)
            {
                ClearHeldState();
            }
        }

        private void OnApplicationPause(bool isPaused)
        {
            if (isPaused)
            {
                ClearHeldState();
            }
        }
    }
}
