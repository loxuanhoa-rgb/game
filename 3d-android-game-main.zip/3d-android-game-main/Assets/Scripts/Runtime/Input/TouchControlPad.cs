using UnityEngine;

namespace RacingDemo.Runtime.Input
{
    /// <summary>
    /// Gom thanh lai va cac nut giu tren man hinh thanh mot cap gia tri throttle/steer.
    /// Ga va phanh trieu tieu nhau (giu ca hai thi throttle = 0); lai doc thang tu thanh analog.
    /// </summary>
    public sealed class TouchControlPad : MonoBehaviour
    {
        [SerializeField] private SteerSlider _steerSlider;
        [SerializeField] private HoldButton _throttleButton;
        [SerializeField] private HoldButton _brakeButton;

        /// <summary>[-1, 1]: duong la ga, am la phanh/lui.</summary>
        public float Throttle
        {
            get { return ValueOf(_throttleButton) - ValueOf(_brakeButton); }
        }

        /// <summary>[-1, 1]: duong la lai phai, am la lai trai; lien tuc theo vi tri ngon tren thanh.</summary>
        public float Steer
        {
            get { return _steerSlider == null ? 0f : _steerSlider.Value; }
        }

        /// <summary>Xoa moi nut dang giu va tra thanh lai ve 0 (pause, mat focus, resume, restart).</summary>
        public void ClearHeldState()
        {
            if (_steerSlider != null)
            {
                _steerSlider.ClearHeldState();
            }

            ClearButton(_throttleButton);
            ClearButton(_brakeButton);
        }

        private static float ValueOf(HoldButton button)
        {
            return button == null ? 0f : button.Value;
        }

        private static void ClearButton(HoldButton button)
        {
            if (button != null)
            {
                button.ClearHeldState();
            }
        }
    }
}
