using System;
using RacingDemo.Core.Persistence;
using RacingDemo.Core.Racing;
using RacingDemo.Core.Scoring;
using RacingDemo.Runtime.Audio;
using RacingDemo.Runtime.CameraRig;
using RacingDemo.Runtime.Input;
using RacingDemo.Runtime.Persistence;
using RacingDemo.Runtime.Track;
using RacingDemo.Runtime.Vehicle;
using UnityEngine;

namespace RacingDemo.Runtime.Race
{
    /// <summary>
    /// NOI DUY NHAT noi Core voi xe, camera, checkpoint, timeScale, respawn va UI.
    /// Thay <c>PrototypeDirector</c> cua Task 2/3: khong duoc co hai noi cung so huu
    /// input hoac timeScale.
    ///
    /// Quy tac thoi gian:
    /// - Core duoc Tick trong FixedUpdate TRUOC khi cac trigger cua chinh buoc do chay.
    /// - Ket qua cuoi luot chi duoc CHOT trong buoc vat ly; viec trinh bay va thu luu
    ///   dien ra o Update, khong ghi file trong buoc vat ly.
    /// </summary>
    [DefaultExecutionOrder(-100)]
    [DisallowMultipleComponent]
    public sealed class RaceDirector : MonoBehaviour
    {
        [SerializeField] private CarController _car;
        [SerializeField] private CarInputRelay _input;
        [SerializeField] private ChaseCamera _chaseCamera;
        [SerializeField] private TrackDefinition _track;
        [SerializeField] private RespawnService _respawn;
        [SerializeField] private HudPresenter _hud;
        [SerializeField] private PausePresenter _pauseMenu;
        [SerializeField] private ResultsPresenter _results;
        [SerializeField] private EngineAudio _engineAudio;
        [SerializeField] private FestivalPresenter _festival;
        [SerializeField] private FestivalAudio _festivalAudio;
        [SerializeField] private CanvasGroup[] _drivingGroups = Array.Empty<CanvasGroup>();
        private bool _atFestival;

        public bool IsFestivalVisible => _atFestival;

        [Tooltip("Xe roi thap hon mat duong qua muc nay (m) thi tu yeu cau reset.")]
        [SerializeField] private float _fallResetDepth = 5f;

        private RaceRules _rules;
        private RecordStore _records;
        private CheckpointVolume[] _gates = Array.Empty<CheckpointVolume>();

        // Chot trong callback vat ly, tieu thu o Update.
        private bool _finishPending;
        private float _pendingFinishTime;
        private bool _resultsShown;

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        // Nhat ky lai thu, chi co trong Editor va ban Development. Ban Release khong co dong nao.
        // Script lai tu dong (Tools/mtinject, Artifacts/verify/mt-lap.ps1) doc chinh dinh dang nay.
        private float _diagnosticDelay;
#endif

        /// <summary>Trang thai luat dua do Core so huu. Moi thay doi deu di qua director.</summary>
        public RaceRules Rules
        {
            get { return _rules; }
        }

        public bool IsPauseMenuVisible
        {
            get { return _pauseMenu != null && _pauseMenu.IsVisible; }
        }

        public bool IsResultsVisible
        {
            get { return _results != null && _results.IsVisible; }
        }

        private void Awake()
        {
            RequireReference(_car, "_car");
            RequireReference(_input, "_input");
            RequireReference(_chaseCamera, "_chaseCamera");
            RequireReference(_track, "_track");
            RequireReference(_respawn, "_respawn");
            RequireReference(_hud, "_hud");
            RequireReference(_pauseMenu, "_pauseMenu");
            RequireReference(_results, "_results");
            RequireReference(_engineAudio, "_engineAudio");
            RequireReference(_festival, "_festival");
            RequireReference(_festivalAudio, "_festivalAudio");

            _rules = new RaceRules(_track.CreateRaceConfig());
            _rules.RaceFinished += OnRaceFinished;
            _records = new RecordStore(CreateRecordRepository());

            // Dang ky mot lan theo vong doi. Restart KHONG dang ky lai, nen khong co
            // listener lap sau moi lan choi lai.
            _gates = _respawn.GetComponentsInChildren<CheckpointVolume>(true);
            for (int i = 0; i < _gates.Length; i++)
            {
                _gates[i].Passed += OnCheckpointPassed;
            }

            _input.PauseRequested += OnPauseRequested;
            _input.ResetRequested += RequestReset;
        }

        /// <summary>
        /// Director dat trang thai dau cua UI. Presenter khong tu an trong Awake, nen panel
        /// van mo duoc ngay lan dau.
        /// </summary>
        private void Start()
        {
            _records.EnsureLoaded();
            ReturnToFestival();
#if UNITY_EDITOR || DEVELOPMENT_BUILD
            RecordData best;
            Debug.Log("[Records] Loaded track=" + _track.TrackId + " best=" +
                (_records.TryGetBest(_track.TrackId, out best) ? RaceTimeFormatter.Format(best.TimeSeconds) : "none") +
                " writesDisabled=" + _records.WritesDisabled + " path=" + Application.persistentDataPath);
#endif
        }

        private void FixedUpdate()
        {
            if (_atFestival) return;
            // Tick truoc: trigger checkpoint cua buoc nay chay sau, tren cung mot delta.
            _rules.Tick(Time.fixedDeltaTime);

            if (_rules.Phase == RacePhase.Running && !_rules.IsRespawning &&
                _car.transform.position.y < _track.SurfaceHeight - _fallResetDepth)
            {
                RequestReset();
            }

            ApplyControlState();
            LogPose();
        }

        private void Update()
        {
            // Ra khoi buoc vat ly moi trinh bay ket qua va thu luu ky luc.
            if (_finishPending && !_resultsShown)
            {
                PresentResults(_pendingFinishTime);
            }

            _hud.Render(_rules, _car.SpeedKph);
        }

        /// <summary>Bat dau lai tu dau: huy respawn cu, xoa tien trinh, timeScale ve 1.</summary>
        public void Restart()
        {
            BeginRace();
        }

        public void StartRace()
        {
            if (_atFestival) BeginRace();
        }

        /// <summary>Discard the unfinished run without submitting any record.</summary>
        public void ReturnToFestival()
        {
            if (_rules == null) return;
            Time.timeScale = 1f;
            _atFestival = true;
            _finishPending = false;
            _resultsShown = false;
            _rules.RaceFinished -= OnRaceFinished;
            _rules = new RaceRules(_track.CreateRaceConfig());
            _rules.RaceFinished += OnRaceFinished;
            _pauseMenu.Hide();
            _results.Hide();
            TeleportTo(null);
            _car.SetControlEnabled(false);
            _car.SetPoseLocked(true);
            _input.SetInputEnabled(false);
            SetDrivingVisible(false);
            _engineAudio.SetPaused(true);
            _festivalAudio.SetContext(false);
            _festivalAudio.SetPaused(false);
            RecordData best;
            _festival.Show(_records.TryGetBest(_track.TrackId, out best) ? best.TimeSeconds : (float?)null);
            LogLoop("Ve le hoi");
        }

        private void SetDrivingVisible(bool visible)
        {
            foreach (var group in _drivingGroups)
            {
                if (group == null) continue;
                group.alpha = visible ? 1f : 0f;
                group.interactable = visible;
                group.blocksRaycasts = visible;
            }
        }

        /// <summary>Nut Pause tren man hinh / phim Escape. Chi pause tu Countdown hoac Running.</summary>
        public void RequestPause()
        {
            if (_rules == null || _atFestival)
            {
                return;
            }

            _rules.Pause();
            if (_rules.Phase != RacePhase.Paused)
            {
                return;
            }

            // Pause giu nguyen van toc va tinh trang khoa pose truoc do.
            Time.timeScale = 0f;
            _car.SetControlEnabled(false);
            _input.SetInputEnabled(false);
            // timeScale = 0 khong dung am thanh lai, phai tat rieng.
            _engineAudio.SetPaused(true);
            _festivalAudio.SetPaused(true);
            SetDrivingVisible(false);
            _pauseMenu.Show();
            _hud.Render(_rules, _car.SpeedKph);
            LogLoop("Tam dung, menu mo");
        }

        /// <summary>Nut CHOI TIEP. Chi mo dieu khien khi ve lai Running va khong con khoa reset.</summary>
        public void Resume()
        {
            if (_rules == null || _rules.Phase != RacePhase.Paused)
            {
                return;
            }

            _rules.Resume();
            Time.timeScale = 1f;
            _engineAudio.SetPaused(false);
            _festivalAudio.SetPaused(false);
            SetDrivingVisible(true);
            _pauseMenu.Hide();

            // Nguoi choi phai nhan lai nut lai/ga sau khi resume.
            _input.ClearHeldState();
            ApplyControlState();
            _hud.Render(_rules, _car.SpeedKph);
            LogLoop("Choi tiep");
        }

        /// <summary>Nut RESET / phim R / xe roi khoi duong. Core quyet dinh co nhan hay khong.</summary>
        public void RequestReset()
        {
            if (_rules == null || _atFestival || !_rules.TryRequestRespawn())
            {
                return;
            }

            int? target = _rules.LastAcceptedCheckpointIndex;
            TeleportTo(target);
            ApplyControlState();
            LogLoop("Dat lai xe ve " + (target.HasValue ? "cong " + target.Value : "vach xuat phat"));
        }

        private void BeginRace()
        {
            _atFestival = false;
            _festival.Hide();
            SetDrivingVisible(true);
            _festivalAudio.SetContext(true);
            _festivalAudio.SetPaused(false);
            Time.timeScale = 1f;
            _finishPending = false;
            _resultsShown = false;

            _pauseMenu.Hide();
            _results.Hide();
            _engineAudio.SetPaused(false);
            _engineAudio.ResetToIdle();

            _rules.Restart();
            TeleportTo(null);
            ApplyControlState();
            _hud.Render(_rules, _car.SpeedKph);
            LogLoop("Bat dau luot moi");
        }

        private void OnCheckpointPassed(int index)
        {
            if (_atFestival) return;
            int? previous = _rules.LastAcceptedCheckpointIndex;
            _rules.TryPassCheckpoint(index);
            ApplyControlState();

            if (previous != _rules.LastAcceptedCheckpointIndex)
            {
                LogLoop("Cong " + index + " duoc cong nhan, vong=" + _rules.CurrentLap +
                        " ke tiep=" + _rules.NextCheckpointIndex);
            }
        }

        /// <summary>Chay trong callback vat ly: chi chot lai, khong dung UI hay file o day.</summary>
        private void OnRaceFinished(float timeSeconds)
        {
            _finishPending = true;
            _pendingFinishTime = timeSeconds;
        }

        private void PresentResults(float timeSeconds)
        {
            _resultsShown = true;
            SetDrivingVisible(false);
            _engineAudio.SetPaused(true);
            _festivalAudio.SetContext(false);

            // Khoa dieu khien ngay tai day: man ket qua khong duoc mo trong khi xe con lai duoc,
            // du buoc vat ly tiep theo chua chay.
            ApplyControlState();

            Medal medal = timeSeconds > 0f
                ? MedalEvaluator.Evaluate(timeSeconds, _track.CreateMedalThresholds())
                : Medal.None;

            // Submit khong bao gio nem loi: ket qua van mo duoc khi luu that bai.
            RecordSubmissionResult submission = _records.Submit(_track.TrackId, timeSeconds, medal);

            _pauseMenu.Hide();
            _results.Show(new RaceResultView(
                timeSeconds, medal, submission.BestPersisted, submission.Improved, submission.Saved, submission.Error));

            LogLoop("Ve dich: huy chuong=" + medal + " nhanh hon ky luc=" + submission.Improved +
                    " da luu=" + submission.Saved);
        }

        /// <summary>Task 5: JSON trong persistentDataPath; khong luu trang thai luot dang choi.</summary>
        private static IRecordRepository CreateRecordRepository()
        {
            return new JsonRecordRepository(new JsonFileStore(System.IO.Path.Combine(Application.persistentDataPath, JsonRecordRepository.FileName)));
        }

        private void TeleportTo(int? checkpointIndex)
        {
            // Xoa trang thai cong TRUOC khi doi vi tri: teleport khong duoc tinh la qua cong.
            for (int i = 0; i < _gates.Length; i++)
            {
                if (_gates[i] != null)
                {
                    _gates[i].ClearTraversal();
                }
            }

            Vector3 position;
            Quaternion rotation;
            _respawn.GetRespawnPose(checkpointIndex, out position, out rotation);

            // Mo khoa truoc khi doi pose; ApplyControlState khoa lai neu con countdown/respawn.
            _car.SetPoseLocked(false);
            _car.ResetTo(position, rotation);
            _input.ClearHeldState();
            _chaseCamera.SnapToTarget();
        }

        private void ApplyControlState()
        {
            if (_atFestival) return;
            // Pause giu nguyen van toc va tinh trang khoa truoc pause.
            if (_rules.Phase == RacePhase.Paused)
            {
                return;
            }

            bool running = _rules.Phase == RacePhase.Running && !_rules.IsRespawning;
            _car.SetPoseLocked(_rules.Phase == RacePhase.Countdown || _rules.IsRespawning);

            if (_car.IsControlEnabled != running)
            {
                _car.SetControlEnabled(running);
            }

            // SetInputEnabled xoa nut dang giu: chi goi khi trang thai that su doi.
            if (_input.IsInputEnabled != running)
            {
                _input.SetInputEnabled(running);
            }
        }

        private void OnPauseRequested()
        {
            if (_rules.Phase == RacePhase.Paused)
            {
                Resume();
                return;
            }

            RequestPause();
        }

        // Mat focus / vao nen deu yeu cau pause; quay lai KHONG tu resume.
        private void OnApplicationFocus(bool hasFocus)
        {
            if (!hasFocus)
            {
                RequestPause();
            }
        }

        private void OnApplicationPause(bool paused)
        {
            if (paused)
            {
                RequestPause();
            }
        }

        private void OnDestroy()
        {
            if (_rules != null)
            {
                _rules.RaceFinished -= OnRaceFinished;
            }

            for (int i = 0; i < _gates.Length; i++)
            {
                if (_gates[i] != null)
                {
                    _gates[i].Passed -= OnCheckpointPassed;
                }
            }

            if (_input != null)
            {
                _input.PauseRequested -= OnPauseRequested;
                _input.ResetRequested -= RequestReset;
            }

            // Teardown phai tra timeScale ve 1 de khong anh huong luot/test sau.
            Time.timeScale = 1f;
        }

        /// <summary>Bang chung lai thu, chi bien dich trong Editor/Development. Khong dieu khien gi.</summary>
        [System.Diagnostics.Conditional("UNITY_EDITOR")]
        [System.Diagnostics.Conditional("DEVELOPMENT_BUILD")]
        private void LogLoop(string message)
        {
            Debug.Log("[RaceLoop] " + message + " | phase=" + _rules.Phase +
                      " t=" + RaceTimeFormatter.Format(_rules.ElapsedSeconds));
        }

        private void LogPose()
        {
#if UNITY_EDITOR || DEVELOPMENT_BUILD
            _diagnosticDelay -= Time.fixedDeltaTime;
            if (_diagnosticDelay > 0f || _rules.Phase != RacePhase.Running)
            {
                return;
            }

            _diagnosticDelay = 1f;
            Vector3 position = _car.transform.position;

            // Dinh dang co dinh, khong phu thuoc locale: script lai tu dong doc bang regex.
            Debug.Log(string.Format(
                System.Globalization.CultureInfo.InvariantCulture,
                "[TrackDrive] Pose x={0:F2} y={1:F2} z={2:F2} yaw={3:F1} speed={4:F1} lap={5} next={6}",
                position.x, position.y, position.z,
                _car.transform.eulerAngles.y, _car.SpeedKph,
                _rules.CurrentLap, _rules.NextCheckpointIndex));
#endif
        }

        private void RequireReference(UnityEngine.Object reference, string fieldName)
        {
            if (reference == null)
            {
                throw new InvalidOperationException(
                    "RaceDirector." + fieldName + " chua duoc gan. Chay RacingDemo/Rebuild Demo.");
            }
        }
    }
}
