using RacingDemo.Core.Racing;
using TMPro;
using UnityEngine;

namespace RacingDemo.Runtime.Race
{
    /// <summary>
    /// Ve HUD trong luc dua. Presenter nam tren object LUON ACTIVE va chi doc trang thai
    /// tu Core — khong tu giu dong ho thu hai, khong quyet dinh luat dua.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class HudPresenter : MonoBehaviour
    {
        [SerializeField] private TextMeshProUGUI _timeLabel;
        [SerializeField] private TextMeshProUGUI _lapLabel;
        [SerializeField] private TextMeshProUGUI _checkpointLabel;
        [SerializeField] private TextMeshProUGUI _speedLabel;
        [SerializeField] private TextMeshProUGUI _bannerLabel;

        public void Render(RaceRules rules, float speedKph)
        {
            if (rules == null)
            {
                return;
            }

            _timeLabel.text = RaceTimeFormatter.Format(rules.ElapsedSeconds);
            _lapLabel.text = RaceHudFormatter.FormatLap(rules.CurrentLap, rules.Config.LapCount);
            _checkpointLabel.text = RaceHudFormatter.FormatNextCheckpoint(
                rules.NextCheckpointIndex, rules.Config.CheckpointCount);
            _speedLabel.text = RaceHudFormatter.FormatSpeed(speedKph);
            _bannerLabel.text = RaceHudFormatter.FormatBanner(
                rules.Phase, rules.CountdownRemaining, rules.IsRespawning, rules.RespawnRemaining);
        }
    }
}
