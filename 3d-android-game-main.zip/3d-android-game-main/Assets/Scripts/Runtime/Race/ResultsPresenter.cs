using RacingDemo.Core.Racing;
using RacingDemo.Core.Scoring;
using TMPro;
using UnityEngine;

namespace RacingDemo.Runtime.Race
{
    /// <summary>Du lieu mot man ket qua. Viec hien thi tach roi han viec ghi file.</summary>
    public readonly struct RaceResultView
    {
        public RaceResultView(float timeSeconds, Medal medal, float? bestSeconds, bool improved, bool saved, string error)
        {
            TimeSeconds = timeSeconds;
            Medal = medal;
            BestSeconds = bestSeconds;
            Improved = improved;
            Saved = saved;
            Error = error;
        }

        public float TimeSeconds { get; }

        public Medal Medal { get; }

        /// <summary>Ky luc dang duoc coi la da luu; null khi chua co ky luc nao.</summary>
        public float? BestSeconds { get; }

        public bool Improved { get; }

        public bool Saved { get; }

        public string Error { get; }
    }

    /// <summary>
    /// Man ket qua cuoi luot. Presenter nam tren object LUON ACTIVE; panel la object con.
    /// Luon mo duoc ke ca khi luu ky luc that bai — loi luu chi doi dong trang thai.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class ResultsPresenter : MonoBehaviour
    {
        [SerializeField] private GameObject _panel;
        [SerializeField] private TextMeshProUGUI _timeLabel;
        [SerializeField] private TextMeshProUGUI _medalLabel;
        [SerializeField] private TextMeshProUGUI _recordLabel;
        [SerializeField] private TextMeshProUGUI _saveStateLabel;
        [SerializeField] private TextMeshProUGUI _messageLabel;

        public bool IsVisible
        {
            get { return _panel != null && _panel.activeSelf; }
        }

        public void Show(RaceResultView view)
        {
            if (_timeLabel != null)
            {
                _timeLabel.text = RaceTimeFormatter.Format(view.TimeSeconds);
            }

            if (_medalLabel != null)
            {
                _medalLabel.text = RaceHudFormatter.FormatMedal(view.Medal);
            }

            if (_recordLabel != null)
            {
                _recordLabel.text = RaceHudFormatter.FormatRecord(view.BestSeconds);
            }

            if (_saveStateLabel != null)
            {
                _saveStateLabel.text = RaceHudFormatter.FormatSaveState(view.Improved, view.Saved, view.Error);
            }

            if (_messageLabel != null)
            {
                _messageLabel.text = FormatMessage(view.Improved, view.Saved);
            }

            if (_panel != null)
            {
                _panel.SetActive(true);
            }
        }

        public void Hide()
        {
            if (_panel != null)
            {
                _panel.SetActive(false);
            }
        }

        /// <summary>
        /// Loi An cuoi luot: nhanh hon va luu duoc / nhanh hon nhung luu that bai / binh thuong.
        /// Chi la loi thoai, khong lap lai trang thai luu (da co _saveStateLabel).
        /// </summary>
        private static string FormatMessage(bool improved, bool saved)
        {
            if (improved && saved)
            {
                return "An: Đẹp rồi! Đồi Mây vừa nhớ thêm một kỷ lục.";
            }

            if (improved)
            {
                return "An: Chạy hay lắm! Sổ ghi kỷ lục đang kẹt, nhưng tôi nhớ thời gian này.";
            }

            return "An: Hai vòng trọn vẹn. Ghé garage nghỉ một chút nhé.";
        }
    }
}
