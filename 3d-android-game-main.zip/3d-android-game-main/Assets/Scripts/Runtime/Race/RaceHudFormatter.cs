using System.Globalization;
using RacingDemo.Core.Racing;
using RacingDemo.Core.Scoring;
using UnityEngine;

namespace RacingDemo.Runtime.Race
{
    /// <summary>
    /// Ham thuan doi trang thai luot dua sang chuoi hien thi. Khong giu trang thai,
    /// khong doc dong ho rieng: moi gia tri deu do Core cung cap.
    /// </summary>
    public static class RaceHudFormatter
    {
        public const string NoRecordText = "KỶ LỤC: CHƯA CÓ";
        public const string SaveFailedText = "KHÔNG LƯU ĐƯỢC KỶ LỤC";
        public const string NewRecordText = "KỶ LỤC MỚI ĐÃ LƯU";

        /// <summary>"VÒNG 1/2". Vong duoc kep trong [1, lapCount] de nhan khong bao gio vuot so vong.</summary>
        public static string FormatLap(int currentLap, int lapCount)
        {
            int total = Mathf.Max(1, lapCount);
            int lap = Mathf.Clamp(currentLap, 1, total);
            return string.Format(CultureInfo.InvariantCulture, "VÒNG {0}/{1}", lap, total);
        }

        /// <summary>"CỔNG 1/4" — checkpoint ke tiep, dem tu 1 cho nguoi choi de doc.</summary>
        public static string FormatNextCheckpoint(int nextCheckpointIndex, int checkpointCount)
        {
            int total = Mathf.Max(1, checkpointCount);
            int next = Mathf.Clamp(nextCheckpointIndex, 0, total - 1) + 1;
            return string.Format(CultureInfo.InvariantCulture, "CỔNG {0}/{1}", next, total);
        }

        public static string FormatSpeed(float speedKph)
        {
            float absolute = Mathf.Abs(speedKph);
            if (float.IsNaN(absolute) || float.IsInfinity(absolute))
            {
                absolute = 0f;
            }

            return string.Format(CultureInfo.InvariantCulture, "{0} KM/H", Mathf.RoundToInt(absolute));
        }

        /// <summary>
        /// Dong chu lon giua man hinh: dem nguoc truoc khi xuat phat, thong bao khi dang khoa
        /// sau reset, va rong khi dang chay binh thuong.
        /// </summary>
        public static string FormatBanner(RacePhase phase, float countdownRemaining, bool isRespawning, float respawnRemaining)
        {
            if (phase == RacePhase.Countdown)
            {
                int seconds = Mathf.CeilToInt(Mathf.Max(0f, countdownRemaining));
                return seconds <= 0 ? "XUẤT PHÁT" : seconds.ToString(CultureInfo.InvariantCulture);
            }

            if (phase == RacePhase.Running && isRespawning)
            {
                return string.Format(
                    CultureInfo.InvariantCulture, "ĐẶT LẠI XE  {0:0.0}", Mathf.Max(0f, respawnRemaining));
            }

            return string.Empty;
        }

        public static string FormatMedal(Medal medal)
        {
            switch (medal)
            {
                case Medal.Gold: return "HUY CHƯƠNG VÀNG";
                case Medal.Silver: return "HUY CHƯƠNG BẠC";
                case Medal.Bronze: return "HUY CHƯƠNG ĐỒNG";
                default: return "CHƯA ĐẠT HUY CHƯƠNG";
            }
        }

        /// <summary>Ky luc da luu; khong hien 0 nhu mot thanh tich hop le khi chua co gi.</summary>
        public static string FormatRecord(float? bestSeconds)
        {
            if (!bestSeconds.HasValue)
            {
                return NoRecordText;
            }

            return "KỶ LỤC: " + RaceTimeFormatter.Format(bestSeconds.Value);
        }

        /// <summary>
        /// Chi bao "ky luc moi da luu" khi vua nhanh hon VUA ghi thanh cong.
        /// Nhanh hon nhung ghi that bai thi bao khong luu duoc, khong im lang.
        /// </summary>
        public static string FormatSaveState(bool improved, bool saved, string error)
        {
            if (improved && saved)
            {
                return NewRecordText;
            }

            if (!string.IsNullOrEmpty(error))
            {
                return SaveFailedText;
            }

            return string.Empty;
        }
    }
}
