using RacingDemo.Runtime.Audio;
using TMPro;
using UnityEngine;

namespace RacingDemo.Runtime.Race
{
    /// <summary>Festival card and shared audio labels; no race state or persistence ownership.</summary>
    [DisallowMultipleComponent]
    public sealed class FestivalPresenter : MonoBehaviour
    {
        private const string NoRecordMessage = "An: Xe vừa bảo dưỡng xong. Chạy thử hai vòng quanh Đồi Mây nhé!";
        private const string HasRecordMessage = "An: Kỷ lục cũ vẫn còn đó. Nắng chiều đẹp thế này, thử vượt nó xem!";

        [SerializeField] private GameObject _panel;
        [SerializeField] private TMP_Text _recordLabel;
        [SerializeField] private TMP_Text _messageLabel;
        [SerializeField] private FestivalAudio _audio;
        [SerializeField] private TMP_Text[] _musicLabels;
        [SerializeField] private TMP_Text[] _effectsLabels;
        private bool? _lastMusic;
        private bool? _lastEffects;

        public bool IsVisible => _panel != null && _panel.activeSelf;

        public void Show(float? bestSeconds)
        {
            if (_recordLabel != null) _recordLabel.text = RaceHudFormatter.FormatRecord(bestSeconds);
            if (_messageLabel != null) _messageLabel.text = bestSeconds.HasValue ? HasRecordMessage : NoRecordMessage;
            if (_panel != null) _panel.SetActive(true);
            RefreshAudio();
        }

        public void Hide()
        {
            if (_panel != null) _panel.SetActive(false);
        }

        private void Update() => RefreshAudio();

        private void RefreshAudio()
        {
            if (_audio == null) return;
            // Chu hoa cho khop caption cac nut menu khac.
            if (_lastMusic != _audio.MusicEnabled)
            {
                SetLabels(_musicLabels, "NHẠC: " + (_audio.MusicEnabled ? "BẬT" : "TẮT"));
                _lastMusic = _audio.MusicEnabled;
            }
            if (_lastEffects != _audio.EffectsEnabled)
            {
                SetLabels(_effectsLabels, "ÂM THANH: " + (_audio.EffectsEnabled ? "BẬT" : "TẮT"));
                _lastEffects = _audio.EffectsEnabled;
            }
        }

        private static void SetLabels(TMP_Text[] labels, string value)
        {
            if (labels == null) return;
            foreach (TMP_Text label in labels) if (label != null) label.text = value;
        }
    }
}
