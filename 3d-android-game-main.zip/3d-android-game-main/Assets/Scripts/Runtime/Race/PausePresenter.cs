using TMPro;
using UnityEngine;

namespace RacingDemo.Runtime.Race
{
    /// <summary>
    /// Bat/tat panel tam dung. Presenter nam tren object LUON ACTIVE, panel chi la object con
    /// do presenter dieu khien — neu presenter nam tren chinh panel thi Show() se khong bao gio
    /// chay lai sau lan dau an. Awake KHONG tu an panel: <see cref="RaceDirector"/> dat trang thai dau.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class PausePresenter : MonoBehaviour
    {
        [SerializeField] private GameObject _panel;
        [SerializeField] private TextMeshProUGUI _titleLabel;

        public bool IsVisible
        {
            get { return _panel != null && _panel.activeSelf; }
        }

        public void Show()
        {
            if (_titleLabel != null)
            {
                _titleLabel.text = "TẠM DỪNG";
            }

            if (_panel != null)
            {
                _panel.SetActive(true);
            }
        }

        public void Hide()
        {
            if (_panel != null)
            {
                _panel.SetActive(false);
            }
        }
    }
}
