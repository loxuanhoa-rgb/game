using UnityEngine;

namespace RacingDemo.Runtime.Bootstrap
{
    /// <summary>
    /// Dat cau hinh khung hinh cho toan ung dung. Chay som hon moi thanh phan gameplay.
    /// </summary>
    [DefaultExecutionOrder(-10000)]
    public sealed class AppBootstrap : MonoBehaviour
    {
        [SerializeField]
        [Tooltip("Muc tieu 60 FPS tren Xiaomi 14.")]
        private int _targetFrameRate = 60;

        private void Awake()
        {
            // vSync phai tat truoc thi targetFrameRate moi co hieu luc.
            QualitySettings.vSyncCount = 0;
            Application.targetFrameRate = _targetFrameRate;

            // Khong de man hinh tu tat khi dang choi.
            Screen.sleepTimeout = SleepTimeout.NeverSleep;
        }
    }
}
