using System;
using UnityEngine;

namespace RacingDemo.Runtime.Audio
{
    /// <summary>Separate preference keys; never touches race records.</summary>
    public sealed class AudioPreferences
    {
        public const string MusicKey = "apex.music";
        public const string EffectsKey = "apex.effects";
        private readonly Func<string, int, int> _read;
        private readonly Action<string, int> _write;
        private readonly Action _save;
        public AudioPreferences() : this(PlayerPrefs.GetInt, PlayerPrefs.SetInt, PlayerPrefs.Save) { }
        public AudioPreferences(Func<string, int, int> read, Action<string, int> write, Action save)
        { _read = read; _write = write; _save = save; }
        public bool MusicEnabled { get; private set; } = true;
        public bool EffectsEnabled { get; private set; } = true;
        public void Load()
        {
            try { MusicEnabled = _read(MusicKey, 1) != 0; EffectsEnabled = _read(EffectsKey, 1) != 0; }
            catch (Exception) { MusicEnabled = true; EffectsEnabled = true; }
        }
        public bool SetMusic(bool enabled) { MusicEnabled = enabled; return Persist(MusicKey, enabled); }
        public bool SetEffects(bool enabled) { EffectsEnabled = enabled; return Persist(EffectsKey, enabled); }
        private bool Persist(string key, bool value)
        {
            try { _write(key, value ? 1 : 0); _save(); return true; }
            catch (Exception) { return false; } // Current session still honors the user's choice.
        }
    }
}
