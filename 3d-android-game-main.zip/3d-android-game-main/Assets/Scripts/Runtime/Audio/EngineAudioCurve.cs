namespace RacingDemo.Runtime.Audio
{
    /// <summary>
    /// Phan tinh toan thuan cua tieng dong co: khong dung AudioSource, khong dung dong ho.
    /// Tach rieng de test duoc ma khong can scene.
    /// </summary>
    public static class EngineAudioCurve
    {
        /// <summary>
        /// Ti le toc do trong [0, 1]. Lay tri tuyet doi vi lui van no may.
        /// Gia tri khong hop le (NaN, vo cuc, maxSpeed &lt;= 0) tra ve 0 thay vi lam hong am thanh.
        /// </summary>
        public static float SpeedRatio(float speedKph, float maxSpeedKph)
        {
            if (!IsFinite(speedKph) || !IsFinite(maxSpeedKph) || maxSpeedKph <= 0f)
            {
                return 0f;
            }

            float ratio = (speedKph < 0f ? -speedKph : speedKph) / maxSpeedKph;
            return ratio > 1f ? 1f : ratio;
        }

        /// <summary>
        /// Cao do tang tuyen tinh theo toc do. Giu don gian de con nghe ra lien he giua
        /// tieng may va toc do; khong gia lap hop so.
        /// </summary>
        public static float Pitch(float speedKph, float maxSpeedKph, float idlePitch, float maxPitch)
        {
            return Lerp(idlePitch, maxPitch, SpeedRatio(speedKph, maxSpeedKph));
        }

        /// <summary>Am luong tang theo toc do; xe dung yen van co tieng no cam chung.</summary>
        public static float Volume(float speedKph, float maxSpeedKph, float idleVolume, float maxVolume)
        {
            float volume = Lerp(idleVolume, maxVolume, SpeedRatio(speedKph, maxSpeedKph));
            if (volume < 0f) return 0f;
            return volume > 1f ? 1f : volume;
        }

        private static float Lerp(float from, float to, float ratio)
        {
            if (!IsFinite(from) || !IsFinite(to))
            {
                return 0f;
            }

            return from + (to - from) * ratio;
        }

        private static bool IsFinite(float value)
        {
            return !float.IsNaN(value) && !float.IsInfinity(value);
        }
    }
}
