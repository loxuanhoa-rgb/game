using System;
using RacingDemo.Runtime.Vehicle;
using UnityEngine;

namespace RacingDemo.Runtime.Audio
{
    /// <summary>
    /// Tieng dong co: mot AudioSource lap vong, cao do va am luong bam theo toc do xe.
    ///
    /// Quy tac:
    /// - Chi goi Play khi that su co clip. Khong co clip thi im lang, khong nem loi.
    /// - Pause cua vong choi phai lam am thanh ngung han (timeScale = 0 KHONG dung am thanh lai).
    /// - Component nay khong tu quyet dinh luc nao pause; <see cref="RacingDemo.Runtime.Race.RaceDirector"/>
    ///   la noi duy nhat so huu trang thai vong choi.
    /// - Khong tu them AudioListener: scene chi duoc co dung mot cai, dat tren camera.
    /// </summary>
    [DisallowMultipleComponent]
    [RequireComponent(typeof(AudioSource))]
    public sealed class EngineAudio : MonoBehaviour
    {
        [SerializeField] private CarController _car;
        [SerializeField] private AudioSource _source;

        [Header("Cao do")]
        [Tooltip("Cao do khi xe dung yen.")]
        [SerializeField] private float _idlePitch = 0.65f;

        [Tooltip("Cao do o toc do toi da cua CarConfig.")]
        [SerializeField] private float _maxPitch = 2.1f;

        [Header("Am luong")]
        [SerializeField] private float _idleVolume = 0.35f;
        [SerializeField] private float _maxVolume = 0.85f;

        [Tooltip("Toc do bam theo toc do xe (don vi/giay). Cang lon cang bat nhay.")]
        [SerializeField] private float _responsePerSecond = 6f;

        private float _pitch;
        private float _volume;
        private bool _applicationSuspended;

        /// <summary>Dang bi vong choi tam dung hay khong.</summary>
        public bool IsPaused { get; private set; }

        /// <summary>Co clip de phat hay khong. Khong co clip la truong hop hop le, chi la im lang.</summary>
        public bool HasClip
        {
            get { return _source != null && _source.clip != null; }
        }

        public float CurrentPitch
        {
            get { return _pitch; }
        }

        public float CurrentVolume
        {
            get { return _volume; }
        }

        private void Awake()
        {
            if (_source == null)
            {
                _source = GetComponent<AudioSource>();
            }

            if (_car == null)
            {
                throw new InvalidOperationException(
                    "EngineAudio._car chua duoc gan. Chay RacingDemo/Rebuild Demo.");
            }

            _pitch = _idlePitch;
            _volume = _idleVolume;
            _source.loop = true;
            _source.playOnAwake = false;
            _source.spatialBlend = 0f; // Camera luon bam sat xe, khong can am thanh 3D.
            _source.pitch = _pitch;
            _source.volume = _volume;
        }

        private void Start()
        {
            // Chi phat khi da co clip that, va khong phat neu vong choi da kip tam dung
            // truoc khi component nay kip Start.
            if (HasClip && !IsPaused && !_applicationSuspended && !_source.isPlaying)
            {
                _source.Play();
            }
        }

        private void Update()
        {
            if (IsPaused || _applicationSuspended || !HasClip)
            {
                return;
            }

            float maxSpeed = _car.Config != null ? _car.Config.MaxSpeedKph : 0f;
            float targetPitch = EngineAudioCurve.Pitch(_car.SpeedKph, maxSpeed, _idlePitch, _maxPitch);
            float targetVolume = EngineAudioCurve.Volume(_car.SpeedKph, maxSpeed, _idleVolume, _maxVolume);

            float step = Mathf.Clamp01(_responsePerSecond * Time.deltaTime);
            _pitch = Mathf.Lerp(_pitch, targetPitch, step);
            _volume = Mathf.Lerp(_volume, targetVolume, step);
            _source.pitch = _pitch;
            _source.volume = _volume;
        }

        /// <summary>Pause cua vong choi. Goi lai voi false de tiep tuc dung cho da dung.</summary>
        public void SetPaused(bool paused)
        {
            IsPaused = paused;
            ApplyPlayback();
        }

        public void SetEffectsEnabled(bool enabled)
        {
            if (_source != null) _source.mute = !enabled;
        }

        public void SetApplicationSuspended(bool suspended)
        {
            _applicationSuspended = suspended;
            ApplyPlayback();
        }

        private void ApplyPlayback()
        {
            if (!HasClip) return;
            if (IsPaused || _applicationSuspended) _source.Pause();
            else if (!_source.isPlaying)
            {
                _source.UnPause();
                // A festival may pause before Start ever plays the clip.
                if (!_source.isPlaying) _source.Play();
            }
        }
        /// <summary>Ve dau luot: tra cao do/am luong ve muc cam chung.</summary>
        public void ResetToIdle()
        {
            _pitch = _idlePitch;
            _volume = _idleVolume;
            if (_source == null)
            {
                return;
            }

            _source.pitch = _pitch;
            _source.volume = _volume;
        }
    }
}
