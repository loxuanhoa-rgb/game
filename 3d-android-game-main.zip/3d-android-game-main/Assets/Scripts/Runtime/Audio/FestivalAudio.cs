using UnityEngine;

namespace RacingDemo.Runtime.Audio
{
    /// <summary>Quiet original music and outdoor ambience, with independent focus/game pause gates.</summary>
    [DisallowMultipleComponent]
    public sealed class FestivalAudio : MonoBehaviour
    {
        [SerializeField] private AudioSource _music;
        [SerializeField] private AudioSource _ambience;
        [SerializeField] private EngineAudio _engine;
        private AudioPreferences _preferences;
        private bool _gamePaused;
        private bool _lostFocus;
        private bool _background;
        private bool _racing;
        public bool MusicEnabled => _preferences == null || _preferences.MusicEnabled;
        public bool EffectsEnabled => _preferences == null || _preferences.EffectsEnabled;
        public bool IsSuspended => _gamePaused || _lostFocus || _background;
        public bool LastSaveSucceeded { get; private set; } = true;
        private void Awake()
        {
            _preferences = new AudioPreferences();
            _preferences.Load();
            Configure(_music); Configure(_ambience);
        }
        private void Start() { Apply(); }
        public void SetContext(bool racing) { _racing = racing; Apply(); }
        public void SetPaused(bool paused) { _gamePaused = paused; Apply(); }
        public void ToggleMusic() { SetMusicEnabled(!MusicEnabled); }
        public void ToggleEffects() { SetEffectsEnabled(!EffectsEnabled); }
        public void SetMusicEnabled(bool enabled)
        { LastSaveSucceeded = _preferences.SetMusic(enabled); Apply(); }
        public void SetEffectsEnabled(bool enabled)
        { LastSaveSucceeded = _preferences.SetEffects(enabled); Apply(); }
        private void OnApplicationFocus(bool focused) { _lostFocus = !focused; Apply(); }
        private void OnApplicationPause(bool paused) { _background = paused; Apply(); }
        private void OnDisable()
        {
            if (_music != null) _music.Pause();
            if (_ambience != null) _ambience.Pause();
        }
        private void OnEnable() { if (_preferences != null) Apply(); }
        private void Apply()
        {
            ApplySource(_music, MusicEnabled, _racing ? 0.035f : 0.09f);
            ApplySource(_ambience, EffectsEnabled, _racing ? 0.025f : 0.04f);
            if (_engine != null)
            {
                _engine.SetEffectsEnabled(EffectsEnabled);
                _engine.SetApplicationSuspended(_lostFocus || _background);
            }
        }
        private void ApplySource(AudioSource source, bool enabled, float volume)
        {
            if (source == null) return;
            source.volume = volume;
            source.mute = !enabled;
            if (IsSuspended || !isActiveAndEnabled) source.Pause();
            else if (source.clip != null && !source.isPlaying)
            {
                source.UnPause();
                if (!source.isPlaying) source.Play();
            }
        }
        private static void Configure(AudioSource source)
        {
            if (source == null) return;
            source.loop = true; source.playOnAwake = false; source.spatialBlend = 0f;
        }
    }
}
