using System.Collections.Generic;
using RacingDemo.Core.Persistence;

namespace RacingDemo.Runtime.Persistence
{
    /// <summary>
    /// Kho trong bo nho de co lap test scene, KHONG ghi xuong dia.
    /// Runtime san pham dung JsonRecordRepository tu Task 5.
    /// Test dung cung hop dong <see cref="IRecordRepository"/> ma khong cham du lieu Editor.
    /// </summary>
    public sealed class SessionRecordRepository : IRecordRepository
    {
        private readonly List<RecordData> _records = new List<RecordData>();

        public bool TryLoad(out IReadOnlyList<RecordData> records, out string error)
        {
            // Chua co ky luc nao la trang thai hop le, khong phai loi doc.
            records = _records.ToArray();
            error = null;
            return true;
        }

        public bool TrySave(IReadOnlyList<RecordData> records, out string error)
        {
            _records.Clear();
            if (records != null)
            {
                for (int i = 0; i < records.Count; i++)
                {
                    if (records[i] != null)
                    {
                        _records.Add(records[i]);
                    }
                }
            }

            error = null;
            return true;
        }
    }
}
