using System;
using System.IO;
using System.Text;

namespace RacingDemo.Runtime.Persistence
{
    // IO seam for deterministic failure tests; exceptions are handled by the repository.
    public interface IJsonFileStore
    {
        string Read(); // null means no file yet
        void BackupCorrupt();
        void WriteAtomic(string json);
    }

    public sealed class JsonFileStore : IJsonFileStore
    {
        private readonly string _path;
        public JsonFileStore(string path) { _path = Path.GetFullPath(path); }

        public string Read()
        {
            try { return File.ReadAllText(_path, Encoding.UTF8); }
            catch (FileNotFoundException) { return null; }
            catch (DirectoryNotFoundException) { return null; }
        }

        public void BackupCorrupt()
        {
            // Never overwrite an earlier backup or delete the original on failure.
            File.Copy(_path, _path + ".corrupt-" + Guid.NewGuid().ToString("N"), false);
        }

        public void WriteAtomic(string json)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(_path));
            string temporary = _path + ".tmp-" + Guid.NewGuid().ToString("N");
            try
            {
                byte[] bytes = new UTF8Encoding(false).GetBytes(json);
                using (var stream = new FileStream(temporary, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                {
                    stream.Write(bytes, 0, bytes.Length);
                    stream.Flush(true);
                }
                // Same-directory rename/replace. Do not delete the destination first.
                if (File.Exists(_path)) File.Replace(temporary, _path, null);
                else File.Move(temporary, _path);
            }
            finally
            {
                try { if (File.Exists(temporary)) File.Delete(temporary); }
                catch (IOException) { }
                catch (UnauthorizedAccessException) { }
            }
        }
    }
}
