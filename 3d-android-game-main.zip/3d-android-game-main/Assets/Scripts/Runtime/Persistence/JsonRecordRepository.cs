using System;
using System.Collections.Generic;
using RacingDemo.Core.Persistence;
using RacingDemo.Core.Scoring;
using UnityEngine;

namespace RacingDemo.Runtime.Persistence
{
    [Serializable]
    internal sealed class RecordFileDto
    {
        public int version;
        public RecordDto[] records;
    }

    [Serializable]
    internal sealed class RecordDto
    {
        public string trackId;
        public float timeSeconds;
        public int medal;
    }

    public sealed class JsonRecordRepository : IRecordRepository
    {
        public const string FileName = "records.json";
        private readonly IJsonFileStore _files;
        private bool _loaded;
        private string _blockedError;
        private IReadOnlyList<RecordData> _records = Array.Empty<RecordData>();

        public JsonRecordRepository(IJsonFileStore files)
        {
            _files = files ?? throw new ArgumentNullException(nameof(files));
        }

        public bool TryLoad(out IReadOnlyList<RecordData> records, out string error)
        {
            if (!_loaded)
            {
                _loaded = true;
                try
                {
                    string json = _files.Read();
                    if (json != null)
                    {
                        RecordFileDto dto = null;
                        try { dto = JsonUtility.FromJson<RecordFileDto>(json); }
                        catch (ArgumentException) { }
                        if (dto != null && dto.version != 1)
                        {
                            _blockedError = "Phien ban du lieu ky luc khong duoc ho tro.";
                        }
                        else if (dto == null || dto.records == null)
                        {
                            // Backup must succeed before an empty store can ever be saved.
                            _files.BackupCorrupt();
                        }
                        else
                        {
                            var converted = new List<RecordData>();
                            foreach (RecordDto item in dto.records)
                                if (item != null)
                                    converted.Add(new RecordData(item.trackId, item.timeSeconds, (Medal)item.medal));
                            _records = Normalize(converted);
                        }
                    }
                }
                catch (Exception exception) { _blockedError = exception.Message; }
            }
            records = _records;
            error = _blockedError;
            return error == null;
        }

        public bool TrySave(IReadOnlyList<RecordData> records, out string error)
        {
            if (!TryLoad(out _, out error)) return false;
            try
            {
                IReadOnlyList<RecordData> normalized = Normalize(records);
                var dto = new RecordFileDto { version = 1, records = new RecordDto[normalized.Count] };
                for (int i = 0; i < normalized.Count; i++)
                {
                    RecordData item = normalized[i];
                    dto.records[i] = new RecordDto { trackId = item.TrackId, timeSeconds = item.TimeSeconds, medal = (int)item.Medal };
                }
                _files.WriteAtomic(JsonUtility.ToJson(dto, true));
                _records = normalized;
                error = null;
                return true;
            }
            catch (Exception exception) { error = exception.Message; return false; }
        }

        private static IReadOnlyList<RecordData> Normalize(IReadOnlyList<RecordData> records)
        {
            var best = new SortedDictionary<string, RecordData>(StringComparer.Ordinal);
            if (records != null)
                foreach (RecordData record in records)
                    if (record != null && record.IsValid &&
                        (!best.TryGetValue(record.TrackId, out RecordData previous) || record.TimeSeconds < previous.TimeSeconds))
                        best[record.TrackId] = record;
            return new List<RecordData>(best.Values).AsReadOnly();
        }
    }
}
