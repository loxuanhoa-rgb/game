using UnityEngine;

namespace RacingDemo.Runtime.Vehicle
{
    /// <summary>
    /// Xe arcade: mot Rigidbody, bon WheelCollider. Banh truoc lai, banh sau truyen luc,
    /// ca bon banh phanh.
    ///
    /// Hop dong voi phan con lai cua game:
    /// - <see cref="SetInput"/> nhan throttle/steer trong [-1, 1].
    /// - <see cref="SetControlEnabled"/> xoa input nhung KHONG tu xoa van toc.
    /// - <see cref="SetPoseLocked"/> giu xe tai cho (countdown/reset): xoa van toc, kinematic.
    /// - <see cref="SpeedKph"/> la van toc doc CO DAU: duong = tien, am = lui.
    /// </summary>
    [RequireComponent(typeof(Rigidbody))]
    public sealed class CarController : MonoBehaviour
    {
        private const float MetersPerSecondToKph = 3.6f;

        [SerializeField] private CarConfig _config;

        [Header("WheelCollider")]
        [SerializeField] private WheelCollider _frontLeftWheel;
        [SerializeField] private WheelCollider _frontRightWheel;
        [SerializeField] private WheelCollider _rearLeftWheel;
        [SerializeField] private WheelCollider _rearRightWheel;

        [Header("Pivot hinh banh xe (mesh la con cua pivot)")]
        [SerializeField] private Transform _frontLeftPivot;
        [SerializeField] private Transform _frontRightPivot;
        [SerializeField] private Transform _rearLeftPivot;
        [SerializeField] private Transform _rearRightPivot;

        private Rigidbody _rigidbody;
        private float _throttle;
        private float _steer;
        private float _currentSteerAngle;
        private bool _controlEnabled = true;
        private bool _poseLocked;

        public CarConfig Config
        {
            get { return _config; }
        }

        /// <summary>Van toc doc co dau (km/h): duong la tien, am la lui.</summary>
        public float SpeedKph
        {
            get
            {
                if (_rigidbody == null)
                {
                    return 0f;
                }

                return Vector3.Dot(_rigidbody.linearVelocity, transform.forward) * MetersPerSecondToKph;
            }
        }

        public bool IsControlEnabled
        {
            get { return _controlEnabled; }
        }

        public bool IsPoseLocked
        {
            get { return _poseLocked; }
        }

        private void Awake()
        {
            _rigidbody = GetComponent<Rigidbody>();
            ApplyConfigToRigidbody();
            ApplyConfigToWheels();
        }

        private void Update()
        {
            UpdateWheelVisual(_frontLeftWheel, _frontLeftPivot);
            UpdateWheelVisual(_frontRightWheel, _frontRightPivot);
            UpdateWheelVisual(_rearLeftWheel, _rearLeftPivot);
            UpdateWheelVisual(_rearRightWheel, _rearRightPivot);
        }

        private void FixedUpdate()
        {
            if (_config == null || _rigidbody == null)
            {
                return;
            }

            if (_poseLocked)
            {
                ApplyBrakeToAllWheels(_config.BrakeTorque);
                ApplyMotorTorque(0f);
                return;
            }

            UpdateSteering(Time.fixedDeltaTime);
            UpdateDrive();
            ApplyDownforce();
        }

        /// <summary>Nhan input da chuan hoa. Bo qua khi dang khoa dieu khien.</summary>
        public void SetInput(float throttle, float steer)
        {
            if (!_controlEnabled)
            {
                _throttle = 0f;
                _steer = 0f;
                return;
            }

            _throttle = Mathf.Clamp(throttle, -1f, 1f);
            _steer = Mathf.Clamp(steer, -1f, 1f);
        }

        /// <summary>Bat/tat dieu khien. Tat se xoa input nhung giu nguyen van toc hien tai.</summary>
        public void SetControlEnabled(bool enabled)
        {
            _controlEnabled = enabled;

            if (!enabled)
            {
                _throttle = 0f;
                _steer = 0f;
            }
        }

        /// <summary>
        /// Khoa xe tai cho (countdown, khoa sau reset): xoa van toc va chuyen kinematic.
        /// Mo khoa tra Rigidbody ve trang thai mo phong binh thuong.
        /// </summary>
        public void SetPoseLocked(bool locked)
        {
            if (_poseLocked == locked)
            {
                return;
            }

            _poseLocked = locked;

            if (_rigidbody == null)
            {
                return;
            }

            if (locked)
            {
                ClearVelocity();
                _rigidbody.isKinematic = true;
                return;
            }

            _rigidbody.isKinematic = false;
        }

        /// <summary>
        /// Dat lai vi tri/huong xe. Xoa van toc, goc lai va trang thai lam muot cua interpolation
        /// de xe khong bi keo tu vi tri cu sang vi tri moi.
        /// </summary>
        public void ResetTo(Vector3 position, Quaternion rotation)
        {
            if (_rigidbody == null)
            {
                transform.SetPositionAndRotation(position, rotation);
                return;
            }

            RigidbodyInterpolation previousInterpolation = _rigidbody.interpolation;
            _rigidbody.interpolation = RigidbodyInterpolation.None;

            ClearVelocity();

            transform.SetPositionAndRotation(position, rotation);
            _rigidbody.position = position;
            _rigidbody.rotation = rotation;

            _throttle = 0f;
            _steer = 0f;
            _currentSteerAngle = 0f;
            ResetWheelState();

            Physics.SyncTransforms();
            _rigidbody.interpolation = previousInterpolation;
        }

        private void UpdateSteering(float deltaTime)
        {
            float speedAbs = Mathf.Abs(SpeedKph);
            float t = Mathf.Clamp01(speedAbs / _config.SpeedForMinSteerKph);
            float maxAngle = Mathf.Lerp(_config.MaxSteerAngle, _config.MinSteerAngle, t);
            float targetAngle = _steer * maxAngle;

            _currentSteerAngle = Mathf.MoveTowards(
                _currentSteerAngle, targetAngle, _config.SteerSpeedDegPerSecond * deltaTime);

            SetSteerAngle(_frontLeftWheel, _currentSteerAngle);
            SetSteerAngle(_frontRightWheel, _currentSteerAngle);
        }

        private void UpdateDrive()
        {
            float speed = SpeedKph;
            float motorTorque = 0f;
            float brakeTorque = 0f;

            if (Mathf.Abs(_throttle) < 0.01f)
            {
                // Nha ga: ham nhe cho xe cham lai thay vi troi mai.
                brakeTorque = _config.EngineBrakeTorque;
            }
            else if (_throttle > 0f)
            {
                if (speed < -_config.ReverseThresholdKph)
                {
                    // Dang lui ma nhan ga tien: phanh truoc da.
                    brakeTorque = _config.BrakeTorque;
                }
                else if (speed < _config.MaxSpeedKph)
                {
                    motorTorque = _throttle * _config.MotorTorque;
                }
            }
            else
            {
                if (speed > _config.ReverseThresholdKph)
                {
                    // Dang tien ma nhan phanh/lui: phanh truoc da.
                    brakeTorque = _config.BrakeTorque;
                }
                else if (-speed < _config.MaxReverseSpeedKph)
                {
                    motorTorque = _throttle * _config.MotorTorque * _config.ReverseTorqueFactor;
                }
            }

            ApplyMotorTorque(motorTorque);
            ApplyBrakeToAllWheels(brakeTorque);
        }

        private void ApplyDownforce()
        {
            float speedAbs = Mathf.Abs(SpeedKph);
            float force = _config.DownforcePer100Kph * (speedAbs / 100f);
            _rigidbody.AddForce(-transform.up * force, ForceMode.Force);
        }

        private void ApplyMotorTorque(float torque)
        {
            SetMotorTorque(_rearLeftWheel, torque);
            SetMotorTorque(_rearRightWheel, torque);
        }

        private void ApplyBrakeToAllWheels(float torque)
        {
            SetBrakeTorque(_frontLeftWheel, torque);
            SetBrakeTorque(_frontRightWheel, torque);
            SetBrakeTorque(_rearLeftWheel, torque);
            SetBrakeTorque(_rearRightWheel, torque);
        }

        private void ClearVelocity()
        {
            if (_rigidbody.isKinematic)
            {
                return;
            }

            _rigidbody.linearVelocity = Vector3.zero;
            _rigidbody.angularVelocity = Vector3.zero;
        }

        private void ResetWheelState()
        {
            SetSteerAngle(_frontLeftWheel, 0f);
            SetSteerAngle(_frontRightWheel, 0f);
            ApplyMotorTorque(0f);
            ApplyBrakeToAllWheels(0f);
        }

        private void ApplyConfigToRigidbody()
        {
            if (_config == null || _rigidbody == null)
            {
                return;
            }

            _rigidbody.mass = _config.Mass;
            _rigidbody.linearDamping = _config.LinearDamping;
            _rigidbody.angularDamping = _config.AngularDamping;
            _rigidbody.centerOfMass = _config.CenterOfMass;
            _rigidbody.interpolation = RigidbodyInterpolation.Interpolate;
            _rigidbody.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
        }

        private void ApplyConfigToWheels()
        {
            ApplyConfigToWheel(_frontLeftWheel);
            ApplyConfigToWheel(_frontRightWheel);
            ApplyConfigToWheel(_rearLeftWheel);
            ApplyConfigToWheel(_rearRightWheel);
        }

        private void ApplyConfigToWheel(WheelCollider wheel)
        {
            if (wheel == null || _config == null)
            {
                return;
            }

            wheel.radius = _config.WheelRadius;
            wheel.mass = _config.WheelMass;
            wheel.suspensionDistance = _config.SuspensionDistance;

            JointSpring spring = wheel.suspensionSpring;
            spring.spring = _config.SuspensionSpring;
            spring.damper = _config.SuspensionDamper;
            spring.targetPosition = _config.SuspensionTargetPosition;
            wheel.suspensionSpring = spring;

            WheelFrictionCurve forward = wheel.forwardFriction;
            forward.stiffness = _config.ForwardFrictionStiffness;
            wheel.forwardFriction = forward;

            WheelFrictionCurve sideways = wheel.sidewaysFriction;
            sideways.stiffness = _config.SidewaysFrictionStiffness;
            wheel.sidewaysFriction = sideways;
        }

        /// <summary>
        /// Cap nhat pivot theo pose that cua WheelCollider. Mesh la con cua pivot nen giu nguyen
        /// goc dung va scale ban dau, khong bi lech truc.
        /// </summary>
        private static void UpdateWheelVisual(WheelCollider wheel, Transform pivot)
        {
            if (wheel == null || pivot == null)
            {
                return;
            }

            Vector3 position;
            Quaternion rotation;
            wheel.GetWorldPose(out position, out rotation);
            pivot.SetPositionAndRotation(position, rotation);
        }

        private static void SetMotorTorque(WheelCollider wheel, float torque)
        {
            if (wheel != null)
            {
                wheel.motorTorque = torque;
            }
        }

        private static void SetBrakeTorque(WheelCollider wheel, float torque)
        {
            if (wheel != null)
            {
                wheel.brakeTorque = torque;
            }
        }

        private static void SetSteerAngle(WheelCollider wheel, float angle)
        {
            if (wheel != null)
            {
                wheel.steerAngle = angle;
            }
        }
    }
}
