using UnityEngine;

namespace RacingDemo.Runtime.Vehicle
{
    /// <summary>
    /// Thong so xe de tune ngoai code. Generator KHONG duoc ghi de asset nay khi rebuild.
    /// Gia tri mac dinh huong toi cam giac arcade de lai, chua phai so cuoi cung.
    /// </summary>
    [CreateAssetMenu(menuName = "RacingDemo/Car Config", fileName = "CarConfig")]
    public sealed class CarConfig : ScriptableObject
    {
        [Header("Than xe")]
        [Tooltip("Khoi luong xe (kg).")]
        public float Mass = 1200f;

        [Tooltip("Trong tam so voi goc xe. Ha thap giup xe kho lat.")]
        public Vector3 CenterOfMass = new Vector3(0f, -0.35f, 0.1f);

        public float LinearDamping = 0.05f;
        public float AngularDamping = 3f;

        [Header("Banh xe va giam xoc")]
        public float WheelRadius = 0.34f;
        public float WheelMass = 20f;
        public float SuspensionDistance = 0.25f;
        public float SuspensionSpring = 32000f;
        public float SuspensionDamper = 4200f;

        [Range(0f, 1f)]
        public float SuspensionTargetPosition = 0.5f;

        public float ForwardFrictionStiffness = 2.2f;
        public float SidewaysFrictionStiffness = 2.6f;

        [Header("Dong co va phanh")]
        public float MotorTorque = 1400f;
        public float BrakeTorque = 2600f;

        [Tooltip("Luc ham nhe khi nha ga, de xe khong troi mai.")]
        public float EngineBrakeTorque = 260f;

        [Tooltip("He so torque khi di lui so voi di toi.")]
        [Range(0.1f, 1f)]
        public float ReverseTorqueFactor = 0.6f;

        [Header("Gioi han toc do")]
        public float MaxSpeedKph = 120f;
        public float MaxReverseSpeedKph = 20f;

        [Tooltip("|SpeedKph| duoi nguong nay thi throttle nguoc dau se doi chieu thay vi phanh.")]
        public float ReverseThresholdKph = 1f;

        [Header("Lai")]
        public float MaxSteerAngle = 32f;

        [Tooltip("Goc lai toi da khi da dat SpeedForMinSteerKph. Giam goc theo toc do cho de giu huong.")]
        public float MinSteerAngle = 12f;

        public float SpeedForMinSteerKph = 90f;
        public float SteerSpeedDegPerSecond = 160f;

        [Header("On dinh")]
        [Tooltip("Luc ep xuong theo toc do, giup banh bam duong khi chay nhanh.")]
        public float DownforcePer100Kph = 3000f;

        private void OnValidate()
        {
            Mass = Mathf.Max(1f, Mass);
            WheelRadius = Mathf.Max(0.05f, WheelRadius);
            WheelMass = Mathf.Max(1f, WheelMass);
            SuspensionDistance = Mathf.Max(0.01f, SuspensionDistance);
            SuspensionSpring = Mathf.Max(1f, SuspensionSpring);
            SuspensionDamper = Mathf.Max(0f, SuspensionDamper);
            MotorTorque = Mathf.Max(0f, MotorTorque);
            BrakeTorque = Mathf.Max(0f, BrakeTorque);
            EngineBrakeTorque = Mathf.Max(0f, EngineBrakeTorque);
            MaxSpeedKph = Mathf.Max(1f, MaxSpeedKph);
            MaxReverseSpeedKph = Mathf.Clamp(MaxReverseSpeedKph, 1f, MaxSpeedKph);
            ReverseThresholdKph = Mathf.Max(0.1f, ReverseThresholdKph);
            MaxSteerAngle = Mathf.Clamp(MaxSteerAngle, 1f, 60f);
            MinSteerAngle = Mathf.Clamp(MinSteerAngle, 1f, MaxSteerAngle);
            SpeedForMinSteerKph = Mathf.Max(1f, SpeedForMinSteerKph);
            SteerSpeedDegPerSecond = Mathf.Max(1f, SteerSpeedDegPerSecond);
        }
    }
}
