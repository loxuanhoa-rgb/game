namespace RacingDemo.Core.Persistence
{
    /// <summary>
    /// Ket qua khi nop thoi gian mot luot dua.
    /// Improved: nhanh hon ky luc da luu (hoac chua co ky luc).
    /// Saved: chi true khi ghi xuong dia thanh cong.
    /// Chi hien "ky luc moi da luu" khi ca hai deu true.
    /// </summary>
    public readonly struct RecordSubmissionResult
    {
        public RecordSubmissionResult(bool improved, bool saved, float? bestPersisted, string error)
        {
            Improved = improved;
            Saved = saved;
            BestPersisted = bestPersisted;
            Error = error;
        }

        public bool Improved { get; }

        public bool Saved { get; }

        /// <summary>Ky luc dang duoc coi la da nam tren dia; null khi chua co ky luc nao.</summary>
        public float? BestPersisted { get; }

        /// <summary>Mo ta loi de hien thi; null/rong khi khong co loi.</summary>
        public string Error { get; }

        public bool HasError
        {
            get { return !string.IsNullOrEmpty(Error); }
        }
    }
}
