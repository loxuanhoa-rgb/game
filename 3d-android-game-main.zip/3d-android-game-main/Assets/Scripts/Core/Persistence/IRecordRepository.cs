using System.Collections.Generic;

namespace RacingDemo.Core.Persistence
{
    /// <summary>
    /// Doc/ghi danh sach ky luc. Khong chua kieu Unity: Runtime cai dat bang JSON + file.
    /// Cai dat KHONG duoc nem loi cho truong hop hong du lieu thong thuong; tra false + error.
    /// (RecordStore van bat exception de phong cai dat lam sai hop dong.)
    /// </summary>
    public interface IRecordRepository
    {
        /// <summary>
        /// True khi doc thanh cong. File chua ton tai cung la thanh cong voi danh sach rong.
        /// False nghia la khong doc duoc an toan: ben goi phai ngung ghi de trong phien do.
        /// </summary>
        bool TryLoad(out IReadOnlyList<RecordData> records, out string error);

        /// <summary>True khi da ghi xong toan bo danh sach xuong dia.</summary>
        bool TrySave(IReadOnlyList<RecordData> records, out string error);
    }
}
