using System;
using RacingDemo.Core.Scoring;

namespace RacingDemo.Core.Persistence
{
    /// <summary>
    /// Mot ky luc da luu. Kieu nay duoc tao ca tu du lieu doc tu dia nen KHONG nem loi
    /// khi du lieu sai; ben goi loc bang <see cref="IsValid"/>.
    /// </summary>
    public sealed class RecordData
    {
        public RecordData(string trackId, float timeSeconds, Medal medal)
        {
            TrackId = trackId;
            TimeSeconds = timeSeconds;
            Medal = medal;
        }

        public string TrackId { get; }

        public float TimeSeconds { get; }

        public Medal Medal { get; }

        /// <summary>trackId khong rong, thoi gian huu han &gt; 0, medal nam trong enum.</summary>
        public bool IsValid
        {
            get
            {
                if (string.IsNullOrEmpty(TrackId))
                {
                    return false;
                }

                if (!Guard.IsFinite(TimeSeconds) || TimeSeconds <= 0f)
                {
                    return false;
                }

                return Enum.IsDefined(typeof(Medal), Medal);
            }
        }
    }
}
