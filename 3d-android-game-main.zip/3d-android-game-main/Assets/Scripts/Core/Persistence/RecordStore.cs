using System;
using System.Collections.Generic;
using RacingDemo.Core.Scoring;

namespace RacingDemo.Core.Persistence
{
    /// <summary>
    /// Giu ky luc tot nhat moi track va quyet dinh khi nao duoc ghi.
    /// Chinh sach: doc khong an toan thi khong ghi de trong phien do; ghi that bai thi
    /// giu nguyen cache cu va van cho thu lai o luot sau.
    /// </summary>
    public sealed class RecordStore
    {
        private readonly IRecordRepository _repository;
        private readonly Dictionary<string, RecordData> _bestByTrack =
            new Dictionary<string, RecordData>(StringComparer.Ordinal);

        private bool _loaded;

        public RecordStore(IRecordRepository repository)
        {
            if (repository == null)
            {
                throw new ArgumentNullException(nameof(repository));
            }

            _repository = repository;
        }

        /// <summary>True khi lan doc dau that bai: khong duoc ghi de file trong phien nay.</summary>
        public bool WritesDisabled { get; private set; }

        /// <summary>Loi gan nhat de hien thi; null khi chua co loi.</summary>
        public string LastError { get; private set; }

        /// <summary>Nap ky luc tu repository neu chua nap. Goi duoc nhieu lan.</summary>
        public void EnsureLoaded()
        {
            if (_loaded)
            {
                return;
            }

            _loaded = true;

            IReadOnlyList<RecordData> records = null;
            string error = null;
            bool loaded;

            try
            {
                loaded = _repository.TryLoad(out records, out error);
            }
            catch (Exception exception)
            {
                loaded = false;
                records = null;
                error = exception.Message;
            }

            if (!loaded)
            {
                WritesDisabled = true;
                LastError = string.IsNullOrEmpty(error) ? "Khong doc duoc ky luc." : error;
                return;
            }

            if (records == null)
            {
                return;
            }

            for (int i = 0; i < records.Count; i++)
            {
                RecordData record = records[i];
                if (record == null || !record.IsValid)
                {
                    continue;
                }

                RecordData current;
                if (!_bestByTrack.TryGetValue(record.TrackId, out current) ||
                    record.TimeSeconds < current.TimeSeconds)
                {
                    _bestByTrack[record.TrackId] = record;
                }
            }
        }

        /// <summary>Ky luc tot nhat da luu cua track; false khi chua co.</summary>
        public bool TryGetBest(string trackId, out RecordData record)
        {
            record = null;

            if (string.IsNullOrEmpty(trackId))
            {
                return false;
            }

            EnsureLoaded();
            return _bestByTrack.TryGetValue(trackId, out record);
        }

        /// <summary>
        /// Nop thoi gian mot luot. Khong bao gio nem loi: ket qua luon du de UI hien thi
        /// va van cho choi tiep khi luu that bai.
        /// </summary>
        public RecordSubmissionResult Submit(string trackId, float timeSeconds, Medal medal)
        {
            if (string.IsNullOrEmpty(trackId))
            {
                return new RecordSubmissionResult(false, false, null, "trackId rong.");
            }

            if (!Guard.IsFinite(timeSeconds) || timeSeconds <= 0f)
            {
                return new RecordSubmissionResult(false, false, null, "Thoi gian khong hop le.");
            }

            if (!Enum.IsDefined(typeof(Medal), medal))
            {
                return new RecordSubmissionResult(false, false, null, "Huy chuong khong hop le.");
            }

            EnsureLoaded();

            RecordData current;
            float? best = _bestByTrack.TryGetValue(trackId, out current)
                ? current.TimeSeconds
                : (float?)null;

            bool improved = !best.HasValue || timeSeconds < best.Value;
            if (!improved)
            {
                return new RecordSubmissionResult(false, false, best, null);
            }

            if (WritesDisabled)
            {
                return new RecordSubmissionResult(true, false, best, LastError);
            }

            List<RecordData> updated = BuildUpdatedRecords(trackId, timeSeconds, medal);

            string error = null;
            bool saved;

            try
            {
                saved = _repository.TrySave(updated, out error);
            }
            catch (Exception exception)
            {
                saved = false;
                error = exception.Message;
            }

            if (!saved)
            {
                // Giu cache cu: khong bao da luu khi chua ghi duoc.
                LastError = string.IsNullOrEmpty(error) ? "Khong luu duoc ky luc." : error;
                return new RecordSubmissionResult(true, false, best, LastError);
            }

            _bestByTrack[trackId] = new RecordData(trackId, timeSeconds, medal);
            LastError = null;
            return new RecordSubmissionResult(true, true, timeSeconds, null);
        }

        private List<RecordData> BuildUpdatedRecords(string trackId, float timeSeconds, Medal medal)
        {
            var updated = new List<RecordData>(_bestByTrack.Count + 1);

            foreach (KeyValuePair<string, RecordData> pair in _bestByTrack)
            {
                if (string.Equals(pair.Key, trackId, StringComparison.Ordinal))
                {
                    continue;
                }

                updated.Add(pair.Value);
            }

            updated.Add(new RecordData(trackId, timeSeconds, medal));
            return updated;
        }
    }
}
