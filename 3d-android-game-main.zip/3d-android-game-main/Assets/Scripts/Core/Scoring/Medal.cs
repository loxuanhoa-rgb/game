namespace RacingDemo.Core.Scoring
{
    /// <summary>Huy chuong theo thoi gian hoan thanh. None = chua dat nguong nao.</summary>
    public enum Medal
    {
        None = 0,
        Bronze = 1,
        Silver = 2,
        Gold = 3
    }
}
