using System;

namespace RacingDemo.Core.Scoring
{
    /// <summary>
    /// Quy doi thoi gian hoan thanh sang huy chuong.
    /// Thoi gian bang dung nguong van dat huy chuong do.
    /// </summary>
    public static class MedalEvaluator
    {
        public static Medal Evaluate(float timeSeconds, MedalThresholds thresholds)
        {
            if (thresholds == null)
            {
                throw new ArgumentNullException(nameof(thresholds));
            }

            Guard.ValidateFinitePositive(timeSeconds, nameof(timeSeconds));

            if (timeSeconds <= thresholds.GoldSeconds)
            {
                return Medal.Gold;
            }

            if (timeSeconds <= thresholds.SilverSeconds)
            {
                return Medal.Silver;
            }

            if (timeSeconds <= thresholds.BronzeSeconds)
            {
                return Medal.Bronze;
            }

            return Medal.None;
        }
    }
}
