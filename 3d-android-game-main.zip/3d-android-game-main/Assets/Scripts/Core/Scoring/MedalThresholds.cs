using System;

namespace RacingDemo.Core.Scoring
{
    /// <summary>
    /// Nguong thoi gian (giay) cho tung huy chuong. Gold nhanh nhat, phai tang dan chat che.
    /// </summary>
    public sealed class MedalThresholds
    {
        public MedalThresholds(float goldSeconds, float silverSeconds, float bronzeSeconds)
        {
            Guard.ValidateFinitePositive(goldSeconds, nameof(goldSeconds));
            Guard.ValidateFinitePositive(silverSeconds, nameof(silverSeconds));
            Guard.ValidateFinitePositive(bronzeSeconds, nameof(bronzeSeconds));

            if (!(goldSeconds < silverSeconds))
            {
                throw new ArgumentOutOfRangeException(
                    nameof(silverSeconds), silverSeconds, "Silver phai lon hon Gold.");
            }

            if (!(silverSeconds < bronzeSeconds))
            {
                throw new ArgumentOutOfRangeException(
                    nameof(bronzeSeconds), bronzeSeconds, "Bronze phai lon hon Silver.");
            }

            GoldSeconds = goldSeconds;
            SilverSeconds = silverSeconds;
            BronzeSeconds = bronzeSeconds;
        }

        public float GoldSeconds { get; }

        public float SilverSeconds { get; }

        public float BronzeSeconds { get; }

        /// <summary>
        /// Nguong tam thoi cho 2 vong (Gold 85 s / Silver 100 s / Bronze 120 s).
        /// Se thay bang so do that o Task 6.
        /// </summary>
        public static MedalThresholds CreateProvisional()
        {
            return new MedalThresholds(85f, 100f, 120f);
        }
    }
}
