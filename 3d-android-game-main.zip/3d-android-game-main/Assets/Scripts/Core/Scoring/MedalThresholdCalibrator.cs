using System;
using System.Collections.Generic;

namespace RacingDemo.Core.Scoring
{
    /// <summary>
    /// Tinh nguong huy chuong tu cac lan chay that, theo cong thuc chot o Task 6 cua ke hoach:
    /// gold = nhanh nhat x 1,03; silver = max(trung vi, gold + 1 s); bronze = max(cham nhat x 1,10, silver + 1 s).
    ///
    /// Ham thuan: khong doc dong ho, khong doc file. Nguoi goi tu lo phan thu thap so lieu.
    /// </summary>
    public static class MedalThresholdCalibrator
    {
        /// <summary>Ke hoach yeu cau it nhat 10 luot hoan chinh truoc khi chot nguong.</summary>
        public const int MinimumSampleCount = 10;

        private const float GoldFactor = 1.03f;
        private const float BronzeFactor = 1.10f;
        private const float MinimumGapSeconds = 1f;

        /// <param name="lapTimesSeconds">Thoi gian cua cac luot da hoan thanh (giay).</param>
        /// <param name="minimumSampleCount">So luot toi thieu; mac dinh la muc ke hoach yeu cau.</param>
        public static MedalThresholds Calibrate(
            IReadOnlyList<float> lapTimesSeconds, int minimumSampleCount = MinimumSampleCount)
        {
            if (lapTimesSeconds == null)
            {
                throw new ArgumentNullException(nameof(lapTimesSeconds));
            }

            if (minimumSampleCount < 1)
            {
                throw new ArgumentOutOfRangeException(
                    nameof(minimumSampleCount), minimumSampleCount, "Phai co it nhat 1 luot.");
            }

            float[] sorted = SortValid(lapTimesSeconds);
            if (sorted.Length < minimumSampleCount)
            {
                throw new ArgumentException(
                    "Can it nhat " + minimumSampleCount + " luot hop le, chi co " + sorted.Length + ".",
                    nameof(lapTimesSeconds));
            }

            float fastest = sorted[0];
            float slowest = sorted[sorted.Length - 1];

            float gold = fastest * GoldFactor;
            float silver = Max(Median(sorted), gold + MinimumGapSeconds);
            float bronze = Max(slowest * BronzeFactor, silver + MinimumGapSeconds);

            // Nhan doi so lan nua: MedalThresholds tu no cung tu choi bo nguong khong tang dan.
            return new MedalThresholds(gold, silver, bronze);
        }

        /// <summary>Trung vi cua day DA SAP XEP; so luong chan thi lay trung binh hai gia tri giua.</summary>
        public static float Median(IReadOnlyList<float> sortedValues)
        {
            if (sortedValues == null)
            {
                throw new ArgumentNullException(nameof(sortedValues));
            }

            if (sortedValues.Count == 0)
            {
                throw new ArgumentException("Day rong khong co trung vi.", nameof(sortedValues));
            }

            int middle = sortedValues.Count / 2;
            return sortedValues.Count % 2 == 1
                ? sortedValues[middle]
                : (sortedValues[middle - 1] + sortedValues[middle]) * 0.5f;
        }

        /// <summary>Bo cac gia tri khong huu han hoac khong duong roi sap xep tang dan.</summary>
        private static float[] SortValid(IReadOnlyList<float> values)
        {
            var valid = new List<float>(values.Count);
            for (int i = 0; i < values.Count; i++)
            {
                float value = values[i];
                if (Guard.IsFinite(value) && value > 0f)
                {
                    valid.Add(value);
                }
            }

            float[] sorted = valid.ToArray();
            Array.Sort(sorted);
            return sorted;
        }

        // Core khong dung UnityEngine.Mathf.
        private static float Max(float a, float b)
        {
            return a > b ? a : b;
        }
    }
}
