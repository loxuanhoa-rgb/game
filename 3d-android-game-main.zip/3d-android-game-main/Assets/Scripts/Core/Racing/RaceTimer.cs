namespace RacingDemo.Core.Racing
{
    /// <summary>
    /// Dong ho cong don cua luot dua. Cong don bang double de tranh sai so tich luy,
    /// nhung cong bo ra ngoai bang float cho tien dung o Runtime/UI.
    /// </summary>
    public sealed class RaceTimer
    {
        private double _elapsedSeconds;

        public float ElapsedSeconds
        {
            get { return (float)_elapsedSeconds; }
        }

        public void Advance(float deltaSeconds)
        {
            Guard.ValidateDeltaSeconds(deltaSeconds, nameof(deltaSeconds));
            _elapsedSeconds += deltaSeconds;
        }

        public void Reset()
        {
            _elapsedSeconds = 0d;
        }
    }
}
