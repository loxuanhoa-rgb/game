using System;

namespace RacingDemo.Core.Racing
{
    /// <summary>
    /// Cau hinh luat dua duoi dang so thuan. Runtime chuyen TrackDefinition thanh kieu nay.
    /// </summary>
    public sealed class RaceConfig
    {
        public const int MinCheckpointCount = 2;

        public RaceConfig(int checkpointCount, int lapCount, float countdownSeconds, float respawnLockSeconds)
        {
            if (checkpointCount < MinCheckpointCount)
            {
                throw new ArgumentOutOfRangeException(
                    nameof(checkpointCount), checkpointCount, "Can it nhat " + MinCheckpointCount + " checkpoint.");
            }

            if (lapCount < 1)
            {
                throw new ArgumentOutOfRangeException(nameof(lapCount), lapCount, "So vong phai >= 1.");
            }

            Guard.ValidateFiniteNonNegative(countdownSeconds, nameof(countdownSeconds));
            Guard.ValidateFiniteNonNegative(respawnLockSeconds, nameof(respawnLockSeconds));

            CheckpointCount = checkpointCount;
            LapCount = lapCount;
            CountdownSeconds = countdownSeconds;
            RespawnLockSeconds = respawnLockSeconds;
        }

        public int CheckpointCount { get; }

        public int LapCount { get; }

        public float CountdownSeconds { get; }

        public float RespawnLockSeconds { get; }

        /// <summary>Thong so chot trong ke hoach: 4 checkpoint, 2 vong, dem 3 giay, khoa reset 1,5 giay.</summary>
        public static RaceConfig CreateDemoDefault()
        {
            return new RaceConfig(4, 2, 3f, 1.5f);
        }
    }
}
