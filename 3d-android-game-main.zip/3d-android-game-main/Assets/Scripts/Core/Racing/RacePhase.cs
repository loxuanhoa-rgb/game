namespace RacingDemo.Core.Racing
{
    /// <summary>
    /// Trang thai chinh cua mot luot dua. Respawn KHONG phai mot phase:
    /// no la trang thai phu <see cref="RaceRules.IsRespawning"/> cua Running.
    /// </summary>
    public enum RacePhase
    {
        Idle = 0,
        Countdown = 1,
        Running = 2,
        Paused = 3,
        Finished = 4
    }
}
