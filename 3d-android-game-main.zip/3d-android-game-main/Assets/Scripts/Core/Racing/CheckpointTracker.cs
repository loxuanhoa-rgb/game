using System;

namespace RacingDemo.Core.Racing
{
    /// <summary>
    /// Theo doi tien trinh checkpoint/vong. Chi nhan checkpoint dung chi so tiep theo.
    /// Checkpoint co chi so lon nhat dong thoi la vach ket thuc vong.
    /// </summary>
    public sealed class CheckpointTracker
    {
        private readonly int _checkpointCount;
        private readonly int _lapCount;

        public CheckpointTracker(int checkpointCount, int lapCount)
        {
            if (checkpointCount < RaceConfig.MinCheckpointCount)
            {
                throw new ArgumentOutOfRangeException(
                    nameof(checkpointCount), checkpointCount, "Can it nhat " + RaceConfig.MinCheckpointCount + " checkpoint.");
            }

            if (lapCount < 1)
            {
                throw new ArgumentOutOfRangeException(nameof(lapCount), lapCount, "So vong phai >= 1.");
            }

            _checkpointCount = checkpointCount;
            _lapCount = lapCount;
            Reset();
        }

        /// <summary>Chi so checkpoint tiep theo can di qua (0..CheckpointCount-1).</summary>
        public int NextCheckpointIndex { get; private set; }

        /// <summary>Vong hien tai, dem tu 1.</summary>
        public int CurrentLap { get; private set; }

        /// <summary>
        /// Checkpoint da nhan gan nhat; null khi chua qua cong nao.
        /// Dau vong 2 gia tri nay van la chi so cong cuoi, khong suy ra tu NextCheckpointIndex.
        /// </summary>
        public int? LastAcceptedCheckpointIndex { get; private set; }

        /// <summary>True sau khi da qua cong cuoi cua vong cuoi.</summary>
        public bool IsComplete { get; private set; }

        public int CheckpointCount
        {
            get { return _checkpointCount; }
        }

        public int LapCount
        {
            get { return _lapCount; }
        }

        public void Reset()
        {
            NextCheckpointIndex = 0;
            CurrentLap = 1;
            LastAcceptedCheckpointIndex = null;
            IsComplete = false;
        }

        public CheckpointPassResult TryPass(int index)
        {
            if (IsComplete)
            {
                return CheckpointPassResult.Rejected;
            }

            if (index != NextCheckpointIndex)
            {
                return CheckpointPassResult.Rejected;
            }

            LastAcceptedCheckpointIndex = index;

            bool isLapGate = index == _checkpointCount - 1;
            if (!isLapGate)
            {
                NextCheckpointIndex = index + 1;
                return CheckpointPassResult.Accepted;
            }

            NextCheckpointIndex = 0;

            if (CurrentLap >= _lapCount)
            {
                IsComplete = true;
                return CheckpointPassResult.RaceCompleted;
            }

            CurrentLap++;
            return CheckpointPassResult.LapCompleted;
        }
    }
}
