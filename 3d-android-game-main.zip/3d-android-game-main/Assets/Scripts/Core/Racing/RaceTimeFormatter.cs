using System;
using System.Globalization;

namespace RacingDemo.Core.Racing
{
    /// <summary>
    /// Ham thuan doi giay sang chuoi hien thi "mm:ss.mmm". UI khong giu dong ho rieng,
    /// chi format gia tri doc tu Core.
    /// </summary>
    public static class RaceTimeFormatter
    {
        public const string ZeroText = "00:00.000";

        /// <summary>
        /// Cat (floor) phan mili giay de so hien thi khong bao gio vuot thoi gian that.
        /// Truoc khi cat, gia tri duoc gan ve mili giay gan nhat neu sai lech chi nam trong
        /// pham vi sai so cua float (vi du 1.234f luu thanh 1.23399996 van hien 1.234).
        /// Gia tri khong huu han hoac khong duong duoc coi la 0 de UI khong vo.
        /// </summary>
        public static string Format(float seconds)
        {
            if (float.IsNaN(seconds) || float.IsInfinity(seconds) || seconds <= 0f)
            {
                return ZeroText;
            }

            double totalMilliseconds = (double)seconds * 1000d;
            double nearestMillisecond = Math.Round(totalMilliseconds);
            double floatTolerance = Math.Abs(totalMilliseconds) * 1e-6d + 1e-4d;

            if (Math.Abs(totalMilliseconds - nearestMillisecond) <= floatTolerance)
            {
                totalMilliseconds = nearestMillisecond;
            }

            long total = (long)Math.Floor(totalMilliseconds);
            long minutes = total / 60000L;
            long remainder = total - minutes * 60000L;
            long secondsPart = remainder / 1000L;
            long millisecondsPart = remainder - secondsPart * 1000L;

            return string.Format(
                CultureInfo.InvariantCulture,
                "{0:00}:{1:00}.{2:000}",
                minutes,
                secondsPart,
                millisecondsPart);
        }
    }
}
