namespace RacingDemo.Core.Racing
{
    /// <summary>Ket qua khi thu di qua mot cong checkpoint.</summary>
    public enum CheckpointPassResult
    {
        /// <summary>Sai thu tu, lap lai, hoac dua da ket thuc.</summary>
        Rejected = 0,

        /// <summary>Nhan checkpoint, chua het vong.</summary>
        Accepted = 1,

        /// <summary>Nhan checkpoint cuoi vong va con vong tiep theo.</summary>
        LapCompleted = 2,

        /// <summary>Nhan checkpoint cuoi cua vong cuoi: hoan thanh cuoc dua.</summary>
        RaceCompleted = 3
    }
}
