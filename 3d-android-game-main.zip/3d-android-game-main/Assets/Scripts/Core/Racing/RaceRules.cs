using System;

namespace RacingDemo.Core.Racing
{
    /// <summary>
    /// May trang thai cua mot luot dua: countdown, chay, pause, respawn, ket thuc.
    /// Khong dung UnityEngine va khong dung dong ho he thong; moi cap nhat thoi gian
    /// di qua <see cref="Tick"/>.
    /// </summary>
    public sealed class RaceRules
    {
        private readonly RaceConfig _config;
        private readonly RaceTimer _timer = new RaceTimer();
        private readonly CheckpointTracker _tracker;

        private RacePhase _phase = RacePhase.Idle;
        private RacePhase _phaseBeforePause = RacePhase.Idle;
        private float _countdownRemaining;
        private float _respawnRemaining;
        private bool _isRespawning;
        private bool _finishReported;

        public RaceRules(RaceConfig config)
        {
            if (config == null)
            {
                throw new ArgumentNullException(nameof(config));
            }

            _config = config;
            _tracker = new CheckpointTracker(config.CheckpointCount, config.LapCount);
        }

        /// <summary>Phat khi Phase thuc su doi gia tri.</summary>
        public event Action<RacePhase> PhaseChanged;

        /// <summary>Phat dung mot lan moi luot, kem thoi gian chot cuoi.</summary>
        public event Action<float> RaceFinished;

        public RaceConfig Config
        {
            get { return _config; }
        }

        public RacePhase Phase
        {
            get { return _phase; }
        }

        public float ElapsedSeconds
        {
            get { return _timer.ElapsedSeconds; }
        }

        public float CountdownRemaining
        {
            get { return _countdownRemaining; }
        }

        public int CurrentLap
        {
            get { return _tracker.CurrentLap; }
        }

        public int NextCheckpointIndex
        {
            get { return _tracker.NextCheckpointIndex; }
        }

        public int? LastAcceptedCheckpointIndex
        {
            get { return _tracker.LastAcceptedCheckpointIndex; }
        }

        public float RespawnRemaining
        {
            get { return _respawnRemaining; }
        }

        public bool IsRespawning
        {
            get { return _isRespawning; }
        }

        /// <summary>Bat dau mot luot moi: xoa toan bo tien trinh cu va dem nguoc.</summary>
        public void BeginCountdown()
        {
            _timer.Reset();
            _tracker.Reset();
            _isRespawning = false;
            _respawnRemaining = 0f;
            _finishReported = false;
            _phaseBeforePause = RacePhase.Idle;
            _countdownRemaining = _config.CountdownSeconds;

            if (_countdownRemaining <= 0f)
            {
                _countdownRemaining = 0f;
                SetPhase(RacePhase.Running);
                return;
            }

            SetPhase(RacePhase.Countdown);
        }

        /// <summary>
        /// Restart tu Pause hoac Results: huy tien trinh respawn cu, xoa trang thai luot
        /// va bat dau countdown moi. Hanh vi giong BeginCountdown, dat ten rieng cho ro y dinh.
        /// </summary>
        public void Restart()
        {
            BeginCountdown();
        }

        /// <summary>
        /// Cap nhat thoi gian. Delta phai huu han va khong am; 0 khong doi trang thai.
        /// Khi delta di qua moc het countdown, chi phan du duoc tinh vao cuoc dua.
        /// </summary>
        public void Tick(float deltaSeconds)
        {
            Guard.ValidateDeltaSeconds(deltaSeconds, nameof(deltaSeconds));

            if (deltaSeconds == 0f)
            {
                return;
            }

            if (_phase == RacePhase.Countdown)
            {
                TickCountdown(deltaSeconds);
                return;
            }

            if (_phase == RacePhase.Running)
            {
                TickRunning(deltaSeconds);
            }

            // Idle, Paused, Finished: khong thay doi gi.
        }

        /// <summary>
        /// Bao cho Core biet xe vua qua mot cong. Tra ve true khi checkpoint duoc cong nhan.
        /// </summary>
        public bool TryPassCheckpoint(int index)
        {
            if (_phase != RacePhase.Running || _isRespawning)
            {
                return false;
            }

            CheckpointPassResult result = _tracker.TryPass(index);
            if (result == CheckpointPassResult.Rejected)
            {
                return false;
            }

            if (result == CheckpointPassResult.RaceCompleted)
            {
                Finish();
            }

            return true;
        }

        /// <summary>
        /// Yeu cau dua xe ve checkpoint da qua. Chi nhan khi dang Running va chua respawn;
        /// nhan nhieu lan khong gia han khoa xe.
        /// </summary>
        public bool TryRequestRespawn()
        {
            if (_phase != RacePhase.Running || _isRespawning)
            {
                return false;
            }

            if (_config.RespawnLockSeconds <= 0f)
            {
                _respawnRemaining = 0f;
                _isRespawning = false;
                return true;
            }

            _isRespawning = true;
            _respawnRemaining = _config.RespawnLockSeconds;
            return true;
        }

        /// <summary>Pause tu Countdown/Running. Idempotent; cac phase khac bo qua.</summary>
        public void Pause()
        {
            if (_phase != RacePhase.Countdown && _phase != RacePhase.Running)
            {
                return;
            }

            _phaseBeforePause = _phase;
            SetPhase(RacePhase.Paused);
        }

        /// <summary>Resume ve dung phase truoc pause, giu nguyen countdown/respawn con lai.</summary>
        public void Resume()
        {
            if (_phase != RacePhase.Paused)
            {
                return;
            }

            RacePhase restored = _phaseBeforePause == RacePhase.Countdown
                ? RacePhase.Countdown
                : RacePhase.Running;

            _phaseBeforePause = RacePhase.Idle;
            SetPhase(restored);
        }

        private void TickCountdown(float deltaSeconds)
        {
            _countdownRemaining -= deltaSeconds;
            if (_countdownRemaining > 0f)
            {
                return;
            }

            float overflow = -_countdownRemaining;
            _countdownRemaining = 0f;
            SetPhase(RacePhase.Running);

            // Handler cua PhaseChanged co the pause ngay; chi tinh phan du khi van dang chay.
            if (overflow > 0f && _phase == RacePhase.Running)
            {
                TickRunning(overflow);
            }
        }

        private void TickRunning(float deltaSeconds)
        {
            _timer.Advance(deltaSeconds);

            if (!_isRespawning)
            {
                return;
            }

            _respawnRemaining -= deltaSeconds;
            if (_respawnRemaining <= 0f)
            {
                _respawnRemaining = 0f;
                _isRespawning = false;
            }
        }

        private void Finish()
        {
            if (_finishReported)
            {
                return;
            }

            _finishReported = true;
            _isRespawning = false;
            _respawnRemaining = 0f;
            SetPhase(RacePhase.Finished);

            Action<float> handler = RaceFinished;
            if (handler != null)
            {
                handler(_timer.ElapsedSeconds);
            }
        }

        private void SetPhase(RacePhase phase)
        {
            if (_phase == phase)
            {
                return;
            }

            _phase = phase;

            Action<RacePhase> handler = PhaseChanged;
            if (handler != null)
            {
                handler(phase);
            }
        }
    }
}
