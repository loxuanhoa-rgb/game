using System;

namespace RacingDemo.Core
{
    /// <summary>
    /// Kiem tra tham so dung chung trong Core. Core khong dung UnityEngine.Mathf.
    /// </summary>
    internal static class Guard
    {
        internal static bool IsFinite(float value)
        {
            return !float.IsNaN(value) && !float.IsInfinity(value);
        }

        /// <summary>Delta thoi gian phai huu han va khong am (0 duoc phep).</summary>
        internal static void ValidateDeltaSeconds(float deltaSeconds, string paramName)
        {
            if (!IsFinite(deltaSeconds))
            {
                throw new ArgumentException("deltaSeconds phai la so huu han.", paramName);
            }

            if (deltaSeconds < 0f)
            {
                throw new ArgumentOutOfRangeException(paramName, deltaSeconds, "deltaSeconds khong duoc am.");
            }
        }

        internal static void ValidateFiniteNonNegative(float value, string paramName)
        {
            if (!IsFinite(value))
            {
                throw new ArgumentException("Gia tri phai la so huu han.", paramName);
            }

            if (value < 0f)
            {
                throw new ArgumentOutOfRangeException(paramName, value, "Gia tri khong duoc am.");
            }
        }

        internal static void ValidateFinitePositive(float value, string paramName)
        {
            if (!IsFinite(value))
            {
                throw new ArgumentException("Gia tri phai la so huu han.", paramName);
            }

            if (value <= 0f)
            {
                throw new ArgumentOutOfRangeException(paramName, value, "Gia tri phai lon hon 0.");
            }
        }
    }
}
