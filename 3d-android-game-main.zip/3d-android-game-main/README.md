# APEX — Mùa Nắng

Demo đua xe tại **Đồi Mây**, thị trấn cao nguyên Việt Nam hư cấu. Một xe, một đường đua khép kín dạng sân vận động, đếm ngược 3 giây, chạy **2 vòng**
qua **4 checkpoint** đúng thứ tự, xem thời gian + huy chương, lưu kỷ lục ngay trên máy.
Chơi offline, không quảng cáo, không tài khoản, không cần mạng.

| | |
|---|---|
| Engine | Unity **6000.6.0f1** + URP 17.6.0 |
| Nền tảng | Android, tối thiểu API 26, ARM64, IL2CPP, OpenGLES3 |
| Package ID | `com.vuit.racingdemo` |
| Hướng màn hình | Landscape Left |
| APK bàn giao | `Builds/Android/racing-demo.apk` (bản Release) |

## Hình ảnh hiện tại

Phong cách **APEX / Mùa Nắng**: ánh sáng chiều ấm, xanh mực–kem–cam đất, núi low-poly,
**Sân hội, Garage Mây, Đồi Thông và Quán Dốc Nắng**, khán giả, cờ và cụm cây bụi–đá.
UI tiếng Việt dùng Be Vietnam Pro, lời nhắn của thợ máy An ở thiệp lễ hội và kết quả.
Nhạc nền/tiếng gió tự tổng hợp, có tùy chọn nhạc và âm thanh lưu riêng trên máy.
Các chi tiết chỉ phục vụ hình ảnh; giữ nguyên collider và thông số lái.

Release hiện tại (sửa tiếng gió, commit `da766e5`): **31.265.211 byte**, SHA256
`53B0FB6E8AE522D77AD8C9181519A594570E0F85C50051C4024AE5E00F6A6B2E`.
Đã kiểm **151 EditMode, 36 PlayMode**, cài và mở trên Pixel 9 và Xiaomi 14.
Người chơi xác nhận trên Xiaomi: hết tiếng gió rè, tiếng ga vẫn ổn; kỷ lục giữ nguyên.
Hiệu năng được người chơi đánh giá ổn; chưa có phép đo 15 phút ×2 hợp lệ cho bản cuối.
Development đã đồng bộ bản sửa audio, source `390e80e`: **63.105.163 byte**, SHA256
`41FABBEF9E1AAAAEEA5456EF676C53D4412F4295A58611723715644E8A067D1E`.
Pixel 9 đã chạy đủ hai vòng **02:02.233 / Đồng**, lưu và đọc lại kỷ lục sau khởi động lại đạt;
dữ liệu gốc được khôi phục nguyên vẹn. Thử lỗi lưu đạt: thông báo lỗi hiện đúng, Đua lại/Về lễ hội vẫn dùng được.
Pause/chơi tiếp, Home/quay lại giữ Pause và tùy chọn âm thanh lưu qua force-stop đều đạt.
Chất lượng âm nghe trực tiếp trên Development chưa đánh giá; xác nhận nghe trên Xiaomi ở trên thuộc Release.
Checkout sạch từ `390e80e`, không có `Library` ban đầu: generate/validator đạt, rebuild **3/3**,
**151/151 EditMode và 36/36 PlayMode**, failed/skipped = 0. Build Release riêng đạt:
**31.265.311 byte**, SHA256 `D79318F161EB6A29D6DCB5B89AFF943E5FC814BD13753A4168CBB4EE7A009C15`;
tuning và `.meta` trước/sau trùng hash. APK kiểm checkout giữ riêng, chưa cài/chạy trên thiết bị.
APK và log không nằm trong Git; build theo hướng dẫn bên dưới.

## Việc tiếp theo để chốt bàn giao

Ba việc kỹ thuật — đồng bộ Development, thử lỗi lưu và kiểm checkout sạch — đã hoàn tất.

1. Chốt checklist máy thật còn thiếu bằng chứng (10 lượt liên tiếp, vòng đời/input, ngưỡng huy chương người chơi).
   Hiệu năng/độ trễ định lượng vẫn ghi chưa kiểm chứng; không yêu cầu đo tiếp nếu người dùng không muốn.
2. Bàn giao APK cùng source và kết quả kiểm; chỉ tạo tag/release khi người dùng yêu cầu.

## Cài nhanh để chơi thử

```powershell
$adb = "$env:LOCALAPPDATA/Android/Sdk/platform-tools/adb.exe"
& $adb install -r './Builds/Android/racing-demo.apk'
& $adb shell am start -n com.vuit.racingdemo/com.unity3d.player.UnityPlayerGameActivity
```

Luồng chơi: **Thiệp lễ hội → Vào đua → Kết quả → Đua lại / Về lễ hội**.
Xe đứng yên tại lễ hội; Đua lại bắt đầu countdown mới, Về lễ hội bỏ lượt đang dở.

Điều khiển: **GA** và **PHANH** bên phải, **thanh lái** `< … >` bên trái (chạm/kéo lệch khỏi tâm,
càng xa càng rẽ gắt), **GỠ KẸT** đưa xe về checkpoint gần nhất đã qua, nút **II** tạm dừng. Giữ ga
bằng một ngón và lái bằng ngón kia — game nhận hai điểm chạm cùng lúc.

## Mở dự án bằng Unity

1. Cài **Unity 6000.6.0f1** kèm module *Android Build Support* (gồm OpenJDK, SDK & NDK).
   Không dùng SDK của Android Studio để build; adb của Android Studio thì dùng được.
2. Có **Git LFS** (model `.fbx`, texture `.png` và file âm thanh `.wav` lưu qua LFS):

   ```powershell
   git lfs install
   git lfs pull
   ```

3. Mở thư mục repo bằng Unity Hub. Lần đầu Unity import mất vài phút.
4. Trong Editor, menu **RacingDemo** có sẵn: *Rebuild Demo*, *Validate Build Scenes*,
   *Build/Android Development*, *Build/Android Release*.

Scene duy nhất là `Assets/Scenes/Race.unity`. Toàn bộ nội dung trong cây `__GeneratedScene` do
`RacingDemo/Rebuild Demo` dựng lại được; đồ tự thêm phải để **ngoài** cây đó.

## Build lại từ dòng lệnh

Đóng Unity Editor trước, rồi chạy tại thư mục gốc repo:

```powershell
$unityExe = 'D:/UnityHub/6000.6.0f1/Editor/Unity.exe'
$root = (Get-Location).Path

# Dung lai scene va asset sinh tu dong
& $unityExe -batchmode -quit -nographics -projectPath $root `
    -executeMethod RacingDemo.EditorTools.DemoProjectGenerator.RebuildDemo `
    -logFile Artifacts/generate.log

# Kiem tra scene truoc khi build
& $unityExe -batchmode -quit -nographics -projectPath $root `
    -executeMethod RacingDemo.EditorTools.SceneValidator.ValidateBuildScenes `
    -logFile Artifacts/validate.log

# Build APK Release -> Builds/Android/racing-demo.apk
& $unityExe -batchmode -quit -projectPath $root -buildTarget Android `
    -executeMethod RacingDemo.EditorTools.BuildCommand.BuildAndroidRelease `
    -logFile Artifacts/build-release.log
```

Chạy test (**không** thêm `-quit` vào lệnh `-runTests`; sau đó **đọc file XML**, vì exit code 0 với
0 test là thất bại chứ không phải thành công):

```powershell
& $unityExe -batchmode -projectPath $root -buildTarget StandaloneWindows64 -nographics `
    -runTests -testPlatform EditMode `
    -testResults Artifacts/editmode.xml -logFile Artifacts/editmode.log

& $unityExe -batchmode -projectPath $root -buildTarget StandaloneWindows64 `
    -runTests -testPlatform PlayMode `
    -testResults Artifacts/playmode.xml -logFile Artifacts/playmode.log
```

Danh sách lệnh đầy đủ nằm ở [AGENTS.md](AGENTS.md) mục 6.

## Cấu trúc mã nguồn

| Assembly | Nội dung | Ràng buộc |
|---|---|---|
| `RacingDemo.Core` | Luật đua, thời gian, checkpoint, huy chương, kỷ lục | C# thuần, `noEngineReferences: true` — không `UnityEngine`, không `System.IO`, không đồng hồ hệ thống |
| `RacingDemo.Runtime` | MonoBehaviour: xe, camera, input cảm ứng, HUD, âm thanh, lưu JSON | Không viết lại luật đua; mọi luật gọi về Core |
| `RacingDemo.Editor` | Sinh scene/asset, validator, lệnh build, hiệu chỉnh huy chương | Chỉ chạy trong Editor |
| `RacingDemo.Tests.*` | EditMode (luật + hàm thuần), TrackEditMode (hình học, validator, âm thanh), PlayMode (scene thật) | |

Mọi cập nhật thời gian trong Core đi qua `Tick(float deltaSeconds)` — không đọc `Time.time`.

## Tài liệu

| File | Nội dung |
|---|---|
| [2026-09-06-android-racing-demo.md](2026-09-06-android-racing-demo.md) | Kế hoạch gốc — **nguồn sự thật** |
| [PROGRESS.md](PROGRESS.md) | Đã làm gì, kiểm chứng bằng cách nào, còn thiếu gì, sai lệch so với kế hoạch |
| [GAME_DESIGN.md](GAME_DESIGN.md) | Thông số xe, đường đua, luật chơi, ngưỡng huy chương |
| [AGENTS.md](AGENTS.md) | Quy ước làm việc trên repo, lệnh PowerShell, cách chạy emulator |
| [HANDOFF.md](HANDOFF.md) | Điểm bắt đầu cho người/agent tiếp theo, kèm các bẫy đã gặp |
| [Assets/ThirdParty/KenneyRacingKit/README.md](Assets/ThirdParty/KenneyRacingKit/README.md) | Nguồn và giấy phép của model 3D |

## Giấy phép asset

- Model 3D: **Kenney Racing Kit 2.0** — CC0 (public domain), <https://kenney.nl/assets/racing-kit>.
  Chi tiết và SHA256 của gói gốc ghi trong README cạnh asset.
- Tiếng động cơ `Assets/Generated/Audio/EngineLoop.wav`: **do chính dự án sinh ra** bằng
  `EngineClipBuilder`, không lấy từ đâu khác.
- Nhạc lễ hội và gió: **do dự án tự tổng hợp** bằng `FestivalAudioBuilder`, không dùng sample ngoài.
- Font UI/biển: **Be Vietnam Pro**, SIL Open Font License 1.1; nguồn và giấy phép trong
  `Assets/ThirdParty/BeVietnamPro/`. LiberationSans đi kèm TMP vẫn được giữ như tài nguyên gốc.

## Giới hạn còn biết

- **Đã chạy trên Xiaomi 14 (Android 16 / HyperOS 3)** ở lượt 13/09, nhưng checklist vòng đời và số đo
  15 phút chưa làm. Thử nhanh 30 s: ~60 FPS, P95 24 ms. Bảng số đo trong `GAME_DESIGN.md` mục 9 vẫn
  trống. Cách cắm máy và các bẫy của HyperOS: `PROGRESS.md`, mục "Lượt Xiaomi 14".
- **Độ trễ chạm chưa đo.**
- `CarConfig` giữ giá trị lý thuyết vì người chơi thật thấy ổn; ngưỡng huy chương vẫn là số của lái
  nút tự động, cần đo lại với thanh lái analog.
- **Ngưỡng huy chương lấy từ 12 lượt lái tự động** trên emulator, chưa phải thời gian của người
  chơi thật; nên đo lại khi có người chơi.
- Bóng đổ dùng shadow cứng (theo cấu hình chốt trong kế hoạch) nên mép bóng có răng cưa nhẹ.
- Xe văng khỏi đường sẽ xuyên qua thảm cỏ rồi mới tự reset — thảm cỏ cố ý không có collider để
  không đổi luật "rơi khỏi đường thì reset".
