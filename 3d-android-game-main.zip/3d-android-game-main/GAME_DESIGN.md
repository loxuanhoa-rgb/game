# GAME_DESIGN.md — Thiết kế demo đua xe

Cập nhật: **09/09/2026**.

Ký hiệu trạng thái dùng trong tài liệu này:

- ✅ đã cài và đã chạy thử thấy đúng
- 🔧 đã cài nhưng **giá trị chưa được tune bằng chơi thử** — vẫn là con số đặt theo lý thuyết
- ⏳ chưa làm

## 1. Phạm vi

Một xe, một đường đua, chơi offline. Countdown 3 giây → chạy 2 vòng qua 4 checkpoint đúng thứ tự → xem thời gian + huy chương → lưu kỷ lục cục bộ → chơi lại.

**Trong bản đầu:** ga, phanh/lùi, lái trái/phải, pause, reset xe, chơi lại; đường phẳng khép kín; camera bám sau; HUD + màn kết quả; âm thanh máy xe; kỷ lục lưu trên máy.

**Ngoài bản đầu:** drift/phanh tay, AI đối thủ, multiplayer, xe bóng ma, nhiều xe/đường đua, nâng cấp xe, trình sửa đường, quảng cáo, tài khoản, máy chủ, phát hành Google Play.

## 2. Xe

### 2.1 Hình học (trong `CarBuilder`) ✅

| Thông số | Giá trị |
|---|---|
| Thân xe (rộng × cao × dài) | 1,7 × 0,7 × 4,0 m |
| Chiều dài cơ sở (trục trước ↔ trục sau) | 2,6 m |
| Bề rộng vệt bánh | 1,5 m |
| Bán kính bánh / bề rộng bánh | 0,34 m / 0,22 m |
| Gốc xe | ngang tâm trục bánh; BoxCollider thân đặt tại `y = 0,45` |

Cấu trúc: một `Rigidbody` + một `BoxCollider` thân + 4 `WheelCollider`. Hình xe **không có collider riêng** — va chạm chỉ dùng BoxCollider thân. Mỗi bánh có một pivot nhận pose từ `WheelCollider.GetWorldPose`, mesh là con của pivot.

Từ Task 6, hình xe là model `raceCarRed.fbx` của Kenney Racing Kit (CC0) thay cho khối hộp prototype. Vật lý **không đổi**: collider, WheelCollider và `CarConfig` giữ nguyên. `CarBuilder` chuẩn hoá model theo hình học của chúng ta chứ không theo tỉ lệ riêng của bộ Kenney:

| Bước | Cách làm |
|---|---|
| Tỉ lệ thân | `2 × HalfWheelBase / chiều dài cơ sở của model` → chiều dài cơ sở hình khớp chiều dài cơ sở vật lý (2,6 m) |
| Gốc toạ độ | Dời model theo tâm bốn bánh của nó, vì gốc xe của ta nằm ngang tâm trục bánh |
| Hướng | Model quay đầu về −Z nên thân và bánh đều xoay 180° quanh Y |
| Bánh | Bốn node bánh của model được gắn vào bốn pivot, thu về đúng `CarConfig.WheelRadius` rồi bù lệch để tâm bánh trùng tâm pivot |

### 2.2 Thông số điều khiển (`Assets/Generated/Config/CarConfig.asset`) 🔧

Đây là giá trị mặc định trong `CarConfig.cs`. **Chưa ai chơi thử để tune.** Generator không bao giờ ghi đè asset này khi rebuild.

| Nhóm | Thông số | Giá trị |
|---|---|---|
| Thân xe | Mass | 1200 kg |
| | CenterOfMass | (0; −0,35; 0,1) |
| | LinearDamping / AngularDamping | 0,05 / 3 |
| Giảm xóc | SuspensionDistance | 0,25 m |
| | Spring / Damper / TargetPosition | 32000 / 4200 / 0,5 |
| Ma sát | Forward / Sideways stiffness | 2,2 / 2,6 |
| Động cơ | MotorTorque | 1400 Nm |
| | BrakeTorque | 2600 Nm |
| | EngineBrakeTorque (hãm khi nhả ga) | 260 Nm |
| | ReverseTorqueFactor | 0,6 |
| Tốc độ | MaxSpeedKph | 120 |
| | MaxReverseSpeedKph | 20 |
| | ReverseThresholdKph | 1 |
| Lái | MaxSteerAngle / MinSteerAngle | 32° / 12° |
| | SpeedForMinSteerKph | 90 |
| | SteerSpeedDegPerSecond | 160 |
| Ổn định | DownforcePer100Kph | 3000 N |

Ghi chú thiết kế:

- Góc lái giảm tuyến tính từ `MaxSteerAngle` xuống `MinSteerAngle` khi tốc độ tăng tới `SpeedForMinSteerKph` — để dễ giữ hướng ở tốc độ cao.
- Giới hạn tốc độ **chỉ cắt lực truyền động**, không ép vector vận tốc mỗi frame.
- `SpeedKph` là vận tốc dọc **có dấu** (chiếu vận tốc lên hướng tiến): dương = tiến, âm = lùi. HUD và âm thanh dùng trị tuyệt đối.
- Throttle > 0 khi đang lùi (`SpeedKph < −1`) thì **phanh trước**, không đảo chiều ngay. Chiều ngược lại tương tự.
- Đọc input ở `Update`, áp lực ở `FixedUpdate`. Rigidbody bật `Interpolate` + `ContinuousDynamic`.
- **Bước vật lý 1/60 giây** (`Fixed Timestep`), khớp với `targetFrameRate = 60`. Unity mặc định 0,02 s (50 Hz) — sai lệch này tồn tại âm thầm từ Task 1 tới khi nghiệm thu Task 7 mới phát hiện. `FixedTimestepSetup` đặt lại mỗi lần rebuild, `SceneValidator` kiểm lại, và có bộ test riêng.
- `ResetTo` tắt interpolation trong lúc dịch chuyển rồi bật lại, để xe không bị kéo lê từ vị trí cũ sang vị trí mới.

### 2.2b Va chạm với rào (13/09, tune trên Xiaomi 14) ✅

Rào trong/ngoài và thân xe mang `Assets/Generated/Materials/DemoSlide.asset`: `dynamicFriction = staticFriction = 0,2`, `bounciness = 0`, `frictionCombine = bounceCombine = Minimum` (hằng `TrackBuilder.BarrierFriction`). Mặc định 0,6 làm xe đâm rào góc ~15° dính lại; 0 làm xe cọ rào không mất tốc, dễ văng; 0,2 do người chơi chọn. Generator đặt lại giá trị mỗi lần rebuild, `SceneValidator` từ chối scene nếu lệch.

### 2.3 Mục tiêu cảm giác lái 🟡 (lượt Xiaomi 14 phiên 1, 13/09)

| Mục tiêu | Trạng thái |
|---|---|
| Tăng tốc 0–100 km/h ≈ 5 giây | ⏳ chưa đo |
| Dễ giữ hướng, phanh trước cua, không phải liên tục reset | 🟡 người chơi thật: ga đủ mạnh, lái nhạy, cua tốc độ cao không văng → `CarConfig` giữ nguyên; phàn nàn duy nhất (dính rào) sửa bằng vật liệu vật lý ở 2.2b |

**Camera (sai lệch #34):** `ChaseCamera` nới góc nhìn **62° → 72°** tuyến tính theo `|SpeedKph| / MaxSpeedKph`, bám 4/s (cùng cách làm mượt với hướng nhìn), `SnapToTarget` đặt thẳng góc đích. Hàm thuần `EvaluateFieldOfView` có test.

## 3. Luật đua (đã cài trong `RacingDemo.Core`, 40/40 test pass) ✅

| Nội dung | Giá trị |
|---|---|
| Countdown | 3 giây |
| Số vòng | 2 |
| Số checkpoint | 4 (order 0–3 theo chiều chạy) |
| Vạch kết thúc vòng | checkpoint index 3 |
| Khóa xe sau reset | 1,5 giây (đồng hồ đua **vẫn chạy**) |

- `RacePhase`: Idle → Countdown → Running → (Paused) → Finished. Respawn là trạng thái phụ `IsRespawning` của Running, **không** phải một phase.
- Chỉ nhận checkpoint đúng chỉ số tiếp theo, khi đang Running và không respawn. Sai thứ tự / lặp lại / đi ngược / trigger lúc khóa xe đều không tính.
- Hết vòng 1: `NextCheckpointIndex` về 0, `CurrentLap` = 2, `LastAcceptedCheckpointIndex` **vẫn là 3**.
- Hết vòng 2: chốt thời gian một lần, chuyển Finished.
- Delta cho `Tick` phải hữu hạn và không âm; 0 không đổi trạng thái. Phần delta dư khi hết countdown mới được tính vào thời gian đua.
- Pause giữ nguyên phase trước đó, countdown/respawn còn lại và vận tốc xe. Resume không tự bật lại nút đang giữ.
- Restart (từ Pause hoặc Results) xóa sạch tiến trình cũ và bắt đầu countdown mới.

## 4. Reset xe

Quy tắc trong Core ✅ | Đã nối vào prototype Task 3; reset đầu vòng hai và pause/resume đã thử trên APK emulator ✅.

- Chỉ nhận khi Running và chưa respawn; nhấn nhiều lần không gia hạn.
- Teleport về respawn pose của `LastAcceptedCheckpointIndex`; chưa qua checkpoint nào thì về start pose.
- Xóa vận tốc + input, snap camera, khóa pose, bỏ qua checkpoint trong 1,5 giây.
- Xe rơi dưới mặt đường > 5 m tự yêu cầu reset theo cùng quy tắc.

`RaceDirector` (Task 4, thay `PrototypeDirector`) gọi `RaceRules` trong FixedUpdate trước trigger, lấy pose từ `RespawnService`, xóa trạng thái cổng/input khi teleport và snap camera. Pause giữ trạng thái khóa/vận tốc; lệnh bàn phím Escape/R vẫn đọc khi khóa điều khiển xe.

## 4b. Vòng chơi và giao diện (Task 4) ✅

`RaceDirector` là **nơi duy nhất** nối Core với xe, camera, checkpoint, `timeScale`, respawn và UI. Không có thành phần thứ hai nào sở hữu input hoặc `timeScale`.

| Việc | Chạy ở đâu |
|---|---|
| `RaceRules.Tick(Time.fixedDeltaTime)` | `FixedUpdate`, **trước** trigger checkpoint của cùng bước |
| Chốt kết quả cuối lượt | Sự kiện `RaceFinished` trong bước vật lý — chỉ ghi lại, không đụng UI |
| Trình bày kết quả + thử lưu kỷ lục | `Update`, ngoài bước vật lý |
| Đăng ký sự kiện cổng/input | `Awake` một lần; `Restart` **không** đăng ký lại |

Ba presenter nằm trên object **luôn active**; panel chỉ là object con do presenter bật/tắt (presenter nằm trên chính panel thì `Show()` không bao giờ chạy lại được sau lần ẩn đầu). Director đặt trạng thái đầu trong `Start`; không presenter nào tự ẩn trong `Awake`.

| Thành phần | Nội dung |
|---|---|
| `HudPresenter` | thời gian `mm:ss.mmm`, `VONG x/2`, `CP x/4`, tốc độ, và dòng lớn giữa màn: đếm ngược hoặc `DAT LAI XE 1.5` |
| `PausePresenter` | `TAM DUNG` + `CHOI TIEP` + `CHOI LAI` |
| `ResultsPresenter` | `KET QUA`, thời gian, huy chương, kỷ lục, trạng thái lưu, `CHOI LAI` |

| Nút | Neo | Vị trí | Gọi |
|---|---|---|---|
| `CHOI TIEP` (pause) | giữa | (0; 0) | `RaceDirector.Resume` |
| `CHOI LAI` (pause) | giữa | (0; −160) | `RaceDirector.Restart` |
| `CHOI LAI` (results) | giữa | (0; −200) | `RaceDirector.Restart` |

`SceneValidator` kiểm đúng một `RaceDirector`/presenter mỗi loại, đủ mọi reference, presenter luôn active, panel là object khác presenter và đang đóng trong scene đã lưu, và mỗi nút menu có **đúng một** listener trỏ tới đúng hàm.

Chuỗi chuyển trạng thái đã kiểm trên máy: `Countdown → Running → Paused → Running → (reset, khóa 1,5 s) → Finished → Results → Restart → Countdown`.

## 5. Điều khiển cảm ứng ✅

Canvas 1920×1080, `ScaleWithScreenSize`, match 0,5; toàn bộ nằm trong `UnityEngine.UI.SafeArea`.

| Nút | Neo | Vị trí | Kích thước |
|---|---|---|---|
| **Thanh lái** `SteerSlider` (`<` … `>`) | dưới-trái | (315; 190) | 430 × 200 |
| PHANH | dưới-phải | (−430; 190) | 200 × 200 |
| GA | dưới-phải | (−200; 190) | 200 × 200 |
| UNSTUCK (object `ResetButton`) | dưới-phải | (−200; 420) | 200 × 110 |
| Pause (II) | trên-phải | (−130; −90) | 200 × 110 |

- **Thanh lái analog (13/09, theo người chơi trên Xiaomi 14):** steer = độ lệch ngang của ngón so với tâm thanh; vùng chết ±10 đơn vị, tăng tuyến tính tới **±1 ở ±115** (đúng tâm hai nút `<` `>` cũ nên nhấn chỗ quen tay vẫn hết lái), xa hơn kẹp. Núm chạy theo ngón; nhả ngón → 0. Hàm thuần `SteerSlider.Evaluate` có test.
- Nút giữ và thanh lái theo dõi đúng **một `pointerId`**; nhả ngón, tắt object hoặc mất focus đều xoá trạng thái giữ.
- GA và PHANH triệt tiêu nhau (giữ cả hai → throttle = 0).
- Nhãn chữ **không nhận raycast** và nằm trong rect của nút; các rect không chồng lấn nhau.
- Chỉ dùng **một nguồn input mỗi lúc**: điện thoại dùng pad cảm ứng, máy tính dùng bàn phím (W/S hoặc ↑/↓, A/D hoặc ←/→, Escape pause, R reset).

✅ **Ga + lái hai ngón cùng lúc đã kiểm và đạt** trên emulator Pixel 9, bơm qua thiết bị `uinput` tự dựng (`adb shell input` chỉ có một con trỏ). Giữ ga liên tục trong khi nhấp lái bằng ngón thứ hai: tốc độ vẫn lên đều, và đã lái trọn một vòng theo cách đó. Chi tiết trong `PROGRESS.md`.

## 6. Huy chương ✅ (chốt ở Task 7 từ 12 lượt thật, vật lý 60 Hz)

| Huy chương | Ngưỡng (2 vòng) | Tính từ |
|---|---|---|
| Gold | ≤ **115,618 s** | nhanh nhất 112,250 × 1,03 |
| Silver | ≤ **117,758 s** | trung vị 117,758 (lớn hơn gold + 1 s nên trung vị thắng) |
| Bronze | ≤ **134,750 s** | chậm nhất 122,500 × 1,10 |

Thời gian **bằng** ngưỡng vẫn đạt huy chương đó. Công thức của kế hoạch:
`gold = nhanh nhất × 1,03`; `silver = max(trung vị, gold + 1 s)`; `bronze = max(chậm nhất × 1,10, silver + 1 s)`.
Cài trong `RacingDemo.Core.Scoring.MedalThresholdCalibrator` (hàm thuần, có test riêng); ghi vào
`TrackDefinition` bằng `MedalCalibration.ApplyFromFile`, không sửa YAML tay.

### Số liệu 12 lượt (ngày 10/09/2026, sau khi sửa bước vật lý về 1/60 giây)

Lái **tự động** bằng `Tools/mtinject/medal-calibration.ps1` trên emulator Pixel 9 (APK Development,
IL2CPP/ARM64). **Không phải thời gian của người chơi** — đây là điểm cần đo lại khi có người chơi thật.
Cả 12 lượt đều chạy trọn 2 vòng, **không lượt nào phải reset**.

| Lượt | Thời gian (s) | | Lượt | Thời gian (s) |
|---|---|---|---|---|
| 1 | 116,766 | | 7 | 112,250 |
| 2 | 112,883 | | 8 | 116,066 |
| 3 | 116,083 | | 9 | 120,566 |
| 4 | 118,750 | | 10 | 112,283 |
| 5 | 122,133 | | 11 | 120,566 |
| 6 | 122,500 | | 12 | 119,700 |

Nhanh nhất 112,250 · trung vị 117,758 · trung bình 117,546 · chậm nhất 122,500.
Với ngưỡng trên, 12 lượt này chia ra 3 Gold, 3 Silver, 6 Bronze.
Bằng chứng: `Artifacts/task7-calibration/` (log, ảnh và vệt lái của từng lượt).

> **Bộ số cũ (Task 6, vật lý 50 Hz)** là gold 105,657 / silver 108,430 / bronze 122,826, đo từ 12 lượt
> nhanh nhất 102,580 và chậm nhất 111,660. Đổi bước vật lý từ 0,02 s về 1/60 s làm mỗi lượt chậm
> thêm khoảng 6–10 giây, nên toàn bộ ngưỡng phải tính lại. Số cũ giữ lại ở đây chỉ để đối chiếu.

## 7. Kỷ lục (Task 5 ✅ — JSON + force-kill đã kiểm trên IL2CPP Pixel 9)

- Một track lưu một thời gian tốt nhất, gắn `trackId`. Bằng hoặc chậm hơn: không ghi.
- Đổi `trackId` khi thay đáng kể chiều dài đường hoặc luật đua.
- Hoàn thành lượt **luôn** mở Results kể cả khi lưu lỗi. `Improved` = nhanh hơn kỷ lục; `Saved` = ghi thành công. Chỉ hiện "kỷ lục mới đã lưu" khi cả hai true; lỗi thì hiện "Không lưu được kỷ lục".
- Đọc file lỗi hoặc version chưa hỗ trợ → **không ghi đè**, tắt ghi trong phiên đó, vẫn cho chơi.
- Ghi file tạm cùng thư mục rồi thay file đích. Chỉ cập nhật cache sau khi ghi thành công.
- Lưu tại `Application.persistentDataPath`. Không lưu trạng thái lượt đang dở.
- `JsonRecordRepository` dùng `JsonFileStore`, file `records.json` có `version: 1` và danh sách `records` (`trackId`, `timeSeconds`, `medal`). Bản ghi sai bị bỏ; trùng trackId giữ thời gian nhỏ nhất. Huy chương của lượt hiện tại luôn tính từ thời gian và ngưỡng hiện tại, không lấy từ dữ liệu cũ.
- JSON hỏng được sao lưu nguyên bản vào `records.json.corrupt-<GUID>` trước khi cho ghi mới; sao lưu thất bại thì khóa ghi trong phiên. Ghi tạm có flush trước khi replace; lỗi ghi giữ file/cache cũ và cho thử lại ở lượt sau.
- `SessionRecordRepository` chỉ còn dùng để cô lập test scene, tránh ghi vào dữ liệu thật của Editor.

## 8. Đường đua (Task 3)

✅ Đã dựng, kiểm qua Unity tests/validator/rebuild và lái trọn một vòng trên APK Pixel 9 (RAM 6144 MB), nhận đủ checkpoint 0–3, không reset trong vòng. Đã lái trọn vòng cả bằng một điểm chạm tổng hợp lẫn bằng **hai ngón thật** (39 giây cho quãng CP0→CP3, so với 105 giây khi dùng một điểm chạm). Chưa kiểm cảm giác lái và hiệu năng — hai thứ đó chờ lượt nghiệm thu Xiaomi 14 ở cuối dự án. Bằng chứng nằm trong `PROGRESS.md`.

| Thông số | Giá trị |
|---|---|
| Hình dạng | Sân vận động phẳng, hai đoạn thẳng 80 m + hai nửa tròn R30 m |
| Rộng / chiều dài tim | 12 m / khoảng 348,496 m |
| Mesh đường | 350 đoạn, dài tối đa 1 m; 700 đỉnh dùng chung tại mối khép vòng |
| Rào trong/ngoài | Rộng 0,4 m, cao 1,2 m, đáy thấp hơn mặt đường 0,15 m |
| Collider | Một MeshCollider tĩnh cho đường, một cho mỗi rào; không ghép collider từng đoạn |
| Track ID | `stadium-80-r30-v1` |
| Chiều chạy | Ở đoạn thẳng bên X = +30, chạy theo +Z; hai cua trái |
| Mốc đích | Khoảng cách 0, vị trí (30; 0; 0), checkpoint index 3 |
| Checkpoint 0 / 1 / 2 | Cách đích theo chiều chạy khoảng 87,124 / 174,248 / 261,372 m |
| Trigger | Rộng 12 m × cao 4 m × dày 4 m |
| Start | Trước đích 8 m: (30; 0,64; −8), hướng +Z |
| Respawn | Sau từng cổng 8 m theo tim đường, đúng hướng tiếp tuyến, ngoài trigger |
| Độ cao gốc xe khi spawn | 0,34 + 0,25 + 0,05 = 0,64 m, tính cả hành trình giảm xóc |

`TrackDefinition` lưu cấu hình luật, huy chương, hình học và pose. Generator chỉ tạo khi thiếu, không ghi đè tuning. `CheckpointVolume` nhận đúng Rigidbody xe, chỉ báo một lần khi qua mặt cổng theo chiều tiến; Core quyết định phase/thứ tự. `RespawnService` trả start khi chưa có checkpoint được nhận. Các giá trị xe và ngưỡng huy chương vẫn chưa tune bằng chơi thử máy thật.

## 9. Đồ họa và hiệu năng

Đã áp: một directional light (hard shadows), skybox thủ tục mặc định của URP, `targetFrameRate = 60`, `vSyncCount = 0`, không cho màn hình tự tắt.

### 9.1 Cấu hình URP (Task 6) ✅

`Assets/Settings/Mobile_RPAsset.asset` — Android dùng mức chất lượng **Mobile** (`m_PerPlatformDefaultQuality: Android: 0`). `RenderQualitySetup` đặt các giá trị này qua `SerializedObject` mỗi lần rebuild và `SceneValidator` kiểm lại:

| Thiết lập | Giá trị | Trước Task 6 |
|---|---|---|
| HDR | off | on |
| MSAA | 2x | off |
| Render scale | 1.0 | 0.8 |
| Additional lights | Disabled | Per-vertex |
| Shadow distance | 40 m | 50 m |
| Shadow cascades | 1 | 1 |
| Soft shadows | off | off |

Không bake lighting ở bản đầu.

### 9.2 Hình ảnh và âm thanh (Task 6) ✅

- **Model:** Kenney Racing Kit 2.0 (CC0) trong `Assets/ThirdParty/KenneyRacingKit` — nguồn, SHA256 và danh sách file trong `README.md` cạnh asset.
- **Trang trí:** 68 vật (cọc tiêu, khối chắn đỏ/trắng ở hai cua, ba khán đài, hai lều, 14 cây, tám cột đèn, ba biển quảng cáo, hai cờ ca-rô ở vạch đích) do `DecorBuilder` đặt theo hình học đường đua — không dùng số ngẫu nhiên nên rebuild hai lần ra y hệt. **Không vật nào có collider**, và validator kiểm từng bao hình để chắc chắn không vật nào lấn ra mặt đường. Cố ý giữ ít; kế hoạch yêu cầu chỉ thêm trang trí sau khi có số đo hiệu năng máy thật.
- **Thảm cỏ:** một mặt phẳng 300 × 300 m ở `y = −0,02`, **không có collider** nên hành vi "rơi khỏi đường thì tự reset" của Task 4 không đổi. Xe văng khỏi đường vẫn xuyên qua thảm cỏ rồi reset như cũ.
- **Âm thanh động cơ:** `Assets/Generated/Audio/EngineLoop.wav` do `EngineClipBuilder` sinh (PCM 16-bit mono, 22050 Hz, 1,0 giây). Tần số cơ bản 50 Hz cho đúng 50 chu kỳ tròn trong một giây nên vòng lặp liền mạch. Ngày 17/09 bỏ lớp nhiễu ngẫu nhiên trộn trong clip theo phản hồi tiếng gió rè khi tăng tốc trên Xiaomi 14; giữ hòa âm, nhịp nổ và đường cong cao độ/âm lượng. Gió nền lễ hội vẫn riêng, không tăng theo tốc độ. Tự sinh để nguồn gốc và giấy phép rõ ràng tuyệt đối.
- **`EngineAudio`:** cao độ 0,65 → 2,1 và âm lượng 0,35 → 0,85 chạy tuyến tính theo `|SpeedKph| / MaxSpeedKph`, bám mượt 6 đơn vị/giây. `spatialBlend = 0` vì camera luôn dính xe. **`timeScale = 0` không dừng âm thanh**, nên `RaceDirector` gọi `SetPaused` riêng khi tạm dừng và mở lại khi chơi tiếp/chơi lại. Chỉ có đúng một `AudioListener`, nằm trên camera.

Mục tiêu 60 FPS trên Xiaomi 14. Tiêu chí sàn 30 FPS: P95 frame time ≤ 33,33 ms trong các cửa sổ gameplay và không có cửa sổ trượt 5 giây nào có FPS trung bình < 30.

### Kết quả đo (điền ở Task 7) ⏳

| Hạng mục | Kết quả | Điều kiện đo |
|---|---|---|
| FPS trung bình | ⏳ | |
| Median / P95 / P99 frame time | ⏳ | |
| Spike > 100 ms | ⏳ | |
| Độ trễ input | ⏳ chưa kiểm chứng | mục tiêu thử ≤ 100 ms |

> Emulator **không** dùng để đo hiệu năng. Mọi số ở bảng này phải lấy từ Xiaomi 14.

### 9.3 Nâng cấp hình ảnh — APEX / Golden Hour (14/09/2026)

Theo yêu cầu cải thiện đồ hoạ/vibe: phong cách lễ hội đua xe low-poly vào chiều vàng.
`FestivalVisuals` dựng toàn bộ chi tiết qua Editor API trong cây generator:

- Nắng ấm góc 28°, ambient ba màu và fog tuyến tính 95–340 m; skybox thủ tục riêng.
- Nhựa xanh than, rào xanh đậm, vạch kem; viền đỏ–kem rộng 0,65 m dùng hai mesh chia submesh.
- Cổng APEX / GOLDEN HOUR, vạch ca-rô, biển sector và 10 biển chỉ cua trái.
- 18 ngọn núi low-poly dùng chung mesh 21 đỉnh, không đổ bóng và không collider; thêm 24 cây thành tám cụm bên ngoài đường đua.
- Xe đỏ đậm, lốp cao su tối và kính xanh; mặt nhựa có texture hạt nhỏ tự sinh 128 × 128, mipmap và trilinear. Không sửa model/asset Kenney gốc.
- HUD nền xanh đậm, điểm nhấn cam, chữ kem; vùng chạm và thông số thanh lái giữ nguyên.

Giữ URP Mobile (HDR off, MSAA 2x, một directional light), hình học collider và tuning xe/huy chương.
Hiệu năng của bản hình ảnh mới trên Xiaomi 14 cần đo lại; số đo bản cũ không đại diện cho bản này.

### 9.4 Chi tiết khu vực đường đua (14/09/2026, lượt tiếp)

`VenueDetails` bổ sung cảnh vật vào `Track/Decor/VenueDetails`, qua Editor API:

- Ba garage pit mở cửa, tủ dụng cụ có ngăn, bàn làm việc, lốp dự phòng, vạch ô dịch vụ và nhân viên.
- Tháp Race Control với cabin kính, anten/cờ; podium với nền ca-rô.
- 45 khán giả low-poly chia trên ba khán đài, màu áo và tư thế khác nhau.
- 24 cụm cây bụi/đá/thảm xanh bố trí xen kẽ trong–ngoài đường; 10 cờ APEX dọc khu xuất phát.
- Gộp các chi tiết thành **42 mesh theo cụm địa phương**, mỗi mesh có các submesh dùng material chung. 15 nhãn cố định được bake thành mesh riêng; không cập nhật text lúc runtime. Cụm cây bụi/khán giả không đổ bóng.

Mọi chi tiết không có collider và phải qua kiểm tra bao hình ngoài mặt đường. Giữ nguyên mặt đường/rào, tuning xe, ánh sáng, HUD và cấu hình URP. Cần đo lại hiệu năng trên máy thật.

Nhãn bake: `VenueDetails.Label` sinh glyph bằng `TextMeshPro` trên một object tạm rồi xoá cả object và tạo `Label` mới với `MeshFilter` thường. **Không được giữ lại `MeshFilter` do TMP tạo** — nó mang cờ `HideAndDontSave` nên không lưu vào scene (lỗi tìm thấy 14/09, xem sai lệch #36). `SceneValidator.ValidateDecor` từ chối renderer không có mesh hoặc component mang cờ DontSave.

### 9.5 Ngân sách hình ảnh tĩnh (`SceneStats`, 14/09/2026)

`RacingDemo.EditorTools.SceneStats.Report` (menu *RacingDemo/Scene Stats*, CLI `-executeMethod … -statsOut <file>`) đọc `Race.unity` đã lưu và đếm từ mesh/renderer thật. Ba mốc trên cùng lệnh:

| Toàn scene | Task 6/7 (`bb5c7fb`, bản đã đo 30 s trên Xiaomi 14) | APEX (`29c2f3c`) | APEX + VenueDetails |
|---|---:|---:|---:|
| MeshRenderer | 139 | 244 | 301 |
| Tam giác | 15.160 | 18.278 | 27.236 |
| Submesh (≈ draw call trước static batching) | 194 | 311 | 464 |
| Material riêng / shader riêng | 32 / 1 | 39 / 2 | 48 / 2 |
| Renderer đổ bóng / tam giác đổ bóng | 139 / 15.160 | 212 / 18.152 | 227 / 23.948 |
| Renderer không static | 5 | 19 | 19 |

Cây `VenueDetails` riêng: 57 renderer, 8.958 tam giác, 153 submesh, 15 renderer đổ bóng. So với bản đã đo trên máy thật: tam giác ×1,8, submesh ×2,4, tam giác đổ bóng ×1,6 — mức thấp với Adreno 750 nhưng **chưa có số đo thật cho bản này**; bảng "Kết quả đo" ở 9.2 vẫn phải điền từ Xiaomi 14. Không cắt cảnh trước khi đo. Nếu không đạt 60 FPS: gộp material cây bụi/khán giả (giảm submesh) trước, rồi mới tới shadow distance.

## UI — 15/09/2026

HUD theo phong cách APEX: tên chế độ nằm trong thẻ đồng hồ, thời gian/tốc độ chữ đậm, checkpoint màu phụ. Thanh lái có đường ray và nhãn LAI; bàn đạp có vân và hướng dẫn giữ ga/phanh-lùi. Giữ kích thước/vị trí vùng chạm, khoảng lái và dead zone đã tune.

Pause dùng thẻ nền đặc, tiêu đề PIT STOP, hướng dẫn điều khiển và nút CHOI TIEP màu cam. Kết quả dùng thẻ riêng, tiêu đề HOAN THANH và nút DUA LAI màu cam. Các chi tiết trang trí không nhận raycast; panel vẫn chặn thao tác xuống điều khiển bên dưới. Toàn bộ được sinh bằng UiBuilder qua Editor API.

## APEX — Mùa Nắng (17/09/2026, thay thế mô tả UI 15/09)

Đồi Mây là thị trấn cao nguyên hư cấu. Bốn khu: Sân hội (podium/tháp), Garage Mây
(ba pit và lời An), Đồi Thông (ba cụm thông ngoài cua), Quán Dốc Nắng (quán nhỏ ngoài đường).
Logo mặt trời sau đồi được ghép bằng mesh trên podium. Cảnh mới chỉ thêm 7 renderer,
696 tam giác, 18 submesh; không thêm collider/light, không đổi tuning.

Luồng: Thiệp lễ hội → Vào đua → Countdown → Đua → Kết quả.
Pause/Kết quả có Đua lại (countdown mới) và Về lễ hội (bỏ lượt dở, không lưu).
Tại lễ hội xe khóa pose, input tắt, Core Idle không tick. HUD và vùng điều khiển
ẩn bằng CanvasGroup khi mở menu; giữ nguyên hitbox, độ nhạy và dead zone.

UI dùng Be Vietnam Pro (OFL 1.1, nguồn trong Assets/ThirdParty/BeVietnamPro),
atlas SDF tĩnh dùng chung cả biển. HUD chỉ thông tin lái: giờ/vòng/cổng/tốc độ.
Lời An chỉ có ở lễ hội/kết quả. Màu xanh mực–kem–cam đất, card đầy đủ trong 16:9/Pixel 9.

Hai clip nhạc/gió 16 giây mono 22.050 Hz do FestivalAudioBuilder tự tổng hợp.
Music volume 0,09 ở menu / 0,035 khi đua; wind 0,04 / 0,025; engine giữ thông số cũ.
Tùy chọn Nhạc/Âm thanh lưu PlayerPrefs riêng (apex.music/apex.effects).
Game pause và OS focus/background là các cổng tắt độc lập: trở lại game đang pause
không tự bật tiếng hoặc tự chạy đua. Package ID/track ID/schema records.json giữ nguyên.

Nghiệm thu chức năng và ảnh: PROGRESS.md mục APEX 17/09. Hiệu năng Xiaomi 14 cho
bản này chưa đo; mục tiêu 60 FPS, P95 ≤33,33 ms và không cửa sổ 5 giây dưới 30 FPS giữ nguyên.
