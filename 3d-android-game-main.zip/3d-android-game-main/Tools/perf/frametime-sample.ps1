# Do frame time cua game tren thiet bi that bang SurfaceFlinger TimeStats (Android 12+).
# Khong can sua code game, khong gan Profiler, dung duoc cho ca ban Release.
#
# Cach dung (tai goc repo):
#   Tools/perf/frametime-sample.ps1 -Serial 192.168.1.4:5555 -DurationSeconds 900 -OutDir Artifacts/xiaomi14/perf-release
#
# Ket qua:
#   <OutDir>/tiles.csv     - moi hang la mot o 5 giay: so khung, khung roi, FPS, pin, nhiet do, histogram
#   <OutDir>/summary.txt   - cua so 60 s quanh phut 1/5/15 (median/P95/P99, spike > 100 ms) + o nao FPS < 30
#   <OutDir>/dump-*.txt    - dump tho cua TimeStats o dau va cuoi de doi chieu
#
# Ghi chu ve so lieu: TimeStats gom present-to-present theo bucket 1 ms (duoi 34 ms), 2 ms (34-50), 4 ms (50-150),
# 50 ms (150-1000). Percentile tinh tren bucket nen sai so bang do rong bucket. Day la thoi gian giua hai lan
# man hinh hien khung cua layer game, khong phai do tre cham.

param(
    [Parameter(Mandatory = $true)] [string] $Serial,
    [int] $DurationSeconds = 900,
    [int] $TileSeconds = 5,
    [string] $OutDir = 'Artifacts/perf',
    [string] $LayerPattern = 'SurfaceView\[com\.vuit\.racingdemo/.*\]\(BLAST\)'
)

$ErrorActionPreference = 'Stop'
$adb = "$env:LOCALAPPDATA/Android/Sdk/platform-tools/adb.exe"
if (-not (Test-Path -LiteralPath $adb)) { throw "Khong thay adb tai $adb" }
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null

function Invoke-Adb([string[]] $cmd) {
    $out = & $adb -s $Serial @cmd 2>&1
    if ($LASTEXITCODE -ne 0) { throw "adb $($cmd -join ' ') that bai: $out" }
    return $out
}

# Doc khoi thong ke cua layer game tu dump TimeStats. Tra ve $null neu chua co layer.
function Read-LayerStats([string[]] $dump) {
    $start = -1
    for ($i = 0; $i -lt $dump.Count; $i++) {
        if ($dump[$i] -match '^layerName = ' -and $dump[$i] -match $LayerPattern) { $start = $i; break }
    }
    if ($start -lt 0) { return $null }
    $stats = @{ Frames = 0; Dropped = 0; AvgFps = 0.0; Hist = @{} }
    for ($i = $start + 1; $i -lt $dump.Count; $i++) {
        $line = $dump[$i]
        if ($line -match '^layerName = ') { break }
        if ($line -match '^totalFrames = (\d+)') { $stats.Frames = [int] $Matches[1]; continue }
        if ($line -match '^droppedFrames = (\d+)') { $stats.Dropped = [int] $Matches[1]; continue }
        if ($line -match '^averageFPS = ([\d.]+)') { $stats.AvgFps = [double] $Matches[1]; continue }
        if ($line -match '^present2present histogram') {
            $histLine = $dump[$i + 1]
            foreach ($pair in ($histLine -split '\s+')) {
                if ($pair -match '^(\d+)ms=(\d+)$') { $stats.Hist[[int] $Matches[1]] = [int] $Matches[2] }
            }
            continue
        }
    }
    return $stats
}

function Get-Battery {
    $b = Invoke-Adb @('shell', 'dumpsys battery')
    $level = ($b | Select-String 'level: (\d+)').Matches[0].Groups[1].Value
    $temp = ($b | Select-String 'temperature: (\d+)').Matches[0].Groups[1].Value
    $usb = ($b | Select-String 'USB powered: (\w+)').Matches[0].Groups[1].Value
    $ac = ($b | Select-String 'AC powered: (\w+)').Matches[0].Groups[1].Value
    return @{ Level = [int] $level; TempC = ([int] $temp) / 10.0; Charging = (($usb -eq 'true') -or ($ac -eq 'true')) }
}

# Hieu hai histogram tich luy -> histogram cua khoang giua hai lan dump.
function Diff-Hist($now, $prev) {
    $d = @{}
    foreach ($k in $now.Keys) {
        $p = 0
        if ($prev.ContainsKey($k)) { $p = $prev[$k] }
        $d[$k] = $now[$k] - $p
    }
    return $d
}

function Add-Hist($acc, $h) {
    foreach ($k in $h.Keys) {
        if ($acc.ContainsKey($k)) { $acc[$k] += $h[$k] } else { $acc[$k] = $h[$k] }
    }
}

function Hist-ToString($h) {
    return (($h.Keys | Sort-Object | Where-Object { $h[$_] -ne 0 } | ForEach-Object { "$($_):$($h[$_])" }) -join ';')
}

# Percentile tren histogram bucket: tra ve canh duoi cua bucket chua percentile do.
function Hist-Percentile($h, [double] $p) {
    $total = 0
    foreach ($k in $h.Keys) { $total += $h[$k] }
    if ($total -le 0) { return -1 }
    $target = [math]::Ceiling($total * $p)
    $cum = 0
    foreach ($k in ($h.Keys | Sort-Object)) {
        $cum += $h[$k]
        if ($cum -ge $target) { return $k }
    }
    return ($h.Keys | Sort-Object | Select-Object -Last 1)
}

function Hist-Count($h, [int] $minMs) {
    $n = 0
    foreach ($k in $h.Keys) { if ($k -ge $minMs) { $n += $h[$k] } }
    return $n
}

function Hist-Total($h) {
    $n = 0
    foreach ($k in $h.Keys) { $n += $h[$k] }
    return $n
}

# ---- bat dau ----
Invoke-Adb @('shell', 'dumpsys SurfaceFlinger --timestats -enable') | Out-Null
Invoke-Adb @('shell', 'dumpsys SurfaceFlinger --timestats -clear') | Out-Null
$t0 = Get-Date
$prev = $null
$tiles = @()
$tileCount = [math]::Ceiling($DurationSeconds / $TileSeconds)
$b0 = Get-Battery
Write-Host ("Bat dau {0}: pin {1}% {2:N1} C sac={3}; {4} o x {5} s" -f $t0.ToString('HH:mm:ss'), $b0.Level, $b0.TempC, $b0.Charging, $tileCount, $TileSeconds)

$firstDump = Invoke-Adb @('shell', 'dumpsys SurfaceFlinger --timestats -dump -maxlayers 64')
$firstDump | Set-Content -LiteralPath (Join-Path $OutDir 'dump-start.txt')
$prev = Read-LayerStats $firstDump
if ($null -eq $prev) { $prev = @{ Frames = 0; Dropped = 0; AvgFps = 0.0; Hist = @{} } }

for ($n = 1; $n -le $tileCount; $n++) {
    $due = $t0.AddSeconds($n * $TileSeconds)
    $wait = ($due - (Get-Date)).TotalMilliseconds
    if ($wait -gt 0) { Start-Sleep -Milliseconds ([int] $wait) }

    $dump = Invoke-Adb @('shell', 'dumpsys SurfaceFlinger --timestats -dump -maxlayers 64')
    $now = Read-LayerStats $dump
    $tNow = Get-Date
    $elapsed = [math]::Round(($tNow - $t0).TotalSeconds, 1)
    $bat = Get-Battery

    if ($null -eq $now) {
        # Layer game khong con (app dong / ve Home). Ghi hang trong.
        $tiles += [pscustomobject]@{ Tile = $n; ElapsedS = $elapsed; Frames = 0; Dropped = 0; Fps = 0.0; BatteryPct = $bat.Level; TempC = $bat.TempC; Hist = ''; Note = 'no-layer' }
        Write-Host ("[{0,4}s] khong thay layer game" -f $elapsed)
        $prev = @{ Frames = 0; Dropped = 0; AvgFps = 0.0; Hist = @{} }
        continue
    }

    $note = ''
    if ($now.Frames -lt $prev.Frames) {
        # Surface moi (app khoi dong lai) -> so tich luy reset. Coi lan nay la moc moi.
        $note = 'layer-reset'
        $prev = @{ Frames = 0; Dropped = 0; AvgFps = 0.0; Hist = @{} }
    }
    $frames = $now.Frames - $prev.Frames
    $dropped = $now.Dropped - $prev.Dropped
    $hist = Diff-Hist $now.Hist $prev.Hist
    $fps = [math]::Round($frames / $TileSeconds, 2)
    $tiles += [pscustomobject]@{ Tile = $n; ElapsedS = $elapsed; Frames = $frames; Dropped = $dropped; Fps = $fps; BatteryPct = $bat.Level; TempC = $bat.TempC; Hist = (Hist-ToString $hist); Note = $note }
    Write-Host ("[{0,4}s] {1,4} khung  {2,6:N1} FPS  roi={3}  P95={4}ms  pin {5}% {6:N1}C {7}" -f $elapsed, $frames, $fps, $dropped, (Hist-Percentile $hist 0.95), $bat.Level, $bat.TempC, $note)
    $prev = $now
}

$lastDump = Invoke-Adb @('shell', 'dumpsys SurfaceFlinger --timestats -dump -maxlayers 64')
$lastDump | Set-Content -LiteralPath (Join-Path $OutDir 'dump-end.txt')
$tiles | Export-Csv -LiteralPath (Join-Path $OutDir 'tiles.csv') -NoTypeInformation -Encoding UTF8

# ---- tong ket ----
function Parse-HistString([string] $s) {
    $h = @{}
    if ([string]::IsNullOrWhiteSpace($s)) { return $h }
    foreach ($pair in ($s -split ';')) { $kv = $pair -split ':'; $h[[int] $kv[0]] = [int] $kv[1] }
    return $h
}

function Summarize-Window([string] $name, [int] $fromS, [int] $toS) {
    $sel = $tiles | Where-Object { ($_.Tile * $TileSeconds) -gt $fromS -and ($_.Tile * $TileSeconds) -le $toS }
    $acc = @{}
    $frames = 0; $dropped = 0; $secs = 0
    foreach ($t in $sel) { Add-Hist $acc (Parse-HistString $t.Hist); $frames += $t.Frames; $dropped += $t.Dropped; $secs += $TileSeconds }
    if ($secs -eq 0) { return "$name ($fromS-$toS s): khong co du lieu" }
    $avgFps = [math]::Round($frames / $secs, 2)
    $med = Hist-Percentile $acc 0.50
    $p95 = Hist-Percentile $acc 0.95
    $p99 = Hist-Percentile $acc 0.99
    $spikes = Hist-Count $acc 100
    $over33 = Hist-Count $acc 34
    $bat = $sel | Select-Object -Last 1
    return ("{0} ({1}-{2} s): {3} khung / {4} s = {5} FPS; median {6} ms, P95 {7} ms, P99 {8} ms; khung >=34 ms: {9}; spike >=100 ms: {10}; khung roi: {11}; pin {12}% {13:N1} C" -f $name, $fromS, $toS, $frames, $secs, $avgFps, $med, $p95, $p99, $over33, $spikes, $dropped, $bat.BatteryPct, $bat.TempC)
}

$b1 = Get-Battery
$lines = @()
$lines += "Do frame time bang SurfaceFlinger TimeStats - $Serial"
$lines += ("Bat dau {0}, ket thuc {1}, {2} o x {3} s" -f $t0.ToString('yyyy-MM-dd HH:mm:ss'), (Get-Date).ToString('HH:mm:ss'), $tiles.Count, $TileSeconds)
$lines += ("Pin dau {0}% {1:N1} C sac={2}; pin cuoi {3}% {4:N1} C sac={5}" -f $b0.Level, $b0.TempC, $b0.Charging, $b1.Level, $b1.TempC, $b1.Charging)
$lines += ''
$lines += (Summarize-Window 'Phut 1 ' 30 90)
$lines += (Summarize-Window 'Phut 5 ' 270 330)
$lines += (Summarize-Window 'Phut 15' ([math]::Max(0, $DurationSeconds - 60)) $DurationSeconds)
$lines += (Summarize-Window 'Toan bo' 0 $DurationSeconds)
$lines += ''
$low = $tiles | Where-Object { $_.Note -ne 'no-layer' -and $_.Fps -lt 30 }
if ($low) {
    $lines += "O 5 s co FPS trung binh < 30:"
    foreach ($t in $low) { $lines += ("  o {0} ({1} s): {2} FPS, {3} khung, ghi chu '{4}'" -f $t.Tile, $t.ElapsedS, $t.Fps, $t.Frames, $t.Note) }
} else {
    $lines += "Khong o 5 s nao co FPS trung binh < 30 (ngoai o khong co layer, neu co)."
}
$noLayer = $tiles | Where-Object { $_.Note -eq 'no-layer' }
if ($noLayer) { $lines += ("O khong thay layer game (app khong o foreground): {0}" -f (($noLayer | ForEach-Object { $_.Tile }) -join ',')) }
$resets = $tiles | Where-Object { $_.Note -eq 'layer-reset' }
if ($resets) { $lines += ("O co surface moi (app khoi dong lai): {0}" -f (($resets | ForEach-Object { $_.Tile }) -join ',')) }
$allSpikes = $tiles | Where-Object { (Hist-Count (Parse-HistString $_.Hist) 100) -gt 0 }
if ($allSpikes) {
    $lines += "O co spike >= 100 ms:"
    foreach ($t in $allSpikes) { $lines += ("  o {0} ({1} s): {2}" -f $t.Tile, $t.ElapsedS, $t.Hist) }
} else {
    $lines += "Khong co khung nao >= 100 ms trong suot lan do."
}
$lines | Set-Content -LiteralPath (Join-Path $OutDir 'summary.txt') -Encoding UTF8
$lines | ForEach-Object { Write-Host $_ }
