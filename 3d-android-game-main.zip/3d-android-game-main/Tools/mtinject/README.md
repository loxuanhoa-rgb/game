# mtinject — bơm cảm ứng đa điểm vào emulator Android

Công cụ **kiểm thử**, không thuộc sản phẩm. Không có gì trong `Assets/` phụ thuộc vào nó, và nó không đi vào APK.

## Vì sao cần

`adb shell input` chỉ có một con trỏ, nên không kiểm được ga + lái hai ngón cùng lúc.

Thiết bị cảm ứng ảo sẵn có của emulator (`virtio_input_multi_touch_N`) bơm được hai ngón, nhưng **không dùng được**: nó khai `BTN_STYLUS` và `BTN_TOOL_RUBBER`, nên Android gắn thêm nguồn `STYLUS`, Unity đẩy sự kiện vào nhánh bút cảm ứng và ném `Unhandled pen event action: 5` / `: 6` rồi bỏ **cả hai** con trỏ.

`mtinject` tạo một màn hình cảm ứng ảo qua `/dev/uinput` khai **chỉ** `BTN_TOUCH` + `INPUT_PROP_DIRECT` + các trục MT protocol B. Android xếp nó là `Sources: TOUCHSCREEN` thuần và Unity xử lý bình thường.

## Yêu cầu

- AVD dùng ảnh **`google_apis`** (build `userdebug`) để `adb root` được — ảnh `google_apis_playstore` là build `user`, không root được và SELinux chặn `/dev/uinput`. Trong repo này là AVD `Pixel_9_root`.
- NDK kèm module Android của Unity.

## Build

```powershell
$ndk   = 'D:/UnityHub/6000.6.0f1/Editor/Data/PlaybackEngines/AndroidPlayer/NDK'
$clang = "$ndk/toolchains/llvm/prebuilt/windows-x86_64/bin/clang.exe"
& $clang --target=x86_64-linux-android26 -O2 -Wall -Wl,-z,max-page-size=16384 `
    -o Tools/mtinject/mtinject Tools/mtinject/mtinject.c
```

Hai điểm dễ sai:

- **`x86_64`**, không phải ARM. Emulator chạy x86_64 native; APK ARM64 chạy được là nhờ lớp dịch mã, còn binary shell thì không.
- **`-Wl,-z,max-page-size=16384` là bắt buộc.** Ảnh `ps16k` dùng trang 16 KB; binary căn 4 KB **segfault ngay khi nạp và không in gì cả** — kể cả `hello world`.

## Chạy

```powershell
$adb = "$env:LOCALAPPDATA/Android/Sdk/platform-tools/adb.exe"
& $adb -s emulator-5554 root
& $adb -s emulator-5554 shell setenforce 0
& $adb -s emulator-5554 push Tools/mtinject/mtinject /data/local/tmp/mtinject
& $adb -s emulator-5554 shell chmod 755 /data/local/tmp/mtinject
& $adb -s emulator-5554 shell 'setsid /data/local/tmp/mtinject /data/local/tmp/mtpipe > /data/local/tmp/mtinject.log 2>&1 < /dev/null &'
```

Kiểm tra Android đã thấy thiết bị đúng kiểu chưa — phải ra `Sources: TOUCHSCREEN`, không kèm `STYLUS`:

```powershell
& $adb -s emulator-5554 shell dumpsys input | Select-String -Pattern 'racingdemo_virtual_touch' -Context 0,10
```

## Giao thức

Đọc lệnh theo dòng từ FIFO `/data/local/tmp/mtpipe`. Toạ độ là **pixel màn hình dọc tự nhiên** (X 0–1079, Y 0–2423).

```
D <slot> <id> <x> <y> [pressure]   ha ngon hoac di chuyen ngon
U <slot>                           nhac ngon
S                                  chot khung (SYN_REPORT)
Q                                  thoat
```

`BTN_TOUCH` được suy ra từ số ngón đang chạm, không cần tự quản lý. Ghi nhiều dòng trước một `S` thì cả cụm thành một khung — hai ngón xuống cùng một `SYN_REPORT`.

## Dùng từ PowerShell

`mt-uinput.ps1` nhận **toạ độ landscape 2424×1080** (đúng như nhìn trên màn hình game) và tự đổi hệ:

```powershell
. './Tools/mtinject/mt-uinput.ps1'
Touch-Down 0 1 2200 865     # ngon 1: GA
Touch-Down 1 2 225 865      # ngon 2: lai trai, GA VAN dang giu
Touch-Up 1; Touch-Up 0
```

Nếu một lượt chạy bị ngắt giữa chừng thì ngón vẫn còn "đang chạm" — luôn mở đầu bằng `Send-Cmd @('U 0','U 1','U 2','S')`.

## Lưu ý khi lái tự động

Game chỉ có lái kiểu nút (hết lái hoặc không). Giữ nút lái liên tục ở 40 km/h làm xe cắt ngang mặt đường 12 m và ghim vào rào trong trong khoảng một giây. Phải **nhấp** lái theo độ lệch, ga giữ riêng bằng ngón kia.

## Hai script lái tự động

| Script | Việc |
|---|---|
| `race-autopilot.ps1` | Lái trọn **một** lượt đua (đủ số vòng của `TrackDefinition`) rồi dừng ở màn kết quả |
| `medal-calibration.ps1` | Gọi `race-autopilot.ps1` nhiều lượt liên tiếp, đọc thời gian về đích của từng lượt và ghi ra `lap-times.txt` để chốt ngưỡng huy chương ở Task 6 |

```powershell
# 10 luot lien tiep; luot hong se khoi dong lai app va chay tiep
& ./Tools/mtinject/medal-calibration.ps1 -Runs 10 -OutputDirectory Artifacts/task6-calibration

# Ghi nguong vao TrackDefinition (cong thuc nam trong Core, co test rieng)
& $unityExe -batchmode -quit -nographics -projectPath $root `
    -executeMethod RacingDemo.EditorTools.MedalCalibration.ApplyFromFile `
    -lapTimes Artifacts/task6-calibration/lap-times.txt -logFile Artifacts/task6-medals.log
```

Cả hai script đọc log `[TrackDrive]` / `[RaceLoop]` nên **chỉ chạy được với APK Development**; bản Release không in các dòng đó. Thời gian thu được là của **lái tự động**, không phải của người chơi — khi báo cáo phải ghi rõ.
