# Driver cho mtinject: ghi lenh vao FIFO tren may ao.
# Toa do dau vao la landscape 2424x1080 (giong toa do nut trong game),
# doi sang pixel man hinh doc tu nhien truoc khi gui.
$script:adb  = "$env:LOCALAPPDATA/Android/Sdk/platform-tools/adb.exe"
$script:dev  = 'emulator-5554'
$script:pipe = '/data/local/tmp/mtpipe'

function ConvertTo-Portrait([int]$landX, [int]$landY) {
    return @((1080 - $landY), $landX)
}

function Send-Cmd([string[]]$lines) {
    $cmd = ($lines | ForEach-Object { "echo '$_' > $script:pipe" }) -join '; '
    & $script:adb -s $script:dev shell $cmd
    if ($LASTEXITCODE -ne 0) { throw "ghi FIFO that bai (exit $LASTEXITCODE)" }
}

# Ha ngon (hoac di chuyen) roi chot khung ngay.
function Touch-Down([int]$slot, [int]$id, [int]$landX, [int]$landY) {
    $p = ConvertTo-Portrait $landX $landY
    Send-Cmd @("D $slot $id $($p[0]) $($p[1])", 'S')
}

function Touch-Up([int]$slot) { Send-Cmd @("U $slot", 'S') }

function Tap-At([int]$landX, [int]$landY, [int]$holdMs = 130) {
    Touch-Down 0 ([int](Get-Random -Minimum 1 -Maximum 30000)) $landX $landY
    Start-Sleep -Milliseconds $holdMs
    Touch-Up 0
}
