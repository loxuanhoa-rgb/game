// mtinject - tao mot man hinh cam ung ao bang /dev/uinput roi bom su kien
// multi-touch protocol B qua do.
//
// Ly do ton tai: thiet bi cam ung san co cua emulator (virtio_input_multi_touch_N)
// khai bao BTN_STYLUS va BTN_TOOL_RUBBER, nen Android gan them nguon STYLUS va
// Unity day su kien vao nhanh but - nhanh do khong xu ly ACTION_POINTER_DOWN/UP
// nen ngon thu hai bi bo. Thiet bi nay KHONG khai bat ky bit stylus nao, chi co
// BTN_TOUCH + INPUT_PROP_DIRECT, nen Android xep no la man hinh cam ung thuan.
//
// Giao thuc: doc lenh theo dong tu mot FIFO.
//   D <slot> <id> <x> <y> [pressure]   ha ngon hoac di chuyen ngon
//   U <slot>                           nhac ngon
//   S                                  chot khung (SYN_REPORT)
//   Q                                  thoat
// Toa do la pixel man hinh doc tu nhien: X trong [0,1079], Y trong [0,2423].
// Ghi nhieu dong trong MOT lan write thi ca cum se thanh mot khung -> hai ngon
// xuong cung mot SYN_REPORT, dung nhu hai ngon that.

#include <errno.h>
#include <fcntl.h>
#include <linux/uinput.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

#define MAX_SLOTS 10
#define SCREEN_W 1080
#define SCREEN_H 2424

static int ufd = -1;
static int slot_active[MAX_SLOTS];
static int active_count = 0;
static int current_slot = -1;
static int touching = 0;

static int emit(int type, int code, int value) {
    struct input_event ev;
    memset(&ev, 0, sizeof(ev));
    ev.type = (unsigned short)type;
    ev.code = (unsigned short)code;
    ev.value = value;
    if (write(ufd, &ev, sizeof(ev)) != (ssize_t)sizeof(ev)) {
        fprintf(stderr, "mtinject: khong ghi duoc su kien: %s\n", strerror(errno));
        return -1;
    }
    return 0;
}

static void select_slot(int slot) {
    if (slot != current_slot) {
        emit(EV_ABS, ABS_MT_SLOT, slot);
        current_slot = slot;
    }
}

static int setup_device(void) {
    struct uinput_user_dev dev;

    ufd = open("/dev/uinput", O_WRONLY | O_NONBLOCK);
    if (ufd < 0) {
        fprintf(stderr, "mtinject: mo /dev/uinput that bai: %s\n", strerror(errno));
        return -1;
    }

    ioctl(ufd, UI_SET_EVBIT, EV_SYN);
    ioctl(ufd, UI_SET_EVBIT, EV_ABS);
    ioctl(ufd, UI_SET_EVBIT, EV_KEY);

    // CHI BTN_TOUCH. Khong BTN_STYLUS, khong BTN_TOOL_RUBBER, khong BTN_TOOL_PEN -
    // day chinh la diem khac biet so voi thiet bi cua emulator.
    ioctl(ufd, UI_SET_KEYBIT, BTN_TOUCH);

    ioctl(ufd, UI_SET_ABSBIT, ABS_MT_SLOT);
    ioctl(ufd, UI_SET_ABSBIT, ABS_MT_TRACKING_ID);
    ioctl(ufd, UI_SET_ABSBIT, ABS_MT_POSITION_X);
    ioctl(ufd, UI_SET_ABSBIT, ABS_MT_POSITION_Y);
    ioctl(ufd, UI_SET_ABSBIT, ABS_MT_PRESSURE);
    ioctl(ufd, UI_SET_ABSBIT, ABS_MT_TOUCH_MAJOR);

    // Man hinh cam ung truc tiep, khong phai touchpad.
    ioctl(ufd, UI_SET_PROPBIT, INPUT_PROP_DIRECT);

    memset(&dev, 0, sizeof(dev));
    snprintf(dev.name, UINPUT_MAX_NAME_SIZE, "racingdemo_virtual_touch");
    dev.id.bustype = BUS_VIRTUAL;
    dev.id.vendor = 0x6f75;
    dev.id.product = 0x0001;
    dev.id.version = 1;

    dev.absmin[ABS_MT_SLOT] = 0;          dev.absmax[ABS_MT_SLOT] = MAX_SLOTS - 1;
    dev.absmin[ABS_MT_TRACKING_ID] = 0;   dev.absmax[ABS_MT_TRACKING_ID] = 65535;
    dev.absmin[ABS_MT_POSITION_X] = 0;    dev.absmax[ABS_MT_POSITION_X] = SCREEN_W - 1;
    dev.absmin[ABS_MT_POSITION_Y] = 0;    dev.absmax[ABS_MT_POSITION_Y] = SCREEN_H - 1;
    dev.absmin[ABS_MT_PRESSURE] = 0;      dev.absmax[ABS_MT_PRESSURE] = 1024;
    dev.absmin[ABS_MT_TOUCH_MAJOR] = 0;   dev.absmax[ABS_MT_TOUCH_MAJOR] = 255;

    if (write(ufd, &dev, sizeof(dev)) != (ssize_t)sizeof(dev)) {
        fprintf(stderr, "mtinject: ghi uinput_user_dev that bai: %s\n", strerror(errno));
        return -1;
    }
    if (ioctl(ufd, UI_DEV_CREATE) < 0) {
        fprintf(stderr, "mtinject: UI_DEV_CREATE that bai: %s\n", strerror(errno));
        return -1;
    }
    return 0;
}

// BTN_TOUCH duoc suy ra tu so ngon dang cham, khong de nguoi goi tu quan ly.
static void sync_frame(void) {
    if (active_count > 0 && !touching) {
        emit(EV_KEY, BTN_TOUCH, 1);
        touching = 1;
    } else if (active_count == 0 && touching) {
        emit(EV_KEY, BTN_TOUCH, 0);
        touching = 0;
    }
    emit(EV_SYN, SYN_REPORT, 0);
}

static void handle_line(const char *line) {
    int slot, id, x, y, pressure;
    char verb = line[0];

    if (verb == 'D') {
        pressure = 512;
        if (sscanf(line + 1, "%d %d %d %d %d", &slot, &id, &x, &y, &pressure) < 4) return;
        if (slot < 0 || slot >= MAX_SLOTS) return;
        select_slot(slot);
        if (!slot_active[slot]) {
            emit(EV_ABS, ABS_MT_TRACKING_ID, id);
            slot_active[slot] = 1;
            active_count++;
        }
        emit(EV_ABS, ABS_MT_POSITION_X, x);
        emit(EV_ABS, ABS_MT_POSITION_Y, y);
        emit(EV_ABS, ABS_MT_PRESSURE, pressure);
        emit(EV_ABS, ABS_MT_TOUCH_MAJOR, 12);
    } else if (verb == 'U') {
        if (sscanf(line + 1, "%d", &slot) < 1) return;
        if (slot < 0 || slot >= MAX_SLOTS || !slot_active[slot]) return;
        select_slot(slot);
        emit(EV_ABS, ABS_MT_TRACKING_ID, -1);
        slot_active[slot] = 0;
        active_count--;
    } else if (verb == 'S') {
        sync_frame();
    }
}

int main(int argc, char **argv) {
    const char *path = (argc > 1) ? argv[1] : "/data/local/tmp/mtpipe";
    int fifo;
    char buf[4096];
    ssize_t n;

    if (setup_device() < 0) return 1;

    unlink(path);
    if (mkfifo(path, 0666) < 0 && errno != EEXIST) {
        fprintf(stderr, "mtinject: mkfifo that bai: %s\n", strerror(errno));
        return 1;
    }
    // Mo O_RDWR de FIFO khong bao EOF khi ben ghi dong lai.
    fifo = open(path, O_RDWR);
    if (fifo < 0) {
        fprintf(stderr, "mtinject: mo FIFO that bai: %s\n", strerror(errno));
        return 1;
    }

    printf("mtinject: san sang, doc lenh tu %s\n", path);
    fflush(stdout);

    while ((n = read(fifo, buf, sizeof(buf) - 1)) > 0) {
        char *line, *save = NULL;
        buf[n] = '\0';
        for (line = strtok_r(buf, "\n", &save); line; line = strtok_r(NULL, "\n", &save)) {
            if (line[0] == 'Q') goto done;
            handle_line(line);
        }
    }

done:
    ioctl(ufd, UI_DEV_DESTROY);
    close(ufd);
    close(fifo);
    unlink(path);
    return 0;
}
