# Lai TRON MOT LUOT DUA (du so vong cua TrackDefinition) bang HAI NGON that qua uinput.
#
#   ngon 0 (slot 0): GIU GA lien tuc, chi nha khi vuot nguong toc do cua doan sap toi
#   ngon 1 (slot 1): NHAP nut lai theo do lech, trong khi ngon 0 van dang giu
#
# Game chi co lai kieu nut (het lai hoac khong lai). Giu het lai trong cua R30 se cat ngang
# mat duong 12 m va ghim vao rao trong khoang mot giay, nen phai nhap nhu nguoi that.
#
# Cong cu KIEM THU, khong thuoc san pham. Doc log [TrackDrive]/[RaceLoop] cua ban Development.
# Ban Release khong in cac dong nay, nen script chi chay duoc voi APK development.
param(
    [int] $MaxSamples = 1200,
    [string] $OutputDirectory = 'Artifacts/verify'
)

$ErrorActionPreference = 'Stop'
. "$PSScriptRoot/mt-uinput.ps1"

# Toa do landscape 2424x1080, khop voi layout do UiBuilder sinh ra.
$BTN_GA = @(2200, 865); $BTN_LEFT = @(225, 865); $BTN_RIGHT = @(483, 865)

# Hinh hoc san van dong: hai doan thang 80 m + hai nua duong tron ban kinh tim 30 m.
$length = 160 + 60 * [Math]::PI
$arc = 30 * [Math]::PI

function Sample-Path([double]$d) {
    $d = (($d % $length) + $length) % $length
    if ($d -lt 40) { return @(30.0, $d) }
    if ($d -lt (40 + $arc)) { $a = ($d - 40) / 30; return @((30 * [Math]::Cos($a)), (40 + 30 * [Math]::Sin($a))) }
    if ($d -lt (120 + $arc)) { return @(-30.0, (40 - ($d - 40 - $arc))) }
    if ($d -lt (120 + 2 * $arc)) { $a = [Math]::PI + ($d - 120 - $arc) / 30; return @((30 * [Math]::Cos($a)), (-40 + 30 * [Math]::Sin($a))) }
    return @(30.0, ($d - $length))
}

function Nearest-Distance([double]$x, [double]$z) {
    if ($z -gt 40) { return 40 + 30 * [Math]::Atan2($z - 40, $x) }
    if ($z -lt -40) { $a = [Math]::Atan2($z + 40, $x); if ($a -lt 0) { $a += 2 * [Math]::PI }; return 120 + 30 * [Math]::PI + 30 * ($a - [Math]::PI) }
    if ($x -ge 0) { if ($z -ge 0) { return $z } else { return $length + $z } }
    return 80 + [Math]::PI * 30 - $z
}

# Trong cua thi chay cham hon de khong truot ra rao.
function In-Curve([double]$s) {
    return (($s -ge 40 -and $s -lt (40 + $arc)) -or ($s -ge (120 + $arc) -and $s -lt (120 + 2 * $arc)))
}

if (-not (Test-Path $OutputDirectory)) { New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null }
$trace = Join-Path $OutputDirectory 'task4-race-actions.txt'
Remove-Item $trace -ErrorAction SilentlyContinue

& $script:adb -s $script:dev logcat -c
# Nhac sach moi ngon con sot lai neu lan chay truoc bi ngat giua chung.
Send-Cmd @('U 0', 'U 1', 'U 2', 'S')
Start-Sleep -Seconds 4    # cho het countdown 3 giay

$gaDown = $false; $trackId = 4000
$lastPose = ''; $samples = 0; $finished = $false; $seen = @{}; $stuck = 0; $maxLap = 1

try {
    while ($samples -lt $MaxSamples) {
        $lines = & $script:adb -s $script:dev logcat -d -t 60 -s Unity
        if ($lines | Select-String -SimpleMatch '[RaceLoop] Ve dich') {
            $finished = $true
            'VE DICH: da chay het so vong.' | Tee-Object -FilePath $trace -Append
            break
        }

        $pose = $lines | Select-String '\[TrackDrive\] Pose' | Select-Object -Last 1
        if (-not $pose -or $pose.Line -eq $lastPose) { Start-Sleep -Milliseconds 60; continue }
        $lastPose = $pose.Line
        if ($lastPose -notmatch 'x=([-.0-9]+) y=([-.0-9]+) z=([-.0-9]+) yaw=([-.0-9]+) speed=([-.0-9]+) lap=(\d+) next=(\d+)') { continue }
        $x = [double]$Matches[1]; $y = [double]$Matches[2]; $z = [double]$Matches[3]
        $yaw = [double]$Matches[4]; $speed = [double]$Matches[5]; $lap = [int]$Matches[6]; $next = [int]$Matches[7]

        if ($y -lt 0) { throw 'Xe roi xuong duoi mat duong.' }
        if ($lap -gt $maxLap) { $maxLap = $lap; "SANG VONG $lap" | Tee-Object -FilePath $trace -Append }
        $seen["$lap-$next"] = $true

        $s = Nearest-Distance $x $z
        $curve = In-Curve $s
        $hi = if ($curve) { 26.0 } else { 34.0 }
        $lo = if ($curve) { 19.0 } else { 26.0 }

        # GA: giu lien tuc, chi nha khi qua nhanh cho doan sap toi.
        if ($gaDown -and $speed -gt $hi) { Touch-Up 0; $gaDown = $false }
        elseif (-not $gaDown -and $speed -lt $lo) { Touch-Down 0 (++$trackId) $BTN_GA[0] $BTN_GA[1]; $gaDown = $true }

        # LAI: nhap mot nhip ty le voi do lech, ngon GA van o nguyen tren man hinh.
        $look = 6 + $speed * 0.22
        $target = Sample-Path ($s + $look)
        $desired = [Math]::Atan2($target[0] - $x, $target[1] - $z) * 180 / [Math]::PI
        $err = ((($desired - $yaw + 540) % 360)) - 180
        $pulse = 0; $side = 'thang'
        if ([Math]::Abs($err) -gt 3) {
            $pulse = [int][Math]::Max(70, [Math]::Min(320, [Math]::Abs($err) * 9))
            $b = if ($err -lt 0) { $side = 'TRAI'; $BTN_LEFT } else { $side = 'PHAI'; $BTN_RIGHT }
            Touch-Down 1 (++$trackId) $b[0] $b[1]
            Start-Sleep -Milliseconds $pulse
            Touch-Up 1
        }

        if ($speed -lt 1.5) { $stuck++ } else { $stuck = 0 }
        if ($stuck -ge 6) { throw "Xe ket tai s=$s x=$x z=$z (co the dang ghim vao rao)." }

        ('mau={0} s={1:F1} x={2:F2} z={3:F2} yaw={4:F1} speed={5:F1} lech={6:F1} vong={7} cong={8} ga={9} lai={10}/{11}ms' -f `
            $samples, $s, $x, $z, $yaw, $speed, $err, $lap, $next, $gaDown, $side, $pulse) | Tee-Object -FilePath $trace -Append
        $samples++
    }
}
finally {
    Touch-Up 1
    if ($gaDown) { Touch-Up 0 }
    ('Cac cap vong-cong da di qua: ' + (($seen.Keys | Sort-Object) -join ' ')) | Tee-Object -FilePath $trace -Append
    & $script:adb -s $script:dev shell screencap -p /sdcard/task4.png | Out-Null
    & $script:adb -s $script:dev pull /sdcard/task4.png (Join-Path $OutputDirectory 'task4-results.png') | Out-Null
    & $script:adb -s $script:dev logcat -d -s Unity | Set-Content (Join-Path $OutputDirectory 'task4-race.log')
}

if (-not $finished) { throw "Het $MaxSamples mau ma chua ve dich (vong cao nhat: $maxLap)." }
'DAT: chay tron luot dua bang hai ngon that.'
