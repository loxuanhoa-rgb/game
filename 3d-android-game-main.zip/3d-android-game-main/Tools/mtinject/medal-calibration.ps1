# Chay NHIEU luot dua lien tiep de lay so lieu chot nguong huy chuong (Task 6).
#
# Moi luot goi race-autopilot.ps1 (lai hai ngon that qua uinput), doc thoi gian ve dich tu
# dong log "[RaceLoop] Ve dich ... t=mm:ss.mmm" cua ban Development, roi bam CHOI LAI de sang
# luot ke tiep. Luot nao hong (ghim rao, roi khoi duong) thi ghi lai va khoi dong lai app,
# khong tinh vao so lieu.
#
# Ket qua: <OutputDirectory>/lap-times.txt — moi dong mot so giay, dua thang vao
# RacingDemo.EditorTools.MedalCalibration de ghi nguong vao TrackDefinition.
#
# LUU Y: day la so lieu cua LAI TU DONG, khong phai cua nguoi choi. Ghi ro dieu do khi bao cao.
param(
    [int] $Runs = 10,
    [string] $OutputDirectory = 'Artifacts/task6-calibration',
    [string] $Package = 'com.vuit.racingdemo'
)

$ErrorActionPreference = 'Stop'
. "$PSScriptRoot/mt-uinput.ps1"

# Nut CHOI LAI cua man ket qua: anchor giua man hinh, lech xuong 200 don vi UI.
# Canvas 1920x1080 scale len man 2424x1080 (he so 1,1236) => (1212, 540 + 225).
$BTN_RESULTS_RESTART = @(1212, 765)

if (-not (Test-Path $OutputDirectory)) { New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null }
$summaryPath = Join-Path $OutputDirectory 'summary.txt'
$timesPath = Join-Path $OutputDirectory 'lap-times.txt'
Remove-Item $summaryPath, $timesPath -ErrorAction SilentlyContinue

function Restart-App {
    & $script:adb -s $script:dev shell am force-stop $Package | Out-Null
    Start-Sleep -Seconds 2
    & $script:adb -s $script:dev shell am start -n "$Package/com.unity3d.player.UnityPlayerGameActivity" | Out-Null
    Start-Sleep -Seconds 8
}

function Read-FinishSeconds([string] $logPath) {
    if (-not (Test-Path $logPath)) { return $null }
    $line = Select-String -Path $logPath -Pattern '\[RaceLoop\] Ve dich.*t=(\d+):(\d+)\.(\d+)' |
        Select-Object -Last 1
    if (-not $line) { return $null }
    $m = [regex]::Match($line.Line, 't=(\d+):(\d+)\.(\d+)')
    return [double]$m.Groups[1].Value * 60 + [double]$m.Groups[2].Value + [double]$m.Groups[3].Value / 1000
}

function Count-Respawns([string] $logPath) {
    if (-not (Test-Path $logPath)) { return 0 }
    return (Select-String -Path $logPath -SimpleMatch '[RaceLoop] Dat lai xe' | Measure-Object).Count
}

$results = @()
for ($run = 1; $run -le $Runs; $run++) {
    $runDirectory = Join-Path $OutputDirectory ('run{0:d2}' -f $run)
    if (-not (Test-Path $runDirectory)) { New-Item -ItemType Directory -Path $runDirectory -Force | Out-Null }
    $logPath = Join-Path $runDirectory 'task4-race.log'
    Write-Output "=== Luot $run/$Runs ==="

    $failure = $null
    try {
        & "$PSScriptRoot/race-autopilot.ps1" -OutputDirectory $runDirectory | Out-Null
    }
    catch {
        $failure = $_.Exception.Message
    }

    $seconds = Read-FinishSeconds $logPath
    $respawns = Count-Respawns $logPath
    if ($null -ne $seconds -and $null -eq $failure) {
        $results += [pscustomobject]@{ Run = $run; Seconds = $seconds; Respawns = $respawns; Note = 'dat' }
        ('{0:F3}' -f $seconds) | Add-Content -Path $timesPath
        $line = 'Luot {0}: {1:F3} s, reset {2} lan' -f $run, $seconds, $respawns
    }
    else {
        $results += [pscustomobject]@{ Run = $run; Seconds = $null; Respawns = $respawns; Note = "hong: $failure" }
        $line = 'Luot {0}: HONG ({1})' -f $run, $failure
    }

    Write-Output $line
    $line | Add-Content -Path $summaryPath

    if ($run -eq $Runs) { break }

    # Sang luot moi: neu vua ve dich thi bam CHOI LAI, con hong thi khoi dong lai app.
    if ($null -ne $seconds -and $null -eq $failure) {
        Send-Cmd @('U 0', 'U 1', 'U 2', 'S')
        Start-Sleep -Milliseconds 400
        Tap-At $BTN_RESULTS_RESTART[0] $BTN_RESULTS_RESTART[1]
        Start-Sleep -Seconds 2
        $started = & $script:adb -s $script:dev logcat -d -t 40 -s Unity |
            Select-String -SimpleMatch '[RaceLoop] Bat dau luot moi'
        if (-not $started) {
            Write-Output '  CHOI LAI khong an; khoi dong lai app.'
            Restart-App
        }
    }
    else {
        Restart-App
    }
}

$valid = @($results | Where-Object { $null -ne $_.Seconds })
$summary = 'Tong: {0} luot chay, {1} luot ve dich hop le.' -f $Runs, $valid.Count
Write-Output $summary
$summary | Add-Content -Path $summaryPath
if ($valid.Count -gt 0) {
    $stats = $valid | Measure-Object -Property Seconds -Minimum -Maximum -Average
    $detail = 'Nhanh nhat {0:F3} s, cham nhat {1:F3} s, trung binh {2:F3} s.' -f `
        $stats.Minimum, $stats.Maximum, $stats.Average
    Write-Output $detail
    $detail | Add-Content -Path $summaryPath
}
