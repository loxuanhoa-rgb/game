# Kế hoạch triển khai demo đua xe Android 3D

**Bản sửa ngày 07/09/2026.** Tài liệu dành cho người mới Unity, muốn có demo arcade dễ lái và chơi thử thường xuyên trên Xiaomi 14. Đây là kế hoạch công việc; các ô chưa đánh dấu không có nghĩa là chức năng đã được triển khai hoặc kiểm chứng.

## 1. Mục tiêu và giới hạn

Giao một APK chơi offline: một xe, một đường đua, đếm ngược 3 giây, đi qua checkpoint đúng thứ tự, hoàn thành 2 vòng, xem thời gian/huy chương và lưu kỷ lục trên máy.

Ưu tiên xe dễ điều khiển và vòng chơi hoàn chỉnh. Mốc 2–3 tuần, mỗi buổi 2–3 giờ là mục tiêu linh hoạt; đánh giá lại sau buổi đầu có xe điều khiển bằng cảm ứng trên điện thoại. Không dùng số lượng code hoặc số test xanh để thay cho việc chơi thử.

| Có trong bản đầu | Để ngoài bản đầu |
|---|---|
| Ga, phanh/lùi, lái trái/phải, pause, reset xe, chơi lại | Drift/phanh tay, AI đối thủ, multiplayer, xe bóng ma |
| Đường phẳng khép kín, camera bám sau, HUD và kết quả | Nhiều xe/đường đua, nâng cấp xe, trình sửa đường tổng quát |
| Hình ảnh đơn giản, âm thanh máy xe, kỷ lục cục bộ | Quảng cáo, tài khoản, máy chủ, phát hành Google Play |

Chỉ cam kết nghiệm thu hiệu năng trên Xiaomi 14 đã thử. Nếu chậm tiến độ, giảm trang trí, hiệu ứng và thời gian tinh chỉnh hình ảnh trước; giữ vòng chơi và các thao tác cần thiết.

## 2. Nền tảng và quy ước

- Unity **6000.3.11f1**, C#, URP; ghi phiên bản vào `ProjectSettings/ProjectVersion.txt` và `AGENTS.md`. Không nâng Editor trong bản demo này.
- Android Build Support cùng OpenJDK, Android SDK & NDK Tools do Unity Hub cài cho đúng Editor; không mặc định dùng SDK của Android Studio.
- IL2CPP, ARM64 only, Minimum API 26; build APK cài trực tiếp. Đặt package ID cố định `com.vuit.racingdemo`, Landscape Left, đồ họa OpenGLES3 cho cấu hình demo đầu tiên.
- Input System, uGUI/TextMeshPro và Unity Test Framework. Cài package trước khi tạo assembly tham chiếu tới nó. Chọn phiên bản tương thích Editor; sau build đầu thành công, ghi phiên bản thực vào `AGENTS.md`, commit `Packages/manifest.json` và `Packages/packages-lock.json`. Không để yêu cầu phiên bản dạng “1.14+”.
- Vật lý dùng **Rigidbody + 4 WheelCollider**, bước vật lý ban đầu 1/60 giây. Cấu hình này vẫn phải kiểm chứng trên thiết bị.
- Asset Serialization = Force Text, Version Control = Visible Meta Files; commit mọi `.meta`. Thay scene/prefab/ScriptableObject qua API Editor hoặc Inspector, không sửa YAML bằng tay.
- Tạo dự án ngay trong thư mục hiện tại `D:/Android/3d-android-game`; không tạo thêm thư mục Unity lồng bên trong. Nếu Hub yêu cầu thư mục trống, tạo dự án tạm rồi chuyển các thư mục dự án vào đây, giữ nguyên tài liệu này.
- Git theo dõi source, asset, Packages, ProjectSettings và tài liệu. Git LFS dùng cho binary như FBX, PNG, WAV, OGG. Bỏ qua Library, Temp, Obj, Logs, UserSettings, Builds, Artifacts và file IDE sinh tự động.
- Mỗi mốc hoàn thành có commit build được. Không yêu cầu commit code đang lỗi để minh họa test thất bại.
- Đóng Unity Editor trước khi dùng Unity CLI trên cùng dự án. Không chạy hai tiến trình Unity cùng mở một project.
- Agent hỗ trợ viết code, công cụ dựng scene, chạy kiểm tra và đọc log. Người dùng thực hiện thao tác Editor/điện thoại khi cần và dành 15–30 phút chơi thử mỗi buổi.

### Thông số ban đầu và tiêu chí sử dụng

| Nội dung | Quy định |
|---|---|
| Tốc độ tối đa dự kiến | 120 km/h, được điều chỉnh sau prototype nếu khó lái |
| Tăng tốc dự kiến | 0–100 km/h khoảng 5 giây, là giá trị để tune, chưa phải điều kiện nghiệm thu cứng |
| Cảm giác lái | Dễ giữ hướng, phanh trước cua, hoàn thành đường đua mà không phải liên tục reset |
| Countdown / số vòng | 3 giây / 2 vòng |
| Reset | Teleport về điểm đã qua, khóa xe 1,5 giây; thời gian đua vẫn chạy |
| Phản hồi điều khiển | Ghi độ trễ bằng ms nếu đo được; mục tiêu thử ban đầu ≤100 ms trên Xiaomi 14, đồng thời đánh giá bằng chơi thử |
| Hiệu năng | Mục tiêu 60 FPS; tiêu chí ổn định 30 FPS được định nghĩa bằng frame time ở mục 8 |

Không dùng phép quy đổi cố định “2 frame = 33 ms”. Không chốt chỉ tiêu bán kính cua trước khi có prototype. Đo tăng tốc từ lúc xe đứng yên đến ngưỡng tốc độ; nếu đã hạ tốc độ tối đa dưới 100 km/h thì ghi lại bài thử phù hợp.

## 3. Kiến trúc và interface

### Ranh giới assembly

| Assembly | Trách nhiệm | Phụ thuộc |
|---|---|---|
| `RacingDemo.Core` | Timer, trạng thái đua, checkpoint/vòng, quy tắc reset, huy chương, kiểm tra và cập nhật kỷ lục | C#/.NET thuần; `noEngineReferences: true` |
| `RacingDemo.Runtime` | MonoBehaviour, xe, input, camera, UI, âm thanh, ScriptableObject, JSON, filesystem | Core, Input System, uGUI, TMP |
| `RacingDemo.Editor` | Tạo dữ liệu/prefab/scene, kiểm tra asset và scene, build | Core, Runtime và thư viện được dùng trực tiếp; Editor only |
| EditMode tests | Quy tắc Core; test Editor/persistence khi cần | Assembly được kiểm thử và Test Framework; Editor only |
| PlayMode tests | Tích hợp scene, UI, xe, pause/reset | Core, Runtime, Test Framework và thư viện dùng trực tiếp |

Core không sử dụng `UnityEngine`, `UnityEditor`, `System.IO`, `JsonUtility`, `ScriptableObject` hoặc đồng hồ hệ thống. Mọi cập nhật thời gian đi qua `Tick(float deltaSeconds)`. Runtime chuyển cấu hình Unity thành giá trị C# khi tạo Core.

Thêm tham chiếu trực tiếp ở từng assembly sử dụng thư viện, không trông chờ references truyền qua Runtime. Kiểm tra tên assembly thực trong package đã khóa: uGUI thường là `UnityEngine.UI`, TMP là `Unity.TextMeshPro`, Input System là `Unity.InputSystem`. Editor cũng cần các references này khi tạo UI/input bằng code. Tạo test assembly qua Test Framework rồi kiểm tra cấu hình NUnit và khả năng phát hiện test trong cả Editor lẫn CLI.

### Cấu trúc dự kiến

~~~
D:/Android/3d-android-game/
├── 2026-09-06-android-racing-demo.md
├── AGENTS.md
├── GAME_DESIGN.md
├── PROGRESS.md
├── .gitignore
├── .gitattributes
├── Packages/
├── ProjectSettings/
├── Assets/
│   ├── Scripts/
│   │   ├── Core/
│   │   │   ├── Racing/          RaceRules, RaceTimer, CheckpointTracker, RaceConfig, RacePhase
│   │   │   ├── Scoring/         Medal, MedalThresholds, MedalEvaluator
│   │   │   └── Persistence/     RecordData, RecordStore, IRecordRepository, RecordSubmissionResult
│   │   ├── Runtime/
│   │   │   ├── Bootstrap/
│   │   │   ├── Vehicle/         CarController, CarConfig
│   │   │   ├── Input/           CarInputRelay, TouchControlPad, HoldButton
│   │   │   ├── CameraRig/       ChaseCamera
│   │   │   ├── Track/           TrackDefinition, CheckpointVolume, RespawnService
│   │   │   ├── Race/            RaceDirector
│   │   │   ├── UI/              HudPresenter, PausePresenter, ResultsPresenter, SafeArea
│   │   │   ├── Persistence/     JsonRecordRepository, JsonFileStore, JSON DTO
│   │   │   └── Audio/           EngineAudio
│   │   └── Editor/             DemoProjectGenerator, SceneValidator, BuildCommand
│   ├── Tests/
│   │   ├── EditMode/
│   │   └── PlayMode/
│   ├── Generated/              Asset, prefab, material do công cụ quản lý
│   ├── Scenes/                 Race.unity
│   ├── Art/                    Hình ảnh/trang trí do người dùng chỉnh
│   └── ThirdParty/             Asset bên ngoài và thông tin nguồn
├── Artifacts/                  Log, kết quả test, số đo; không commit
└── Builds/Android/             APK; không commit
~~~

Mỗi nhóm Scripts và mỗi nhóm test có asmdef tương ứng. Cây này là cấu trúc dự kiến, không phải danh sách file đã có.

### Các hợp đồng chính

| Thành phần | Interface/hành vi cần giữ |
|---|---|
| `CarController` | `SetInput(float throttle, float steer)`; cả hai trong [-1, 1]. `SetControlEnabled(bool enabled)`, `ResetTo(Vector3 position, Quaternion rotation)`, `SetPoseLocked(bool locked)`, `SpeedKph`, `Config` |
| `CarInputRelay` | Tổng hợp bàn phím/cảm ứng, gọi SetInput; sự kiện Pause/Reset; `SetInputEnabled(bool)` và xóa trạng thái giữ nút |
| `ChaseCamera` | Theo target trong LateUpdate; `SnapToTarget()` đặt đúng vị trí và hướng ngay |
| `RaceRules` | `BeginCountdown()`, `Tick(float deltaSeconds)`, `TryPassCheckpoint(int index)`, `TryRequestRespawn()`, `Pause()`, `Resume()`, `Restart()` |
| `RaceRules` đọc trạng thái | `Phase`, `ElapsedSeconds`, `CountdownRemaining`, `CurrentLap`, `NextCheckpointIndex`, `int? LastAcceptedCheckpointIndex`, `RespawnRemaining`, `IsRespawning`; sự kiện đổi phase/kết thúc đua |
| `RespawnService` | `GetRespawnPose(int? lastAcceptedCheckpointIndex, out Vector3 position, out Quaternion rotation)`; null trả start pose |
| `RecordStore` | `Submit(trackId, timeSeconds, medal)` trả `RecordSubmissionResult`: Improved, Saved, BestPersisted, Error |
| `IRecordRepository` | Đọc/ghi danh sách RecordData bằng TryLoad/TrySave, trả trạng thái thành công và lỗi; không chứa kiểu Unity |
| `DemoProjectGenerator` | `RebuildDemo()`, gọi từ menu `RacingDemo/Rebuild Demo` hoặc CLI |
| `SceneValidator` | `ValidateBuildScenes()` kiểm tra các scene đã lưu được chọn làm đầu vào build |
| `BuildCommand` | `BuildAndroidDevelopment()` và `BuildAndroidRelease()`, cùng dùng validator |

`SetControlEnabled(false)` xóa input nhưng không tự xóa vận tốc. `SetPoseLocked(true)` dùng để giữ xe tại chỗ trong countdown/reset: xóa vận tốc, giữ Rigidbody kinematic; mở khóa khi được phép chạy. Pause dùng timeScale, giữ nguyên vận tốc và tình trạng khóa trước pause.

`SpeedKph` là vận tốc dọc có dấu: chiếu vận tốc Rigidbody lên hướng tiến của xe rồi đổi sang km/h; dương là tiến, âm là lùi. HUD/âm thanh dùng trị tuyệt đối khi cần giá trị không âm. `ResetTo` đưa SpeedKph về 0 cùng vận tốc và xóa trạng thái làm mượt pose cũ.

`TrackDefinition` và `CarConfig` là ScriptableObject trong Runtime. TrackDefinition chứa trackId, số vòng/countdown/reset, ngưỡng huy chương, start pose, các checkpoint có order và respawn pose riêng, cùng thông số hình học đường cố định. Core chỉ nhận số checkpoint và cấu hình luật đua, không nhận Transform hoặc Vector3.

## 4. Hành vi vòng chơi đã chốt

### Trạng thái, thời gian và checkpoint

- `RacePhase`: Idle, Countdown, Running, Paused, Finished. Reset là trạng thái phụ `IsRespawning` của Running, không phải một phase làm dừng đồng hồ đua.
- Bắt đầu lượt: đặt xe tại start, xóa vận tốc/input, khóa pose, đếm 3 giây; hết đếm mới mở khóa và tính thời gian đua.
- Tick nhận số hữu hạn, không âm; 0 không thay đổi trạng thái. Delta không hợp lệ bị từ chối bằng exception tham số. Khi Tick đi qua mốc hết countdown, chỉ phần thời gian dư được tính vào cuộc đua.
- Có 4 checkpoint, order 0–3 theo chiều chạy. Checkpoint 3 đồng thời là vạch kết thúc vòng; start pose ở trước vạch này, checkpoint cần qua đầu tiên vẫn là 0.
- Chỉ nhận checkpoint đúng chỉ số tiếp theo khi Running và không respawn. Đi qua sai thứ tự, lặp lại, đi ngược hướng qua cổng hoặc trigger khi khóa xe không tăng tiến trình.
- CheckpointVolume xác minh đúng Rigidbody của xe người chơi và hướng qua cổng; Core xác minh phase/thứ tự. Không nhận nhiều lần do xe có nhiều collider.
- Qua checkpoint 3 sau 0, 1, 2 thì hoàn thành vòng. Sau vòng 1, next checkpoint trở về 0 và CurrentLap = 2; LastAcceptedCheckpointIndex vẫn là 3. Sau vòng 2, chốt thời gian một lần và chuyển Finished.
- Runtime chuyển tín hiệu checkpoint sang Core trong bước mô phỏng. Cập nhật Core bằng delta của cùng bước trước khi xử lý các trigger bước đó; chấp nhận độ phân giải thời gian bằng một bước vật lý, không tuyên bố độ chính xác cao hơn.
- Đồng hồ giao diện đọc từ Core; format thời gian là hàm thuần, không tự giữ một đồng hồ thứ hai.

### Reset xe và pause

- Chỉ nhận Reset khi Running và chưa respawn. Nhấn nhiều lần không gia hạn hoặc tạo thêm reset. Countdown, Paused và Finished không nhận Reset.
- Khi được chấp nhận: lấy LastAcceptedCheckpointIndex, teleport đến respawn pose tương ứng, xóa vận tốc/input, snap camera, khóa pose và bỏ qua checkpoint trong 1,5 giây.
- Race timer tiếp tục tăng trong 1,5 giây đó. Hết thời gian mới mở khóa; việc teleport không tự công nhận checkpoint.
- Trước checkpoint đầu tiên dùng start pose. Qua vòng mới vẫn giữ checkpoint cuối vòng trước. Respawn pose nằm trên mặt đường, hướng đúng và ở ngoài trigger, cách cổng đủ để toàn bộ xe không chồng lấn.
- Xe rơi dưới mặt đường hơn 5 m tự yêu cầu Reset theo cùng quy tắc. Xe lật/kẹt nhưng chưa rơi dùng nút Reset; chưa thêm hệ thống phát hiện kẹt tự động.
- Pause từ Countdown/Running giữ phase trước đó, countdown/respawn còn lại và vận tốc xe. Director đặt timeScale = 0, xóa trạng thái nút đang giữ và mở menu; UI vẫn dùng được.
- Resume phục hồi phase và các giá trị còn lại; chỉ mở điều khiển nếu Running và không respawn. Người chơi phải nhấn lại nút lái/ga sau resume.
- Mất focus hoặc ứng dụng vào nền đều yêu cầu pause theo thao tác idempotent; quay lại không tự resume.
- Restart từ Pause hoặc Results hủy tiến trình reset cũ, xóa trạng thái lượt/input, khôi phục timeScale = 1 và bắt đầu countdown mới. Respawn dùng bộ đếm trong Core, không dùng coroutine độc lập có thể mở khóa xe của lượt cũ.
- Khi kết thúc, khóa input, hiện kết quả và cho chơi lại. Các thao tác scene teardown khôi phục timeScale và hủy đăng ký sự kiện để không ảnh hưởng lượt/test sau.

### Lưu kỷ lục và kết quả

- Hoàn thành lượt luôn chốt thời gian/huy chương và mở Results, kể cả storage lỗi. Lỗi lưu không được bỏ qua việc mở Results hoặc vô hiệu hóa Restart; xử lý cả lỗi trả về lẫn exception.
- Bản đầu đọc/ghi đồng bộ file JSON nhỏ. Director chuyển kết quả từ sự kiện Core sang Update để trình bày và thử lưu, không ghi file trong bước vật lý. Đo thời gian I/O khi profiling; không hứa thao tác đĩa hoàn toàn không chặn luồng chính.
- Một track lưu thời gian tốt nhất; thời gian bằng hoặc chậm hơn không ghi lại. Kỷ lục gắn trackId; khi thay đáng kể chiều dài đường hoặc luật đua, đổi trackId để không so sánh thành tích khác điều kiện.
- Runtime đọc/ghi JSON có version, DTO và chuyển đổi sang RecordData. RecordData hợp lệ phải có trackId không rỗng, thời gian hữu hạn >0 và medal trong enum.
- Bản ghi sai bị bỏ; bản ghi trùng trackId giữ thời gian hợp lệ nhỏ nhất. Medal hiển thị của track hiện tại được tính lại từ thời gian và ngưỡng hiện tại.
- File không tồn tại là trạng thái chưa có kỷ lục. JSON không phân tích được được sao lưu trước khi khởi tạo rỗng; nếu sao lưu thất bại thì ngừng ghi trong phiên đó và vẫn cho chơi.
- Lỗi I/O khi đọc hoặc version mới chưa hỗ trợ: không ghi đè file; tiếp tục chơi và thông báo không lưu được trong phiên. Lần mở app sau thử đọc lại.
- Ghi file tạm cùng thư mục rồi thay file đích; kiểm chứng đường ghi lần đầu và cập nhật trên Android IL2CPP. Không xóa bản cũ trước khi bản mới hoàn tất.
- Chỉ cập nhật cache BestPersisted sau khi ghi thành công. Nếu ghi lỗi, giữ kỷ lục đã lưu trước đó; lần đạt thành tích tốt tiếp theo vẫn có thể thử ghi lại.
- Improved mô tả lượt nhanh hơn kỷ lục đã lưu; Saved chỉ true khi ghi thành công. Chỉ hiện “kỷ lục mới đã lưu” khi cả hai true; nếu lỗi, hiện thời gian/huy chương và dòng “Không lưu được kỷ lục”.
- Dùng persistentDataPath; không lưu trạng thái lượt đua đang dở. Mở lại sau force-kill bắt đầu lượt mới nhưng giữ kỷ lục đã lưu.

## 5. Các task triển khai và điều kiện đạt

Mỗi task ghi rõ phần đã kiểm thử tự động và phần đã chơi thử. Nếu điều kiện đạt chưa đủ, ghi vào PROGRESS thay vì đánh dấu hoàn tất.

### Task 1 — Thiết lập dự án và APK đầu tiên

**Đầu ra:** Unity mở được, scene khởi động chạy trên Xiaomi 14, có lệnh build/test dùng lại.

- [ ] Cài Editor/module Android bằng Hub; bật Developer options và USB debugging trên Xiaomi, kết nối USB và chấp nhận khóa RSA.
- [ ] Tạo dự án URP vào workspace theo mục 2, áp dụng cấu hình Android, kiểm tra adb nhận đúng thiết bị ở trạng thái device.
- [ ] Cài package cần thiết trước khi thêm references. Tạo Core/Runtime/Editor asmdef và EditMode test assembly; xác nhận Core không có engine references.
- [ ] Tạo gitignore, gitattributes, khởi tạo Git/Git LFS nếu chưa có; không thao tác remote hoặc upload ở bước này.
- [ ] Tạo AGENTS.md: phiên bản, đường dẫn Unity/adb, lệnh PowerShell, quy tắc assembly và asset. GAME_DESIGN.md ghi phạm vi/thông số; PROGRESS.md ghi đã xong, lỗi, bước tiếp theo.
- [ ] Tạo AppBootstrap: targetFrameRate = 60, vSyncCount = 0, không tự sleep khi chơi.
- [ ] Tạo phiên bản đầu của DemoProjectGenerator.RebuildDemo: tạo thư mục, material URP cơ bản và Race.unity với đúng một camera, AudioListener, ánh sáng và nền thử. Chưa tham chiếu lớp gameplay chưa được viết.
- [ ] Tạo SceneValidator kiểm tra tối thiểu scene/path của giai đoạn hiện tại. BuildCommand kiểm tra cấu hình Android và scene đã lưu trước khi build; thiếu điều kiện thì dừng với lỗi rõ ràng.
- [ ] Build Development APK, cài và mở trên Xiaomi. Khóa manifest/package lock sau build thành công; ghi phiên bản đã giải quyết vào AGENTS.
- [ ] Chạy một test Core nhỏ qua Test Runner và CLI để xác nhận test thực sự được phát hiện. Test này kiểm tra quy tắc thực như format thời gian, không kiểm tra hằng số vô nghĩa.

**Điều kiện đạt:** APK mở ngang trên điện thoại, không exception lúc khởi động; CLI trả mã thoát đúng và tạo log/test XML. Chưa yêu cầu xe ở task này.

### Task 2 — Xe, camera và điều khiển trên điện thoại

**Đầu ra:** Prototype lái được trên mặt phẳng trước khi hoàn thiện luật đua.

- [ ] Tạo CarConfig và CarController với một Rigidbody, collider thân xe đơn giản, bốn WheelCollider đúng vị trí/bán kính. Bánh trước lái, bánh sau nhận motorTorque, cả bốn bánh phanh.
- [ ] Thông số trong CarConfig: khối lượng/trọng tâm, wheel radius, motor/brake torque, giới hạn tốc độ tiến/lùi, góc và tốc độ chuyển lái, giảm góc lái theo tốc độ, spring/damper/travel và friction.
- [ ] Throttle >0 đi tới; <0 phanh khi xe đang tiến, chuyển lùi khi gần đứng yên (|SpeedKph| ≤1). Chiều ngược lại áp dụng tương tự. Giới hạn lùi ban đầu 20 km/h; giới hạn tốc độ chỉ cắt lực truyền động, không ép vector vận tốc mỗi frame.
- [ ] Đọc input ở Update, áp lực trong FixedUpdate. Bật Rigidbody interpolation; kiểm tra tiếp xúc/va chạm thay vì mặc định 60 Hz sẽ giải quyết mọi lỗi vật lý.
- [ ] WheelCollider.GetWorldPose cập nhật pivot bánh; mesh con giữ góc dựng và scale ban đầu để không mất hướng trục bánh.
- [ ] Tạo camera bám sau và FOV đơn giản. SnapToTarget tính vị trí mới trước, hướng nhìn từ chính vị trí mới, xóa giá trị làm mượt cũ; reset không quét camera xuyên đường.
- [ ] Bàn phím: W/S hoặc lên/xuống cho throttle, A/D hoặc trái/phải cho steer, Escape pause, R reset. Không dùng Legacy Input.
- [ ] Cảm ứng: nút trái, phải, ga, phanh/lùi, reset, pause; hai nút đối nghịch triệt tiêu nhau. Thiết bị touch dùng pad, desktop dùng bàn phím để tránh cộng input hai nguồn.
- [ ] Mỗi HoldButton theo dõi pointer đang giữ; pointer up/cancel/disable và mất focus xóa trạng thái. Resume chỉ nhận lần nhấn mới.
- [ ] UI dùng InputSystemUIInputModule và một EventSystem. Text không nhận raycast, nhãn nằm trong nút, rect các nút không chồng lấn; canvas dùng safe area và scale theo màn hình.
- [ ] Nâng RebuildDemo để tạo xe/config/input/camera và UI prototype. Trước khi có RaceDirector, dùng bộ điều phối prototype nhỏ cho pause/reset; loại bỏ nó khi ghép Task 4, không để hai nơi cùng sở hữu input/timeScale.
- [ ] Build và chơi trên Xiaomi: tiến, phanh, lùi, cua, ga+lái hai ngón, reset và pause. Ghi nhận cảm giác lái trước khi thêm trang trí.

**Điều kiện đạt:** Xe đứng ổn định, không xuyên nền, đi đúng chiều, các nút nhận đúng thao tác, camera reset đúng. Người dùng chạy và cua vài phút mà không cần liên tục sửa Inspector. Đây là mốc đánh giá lại lịch; nếu chưa đạt, ưu tiên sửa prototype.

### Task 3 — Đường đua cố định và công cụ dựng đầy đủ

**Đầu ra:** Một đường phẳng khép kín có thể lái trọn vòng.

- [ ] Nâng RebuildDemo để tạo đường dạng sân vận động: hai đoạn thẳng dài 80 m nối hai nửa đường tròn bán kính tim đường 30 m, mặt đường rộng 12 m. Không dốc/nhảy trong bản đầu.
- [ ] Tạo dải mesh mặt đường liên tục, khép kín cùng static collider; phân đoạn cong đủ mịn để không tạo bậc cản bánh. Biên trong/ngoài có rào đơn giản để xe không chạy xuyên giữa sân.
- [ ] Dữ liệu hình học mặc định được generator tạo lần đầu trong TrackDefinition. Các thông số này chỉ dành cho đường cố định trên; không xây hệ thống miếng đường hoặc trình sửa đường tổng quát.
- [ ] Tạo bốn cổng checkpoint cách nhau xấp xỉ một phần tư chiều dài đường; cổng cuối là vạch kết thúc vòng. Trigger phủ đủ rộng/cao cho xe và đủ dày so với quãng đường xe đi mỗi bước vật lý.
- [ ] Tạo start pose trước vạch kết thúc; mỗi checkpoint có respawn pose riêng sau cổng theo chiều chạy. Tính độ cao theo hình học xe/mặt đường, bảo đảm thân và bánh không nằm trong nền hoặc rào.
- [ ] Validator kiểm tra mối nối vòng kín bằng hình học sinh ra, chiều chạy, chỉ số 0–3 liên tục/duy nhất, checkpoint nằm trên đường, vạch kết thúc ở index cuối và pose an toàn.
- [ ] Generator chỉ quản lý Assets/Generated, Race.unity và cây __GeneratedScene. Giữ object chỉnh tay bên ngoài cây đó, giữ reference/GUID asset khi cập nhật, không ghi đè CarConfig/TrackDefinition đã tune mỗi lần rebuild.
- [ ] Rebuild tạo các asset/config còn thiếu, kiểm tra phụ thuộc trước khi thay nội dung scene; không gọi phương thức trên asset null.
- [ ] Nếu scene đang mở có thay đổi chưa lưu, yêu cầu lưu/hủy thao tác qua UI Unity; CLI dừng báo lỗi. Không âm thầm mở scene khác làm mất thay đổi.
- [ ] Chạy RebuildDemo hai lần. Không thêm camera, EventSystem, collider hoặc listener trùng; scene/template URP cũ không để lại camera/đèn mặc định dư.
- [ ] Từ dự án đã có source/package nhưng chưa có Generated/Race.unity, một lệnh RebuildDemo phải tạo đủ demo của giai đoạn hiện tại.

**Điều kiện đạt:** Lái được trọn vòng bằng cảm ứng; đường không hở/đứt mặt collider; rebuild lặp lại giữ cấu hình đã tune và nội dung người dùng ngoài vùng quản lý.

### Task 4 — Ghép vòng chơi, pause, reset và kết quả

**Đầu ra:** Countdown → đua 2 vòng → kết quả → chơi lại.

- [ ] Viết RaceTimer, CheckpointTracker, RaceRules và MedalEvaluator theo mục 3–4. Viết EditMode test cùng từng chức năng, không dành cả tuần chỉ làm Core.
- [ ] Dùng ngưỡng ban đầu Gold 85 s / Silver 100 s / Bronze 120 s cho 2 vòng; ghi rõ tạm thời. Thời gian bằng ngưỡng vẫn đạt huy chương đó.
- [ ] Tạo RaceDirector là nơi duy nhất nối Core với xe, camera, checkpoint, timeScale, respawn và UI. Thay bộ điều phối prototype của Task 2.
- [ ] Cài luồng pause/resume/reset/restart đúng bảng hành vi; xóa input khi khóa điều khiển và khi ứng dụng mất focus.
- [ ] Đặt presenter trên object luôn active; panel chỉ là object được presenter điều khiển. Director đặt trạng thái ban đầu; Awake không tự Hide khi panel mở lần đầu.
- [ ] HUD hiển thị thời gian, vòng, checkpoint kế tiếp, countdown/khóa reset và nút pause/reset. Pause có Resume/Restart; Results có thời gian, huy chương, kỷ lục và Restart.
- [ ] Nối mọi button bằng generator, kiểm tra cả Inspector reference lẫn thao tác thực tế. Đăng ký/hủy sự kiện theo vòng đời, không thêm listener lặp sau restart.
- [ ] Nâng validator yêu cầu đủ reference, đúng một Director/xe/camera/EventSystem và đủ checkpoint. Từ đây mọi build dùng đầy đủ kiểm tra vòng chơi.
- [ ] Chơi trọn lượt trên Xiaomi ngay khi ghép xong, trước khi làm art.

**Điều kiện đạt:** Đủ vòng chơi trên thiết bị; menu mở đúng ngay lần đầu; skip checkpoint không hoàn thành lượt; reset đầu vòng hai giữ đúng điểm hồi xe; pause/countdown/respawn/restart khớp mục 4.

### Task 5 — Kỷ lục và khả năng tiếp tục chơi khi lưu lỗi

**Đầu ra:** Kỷ lục còn sau mở lại app; lỗi lưu không làm hỏng kết quả.

- [ ] Viết RecordStore và IRecordRepository trong Core; dùng repository giả để test nhanh.
- [ ] Viết JSON DTO, JsonRecordRepository và JsonFileStore trong Runtime theo chính sách mục 4.
- [ ] Tách việc hiển thị kết quả khỏi việc ghi file. BestPersisted có thể chưa có; UI hiện “Chưa có kỷ lục”, không hiện 0 như một thành tích hợp lệ.
- [ ] Test ghi lần đầu, phá kỷ lục, bằng/chậm hơn, nhiều trackId, reload, JSON hỏng, version chưa hỗ trợ, record sai/trùng, lỗi đọc và lỗi ghi.
- [ ] Kiểm tra ghi lần đầu/cập nhật bằng bản IL2CPP trên Xiaomi; force-kill sau khi UI xác nhận đã lưu rồi mở lại.
- [ ] Dùng Clear app storage để kiểm tra trạng thái sạch; không mặc định uninstall luôn loại bỏ dữ liệu vì cơ chế backup/restore có thể tác động.

**Điều kiện đạt:** Kết quả vẫn thao tác được khi repository giả ném lỗi hoặc trả thất bại; cache không báo lưu sai; dữ liệu đã lưu tồn tại sau force-kill.

### Task 6 — Hình ảnh và âm thanh tối thiểu

**Đầu ra:** Demo dễ nhìn, có âm thanh, giữ nguyên khả năng chơi.

- [ ] Import Kenney Racing Kit vào ThirdParty, lưu nguồn và giấy phép kèm asset. Gắn hình xe/trang trí lên prototype đã chơi được; giữ collider đường ổn định.
- [ ] Visual thay qua prefab tham chiếu trong cấu hình/generator hoặc đặt ngoài __GeneratedScene; không chỉnh trực tiếp phần sẽ bị rebuild xóa.
- [ ] Tạo EngineAudio, gán clip loop có nguồn/giấy phép rõ ràng và gọi Play sau khi có clip. Pitch thay đổi theo tốc độ; pause tạm dừng âm thanh, resume khôi phục, tránh listener trùng.
- [ ] Cấu hình URP ban đầu: HDR off, MSAA 2x, soft shadows off, shadow distance 40 m, 1 cascade, additional lights off, render scale 1.0; một directional light.
- [ ] Không bắt buộc bake lighting cho bản đầu. Thêm trang trí sau khi có số đo hiệu năng.
- [ ] Chạy ít nhất 10 lượt hoàn chỉnh để chỉnh huy chương. Từ thời gian hợp lệ, đặt gold = nhanh nhất ×1,03; silver = max(trung vị, gold +1 giây); bronze = max(chậm nhất ×1,10, silver +1 giây). Ghi số liệu thật và ngưỡng cuối.
- [ ] Chỉnh CarConfig theo phản hồi, cho phép sửa controller nếu lỗi nằm trong mô hình hoặc tích hợp. Kiểm tra lại ca bị ảnh hưởng sau sửa.

**Điều kiện đạt:** UI dễ đọc, audio thực sự phát, hình bánh/camera đúng, trang trí không chặn đường và việc thay visual không phá vòng chơi.

### Task 7 — Nghiệm thu và bàn giao

**Đầu ra:** Source tái tạo được demo, APK cuối, hướng dẫn mở/build và kết quả kiểm chứng.

- [ ] Chạy bộ kiểm tra mục 8; sửa lỗi liên quan, không chạy lặp toàn bộ vô hạn khi không có thay đổi mới.
- [ ] Chạy Development APK để phân tích hiệu năng; tắt Deep Profile khi lấy số liệu nền.
- [ ] Build Release APK với Development/Script Debugging/Autoconnect Profiler tắt; đo lại trên Xiaomi theo cùng kịch bản.
- [ ] Xác minh từ checkout sạch: restore LFS/package, mở đúng Unity, RebuildDemo, test, build và cài APK. Không phụ thuộc asset trong Library của máy cũ.
- [ ] Cập nhật AGENTS, GAME_DESIGN và PROGRESS; ghi cả lỗi/giới hạn còn biết, máy/OS, commit và cấu hình đo.
- [ ] Bàn giao source Git, Builds/Android/racing-demo.apk và hướng dẫn PowerShell. Tạo tag demo-v1 sau khi đạt nghiệm thu; không tự push lên remote.

**Điều kiện đạt:** Người dùng làm theo hướng dẫn để mở/build lại được; mọi tuyên bố hiệu năng có số đo và bản APK tương ứng.

## 6. Lệnh PowerShell dùng khi triển khai

Các lệnh dưới đây là giao diện sẽ được tạo ở các task trên. Hiện tại không giả định project hoặc tool đã được cài. Chạy tại thư mục gốc; thay đường dẫn Editor bằng nơi cài thực tế nếu khác.

### Chuẩn bị đường dẫn và thiết bị

~~~powershell
Set-Location -LiteralPath 'D:/Android/3d-android-game'
$unityExe = 'C:/Program Files/Unity/Hub/Editor/6000.3.11f1/Editor/Unity.exe'
$unityEditorDir = Split-Path -Parent $unityExe
$adbExe = Join-Path $unityEditorDir 'Data/PlaybackEngines/AndroidPlayer/SDK/platform-tools/adb.exe'
$projectRoot = (Get-Location).Path

if (-not (Test-Path -LiteralPath $unityExe)) { throw 'Chưa tìm thấy Unity Editor đúng phiên bản.' }
if (-not (Test-Path -LiteralPath $adbExe)) { throw 'Chưa tìm thấy adb; kiểm tra module Android của Unity.' }
New-Item -ItemType Directory -Path './Artifacts' -Force | Out-Null
& $adbExe devices
~~~

Nếu thiết bị báo unauthorized, mở khóa điện thoại và chấp nhận USB debugging. Nếu có nhiều thiết bị, thêm `-s SERIAL` ngay sau `$adbExe` cho các lệnh thiết bị. Không đưa serial thật hoặc đường dẫn riêng của máy vào code runtime.

### Dựng demo, chạy test và build

Dùng Start-Process -Wait để đợi Unity.exe hoàn tất trên Windows; log/result đi vào Artifacts. Đóng Editor trước khi chạy.

~~~powershell
function Invoke-DemoUnity {
    param([Parameter(Mandatory = $true)][string[]] $ExtraArgs)

    $unityArgs = @('-batchmode', '-projectPath', ('"{0}"' -f $projectRoot)) + $ExtraArgs
    $unityProcess = Start-Process -FilePath $unityExe -ArgumentList $unityArgs -Wait -PassThru -WindowStyle Hidden
    if ($unityProcess.ExitCode -ne 0) {
        throw "Unity thất bại với exit code $($unityProcess.ExitCode). Đọc log tương ứng trong Artifacts."
    }
}

Invoke-DemoUnity -ExtraArgs @(
    '-quit',
    '-executeMethod', 'RacingDemo.EditorTools.DemoProjectGenerator.RebuildDemo',
    '-logFile', 'Artifacts/generate.log'
)

Invoke-DemoUnity -ExtraArgs @(
    '-buildTarget', 'StandaloneWindows64',
    '-nographics', '-runTests', '-testPlatform', 'EditMode',
    '-testResults', 'Artifacts/editmode-results.xml',
    '-logFile', 'Artifacts/editmode.log'
)

Invoke-DemoUnity -ExtraArgs @(
    '-buildTarget', 'StandaloneWindows64',
    '-runTests', '-testPlatform', 'PlayMode',
    '-testResults', 'Artifacts/playmode-results.xml',
    '-logFile', 'Artifacts/playmode.log'
)

Invoke-DemoUnity -ExtraArgs @(
    '-quit', '-buildTarget', 'Android',
    '-executeMethod', 'RacingDemo.EditorTools.BuildCommand.BuildAndroidDevelopment',
    '-logFile', 'Artifacts/build-development.log'
)
~~~

Không thêm -quit vào lệnh runTests; để test runner kết thúc theo cơ chế của nó. Đọc XML để xác nhận đúng test được phát hiện và không có test failed; exit code thành công với 0 test chưa đủ. Không khóa sẵn tổng số test vào tài liệu.

Hai lệnh test chọn target StandaloneWindows64 để chạy trong Editor; cần cài Windows Build Support (Mono) qua Hub nếu bộ cài chưa có target này. Lệnh build chọn lại Android. Việc chuyển target có thể làm import lại asset; gom các lần test cùng target để giảm chờ. Kiểm thử trên APK là bước riêng.

Build Release để bàn giao:

~~~powershell
Invoke-DemoUnity -ExtraArgs @(
    '-quit', '-buildTarget', 'Android',
    '-executeMethod', 'RacingDemo.EditorTools.BuildCommand.BuildAndroidRelease',
    '-logFile', 'Artifacts/build-release.log'
)
~~~

BuildCommand dùng cùng danh sách scene đã lưu cho validator và BuildPlayerOptions, không lấy active scene làm đại diện. Bootstrap ban đầu chỉ kiểm tra thành phần đang có; nâng yêu cầu theo từng task, không chặn Task 1 vì chưa có RaceDirector.

Development xuất `Builds/Android/racing-demo-development.apk`; Release xuất `Builds/Android/racing-demo.apk`. Release ở đây là bản tắt công cụ debug để cài trực tiếp; không yêu cầu keystore phát hành Google Play. Giữ cùng package ID và khóa ký thử nghiệm trong quá trình cập nhật tại máy này.

### Cài APK và lấy log

~~~powershell
& $adbExe install -r './Builds/Android/racing-demo-development.apk'
if ($LASTEXITCODE -ne 0) { throw 'Cài APK thất bại.' }

& $adbExe logcat -c
& $adbExe logcat -v time 'Unity:V' 'AndroidRuntime:E' '*:S' |
    Tee-Object -FilePath './Artifacts/device.log'
~~~

Sau khi logcat bắt đầu chạy, mở app bằng biểu tượng trên điện thoại và tái hiện lỗi; dừng ghi bằng Ctrl+C. Không xóa log trước khi lưu lỗi đang cần phân tích.

Cài bản bàn giao:

~~~powershell
& $adbExe install -r './Builds/Android/racing-demo.apk'
if ($LASTEXITCODE -ne 0) { throw 'Cài APK bàn giao thất bại.' }
~~~

Đọc lỗi đầu tiên có ý nghĩa trong log build/test và lưu đoạn liên quan; không suy đoán thời gian build cố định. IL2CPP lần đầu có thể lâu hơn các lần sau.

## 7. Lịch buổi tối và cách làm việc

| Buổi dự kiến | Công việc | Mốc kiểm chứng |
|---|---|---|
| 1–2 | Task 1 | APK khởi động được trên Xiaomi 14 |
| 3–5 | Task 2, bắt đầu Task 3 nếu còn thời gian | Xe + camera + cảm ứng chạy được |
| 6–10 | Hoàn thành Task 3, Task 4–5 | Một lượt đua đầy đủ và kỷ lục lưu được |
| 11–13 | Task 6, đo hiệu năng sớm của Task 7 | Hình ảnh/âm thanh và số đo bản gần hoàn chỉnh |
| 14–18 | Dự phòng sửa lỗi, nghiệm thu và bàn giao Task 7 | APK cuối và hướng dẫn tái tạo |

Phần dự phòng chiếm khoảng 20–30% lịch tối đa. Không tự chuyển lỗi điều khiển chưa giải quyết sang giai đoạn trang trí để giữ lịch.

Mỗi buổi:

1. Đọc PROGRESS, chọn việc nhỏ nhất giúp đạt mốc kế tiếp.
2. Viết/sửa chức năng cùng test liên quan; compile trước khi mở rộng.
3. Chơi thử tình huống cụ thể trong Editor và trên điện thoại ở mốc cần thiết.
4. Ghi phản hồi theo “đang làm gì → mong muốn → thực tế”, kèm log khi có lỗi.
5. Cập nhật PROGRESS ngắn gọn và commit mốc đã chạy được.

Mỗi task nêu rõ thao tác người dùng cần làm trong Unity/điện thoại; không yêu cầu người mới tự suy ra bước gán asset, tạo scene hoặc sửa YAML.

## 8. Kiểm thử và nghiệm thu

### EditMode — quy tắc và lỗi có thể tái hiện ổn định

- [ ] Countdown 3 giây; phần delta dư chuyển sang Running đúng; delta 0/âm/NaN/vô hạn theo contract.
- [ ] Timer chỉ tăng khi Running, gồm thời gian respawn; không tăng khi Paused/Finished.
- [ ] Checkpoint đúng thứ tự, bỏ qua cổng, cổng lặp/sai index, đủ 2 vòng mới kết thúc; sự kiện kết thúc phát một lần.
- [ ] LastAcceptedCheckpointIndex còn là 3 ngay đầu vòng 2, không bị suy ra từ next index 0.
- [ ] Reset trước checkpoint đầu dùng start; reset lặp bị bỏ; không nhận reset khi countdown/pause/results.
- [ ] Pause khi respawn còn 0,4 giây, Tick khi pause không thay đổi; resume còn 0,4 giây.
- [ ] Restart trong respawn/countdown/pause xóa trạng thái lượt cũ và bắt đầu countdown mới.
- [ ] Ngưỡng huy chương, giá trị sát biên và định dạng thời gian.
- [ ] Kỷ lục bằng/chậm/nhanh hơn; lỗi repository; cache giữ giá trị đã lưu khi ghi thất bại; lượt tiếp theo có thể thử lại.
- [ ] JSON thiếu/hỏng/sai version, dữ liệu không hợp lệ hoặc trùng ID; chính sách không ghi đè khi đọc không an toàn.
- [ ] Validator phát hiện đường hở, checkpoint trùng/thiếu/sai vị trí, spawn trong trigger/ngoài đường và scene thiếu references.

### PlayMode — tích hợp scene và vật lý

- [ ] Scene khởi động không exception; countdown giữ xe tại chỗ rồi cho chạy.
- [ ] Pause và Results mở được ngay lần đầu từ scene mới; Resume/Restart hoạt động.
- [ ] Nút Pause/Reset tồn tại, được nối đúng; nhãn chữ không chắn input.
- [ ] Xe đứng vững, tiến/phanh/lùi đúng, đi qua mối nối đường và reset không xuyên nền; hình bánh giữ đúng trục.
- [ ] Reset xa hoặc đổi hướng 180° đặt camera đúng ngay, không nội suy từ pose cũ.
- [ ] Restart nhiều lần không thêm listener, xe, EventSystem hoặc AudioListener.
- [ ] Kết quả vẫn mở và chơi lại được khi giả lập lỗi lưu.
- [ ] Cleanup scene/test khôi phục timeScale và input.

Test vật lý dùng điều kiện khoảng hợp lý và timeout có giới hạn, không yêu cầu quỹ đạo/tốc độ chính xác theo từng frame. Luật đua vẫn kiểm tra bằng Core; PlayMode bổ sung kiểm tra tích hợp và không thay cho máy thật.

### Xiaomi 14 — vòng chơi và vòng đời ứng dụng

- [ ] Hoàn thành 10 lượt liên tiếp không crash/exception làm hỏng vòng chơi.
- [ ] Bấm đúng tâm mỗi nút; ga+lái đồng thời bằng hai ngón; nhả/rê ngón ra ngoài không kẹt ga/phanh.
- [ ] Pause giữa countdown, giữa đua và giữa reset; resume đúng vị trí/thời gian còn lại.
- [ ] Khóa màn hình, về Home, mở ứng dụng khác rồi quay lại: game vẫn pause, âm thanh dừng, phải nhấn Resume và nhấn ga lại.
- [ ] Reset đầu vòng hai về checkpoint cuối vòng một, không tự tăng thêm vòng.
- [ ] Bỏ checkpoint hoặc đi ngược qua cổng không được tính đúng lượt.
- [ ] Restart từ pause/results trong nhiều lượt hoạt động; reset liên tục không kéo dài khóa.
- [ ] Force-kill sau xác nhận lưu rồi mở lại còn kỷ lục; Clear app storage mở lại chơi được từ trạng thái mới.
- [ ] Layout nằm trong safe area; chữ rõ, không che nút; audio phát và pause đúng.

### Hiệu năng và bằng chứng

- Mục tiêu 60 FPS; báo FPS trung bình cùng median/P95/P99 frame time, tránh chỉ chụp số FPS tức thời.
- Chơi liên tục ít nhất 15 phút, chạy/restart các lượt theo cùng kịch bản. Lấy cửa sổ 60 giây quanh phút 1, 5 và phút 15; loại thời gian loading và pause chủ động, ghi rõ phần loại.
- Tiêu chí sàn 30 FPS: P95 frame time ≤1000/30 ms (xấp xỉ 33,33 ms) ở các cửa sổ gameplay; không có cửa sổ trượt 5 giây trong gameplay có FPS trung bình <30. Ghi riêng spike >100 ms và nguyên nhân; không che spike bằng số trung bình.
- Ghi thiết bị/Android, APK và commit, build flags, graphics API, render scale/độ phân giải, refresh rate, fixed timestep, pin, trạng thái cắm sạc và điều kiện máy trước lượt đo.
- Dùng Development Build/Profiler để tìm CPU/GPU/GC hoặc allocation tăng dần. Không kết luận máy nóng chỉ từ FPS giảm.
- Đo lại Release APK, không gắn Profiler; dùng bộ ghi frame time nhẹ đã kiểm tra hoặc công cụ đo trên thiết bị. Ghi rõ nếu số đo là thời gian frame của ứng dụng, không suy ra trực tiếp độ trễ chạm đến màn hình.
- Khi không đạt, xử lý theo bằng chứng: shadow distance, số object/vật liệu, allocation, rồi render scale 0,85 nếu cần. Đo lại đúng ca thất bại sau thay đổi.
- Độ trễ input nếu đo bằng quay chậm phải ghi cách đo và sai số; nếu chưa đo được thì đánh dấu chưa kiểm chứng, không ghi “đạt 33 ms”.

## 9. Rủi ro và quyết định khi gặp vấn đề

| Rủi ro/dấu hiệu | Xử lý |
|---|---|
| Buổi 2 chưa có APK mở được | Dừng thêm gameplay; sửa chuỗi Editor/module/license/build/adb trước |
| Sau buổi 5 xe khó lái | Giữ đường phẳng, hạ tốc độ, chỉnh góc lái/phanh/trọng tâm; sửa controller nếu cần và cập nhật lịch |
| WheelCollider kẹt ở đường nối | Kiểm tra collider, scale, độ mịn mặt đường, vị trí bánh; không chỉ tăng timestep hoặc đổi khối lượng |
| Nút cảm ứng nhận sai/kẹt | Kiểm tra rect/raycast/pointer lifecycle và thử hai ngón; chưa thêm kiểu điều khiển mới trước khi sửa lỗi hiện tại |
| Rebuild mất cấu hình/người dùng sửa | Giới hạn vùng sinh, giữ asset đã tune, bảo vệ scene chưa lưu, test rebuild hai lần |
| Build/test CLI kiểm tra nhầm scene hoặc 0 test | Dùng danh sách scene build tường minh, đọc XML/log, kiểm tra references và platform |
| Kỷ lục lỗi làm gián đoạn | Giữ Results độc lập, bảo toàn bản đã lưu, ghi lỗi và vẫn cho Restart |
| FPS giảm theo thời gian | Phân tích CPU/GPU/GC/bộ nhớ và điều kiện nhiệt; chỉ tối ưu sau khi xác định nguyên nhân |
| Chưa đạt toàn bộ sau 3 tuần | Giảm art/âm thanh phụ, dùng buổi dự phòng; báo điều kiện chưa đạt thay vì tự xác nhận hoàn tất |

## 10. Tài liệu bàn giao và nguồn tham khảo

AGENTS.md giữ hướng dẫn ngắn, lệnh chạy được trên Windows, đường dẫn tool thực tế và package version đã xác nhận. GAME_DESIGN.md chứa thông số sau tune, quy tắc chơi, kết quả đo và điều kiện đo. PROGRESS.md phản ánh đúng phần đã xong/lỗi còn lại/việc tiếp theo; không tự đánh dấu test hoặc hiệu năng chưa chạy.

Trước khi bàn giao, đối chiếu lại interface, cây thư mục, menu/executeMethod, lệnh PowerShell, build scene, checklist và tên APK. Không giữ khối mã mẫu mâu thuẫn với kiến trúc mới.

Nguồn chính thức để tra cứu khi triển khai:

- [Unity 6000.3.11f1 và ghi chú phiên bản](https://unity.com/releases/editor/whats-new/6000.3.11f1).
- [Dựng xe bằng WheelCollider](https://docs.unity3d.com/6000.3/Documentation/Manual/WheelColliderTutorial.html).
- [Tham chiếu giữa các assembly](https://docs.unity3d.com/6000.3/Documentation/Manual/assembly-definitions-referencing.html).
- [Vòng đời Awake và object inactive](https://docs.unity3d.com/6000.3/Documentation/ScriptReference/MonoBehaviour.Awake.html).

Kế hoạch không phụ thuộc một skill hay phương thức chạy agent riêng. Thực hiện theo các mốc có đầu ra kiểm chứng được ở trên.
